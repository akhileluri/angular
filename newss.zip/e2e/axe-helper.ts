// ============================================================================
// Class to run axe ARIA accessibility suite from protractor script. Methods
// adopted from protractor plugin.js. The idea is to be able to run individual
// suites after manipulating the UI from protractor.
//
// This runner wraps and mimics the AxeBuilder chainable API
//
// AXE API: https://axe-core.org/docs/#api-name-axeconfigure
// Protractor API: https://www.protractortest.org/#/api
// Jasmine API: https://jasmine.github.io/api/2.6/global
//
// To debug protractory scripts from VS code see:
// https://blogs.msdn.microsoft.com/wushuai/2016/08/24/debug-protractor-script-in-visual-studio-code/
// ============================================================================
import { browser } from 'protractor';
import * as axe from 'axe-core';
import { Logger } from '../node_modules/protractor/built/Logger';
import { ComponentFactoryResolver } from '@angular/core';

const AxeBuilder = require('../node_modules/axe-webdriverjs');
const logger = new Logger('axe');

export interface Assertion { passed: boolean; errorMsg?: string; stackTrace?: any; }

export class AxeRunner {
    axe_builder: any;
    assertions = {};
    resultsReported = false;
    ranTests = false;

    constructor() {
        this.axe_builder = AxeBuilder(browser.driver);
    }

    static build() {
        return new AxeRunner();
    }

    /**
     * Selector to include in analysis
     * @param  {String} selector CSS selector of the element to include
     * @return {AxeRunner}
     */
    include(selector: string): AxeRunner {
        this.axe_builder.include(selector);
        return this;
    }

    /**
     * Selector to exclude in analysis
     * @param  {String} selector CSS selector of the element to exclude
     * @return {AxeRunner}
     */
    exclude(selector: string): AxeRunner {
        this.axe_builder.exclude(selector);
        return this;
    }

    /**
     * Options to directly pass to `axe.a11yCheck`.  See API documentation for axe-core for use.
     * Will override any other configured options, including calls to `withRules` and `withTags`.
     * @param  {Object} options Options object
     * @return {AxeRunner}
     */
    options(options: axe.RunOptions): AxeRunner {
        this.axe_builder.options(options);
        return this;
    }

    /**
     * Limit analysis to only the specified rules.  Cannot be used with `withTags`.
     * @param {Array|String} rules Array of rule IDs, or a single rule ID as a string
     * @return {AxeRunner}
     */
    withRules(rules: Array<any> | string): AxeRunner {
        this.axe_builder.withRules(rules);
        return this;
    }

    /**
     * Limit analysis to only the specified tags.  Cannot be used with `withRules`.
     * @param {Array|String} rules Array of tags, or a single tag as a string
     * @return {AxeRunner}
     */
    withTags(tags): AxeRunner {
        this.axe_builder.withTags(tags);
        return this;
    }

    /**
     * Perform analysis and process results. *Does not chain.*
     * This calls AxeBuiler.analyze and calls processAxeResults() in the
     * analyze callback. Call getResults() from jasmine script to print
     * the test  results
     */
    run(): Promise<axe.AxeResults> {
        const runner = this;
        this.ranTests = true;

        return new Promise<axe.AxeResults>((resolve, reject) => {
            this.axe_builder
                .analyze(function (results) {
                    try {
                        runner.processAxeResults(results);
                        resolve(results);
                    } catch (e) {
                        reject(e);
                    }
                });
        });
    }

    /**
     * Reset the runner to setup another run
     */
    reset() {
        this.assertions = {};
        this.resultsReported = false;
        this.ranTests = false;
        this.axe_builder = AxeBuilder(browser.driver);
    }

    // ========================================================================
    // The following methods were lifted from protractor plugins.js
    // ========================================================================
    /**
     * Called by AxeBuilder.analyze callback to process the test results
     * @param results
     */
    private processAxeResults(results) {
        const testHeader = 'aXe - ';
        const numResults = results.violations.length;
        const self = this;

        // if (numResults === 0) {
        //     return this.addSuccess();
        // }

        results.passes.forEach(function (result) {
            self.addSuccess({ specName: testHeader + result.help });
        });

        return results.violations.forEach(function (result) {
            const label = result.nodes.length === 1 ? ' element ' : ' elements ';
            let _msg = result.nodes.reduce(function (msg, node) {
                return msg + '\t\t' + node.html + '\n';
            }, '\n');

            _msg = '\n\t\t' + result.nodes.length + label + 'failed:' + _msg + '\n\n\t\t' + result.helpUrl;
            self.addFailure(_msg, { specName: testHeader + result.help });
        });
    }

    /**
     * Print out the results of the last run
     */
    getResults() {
        if (this.ranTests) {
            const results = { failedCount: 0, specResults: [] };
            for (const specName in this.assertions) {
                if (this.assertions.hasOwnProperty(specName)) {
                    results.specResults.push({ description: specName, assertions: this.assertions[specName] });
                    results.failedCount +=
                        this.assertions[specName].filter(assertion => !assertion.passed).length;
                }
            }
            this.printResults(results.specResults);
            this.resultsReported = true;
            return results;
        }
    }

    private addSuccess(spec?: { specName: string }) {
        this.addAssertion(spec, true);
    }

    private addFailure(msg: string, spec: { specName: string }) {
        this.addAssertion(spec, false, msg);
    }

    private addAssertion(info, passed, message?) {
        if (this.resultsReported) {
            throw new Error('Cannot add new tests results, since they were already ' +
                'reported.');
        }
        info = info || {};
        const specName = info.specName || ' Axe Tests';
        const assertion = { passed: passed } as Assertion;
        if (!passed) {
            assertion.errorMsg = message;
            if (info.stackTrace) {
                assertion.stackTrace = info.stackTrace;
            }
        }
        this.assertions[specName] = this.assertions[specName] || [];
        this.assertions[specName].push(assertion);
    }

    private printResults(specResults) {
        const green = '\x1b[32m';
        const red = '\x1b[31m';
        const normalColor = '\x1b[39m';
        const printResult = (message, pass) => {
            logger.info(pass ? green : red, '\t', pass ? 'Pass: ' : 'Fail: ', message, normalColor);
        };
        for (const specResult of specResults) {
            const passed = specResult.assertions.map(x => x.passed).reduce((x, y) => (x && y), true);
            printResult(specResult.description, passed);
            if (!passed) {
                for (const assertion of specResult.assertions) {
                    if (!assertion.passed) {
                        logger.error('\t\t' + assertion.errorMsg);
                        if (assertion.stackTrace) {
                            logger.error('\t\t' + assertion.stackTrace.replace(/\n/g, '\n\t\t'));
                        }
                    }
                }
            }
        }
    }
}
