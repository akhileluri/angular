const express = require('express');
const path = require('path');
const ngApimock = require('ng-apimock')();
const app = express();

console.log('********************************************************************************************');
console.log('Starting Mock server. Working directory: ' + process.cwd());

/**
* Register all available mocks and generate interface
*/
ngApimock.run({
   "src": "./test/api-mocks",
   "outputDir": ".tmp/ngApimock",
   "done": function() {}
}); 

app.set('port', (process.env.PORT || 3000));

// process the api calls through ng-apimock
app.use(require('ng-apimock/lib/utils').ngApimockRequest);

// serve the mocking interface for local development
app.use('/mocking', express.static('.tmp/ngApimock'));

app.listen(app.get('port'), function() {
 console.log('Mock server running on port', app.get('port'));
 console.log('********************************************************************************************');
});