// Protractor configuration file, see link for more information
// https://github.com/angular/protractor/blob/master/lib/config.ts

const { SpecReporter } = require('jasmine-spec-reporter');

// Required modules
const path = require('path');
const fs = require('fs');

// Check which OS
const isWin = process.platform === "win32";

// resolve support directory stuff
var support_dir = path.resolve('../../ui-e2e-support');
var server_js = path.join(support_dir, 'server.js');
var chrome_driver =  path.join(support_dir, 'chromedriver');

// resolve path to mock server within e2e directory
var e2e_js =  path.join(process.cwd(), 'e2e', 'server.js');

// Make sure we have a copy of the server file in the e2e directory
if (!fs.existsSync(e2e_js)) {
  fs.copyFileSync(server_js, e2e_js)
}

// --------------------------------------------------------------------------
// Fork the mock server before beginning tests
// --------------------------------------------------------------------------
var child = 
require("child_process").fork(e2e_js);

if (child) {
  console.info('Mock server started...');
} else {
  process.exit(-1);
}


exports.config = {
  chromeDriver: isWin ? chrome_driver + '.exe' : chrome_driver,
  allScriptsTimeout: 11000,
  specs: [
    './src/**/*.e2e-spec.ts'
  ],
  capabilities: {
    'browserName': 'chrome',
    'chromeOptions': { 
      // args: [ "--window-size=1519,771"] 
      args: [ "--headless", "--disable-gpu", "--window-size=1519,771"] 
    },
  },
  directConnect: true,
  baseUrl: 'http://localhost:4200/',
  framework: 'jasmine',
  jasmineNodeOpts: {
    showColors: true,
    defaultTimeoutInterval: 30000,
    print: function() {}
  },
  onPrepare() {
    require('ts-node').register({
      project: require('path').join(__dirname, './tsconfig.e2e.json')
    });
    jasmine.getEnv().addReporter(new SpecReporter({ spec: { displayStacktrace: true } }));
  }
};