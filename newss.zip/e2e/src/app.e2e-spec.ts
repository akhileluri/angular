import { AppPage } from './app.po';
import { AxeRunner } from '../axe-helper';
import * as axe from 'axe-core';
import { browser, protractor, by } from 'protractor';

describe('ui-useradmin App', () => {
  let page: AppPage;
  let axe_runner: AxeRunner;

  beforeAll(() => {
    page = new AppPage();
    axe_runner = AxeRunner.build();
    page.navigateTo();
  });

  function run_axe() {
    axe_runner
      .include('body')
      .options({
        runOnly: {
          type: 'tag',
          values: ['wcag2a','wcag2aa']
        }
      })
      .run()
      .then(function (result) {
        expect(result.violations.length).toEqual(0);
      },
        function (err) {
          expect(err).toBeNull();
        }).catch(function (reason) {
          console.log('Axe runner error: ' + reason);
          expect(1).toBeNull();
        });
  }

  /**
   * Run the results before each test so if the previous test ran axe then the
   * results will be printed after the Jasmin status
   */
  beforeEach(function () {
    const result = axe_runner.getResults();
    axe_runner.reset();
  });

  /**
   * Run the results after all so that if the last test ran axe then the result will be reported
   */
  afterAll(function () {
    axe_runner.getResults();
    axe_runner.reset();
  });

  it('should display title in title bar', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Administration');
  });

  it('page should have no accessibility violations', () => {
    run_axe();
  });

  it('should display users in the page', () => {
    //page.navigateTo();
    page.getViewUserButtonElement().click();
    expect(page.getParagraphTextForViewUsers()).toEqual('Users');
  });

  it('page should have no accessibility violations', () => {
    run_axe();
  });

  it('should display  Edit users in the page', () => {
    page.getSpecificUserElement().click();
    expect(page.getEditUserTitle()).toContain('Edit User');
  });

  it('page should have no accessibility violations', () => {
    run_axe();
  });

  it('should display Add user in the page', () => {
    page.navigateTo();
    page.getAddUserButtonElement().click();
    expect(page.getEditUserTitle()).toContain('Add User');
  });

  it('page should have no accessibility violations', () => {
    //browser.sleep(100000);
    run_axe();
  });

  it('should display Groups in the page', () => {
    page.navigateToGroups();
    expect(page.getEditUserTitle()).toContain('Groups');
  });

  it('page should have no accessibility violations', () => {
    run_axe();
  });

  it('should display Edit Group in the page', () => {
    page.getSpecificGroupElement().click();
    expect(page.getEditUserTitle()).toContain('Edit Group');
  });

  it('page should have no accessibility violations', () => {
    run_axe();
  });

  it('should display Add Group in the page', () => {
    page.navigateToAddGroup();
    expect(page.getEditUserTitle()).toContain('Add Group');
  });

  it('page should have no accessibility violations', () => {
    run_axe();
  });

  it('should display Policies in the page', () => {
    page.navigateToPolicies();
    expect(page.getEditUserTitle()).toContain('Policies');
  });

  it('page should have no accessibility violations', () => {
    run_axe();
  });

  it('should display Edit Policy in the page', () => {
    page.getSpecificPolicyElement().click();
    expect(page.getEditUserTitle()).toContain('Edit Policy');
  });

  it('page should have no accessibility violations', () => {
    run_axe();
  });

  it('should display Add Policy in the page', () => {
    page.navigateToAddPolicy();
    expect(page.getEditUserTitle()).toContain('Add Policy');
  });

  it('page should have no accessibility violations', () => {
    run_axe();
  });

  it('should display Divisions in the page', () => {
    page.navigateToDivisions();
    expect(page.getDivisionTitle()).toContain('Divisions');
  });

  it('page should have no accessibility violations', () => {
    run_axe();
  });
 
});
