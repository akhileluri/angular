import { browser, by, element } from 'protractor';

export class AppPage {
  navigateTo() {
    return browser.get('/');
  }

  getParagraphText() {
    return element(by.cssContainingText('mat-toolbar-row','Administration')).getText();
  }

  getViewUserButtonElement() {
    return element(by.buttonText('View User'));
  }

  getParagraphTextForViewUsers() {
    return element(by.cssContainingText('mat-toolbar-row','Users')).getText();
  }

  navigateToEditUser() {
    return browser.get('/landing/manage-users/edit-user');
  }

  getSpecificUserElement() {
    return element(by.partialLinkText('CLS2@swiftview.com'));
  }

  getEditUserTitle() {
    return element(by.className('mat-toolbar-row')).getText();
  }

  getAddUserButtonElement() {
    return element(by.buttonText('Add User'));
  }
  
  navigateToGroups() {
    return browser.get('/landing/manage-groups/groups');
  }

  getSpecificGroupElement() {
    return element(by.partialLinkText('Admin Group'));
  }

  navigateToAddGroup() {
    return browser.get('/landing/manage-groups/add-new-group');
  }

  navigateToPolicies() {
    return browser.get('/landing/manage-policies/policies');
  }

  getSpecificPolicyElement() {
    return element(by.partialLinkText('Admin \'Policy\''));
  }

  navigateToAddPolicy() {
    return browser.get('/landing/manage-policies/add-new-policy');
  }

  navigateToDivisions() {
    return browser.get('/landing/divisions');
  }

  getDivisionTitle() {
    return element(by.className('mat-toolbar mat-toolbar-single-row')).getText();
  }
}
