import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {MatSortModule} from '@angular/material/sort';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import { FormsModule, ReactiveFormsModule  }   from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {HttpModule} from '@angular/http';

import { AppComponent } from './app.component';

import {AuthInterceptorModule, AuthInterceptorService} from 'ui-auth-interceptor';

import { ManageUsersComponent } from './manage-users/manage-users.component';
import { UsersComponent } from './manage-users/users/users.component';
import { AddNewUserComponent } from './manage-users/add-new-user/add-new-user.component';
import { EditUserComponent } from './manage-users/edit-user/edit-user.component';
import { GroupsComponent } from './manage-groups/groups/groups.component';
import { DivisionsComponent } from './divisions/divisions.component';
import { AddGroupComponent } from './manage-groups/add-group/add-group.component';
import { ManageGroupsComponent } from './manage-groups/manage-groups.component';
import { LandingComponent } from './landing/landing.component';
import { ManagePoliciesComponent } from './manage-policies/manage-policies.component';
import { AddNewPolicyComponent } from './manage-policies/add-new-policy/add-new-policy.component';
import { PoliciesComponent } from './manage-policies/policies/policies.component';
import { EditGroupComponent } from './manage-groups/edit-group/edit-group.component';
import { EditPolicyComponent } from './manage-policies/edit-policy/edit-policy.component';
import { ShowRelatedUsersComponent } from './manage-groups/show-related-users/show-related-users.component';
import { WarningMsgModalComponent } from './warning-msg-modal/warning-msg-modal.component';
import { UnauthorisedUserComponent } from './unauthorised-user/unauthorised-user.component';
import {AlwaysAuthGuard} from './always-auth-guard';


const appRoutes: Routes = [
    { path: 'landing', component: LandingComponent},
    { path: 'landing/manage-users', component: ManageUsersComponent,
      canActivate: [AlwaysAuthGuard],
      children: [
        { path: '', redirectTo: 'users', pathMatch: 'full' },
        { path: 'users', component: UsersComponent },
        { path: 'add-new-user', component: AddNewUserComponent },
        { path: 'edit-user', component: EditUserComponent }
      ] 
    },
    { path: 'landing/manage-groups', component: ManageGroupsComponent,
      canActivate: [AlwaysAuthGuard],
      children: [
        { path: '', redirectTo: 'groups', pathMatch: 'full' },
        { path: 'add-new-group', component: AddGroupComponent },
        { path: 'edit-group', component: EditGroupComponent },
        { path: 'show-group-users/:organizationId/:externalGroupId', component: ShowRelatedUsersComponent },
        { path: 'groups', component: GroupsComponent }
      ]
    },
    { path: 'landing/divisions', component: DivisionsComponent,canActivate: [AlwaysAuthGuard], pathMatch: 'full'},
    { path: 'landing/manage-policies', component: ManagePoliciesComponent,
      canActivate: [AlwaysAuthGuard],
      children: [
        { path: '', redirectTo: 'policies', pathMatch: 'full' },
        { path: 'add-new-policy', component: AddNewPolicyComponent },
        { path: 'edit-policy', component: EditPolicyComponent },
        { path: 'policies', component: PoliciesComponent }
      ]
    },
    { path: 'unauthorised-user', component: UnauthorisedUserComponent,pathMatch: 'full'},
    { path: '**',
      redirectTo: '/landing',
      pathMatch: 'full'
    }
  ];

@NgModule({
  imports: [ RouterModule.forRoot(appRoutes) ],
  exports: [
      RouterModule
   ] 
})
export class RoutingModule { };