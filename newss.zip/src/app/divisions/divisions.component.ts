import { Component, OnInit, ViewChild } from '@angular/core';

import { isDevMode } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatTableDataSource, MatSort} from '@angular/material';

import { DivisionsService } from './divisions.service';
import { UsersService } from '../manage-users/users/users.service';
import { Store } from '@ngrx/store';
import { State } from '../state/state';

import {Observable,  Subscription } from 'rxjs';
import * as AdminActions from '../state/actions';

export interface DivisionStruct {
  parentId: number;
  linkParent?: boolean; // confirm that parent is exist
  divisions: object[];  // use existing object then plus + subDivisions: DivisionStruct

}

@Component({
  selector: 'app-divisions',
  templateUrl: './divisions.component.html',
  styleUrls: ['./divisions.component.css'],
  providers: [DivisionsService, UsersService]
})
export class DivisionsComponent implements OnInit {

  allDivisionCnt: number;

  newLevel_1: DivisionStruct[];
  newLevel_2: DivisionStruct[];
  newLevel_3: DivisionStruct[];
  newLevel_4: DivisionStruct[]; // not display

  parentName: string;
  notFoundIcon: Boolean[];
  subDivClicked:  Boolean[];
  thirdDivClicked: Boolean[];
  errMessage = '';
  hasError = false;

  displayedColumns = ['id', 'name', 'user'];
  dataSource; // = new MatTableDataSource<any>([]);
  subDataSource; // = new MatTableDataSource<any>([]);
  thirdDataSource;
  totalUsers: number;
  iconUrl;
  linktoUserUrl;
  userObj:any = {userName:'',userEmail:'',actions:[]};
  account$:Observable<any>;
  userInfoSub: Subscription;
  userActionsList=[];
  hasListUser : boolean =false;
  lastRowClicked: any = {};
  

  @ViewChild(MatSort) sort: MatSort;

  constructor(private http: HttpClient,
        private divisionsService: DivisionsService,
        private usersService: UsersService,
         private state: Store<State>) { 
          this.account$ = this.state.select(st => st.userInfo);
          this.hasListUser  = this.includeAction(this.userActionsList,'LIST_USER');
        }

  ngOnInit() {
    this.iconUrl = this.divisionsService.getIconUrl();
    this.getUserUrl();
    
    this.userInfoSub = this.account$.subscribe(data => {
      if(data) {
    
        this.userActionsList = data['actions'];
        this.userObj = {userName:data.userName,userEmail:data.emailAddress,actions: data.actions};
        
        this.allDivisionCnt = data.divisions.length;
        // this.dataSource = new MatTableDataSource<any>(data.divisions); //list all division as raw
        // get total user count
        this.totalUsers = 0;
        for ( let i = 0; i < this.allDivisionCnt; i++) {
            this.totalUsers += data.divisions[i].userCount;
        }
  
        this.buildDivisionStruct(data.divisions);
  
        this.notFoundIcon = [new Boolean(this.allDivisionCnt)];
        this.subDivClicked = [new Boolean(this.allDivisionCnt)];
        this.thirdDivClicked = [new Boolean(this.allDivisionCnt)];
      }
    }, (err) => {
        console.log('Error');
    });
  }

 

  // process all division data
  buildDivisionStruct(divisions) {
    this.newLevel_1 = new Array() ;
    this.newLevel_2 = new Array() ;
    this.newLevel_3 = new Array() ;
    this.newLevel_4 = new Array() ;

    for ( let i  = 0; i < divisions.length; i++) {
      if (divisions[i].parentId == null) {
        this.processRawDivisions(divisions[i], this.newLevel_1);
      } else {
        this.processRawDivisions(divisions[i], this.newLevel_2);
      }
    }

    this.linkLevels(this.newLevel_1, this.newLevel_2);
    this.buildNextLevel(this.newLevel_2, this.newLevel_3);
    this.linkLevels(this.newLevel_2, this.newLevel_3);
    this.buildNextLevel(this.newLevel_3, this.newLevel_4);  // drop unlinked from third to fourth
    
    // bring the 4th unlinked to top
    if (this.newLevel_4.length > 0) {
      for (const curOne of this.newLevel_4) {
        if (curOne.divisions.length > 0 ) {
          // create an empty (parent) level1
          const newParent = {id: curOne.parentId,
                             name: curOne.divisions[0]['parentName'],
                             parentId: null,
                             subDivisions: curOne
                             };
          if (this.newLevel_1 && this.newLevel_1.length > 0) {
            this.newLevel_1[0].divisions.push(newParent);
          } else {
            this.newLevel_1.push({'parentId': null,
                      'divisions': [newParent] } );
          }


          // put content to level 2
          curOne.linkParent = true;
          this.newLevel_2.push(curOne);
        }
      }
    }

    if (this.newLevel_1.length > 0 ) {
      this.dataSource = new MatTableDataSource<any>(this.newLevel_1[0].divisions);
      this.parentName = 'Divisions' ;
    }
  }

  processRawDivisions(rawOneDivision, curDivsionLevel) {
    let found = false;

    if (curDivsionLevel) {
      for (const curOne of curDivsionLevel) {
        if (curOne.parentId === rawOneDivision.parentId) {
          // found same parentId, push into the division array
          curOne['divisions'].push(rawOneDivision);
          found = true;
        }
      }
    }
    if (found === false) { // create a new entry
      curDivsionLevel.push({'parentId': rawOneDivision.parentId,
                                'divisions': [rawOneDivision] } );
    }
  }


  // add subDivisions flags to division element
  // add linkParent flag to DivisionStruct object
  linkLevels(parent: DivisionStruct[], child: DivisionStruct[]) {

    for (const oneParent of parent) {
      for (const oneParentDiv of oneParent.divisions) {
        // pick one parent to compare with all children division
        for (const oneChild of child) {

            if (oneParentDiv['id'] === oneChild['parentId'] ) {
              // add new column
              oneParentDiv['subDivisions'] = oneChild;
              oneChild['linkParent'] = true;
            }
        }
      }
    }

  }

  private buildNextLevel(parent: DivisionStruct[], child: DivisionStruct[]) {
    // process all parent level, push to next level if it is not linked to parent.
    const removeIndex = [];
    for (const oneParent of parent) {
      if (!oneParent.linkParent) {    // no parent is claimed, push to third level
        child.push({'parentId': oneParent['parentId'],
                    'divisions': oneParent.divisions } );
        // save remove item index. Cannot remove here. After delete, the loop index mixed up
        removeIndex.push(parent.indexOf(oneParent));
      }
    }
    for (let i = removeIndex.length - 1; i >= 0; i--) {
      parent.splice(removeIndex[i], 1);
    }
  }

  setNotFoundIcon(index: number) {
  // keep only one open
    this.notFoundIcon[index] = true;
    console.log('setNotFoundIcon(), no icon is found: ' + index);
  }

// Need erase all flags.
// Otherwise, all one rows will have the same value
  onTopRowClicked(row) {
    if(this.lastRowClicked.id != row.id){
      row.rowClicked = true;
      this.lastRowClicked.rowClicked = false;
      this.lastRowClicked = row;
    }
    else{
      this.lastRowClicked.rowClicked = false;
      this.lastRowClicked = {};
    }

    const row_old_value = this.subDivClicked[row.id];
    this.subDivClicked = [new Boolean(this.allDivisionCnt)];
    this.subDivClicked[row.id] = (row_old_value === true) ? false : true;

    //console.log('*** clicked on row onTopRowClicked');
    this.subDataSource = null;
    if (row.subDivisions != null  && typeof (row.subDivisions) !== 'undefined') {
      this.subDataSource = new MatTableDataSource<any>(row.subDivisions.divisions);
    }
  }

  onSecondRowClicked(row) {
    if(this.lastRowClicked.id != row.id){
      row.rowClicked = true;
      this.lastRowClicked.rowClicked = false;
      this.lastRowClicked = row;
    }
    else{
      this.lastRowClicked.rowClicked = false;
      this.lastRowClicked = {};
    }
    const row_old_value = this.thirdDivClicked[row.id];
    this.thirdDivClicked = [new Boolean(this.allDivisionCnt)];
    this.thirdDivClicked[row.id] = (row_old_value === true) ? false : true;

    // console.log('*** clicked on row onSecondRowClicked');
    this.thirdDataSource = null;
    if (row.subDivisions != null  && typeof (row.subDivisions) !== 'undefined') {
      this.thirdDataSource = new MatTableDataSource<any>(row.subDivisions.divisions);
    }
   }

   includeAction(list,actionItem) {
    if (list.indexOf(actionItem) > -1){
        return false;
    } else {
      return true;
    }
  }



  getUserUrl() {
    this.linktoUserUrl = '/useradmin/landing/manage-users/users?divId=';
    if (isDevMode()) {
      this.linktoUserUrl = '/landing/manage-users/users?divId=';
    }
  }

}




