import { Injectable, Inject, isDevMode} from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';

import { catchError } from 'rxjs/internal/operators/catchError';
import {Observable} from 'rxjs';
import { APP_CONFIG, IAppConfig } from '../app.config';
import { AuthInterceptorService } from 'ui-auth-interceptor';


@Injectable()
export class DivisionsService {
	
        private apiUrl: string;
        private authToken: string = this.config.authToken;

        private iconUrl = "/transactional/image?customerId=CUSID&keyName=customer.logo.small";

        constructor(private http: HttpClient,@Inject(APP_CONFIG) private config: IAppConfig) { 
                if(isDevMode()){
                        this.apiUrl = this.config.baseDevApiURL;
                        this.iconUrl = this.apiUrl + this.iconUrl;
                }
        }

        getIconUrl(){
                return this.iconUrl;
        }


}


