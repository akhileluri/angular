import { Component, OnInit } from '@angular/core';
import { AddNewUserService } from '../manage-users/add-new-user/add-new-user.service';
import { ManageUsersService} from '../manage-users/manage-users.service';
import {Observable, Subscription} from 'rxjs';
import {startWith, map} from 'rxjs/operators';
import { Store } from '@ngrx/store';
import { State } from '.././state/state';
import * as AdminActions from '.././state/actions';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css'],
  providers: [AddNewUserService,ManageUsersService]
})
export class LandingComponent implements OnInit {

  menuItem = 1;
  groupDetailsList: any = '';
  orgId: any = '';
  account$:Observable<any>;
  userInfoSub: Subscription;
  userActionsList =  [ ];
  userObj:any = {userName:'',userEmail:'',actions:[]};
  hasViewUser : boolean = false;
  hasAddUser : boolean = false;
  hasViewGroup : boolean = false;
  hasAddGroup : boolean = false;
  hasViewPolicies : boolean = false;
  hasAddPolicies : boolean = false;


  constructor(private addNewUserService: AddNewUserService,
    protected router: Router, 
    private manageUsersService: ManageUsersService,
    private state: Store<State>) { 
   
    this.account$ = this.state.select(st => st.userInfo);
    this.userInfoSub = this.account$.subscribe(data => {
      if(data){
        this.userActionsList = data['actions'];
        this.userObj = {userName:data.userName,userEmail:data.emailAddress,actions: data.actions};

        this.hasViewUser  = this.includeAction(this.userActionsList,'LIST_USER');

        this.hasAddUser  = this.includeAction(this.userActionsList,'LIST_USER') || this.includeAction(this.userActionsList,'ACCESS_POLICY_GROUP_LIST') ||
        this.includeAction(this.userActionsList,'EDIT_USER') || this.includeAction(this.userActionsList,'CREATE_USER') ||  this.includeAction(this.userActionsList,'ACCESS_POLICY_GROUP_EDIT');

        this.hasViewGroup  = this.includeAction(this.userActionsList,'ACCESS_POLICY_GROUP_LIST');
      
        this.hasAddGroup  = this.includeAction(this.userActionsList,'ACCESS_POLICY_GROUP_LIST') || this.includeAction(this.userActionsList,'ACCESS_POLICY_LIST') || 
        this.includeAction(this.userActionsList,'ACCESS_POLICY_ACTION_LIST') ||  this.includeAction(this.userActionsList,'ACCESS_POLICY_GROUP_EDIT');

        this.hasViewPolicies  = this.includeAction(this.userActionsList,'ACCESS_POLICY_LIST');

        this.hasAddPolicies  = this.includeAction(this.userActionsList,'ACCESS_POLICY_LIST') || this.includeAction(this.userActionsList,'ACCESS_POLICY_ACTION_LIST') ||  this.includeAction(this.userActionsList,'ACCESS_POLICY_EDIT');
        
        
        }
      
    }, (err) => {
        console.log('Error');
    });
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    if (this.userInfoSub) {
      this.userInfoSub.unsubscribe();
    }
  }

  setMenuItem(index){
    this.menuItem = index;
  }

  includeAction(list,actionItem){
    if(list.indexOf(actionItem) > -1){
        return false;
    }
    else{
      return true;
    }
  }

 
 
}
