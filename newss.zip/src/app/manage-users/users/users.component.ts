import { Component, OnInit, Inject, isDevMode  } from '@angular/core';
import { Router ,ActivatedRoute,Params} from '@angular/router';
import {ViewChild} from '@angular/core';
import {MatPaginator, MatTableDataSource,MatSort} from '@angular/material';
import { ManageUsersService } from '../manage-users.service';
import { UsersService } from './users.service';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import {ErrorShowDialogComponent} from '../../error-show-dialog/error-show-dialog.component';
import { AuthInterceptorService } from 'ui-auth-interceptor';
import { AddNewUserService } from '../add-new-user/add-new-user.service';
import {map, startWith} from 'rxjs/operators';
import {FormControl, Validators} from '@angular/forms';
import { FormsModule } from '@angular/forms';
import {Observable,  Subscription } from 'rxjs';
import { Store } from '@ngrx/store';
import { State } from '../../state/state';
import * as AdminActions from '../../state/actions';


@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css'],
  providers: [UsersService,AddNewUserService]
})
export class UsersComponent implements OnInit{

  users = [];
  
  errMessage: string = '';
  hasError: boolean = false;
  dataSource = new MatTableDataSource<any>(this.users);
  modalTextValue: string = '';
  defaultOrg: string = '';
  defaultDivisionCtrl: FormControl;
  filteredDivisions: Observable<any[]>;
  divisions = [];
  routeSub:Subscription;
  isSearchData = false;
  noSearchDataMessage: string = '';
  isActive=true;
  searchParam: string = '';
  orgParam:string = '';

  
  searchVal:String='';
  lastFilter:number;
  lastSearch:string;
  params:any;
  routeParamsSub: Subscription;
  searchAutoCompleteObj:any ={ searchOpts:[], value:'', placeholder:'Organization' };
  userObj:any = {userName:'',userEmail:'',actions:[]};
  account$:Observable<any>;
  userInfoSub: Subscription;
  userActionsList=[];
  hasListUser : boolean = false;
  
  hasListAdd : boolean = false;

  constructor(private manageUsersService: ManageUsersService,
    private usersService: UsersService,
    private router:Router,
    public dialog: MatDialog,
    private addNewUserService: AddNewUserService, 
    private activatedRoute: ActivatedRoute, private state: Store<State>) { 
    this.account$ = this.state.select(st => st.userInfo);
    this.defaultDivisionCtrl = new FormControl();
    this.filteredDivisions = this.defaultDivisionCtrl.valueChanges
    .pipe(
      startWith(''),
      map(division => division ? this.filterDivisions(division) : this.divisions.slice())
    );
  }

  openDialog(message): void {
    let dialogRef = this.dialog.open(UserModalDialog, {
      width: '500px',
      data: { text: message}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed : ' + result);
      this.modalTextValue = result;
    });
  }

  showErrorDialog(errMessage): void {
    let dialogRef = this.dialog.open(ErrorShowDialogComponent, {
      width: '500px',
      data: { text: errMessage}
    });
  }

  ngOnInit() {
    this.userInfoSub = this.account$.subscribe(data => {
      if(data){
        this.divisions = data.divisions;
        this.userActionsList = data['actions'];
        this.hasListUser  = this.includeAction(this.userActionsList,'ACCESS_POLICY_GROUP_LIST') ||
        this.includeAction(this.userActionsList,'EDIT_USER') ||  
        this.includeAction(this.userActionsList,'ACCESS_POLICY_GROUP_EDIT');
       
        this.hasListAdd  = this.includeAction(this.userActionsList,'ACCESS_POLICY_GROUP_LIST') || 
        this.includeAction(this.userActionsList,'CREATE_USER') || 
        this.includeAction(this.userActionsList,'EDIT_USER') ||  
        this.includeAction(this.userActionsList,'ACCESS_POLICY_GROUP_EDIT');
     
        this.userObj = {userName:data.userName,userEmail:data.emailAddress,actions: data.actions};
        for(let division of data.divisions){
          this.searchAutoCompleteObj.searchOpts.push(division.name);
        }
        this.routeSub = this.activatedRoute.queryParams.subscribe(params =>{
          if(params && params['search'] && params['organization']){
            let x = params['search'];
            let y = params['organization'];
            y = this.getOrgId(y);
            this.searchParam = params['search'];
            this.orgParam = params['organization'];
            this.getUsers({"search" : x, "organization" : y});
          }
          else if(params && params['search']){
            let x = params['search'];
            this.searchParam = params['search'];
            this.getUsers({"search" : x});
          }
          else if(params && params['organization']){
            let x = params['organization'];
            x = this.getOrgId(x);
            this.orgParam = params['organization'];
            this.getUsers({"organization" : x});
          }
          else if(params && params['divId']) {
            this.divisionSelected({"id": params['divId']});
          }
          else {
            this.getUsers();
          }
        });
      }
    }, (err) => {
        console.log('Error');
    });
  }
  ngOnDestroy(){
    if (this.routeSub) {
      this.routeSub.unsubscribe();
    }
    if (this.userInfoSub) {
      this.userInfoSub.unsubscribe();
    }
  }

  
  
  displayedColumns = ['firstName','emailAddress', 'status','deactivate'];

  applyFilter(filterValue: string) {
   filterValue = filterValue.trim(); // Remove whitespace
   filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
   this.dataSource.filter = filterValue;
  }

  @ViewChild(MatSort) sort: MatSort;

  @ViewChild(MatPaginator) paginator: MatPaginator;

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }

  getUsers = function(obj?){
    this.usersService.getUsers(obj).subscribe((data) => {
      this.users = data;
      this.dataSource = new MatTableDataSource<any>(this.users);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
      this.isActive=false;
      this.isSearchData = false;
      
      if(data.length == 0 && obj.search){
        this.noSearchDataMessage = 'No Users were found matching your search';
        this.isSearchData = true;
      }

      if(data.length == 0 && !obj.search){
        this.noSearchDataMessage = 'No Users were found for this organization';
        this.isSearchData = true;
      }
      if(data.length == 255 && obj.search){
        let noSearchDataMessage = 'More than 255 results were returned. Only the first 255 results will be shown. If you do not see the user you were looking for, please refine your search criteria.';
        this.openDialog(noSearchDataMessage);
      }
     
    }, (err) => {
        this.isActive=false;
        if(err.status == 403){
          this.showErrorDialog('Forbidden');
        }
        else if(err.status == 404){
          this.showErrorDialog('Not Found');
        }
        else if(err.message == 'getUsers.emailId: Enter a minimum of two characters, getUsers.name: Enter a minimum of two characters'){
          this.showErrorDialog('Enter a minimum of two characters of the last name or email address.');
        }
        else if(err.message == 'getUsers.name: Enter a minimum of two characters, getUsers.emailId: Enter a minimum of two characters'){
          this.showErrorDialog('Enter a minimum of two characters of the last name or email address.');
        }
        
        else{
          this.errMessage = err.status + '-' + err.statusText;
          this.hasError = true;
        }
    });
  }

  filterDivisions(name: string) {
    return this.divisions.filter(division => 
      division.name.toLowerCase().indexOf(name.toLowerCase()) === 0);
  }

  divisionSelected = function(obj){
    this.getUsers(obj);
  }

  getOrgId = function(organization){
    for(let i=0;i<this.divisions.length;i++){
      if(this.divisions[i].name == organization){
        organization = this.divisions[i].id;
        return organization;
      }
    }
  }

  includeAction(list,actionItem){
    if(list.indexOf(actionItem) > -1){
        return false;
    }
    else{
      return true;
    }
  }

  activeDeactiveUser=function(currObj,obj){
    this.router.navigate([], {
      relativeTo: this._route,
      queryParams: {
        organization: this.orgParam,
        search: this.searchParam
      },
      queryParamsHandling: 'merge', 
      // preserve the existing query params in the route
      skipLocationChange: true
      // do not trigger navigation
    });
    
   
    let temp = {"id":currObj.id,"active":currObj.active,"ownerId":currObj.ownerId};
    if(currObj.active == true){
      temp.active =false;
    }
    else{
      temp.active = true;
    }
    this.usersService.activeDeactiveUser(temp).subscribe((data) => {
      let obj = {"search" : '', "organization" : ''};
      if(this.orgParam && this.searchParam){
        obj.search = this.searchParam;
        obj.organization = this.orgParam;
      }
      else if (this.orgParam){
        obj.organization = this.orgParam;
      }
      else if (this.searchParam){
        obj.search = this.searchParam;
      }
      if(obj.organization){
        obj.organization = this.getOrgId(obj.organization)
      }
      this.getUsers(obj);
      
    }, (err) => {
      if(err.status == 403){
        this.showErrorDialog('You do not have admin rights to make this change.');
      }
      else if(err.status == 404){
        this.showErrorDialog('Not Found');
      }
      else if(err.status == 500){
        this.showErrorDialog('Fetching Data was unsuccessful!');
      }
      else{
        this.errMessage = err.status + '-' + err.statusText;
        this.hasError = true;
      }
    });
  };

  editUser=function(currObj){
    this.manageUsersService.setEditUserObj(currObj);
    this.router.navigateByUrl('/landing/manage-users/edit-user');
  };

}


@Component({
  selector: 'user-modal-dialog',
  templateUrl: 'user.modal.html',
})
export class UserModalDialog {

  constructor(
    public dialogRef: MatDialogRef<UserModalDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  onNoClick(): void {
    this.dialogRef.close();
  }

}