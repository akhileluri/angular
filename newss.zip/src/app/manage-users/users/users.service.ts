import { Injectable, Inject, isDevMode} from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import {Observable } from 'rxjs';
import { catchError } from 'rxjs/internal/operators/catchError';

import { APP_CONFIG, IAppConfig } from '../../app.config';
// import {handleError} from '../../service.util';
import { AuthInterceptorService } from 'ui-auth-interceptor';

@Injectable()
export class UsersService {

	getUsers(data) : Observable<Object> {

		const httpOptions = {
		  headers: new HttpHeaders({
		    'Content-Type':  'application/json',
		    'Authorization': 'bearer ' + this.config.authToken
		  })
		};

		var payload = '';
		if(data && data.id){
		 payload = '?orgId=' + data.id;
		}
		if(data && data.search){
			payload += '?name=' + encodeURIComponent(data.search) + '&emailId=' + encodeURIComponent(data.search);
		}
		if(data && data.organization){
			if(data.search){
				payload += '&orgId=' + data.organization;
			}
			else{
				payload += '?orgId=' + data.organization;
			}
		}
		//return this.http.get(this.getUsersUrl + payload,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).catchError(AuthInterceptorService.handleError);
		return this.http.get(this.getUsersUrl + payload,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));		
	}

	activeDeactiveUser(data) : Observable<Object> {
		//return this.http.put(this.activeDeactiveUserUrl+data.id,data,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).catchError(AuthInterceptorService.handleError);
		return this.http.put(this.activeDeactiveUserUrl+data.id,data,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
	}

	private getUsersUrl = '/rest/v1/customer/users';	//URL to get users list

	private activeDeactiveUserUrl = '/rest/v1/user/';	//URL to active/deactive user

	private apiUrl: string;

	private authToken: string = this.config.authToken;

	constructor(private http: HttpClient,@Inject(APP_CONFIG) private config: IAppConfig) { 
		if(isDevMode()){
			this.apiUrl = this.config.baseDevApiURL;
			this.getUsersUrl = this.apiUrl + this.getUsersUrl;
			this.activeDeactiveUserUrl = this.apiUrl + this.activeDeactiveUserUrl;
		}
	}

}
