import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {Observable, Subscription} from 'rxjs';
import {startWith, map} from 'rxjs/operators';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { AddNewUserService } from './add-new-user.service';
import {ErrorShowDialogComponent} from '../../error-show-dialog/error-show-dialog.component';
import { ManageUsersService } from '../manage-users.service';
import { Store } from '@ngrx/store';
import { State } from '../../state/state';
import * as AdminActions from '../../state/actions';


@Component({
  selector: 'app-add-new-user',
  templateUrl: './add-new-user.component.html',
  styleUrls: ['./add-new-user.component.css'],
  providers: [AddNewUserService,ManageUsersService]
})
export class AddNewUserComponent implements OnInit {

  divisionCtrl = new FormControl('', []);

  divisions = [];
  user = {} as any;
  lastSelectedDivision = {} as any;
  errMessage: string = '';
  hasError: boolean = false;
  authToken: string = '';
  assignDivisions = [];
  allDivision: boolean = false;
  searchText: string = '';
  searchTextGroup: string = '';
  defaultOrg: string = '';
  defaultDivisionCtrl: FormControl;
  filteredDivisions: Observable<any[]>;
  emailFormControl: FormControl;
  phoneNumberFormControl: FormControl;
  policies = [];
  policySelected : boolean = true;
  showPolicies : boolean = false;
  groupDetailsList = [];
  actions = [];
  list = [];
  finalList = [];
  grpSelectList = [];
  arrList = [];
  arrPolicyExternalId = [];
  arrActionExternalId = [];
  account$:Observable<any>;
  userInfoSub: Subscription;
  userActionsList =  [ ];
  userObj:any = {userName:'',userEmail:'',actions:[]};
  
  
  
  constructor(private router:Router,
    private route: ActivatedRoute,
    private manageUsersService: ManageUsersService,
    private addNewUserService: AddNewUserService,
    public dialog: MatDialog,
    private state: Store<State>) {
    this.account$ = this.state.select(st => st.userInfo);
    this.defaultDivisionCtrl = new FormControl();
    this.filteredDivisions = this.defaultDivisionCtrl.valueChanges
    .pipe(
      startWith(''),
      map(division => division ? this.filterDivisions(division) : this.divisions.slice())
    );

    this.emailFormControl = new FormControl('', [
      Validators.required,
      Validators.email
    ]);

    this.phoneNumberFormControl = new FormControl('', [
      Validators.required,
      Validators.minLength(10),
      Validators.maxLength(10),
      Validators.pattern('[0-9]+')
    ]);

  }

  filterDivisions(name: string) {
    return this.finalList.filter(division =>
      division.name.toLowerCase().indexOf(name.toLowerCase()) === 0);
  }

  ngOnInit() {

      this.userInfoSub = this.account$.subscribe(data => {
        if(data){
          this.userActionsList = data['actions'];
          this.userObj = {userName:data.userName,userEmail:data.emailAddress,actions: data.actions};
          this.divisions = data.divisions;
          this.assignDivisions = data.divisions;
        
          this.convertRawDivision();
          
          }
        
      });
  }

  ngOnDestroy() {
   this.divisions=[];
   this.assignDivisions=[];
   this.finalList = [];
    if (this.userInfoSub) {
      this.userInfoSub.unsubscribe();
    }
  }

  showErrorDialog(errMessage): void {
    let dialogRef = this.dialog.open(ErrorShowDialogComponent, {
      width: '500px',
      data: { text: errMessage}
    });
  }

  

  getAllGroupDetails = function(obj){
    this.manageUsersService.getAllGroupDetails(obj).subscribe((data) => {
        this.groupDetailsList = data;
    }, (err) => {
        if(err.status == 403){
          this.showErrorDialog('Forbidden');
        }
        else if(err.status == 404){
          this.showErrorDialog('Not Found');
        }
        else if(err.status == 500){
          this.showErrorDialog('Fetching Groups was unsuccessful for Selected Default Division!');
        }
        else{
          this.errMessage = err.status + '-' + err.statusText;
          this.hasError = true;
        }
    });
  }

  convertRawDivision = function(){
    let x = this.divisions.map(y => Object.assign({}, y));
    var flag = true;
    for(var i=0;i<x.length;i++){
      flag = true;
      if(x[i].parentId == null){
        this.list[x[i].id] = x[i];
        this.list[x[i].id].sublist = [];
        flag = false;
      }
      else if(this.list[x[i].parentId]){
          this.list[x[i].parentId].sublist[x[i].id] = x[i];
          this.list[x[i].parentId].sublist[x[i].id].sublist = [];
          flag = false;
        }
      else{
        for(var j=0;j<this.list.length;j++){
          if(this.list[j] && this.list[j].sublist[x[i].parentId]){
            this.list[j].sublist[x[i].parentId].sublist[x[i].id] = x[i];
            flag = false;
          }
        }
      }
      if(flag){
        x[i].name = '../' + x[i].parentName + '/' + x[i].name;
        this.list[x[i].id] = x[i];
        this.list[x[i].id].sublist = [];
      }
    }

    this.finalList = this.list.filter(value => Object.keys(value).length !== 0);
    for (var i = 0; i < this.finalList.length; i++) {
      if(this.finalList[i]){
       var temp = this.finalList[i].sublist.filter(value => Object.keys(value).length !== 0);
       this.finalList[i].sublist = temp;
       this.finalList[i].checked = false;
      }
    }
    for (var i = 0; i < this.finalList.length; i++) {
      if(this.finalList[i]){
        for (var j = 0; j < this.finalList[i].sublist.length; j++) {
          if(this.finalList[i].sublist[j]){
            var temp = this.finalList[i].sublist[j].sublist.filter(value => Object.keys(value).length !== 0);
            this.finalList[i].sublist[j].sublist = temp;
            this.finalList[i].sublist[j].checked = false;
          }
        }
      }
    }
    console.log(this.finalList);
  }

  divisionSelected = function(division){
    
    //this.lastSelectedDivision.checked = false;
    this.lastSelectedDivision.disabled = false;
    division.checked = true;
    division.disabled = true;
    this.lastSelectedDivision = division;
    this.user.ownerId = division.id;
    this.user.ownerName = division.name;
    this.actions = [];
    this.policies = [];
    this.grpSelectList = [];
    this.arrList = [];
    this.arrPolicyExternalId = [];
    this.arrActionExternalId = [];
    this.getAllGroupDetails(division);
  }

  selectInnerDivision = function(division,flag){
    division.checked = flag;
    division.showPlus = flag;
    if(division.sublist.length > 0){
      for(let i=0;i<division.sublist.length;i++){
        division.sublist[i].checked = flag;
      }
    }
  }

  selectAllDivisions = function(){
    for(let i=0;i<this.assignDivisions.length;i++){
      if(!this.assignDivisions[i].disabled){
        this.assignDivisions[i].checked = this.allDivision;
      }
    }
  }

  groupSelected = function(group,index){
    var index = this.grpSelectList.indexOf(group);
    if(index >= 0){
      this.grpSelectList.splice(index,1);
    }else{
      this.grpSelectList.push(group);
    }
    if(group.assigned){
      for(let i=0;i<group.policies.length;i++){
        var policyIndex = this.isPolicyExternalIdExist(group.policies[i].externalPolicyId);
        if(policyIndex < 0){
          this.policies.push(group.policies[i]);
          this.arrPolicyExternalId[group.policies[i].externalPolicyId] = 1;
        }
        else{
          this.arrPolicyExternalId[group.policies[i].externalPolicyId]++;
        }
        if(group.policies[i].actions && group.policies[i].actions.length > 0){
          for(let j=0;j<group.policies[i].actions.length;j++){
            var actionIndex = this.isActionExternalIdExist(group.policies[i].actions[j].externalActionId);
            if(actionIndex < 0){
              this.actions.push(group.policies[i].actions[j]);
              this.arrActionExternalId[group.policies[i].actions[j].externalActionId] = 1;
            }
            else{
              this.arrActionExternalId[group.policies[i].actions[j].externalActionId]++;
            }
          }
        }
      }
    }
    else{
      for(let i=0;i<group.policies.length;i++){
        if(group.policies[i].actions && group.policies[i].actions.length > 0){
          for(let j=0;j<group.policies[i].actions.length;j++){
            if(this.arrActionExternalId[group.policies[i].actions[j].externalActionId] > 1){
              this.arrActionExternalId[group.policies[i].actions[j].externalActionId]--;
            }
            else{
              delete this.arrActionExternalId[group.policies[i].actions[j].externalActionId];
              let index = this.actions.indexOf(group.policies[i].actions[j]);
              this.actions.splice(index,1);
            }
          }
        }
        if(this.arrPolicyExternalId[group.policies[i].externalPolicyId] > 1){
          this.arrPolicyExternalId[group.policies[i].externalPolicyId]--;
        }
        else{
          delete this.arrPolicyExternalId[group.policies[i].externalPolicyId];
          let index = this.policies.indexOf(group.policies[i]);
          this.policies.splice(index,1);
        }
      }
    }

    let arr2 = [];
    this.arrList = [];
    for(let j=0;j<this.actions.length;j++){
      if(arr2.indexOf(this.actions[j].resourceType) < 0){
        arr2.push(this.actions[j].resourceType);
        this.arrList.push({"resourceType" : this.actions[j].resourceType ,"names" : []});
      }
    }
    for(let i=0;i<this.arrList.length;i++){
      for(let j=0;j<this.actions.length;j++){
        if(this.arrList[i].resourceType == this.actions[j].resourceType){
          this.arrList[i].names.push(this.actions[j].name);
        }
      }
    }
  }

  isPolicyExternalIdExist = function(policyExternalId){
    if(this.arrPolicyExternalId[policyExternalId]){
      return 1;
    }
    return -1;
  }

  isActionExternalIdExist = function(actionExternalId){
    if(this.arrActionExternalId[actionExternalId]){
      return 1;
    }
    return -1;
  }

  isPolicyExist = function(policy){
    for(let j=0;j<this.policies.length;j++){
      if(policy.externalPolicyId == this.policies[j].externalPolicyId)
      {
        return j;
      }
    }
    return -1;
  }

  save = function(){
   
    let temp ={"divisions" : []};
   
    for (var i = 0; i < this.finalList.length; i++) {
      if(this.finalList[i].checked){
        let divisionObj = {} as any;
        divisionObj.id = this.finalList[i].id;
        divisionObj.accessChild = true;
        temp.divisions.push(divisionObj);
      }
    }
    for (var i = 0; i < this.finalList.length; i++) {
      for (var j = 0; j < this.finalList[i].sublist.length; j++) {
        if(this.finalList[i].sublist[j].checked){
          let divisionObj = {} as any;
          divisionObj.id = this.finalList[i].sublist[j].id;
          divisionObj.accessChild = true;
          temp.divisions.push(divisionObj);
        }
      }
    }
    for (var i = 0; i < this.finalList.length; i++) {
      for (var j = 0; j < this.finalList[i].sublist.length; j++) {
        for (var k = 0; k < this.finalList[i].sublist[j].sublist.length; k++) {
          if(this.finalList[i].sublist[j].sublist[k].checked){
            let divisionObj = {} as any;
            divisionObj.id = this.finalList[i].sublist[j].sublist[k].id;
            divisionObj.accessChild = true;
            temp.divisions.push(divisionObj);
          }
        }
      }
    }
    //groups data 
    var groupURI  = '';
    for(let i=0;i<this.groupDetailsList.length;i++){
      if(this.groupDetailsList[i].assigned){
        groupURI += '&groupURI='+  this.groupDetailsList[i].self;
      }
    }
    this.user.service = 'TW';
    this.user.accessChildCustomers = 'Y';
    if(!this.user.uniqueId){
      this.user.uniqueId = null;
    }
    this.addNewUserService.createUser(this.user).subscribe((dataUser) => {
      this.addNewUserService.assignDivisions(dataUser,temp,this.user).subscribe((data) => {
        if(this.user.ownerName != 'EXP System Admin'){
          this.manageUsersService.saveUserGroups(dataUser,groupURI).subscribe((data) => {
            if(data.success){
              this.router.navigateByUrl('/landing/manage-users/users');
            }
          }, (err) => {
              if(err.status == 403){
                this.showErrorDialog('Forbidden');
              }
              else if(err.status == 404){
                this.showErrorDialog('Not Found');
              }
              else if(err.status == 500){
                this.showErrorDialog('Mapping Groups was unsuccessful for Selected Default Division!');
              }
              else{
                this.errMessage = err.status + '-' + err.statusText;
                this.hasError = true;
              }
          });
        }
        else{
          this.router.navigateByUrl('/landing/manage-users/users');
        }
      }, (err) => {
          if(err.status == 403){
            this.showErrorDialog('Forbidden');
          }
          else if(err.status == 404){
            this.showErrorDialog('Not Found');
          }
          else if(err.status == 500){
            this.showErrorDialog('Mapping Divisions was unsuccessful!');
          }
          else{
            this.errMessage = err.status + '-' + err.statusText;
            this.hasError = true;
          }
      });
    }, (err) => {
      if(err.status == 409){
        this.errMessage = ' User exists';
      }
      else if(err.status == 403){
        this.showErrorDialog('Forbidden');
      }
      else if(err.status == 404){
        this.showErrorDialog('Not Found');
      }
      else if(err.status == 500){
        this.showErrorDialog('Creating User was unsuccessful!');
      }
      else{
        this.errMessage = err.status + '-' + err.statusText;
        this.hasError = true;
      }
      this.hasError = true;
    });
  }

  cancel = function(){
    this.router.navigateByUrl('/landing/manage-users/users');
  }

}