import { Injectable, Inject, isDevMode} from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { catchError } from 'rxjs/internal/operators/catchError';
import {Observable, Subscription} from 'rxjs';
import { APP_CONFIG, IAppConfig } from '../../app.config';
import { AuthInterceptorService } from 'ui-auth-interceptor';

@Injectable()
export class AddNewUserService {

	loadUserInfo() : Observable<Object> {
		return this.http.get(this.getDivisionsUrl,{headers: new HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
	}

	getDivisions(authToken) : Observable<Object> {
		return this.http.get(this.getDivisionsUrl,{headers: new HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
	}

	getAuthToken(){
		return this.authToken;
	}

	createUser(data) : Observable<Object> {
		return this.http.post(this.createUserUrl,data,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
		
	}

	assignDivisions(data,divisionObj,user){
		return this.http.post(this.assignDivisionsUrl+data.accountId+'/divisions?orgId='+user.ownerId,divisionObj,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
	}

	private getDivisionsUrl = '/rest/v1/me';	//URL to get divisions list

	private createUserUrl = '/api/v1/user';	//URL to create a new user

	private assignDivisionsUrl = '/rest/v1/user/';	//URL to assign divisions to a user

	private apiUrl: string;

	private authToken: string = this.config.authToken;

	constructor(private http: HttpClient,@Inject(APP_CONFIG) private config: IAppConfig) { 
		if(isDevMode()){
			this.apiUrl = this.config.baseDevApiURL;
			this.getDivisionsUrl = this.apiUrl + this.getDivisionsUrl;
			this.createUserUrl = this.apiUrl + this.createUserUrl;
			this.assignDivisionsUrl = this.apiUrl + this.assignDivisionsUrl;
		}
	}

}
