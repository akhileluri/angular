import { Component, OnInit } from '@angular/core';

import { ManageUsersService } from './manage-users.service';
import { AddNewUserService } from './add-new-user/add-new-user.service';
import { EditUserService } from './edit-user/edit-user.service';
import { UsersService } from './users/users.service';


@Component({
  selector: 'app-manage-users',
  templateUrl: './manage-users.component.html',
  styleUrls: ['./manage-users.component.css'],
  providers: [AddNewUserService,ManageUsersService]
})

export class ManageUsersComponent implements OnInit {

  errMessage: string = '';
  hasError: boolean = false;

  constructor(private addNewUserService: AddNewUserService,private manageUsersService: ManageUsersService) { }

  ngOnInit() {
  	//this.getDivisions();
  }

  getDivisions = function(){
    this.addNewUserService.getDivisions().subscribe((data) => {
        console.log('Sucess');
    }, (err) => {
        console.log('Error');
    });
  }

}
