import { Injectable, Inject, isDevMode} from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { catchError } from 'rxjs/internal/operators/catchError';
import {Observable} from 'rxjs';


import { APP_CONFIG, IAppConfig } from '../../app.config';
// import{handleError} from '../../service.util';
import { AuthInterceptorService } from 'ui-auth-interceptor';

@Injectable()
export class EditUserService {

	editUser(data) : Observable<Object> {
		return this.http.put(this.editUserUrl,data,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
	}

	getUserPhoneDetails(data,rawData) : Observable<Object> {
		return this.http.get(this.getUserPhoneDetailsUrl+'?userEmail='+data.userEmail+'&firstName='+data.firstName+'&lastName='+data.lastName+'&middleName='+data.middleName+'&suffix='+data.suffix+'&customerId='+data.organizationId+'&service='+rawData.service,{headers: new HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
	}

	getUserDivisions(data) : Observable<Object> {
		return this.http.get(this.getUserDivisionsUrl+data.id+'/divisions',{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
	}

	getUserGroups(data) : Observable<Object> {
		var userURI = 'https://expedite400.qa.bkfstest.com' + '/rest/v1/authorization/users/' + data.id;
		return this.http.get(this.getUserGroupsUrl+'?userURI='+userURI,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
	}

	private editUserUrl = '/rest/v1/user';	//URL to edit a user

	private getUserPhoneDetailsUrl = '/api/v1/mfa/user';	//URL to edit a user

	private getUserDivisionsUrl = '/rest/v1/';	//URL to get users divisions

	private getUserGroupsUrl = '/rest/v1/authorization/users/groups';	//URL to get users group

	private apiUrl: string;

	private authToken: string = this.config.authToken;

	constructor(private http: HttpClient,@Inject(APP_CONFIG) private config: IAppConfig) { 
		if(isDevMode()){
			this.apiUrl = this.config.baseDevApiURL;
			this.editUserUrl = this.apiUrl + this.editUserUrl;
			this.getUserPhoneDetailsUrl = this.apiUrl + this.getUserPhoneDetailsUrl;
			this.getUserDivisionsUrl = this.apiUrl + this.getUserDivisionsUrl;
			this.getUserGroupsUrl = this.apiUrl + this.getUserGroupsUrl;
		}
	}

}
