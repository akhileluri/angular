import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {Observable, Subscription} from 'rxjs';
import {startWith, map} from 'rxjs/operators';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { EditUserService } from './edit-user.service';
import { AddNewUserService } from '../add-new-user/add-new-user.service';
import { ManageUsersService } from '../manage-users.service';
import {ErrorShowDialogComponent} from '../../error-show-dialog/error-show-dialog.component';
import {WarningMsgModalComponent} from '../../warning-msg-modal/warning-msg-modal.component';
import { AuthInterceptorService } from 'ui-auth-interceptor';
import { Store } from '@ngrx/store';
import { State } from '../../state/state';
import * as AdminActions from '../../state/actions';


@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css'],
  providers: [EditUserService,AddNewUserService]
})

export class EditUserComponent implements OnInit {

  divisionCtrl = new FormControl('', []);
  divisions = [];
  groups = [];
  user = {} as any;
  lastSelectedDivision = {} as any;
  errMessage: string = '';
  hasError: boolean = false;
  authToken: string = '';
  assignDivisions = [];
  unAssignDivisions = [];
  allDivision: boolean = false;
  isAssigned = 'assigned';
  searchText: string = '';
  searchTextGroup: string = '';
  defaultOrg: string = '';
  defaultDivisionCtrl: FormControl;
  filteredDivisions: Observable<any[]>;
  emailFormControl: FormControl;
  phoneNumberFormControl: FormControl;
  policies = [];
  policySelected : boolean = true;
  showPolicies : boolean = false;
  groupDetailsList = [];
  actions = [];
  list = [];
  finalList = [];
  grpSelectList = [];
  arrList = [];
  arrPolicyExternalId = [];
  arrActionExternalId = [];
  account$:Observable<any>;
  userInfoSub: Subscription;
  userActionsList =  [ ];
  userObj:any = {userName:'',userEmail:'',actions:[]};
  
  constructor(private router:Router,
    private route: ActivatedRoute,
    private addNewUserService: AddNewUserService,
    private editUserService: EditUserService,
    private manageUsersService: ManageUsersService,
    public dialog: MatDialog,
    private state: Store<State>) {
    
    this.account$ = this.state.select(st => st.userInfo);
    this.defaultDivisionCtrl = new FormControl();
    this.filteredDivisions = this.defaultDivisionCtrl.valueChanges
    .pipe(
      startWith(''),
      map(division => division ? this.filterDivisions(division) : this.divisions.slice())
    );

    this.emailFormControl = new FormControl('', [
      Validators.required,
      Validators.minLength(10),
      Validators.maxLength(10),
      Validators.pattern('[0-9]+')
    ]);

    this.phoneNumberFormControl = new FormControl('', [
      Validators.required,
      Validators.minLength(10),
      Validators.maxLength(10),
      Validators.pattern('[0-9]+')
    ]);
  }

  filterDivisions(name: string) {
    return this.finalList.filter(division =>
      division.name.toLowerCase().indexOf(name.toLowerCase()) === 0);
  }

  showErrorDialog(errMessage): void {
    let dialogRef = this.dialog.open(ErrorShowDialogComponent, {
      width: '500px',
      data: { text: errMessage}
    });
  }

  showWarningDialog(errMessage): void {
    let dialogRef = this.dialog.open(WarningMsgModalComponent, {
      width: '500px',
      data: { text: errMessage}
    });
  }

  ngOnInit() {
    if(this.manageUsersService.getEditUserObj()){
      this.user = this.manageUsersService.getEditUserObj();
      let temp = {} as any;
      temp.id = this.user.ownerId;
      this.getAllGroupDetails(temp);
    }
    else{
      this.router.navigateByUrl('/landing/manage-users');
    }
   

    this.userInfoSub = this.account$.subscribe(data => {
      if(data){
        this.userActionsList = data['actions'];
        this.userObj = {userName:data.userName,userEmail:data.emailAddress,actions: data.actions};
        this.divisions = data.divisions;
        this.assignDivisions = data.divisions;
        this.getUserDivisions();
        this.convertRawDivision();
        
        }
      
    });
  }


  getUserDivisions = function(){
    this.editUserService.getUserDivisions(this.user).subscribe((data) => {
      var assignDivisions = data.divisions;
       
      for(let i=0;i<this.divisions.length;i++){
         for(let j=0;j<assignDivisions.length;j++){
            if(this.divisions[i].id == assignDivisions[j].id){
               let x = this.divisions[i];
               x['checked'] =  true;
            }
         }
      }
      this.convertRawDivision();
       
    }, (err) => {
        if(err.status == 403){
          this.showErrorDialog('Forbidden');
        }
        else if(err.status == 'FAILURE'){
          this.showErrorDialog('You do not have admin rights to view divisions.');
        }
        else if(err.status == 404){
          this.showErrorDialog('Not Found');
        }
        else if(err.status == 500){
          this.showErrorDialog('Fetching Data was unsuccessful!');
        }
        else{
          this.errMessage = err.status + '-' + err.statusText;
          this.hasError = true;
        }
    });
  }

  convertRawDivision = function(){
    let x = this.divisions.map(y => Object.assign({}, y));
    var flag = true;
    for(var i=0;i<x.length;i++){
      flag = true;
      if(x[i].parentId == null){
        this.list[x[i].id] = x[i];
        this.list[x[i].id].sublist = [];
        flag = false;
      }
      else if(this.list[x[i].parentId]){
          this.list[x[i].parentId].sublist[x[i].id] = x[i];
          this.list[x[i].parentId].sublist[x[i].id].sublist = [];
          flag = false;
      }
      else{
        for(var j=0;j<this.list.length;j++){
          if(this.list[j] && this.list[j].sublist[x[i].parentId]){
            this.list[j].sublist[x[i].parentId].sublist[x[i].id] = x[i];
            flag = false;
          }
        }
      }
      if(flag){
        x[i].name = '../' + x[i].parentName + '/' + x[i].name;
        this.list[x[i].id] = x[i];
        this.list[x[i].id].sublist = [];
      }
    }

    this.finalList = this.list.filter(value => Object.keys(value).length !== 0);
    for (var i = 0; i < this.finalList.length; i++) {
      if(this.finalList[i]){
       var temp = this.finalList[i].sublist.filter(value => Object.keys(value).length !== 0);
       this.finalList[i].sublist = temp;
      }
    }
    for (var i = 0; i < this.finalList.length; i++) {
      if(this.finalList[i]){
        for (var j = 0; j < this.finalList[i].sublist.length; j++) {
          if(this.finalList[i].sublist[j]){
            var temp = this.finalList[i].sublist[j].sublist.filter(value => Object.keys(value).length !== 0);
            this.finalList[i].sublist[j].sublist = temp;
          }
        }
      }
    }
    console.log(this.finalList); 
  }

  getAllGroupDetails = function(obj){
    this.manageUsersService.getAllGroupDetails(obj,this.user).subscribe((data) => {
        this.groupDetailsList = data;
        for(let i=0;i<this.groupDetailsList.length;i++){
          if(this.groupDetailsList[i].assigned){
            this.groupSelected(this.groupDetailsList[i],i);
          }
        }
    }, (err) => {
        if(err.status == 403){
          this.showErrorDialog('You do not have admin rights to view Groups.');
        }
        
        else if(err.status == 404){
          this.showErrorDialog('Not Found');
        }
        else if(err.status == 500){
          this.showErrorDialog('Fetching Data was unsuccessful!');
        }
        else{
          this.errMessage = err.status + '-' + err.statusText;
          this.hasError = true;
        }
    });
  }

  getUserGroups = function(){
    this.editUserService.getUserGroups(this.user).subscribe((data) => {
      if(data.success){
        var assignedGroups = data.resource.group.items;
        for(let i=0;i<this.groups.length;i++){
          let flag = false;
          for(let j=0;j<assignedGroups.length;j++){
            if(this.groups[i].externalGroupId == assignedGroups[j].externalGroupId){
              this.groups[i].checked=true;
            }
          }
        }
      }
    }, (err) => {
        if(err.status == 403){
          this.showErrorDialog('Forbidden');
        }
        else if(err.status == 404){
          this.showErrorDialog('Not Found');
        }
        else if(err.status == 500){
          this.showErrorDialog('Fetching Data was unsuccessful!');
        }
        else{
          this.errMessage = err.status + '-' + err.statusText;
          this.hasError = true;
        }
    });
  }

  groupSelected = function(group,index){
    var index = this.grpSelectList.indexOf(group);
    if(index >= 0){
      this.grpSelectList.splice(index,1);
    }else{
      this.grpSelectList.push(group);
    }
    if(group.assigned){
      for(let i=0;i<group.policies.length;i++){
        var policyIndex = this.isPolicyExternalIdExist(group.policies[i].externalPolicyId);
        if(policyIndex < 0){
          this.policies.push(group.policies[i]);
          this.arrPolicyExternalId[group.policies[i].externalPolicyId] = 1;
        }
        else{
          this.arrPolicyExternalId[group.policies[i].externalPolicyId]++;
        }
        if(group.policies[i].actions && group.policies[i].actions.length > 0){
          for(let j=0;j<group.policies[i].actions.length;j++){
            var actionIndex = this.isActionExternalIdExist(group.policies[i].actions[j].externalActionId);
            if(actionIndex < 0){
              this.actions.push(group.policies[i].actions[j]);
              this.arrActionExternalId[group.policies[i].actions[j].externalActionId] = 1;
            }
            else{
              this.arrActionExternalId[group.policies[i].actions[j].externalActionId]++;
            }
          }
        }
      }
    }
    else{
      for(let i=0;i<group.policies.length;i++){
        if(group.policies[i].actions && group.policies[i].actions.length > 0){
          for(let j=0;j<group.policies[i].actions.length;j++){
            if(this.arrActionExternalId[group.policies[i].actions[j].externalActionId] > 1){
              this.arrActionExternalId[group.policies[i].actions[j].externalActionId]--;
            }
            else{
              delete this.arrActionExternalId[group.policies[i].actions[j].externalActionId];
              let index = this.actions.indexOf(group.policies[i].actions[j]);
              this.actions.splice(index,1);
            }
          }
        }
        if(this.arrPolicyExternalId[group.policies[i].externalPolicyId] > 1){
          this.arrPolicyExternalId[group.policies[i].externalPolicyId]--;
        }
        else{
          delete this.arrPolicyExternalId[group.policies[i].externalPolicyId];
          let index = this.policies.indexOf(group.policies[i]);
          this.policies.splice(index,1);
        }
      }
    }

    let arr2 = [];
    this.arrList = [];
    for(let j=0;j<this.actions.length;j++){
      if(arr2.indexOf(this.actions[j].resourceType) < 0){
        arr2.push(this.actions[j].resourceType);
        this.arrList.push({"resourceType" : this.actions[j].resourceType ,"names" : []});
      }
    }
    for(let i=0;i<this.arrList.length;i++){
      for(let j=0;j<this.actions.length;j++){
        if(this.arrList[i].resourceType == this.actions[j].resourceType){
          this.arrList[i].names.push(this.actions[j].name);
        }
      }
    }
  }

  isPolicyExternalIdExist = function(policyExternalId){
    if(this.arrPolicyExternalId[policyExternalId]){
      return 1;
    }
    return -1;
  }

  isActionExternalIdExist = function(actionExternalId){
    if(this.arrActionExternalId[actionExternalId]){
      return 1;
    }
    return -1;
  }

  isPolicyExist = function(policy){
    for(let j=0;j<this.policies.length;j++){
      if(policy.externalPolicyId == this.policies[j].externalPolicyId)
      {
        return j;
      }
    }
    return -1;
  }

  divisionSelected = function(division){
    
    //this.lastSelectedDivision.checked = false;
    this.showWarningDialog('You are changing the division.');
    this.lastSelectedDivision.disabled = false;
    division.checked = true;
    division.disabled = true;
    this.lastSelectedDivision = division;
    this.user.ownerId = division.id;
    this.user.ownerName = division.name;
    this.actions = [];
    this.policies = [];
    this.grpSelectList = [];
    this.arrList = [];
    this.arrPolicyExternalId = [];
    this.arrActionExternalId = [];
    this.getAllGroupDetails(division);
  }

  selectInnerDivision = function(division,flag){
    division.checked = flag;
    division.showPlus = flag;
    if(division.sublist.length > 0){
      for(let i=0;i<division.sublist.length;i++){
        division.sublist[i].checked = flag;
      }
    }
  }

  selectAllDivisions = function(){
    for(let i=0;i<this.assignDivisions.length;i++){
      if(!this.assignDivisions[i].disabled){
        this.assignDivisions[i].checked = this.allDivision;
      }
    }
  }

  save = function(){
    
    let temp ={"divisions" : []};
    
    
    for (var i = 0; i < this.finalList.length; i++) {
      if(this.finalList[i].checked){
        let divisionObj = {} as any;
        divisionObj.id = this.finalList[i].id;
        divisionObj.accessChild = true;
        temp.divisions.push(divisionObj);
      }
    }
    for (var i = 0; i < this.finalList.length; i++) {
      for (var j = 0; j < this.finalList[i].sublist.length; j++) {
        if(this.finalList[i].sublist[j].checked){
          let divisionObj = {} as any;
          divisionObj.id = this.finalList[i].sublist[j].id;
          divisionObj.accessChild = true;
          temp.divisions.push(divisionObj);
        }
      }
    }
    for (var i = 0; i < this.finalList.length; i++) {
      for (var j = 0; j < this.finalList[i].sublist.length; j++) {
        for (var k = 0; k < this.finalList[i].sublist[j].sublist.length; k++) {
          if(this.finalList[i].sublist[j].sublist[k].checked){
            let divisionObj = {} as any;
            divisionObj.id = this.finalList[i].sublist[j].sublist[k].id;
            divisionObj.accessChild = true;
            temp.divisions.push(divisionObj);
          }
        }
      }
    }
    //groups data
    var groupURI  = '';
    for(let i=0;i<this.groupDetailsList.length;i++){
      if(this.groupDetailsList[i].assigned){
        groupURI += '&groupURI='+  this.groupDetailsList[i].self;
      }
    }
   let usrObj = {} as any;
   usrObj.service = 'TW';
   usrObj.id = this.user.id;
   usrObj.firstName = this.user.firstName;
   usrObj.lastName = this.user.lastName;
   usrObj.middleName = this.user.middleName;
   usrObj.suffix = "";
   usrObj.ownerId = this.user.ownerId;
   usrObj.primaryPhone = this.user.primaryPhone;
   usrObj.backupPhone = this.user.backupPhone;
   usrObj.primaryPhoneHasSMS = true; 
   usrObj.backupPhoneHasSMS = false;    
  //  usrObj.uniqueId = this.user.uniqueId ? this.user.uniqueId : null;
   this.editUserService.editUser(usrObj).subscribe((data) => {
      this.addNewUserService.assignDivisions(this.user,temp,this.user).subscribe((data) => {
        if(this.user.ownerName != 'EXP System Admin'){
          this.manageUsersService.saveUserGroups(this.user,groupURI).subscribe((data) => {
            if(data.success){
              this.router.navigateByUrl('/landing/manage-users/users');
            }
          }, (err) => {
              if(err.status == 403){
                this.showErrorDialog('Forbidden');
              }
              else if(err.status == 404){
                this.showErrorDialog('Not Found');
              }
              else if(err.status == 500){
                this.showErrorDialog('Mapping Groups was unsuccessful for Selected Default Division!');
              }
              else{
                this.errMessage = err.status + '' + 'Status Code';
                this.hasError = true;
              }
          });
        }
        else{
          this.router.navigateByUrl('/landing/manage-users/users');
        }
      }, (err) => {
        if(err.status == 403){
          this.showErrorDialog('User Updated but for assining divisions you do not have admin rights.');
        }
        else if(err.status == 404){
          this.showErrorDialog('Not Found');
        }
        else if(err.status == 500){
          this.showErrorDialog('Fetching Data was unsuccessful!');
        }
      });
    }, (err) => {
      if(err.status == 304){
        this.showErrorDialog('Not Updated.');
      }
      else if(err.status == 403){
        this.showErrorDialog('Forbidden');
      }
      else if(err.status == 404){
        this.showErrorDialog('Not Found');
      }
      else if(err.status == 500){
        this.showErrorDialog('Fetching Data was unsuccessful!');
      }
      else{
        this.showErrorDialog('You do not have admin rights to make this change.');
      }
      if(err.status == 409){
        this.errMessage = ' User exists';
      }
      this.errMessage = err.status + '' + 'Status Code';
      this.hasError = true;
    });
  }

  cancel = function(){
    this.router.navigateByUrl('/landing/manage-users/users');
  }

}
