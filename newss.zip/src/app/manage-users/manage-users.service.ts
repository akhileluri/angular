import { Injectable, Inject, isDevMode} from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { catchError } from 'rxjs/internal/operators/catchError';
import { Observable } from 'rxjs';
import { APP_CONFIG, IAppConfig } from '../app.config';
import { AuthInterceptorService } from 'ui-auth-interceptor';

@Injectable()
export class ManageUsersService {

	getEditUserObj(){
		return this.userObject;
	}

	setEditUserObj(user){
		this.userObject = user;
	}

	getGroups() : Observable<Object> {
		return this.http.get(this.getGroupsUrl,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
		//.catch(AuthInterceptorService.handleError);
	}

	getGroupPolicies(data) : Observable<Object> {
		return this.http.get(this.getGroupPoliciesUrl + data.externalGroupId + '/policies',{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
		//.catch(AuthInterceptorService.handleError);
	}

	saveUserGroups(user,groupURI) : Observable<Object> {
		var flag = true;
		var userId = user.userId ? user.userId : user.id;
		var userURI = window.location.protocol+'//'+window.location.hostname+'/rest/v1/authorization/users/'+ userId;
		return this.http.post(this.saveUserGroupsUrl+'?userURI=' + userURI + groupURI+'&orgId='+user.ownerId+'&removeExisting='+flag,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
		//.catch(AuthInterceptorService.handleError);
	}

	getAllGroupDetails(data,user) : Observable<Object> {
		var userId = '';
		if(user && user.id){
			 userId = '?userId=' + user.id;
		   }
		 
		return this.http.get(this.getAllGroupDetailsUrl+data.id+userId,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
		//.catch(AuthInterceptorService.handleError);
	}

	private userObject: Object;

	private searchItem: Object;
	
	private apiUrl: string;

	private authToken: string = this.config.authToken;

	private getGroupsUrl = '/rest/v1/authorization/groups';	//URL to get groups list

	private getGroupPoliciesUrl = '/rest/v1/authorization/groups/';	//URL to get policies for group

	private saveUserGroupsUrl = '/rest/v1/authorization/groups/user';	//URL to save users group

	private getAllGroupDetailsUrl = '/rest/v1/authorization/user/';	//URL to get groups list with related policies & actions

	constructor(private http: HttpClient,@Inject(APP_CONFIG) private config: IAppConfig) { 
		if(isDevMode()){
			this.apiUrl = this.config.baseDevApiURL;
			this.getGroupsUrl = this.apiUrl + this.getGroupsUrl;
			this.getGroupPoliciesUrl = this.apiUrl + this.getGroupPoliciesUrl;
			this.saveUserGroupsUrl = this.apiUrl + this.saveUserGroupsUrl;
			this.getAllGroupDetailsUrl = this.apiUrl + this.getAllGroupDetailsUrl;
		}
	}

}
