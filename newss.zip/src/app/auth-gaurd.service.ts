import { Injectable, Inject, isDevMode} from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { catchError } from 'rxjs/internal/operators/catchError';
import { APP_CONFIG, IAppConfig } from './app.config';
import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import { Subscription, Observable } from 'rxjs';
import { AddNewUserService } from './manage-users/add-new-user/add-new-user.service';

import { Store } from '@ngrx/store';
import { State } from './state/state';
import * as AdminActions from './state/actions';
@Injectable()
export class AuthGaurdService {

  account$:Observable<any>;
  userInfoSub: Subscription;
	
	routesWithActions = [
		{
			'url' : '/landing/manage-users/users',
			'actions' : ['LIST_USER']
		},
		{
			'url' : '/useradmin/landing/manage-users/users',
			'actions' : ['LIST_USER']
		},

		{
			'url' : '/landing/manage-users/add-new-user',
			'actions' : ['LIST_USER','ACCESS_POLICY_GROUP_LIST','CREATE_USER','EDIT_USER','ACCESS_POLICY_GROUP_EDIT']
		},
		{
			'url' : '/useradmin/landing/manage-users/add-new-user',
			'actions' : ['LIST_USER','ACCESS_POLICY_GROUP_LIST','CREATE_USER','EDIT_USER','ACCESS_POLICY_GROUP_EDIT']
		},

		{
			'url' : '/landing/manage-users/edit-user',
			'actions' : ['LIST_USER','ACCESS_POLICY_GROUP_LIST','EDIT_USER','ACCESS_POLICY_GROUP_EDIT']
		},
		{
			'url' : '/useradmin/landing/manage-users/edit-user',
			'actions' : ['LIST_USER','ACCESS_POLICY_GROUP_LIST','EDIT_USER','ACCESS_POLICY_GROUP_EDIT']
		},

		{
			'url' : '/landing/manage-groups/add-new-group',
			'actions' : ['ACCESS_POLICY_LIST','ACCESS_POLICY_ACTION_LIST','ACCESS_POLICY_GROUP_EDIT']
		},
		{
			'url' : '/useradmin/landing/manage-groups/add-new-group',
			'actions' : ['ACCESS_POLICY_LIST','ACCESS_POLICY_ACTION_LIST','ACCESS_POLICY_GROUP_EDIT']
		},

		{
			'url' : '/landing/manage-groups/edit-group',
			'actions' : ['ACCESS_POLICY_LIST','ACCESS_POLICY_ACTION_LIST','ACCESS_POLICY_GROUP_EDIT']
		},
		{
			'url' : '/useradmin/landing/manage-groups/edit-group',
			'actions' : ['ACCESS_POLICY_LIST','ACCESS_POLICY_ACTION_LIST','ACCESS_POLICY_GROUP_EDIT']
		},

		{
			'url' : '/landing/manage-groups/show-group-users',
			'actions' : ['ACCESS_POLICY_GROUP_EDIT']
		},
		{
			'url' : '/useradmin/landing/manage-groups/show-group-users',
			'actions' : ['ACCESS_POLICY_GROUP_EDIT']
		},

		{
			'url' : '/landing/manage-groups/groups',
			'actions' : ['ACCESS_POLICY_GROUP_LIST']
		},
		{
			'url' : '/useradmin/landing/manage-groups/groups',
			'actions' : ['ACCESS_POLICY_GROUP_LIST']
		},

		{
			'url' : '/landing/divisions',
			'actions' : []
		},
		{
			'url' : '/useradmin/landing/divisions',
			'actions' : []
		},
		{
			'url' : '/landing',
			'actions' : []
		},
		{
			'url' : '/useradmin/landing',
			'actions' : []
		},

		{
			'url' : '/landing/manage-policies/add-new-policy',
			'actions' : ['ACCESS_POLICY_LIST','ACCESS_POLICY_ACTION_LIST','ACCESS_POLICY_EDIT']
		},
		{
			'url' : '/useradmin/landing/manage-policies/add-new-policy',
			'actions' : ['ACCESS_POLICY_LIST','ACCESS_POLICY_ACTION_LIST','ACCESS_POLICY_EDIT']
		},
		
		{
			'url' : '/landing/manage-policies/edit-policy',
			'actions' : ['ACCESS_POLICY_LIST','ACCESS_POLICY_ACTION_LIST','ACCESS_POLICY_EDIT']
		},
		{
			'url' : '/useradmin/landing/manage-policies/edit-policy',
			'actions' : ['ACCESS_POLICY_LIST','ACCESS_POLICY_ACTION_LIST','ACCESS_POLICY_EDIT']
		},

		{
			'url' : '/landing/manage-policies/policies',
			'actions' : ['ACCESS_POLICY_LIST']
		},
		{
			'url' : '/useradmin/landing/manage-policies/policies',
			'actions' : ['ACCESS_POLICY_LIST']
		}
	];
	
	routesWithAssociatedActionsList = [];

	redirectURL = '';

	setRedirectURL(url){
		this.redirectURL = url;
	}

	getRedirectURL(){
		return this.redirectURL;
	}

	createRoutesWithAssociatedActionsList(){
		for(let i=0;i<this.routesWithActions.length;i++){
			this.routesWithAssociatedActionsList[this.routesWithActions[i].url] = this.routesWithActions[i].actions;
		}
	}

	isValidUser(url,userActionsList){
		this.setRedirectURL(url);
		url = url.split("?")[0];
		
		this.createRoutesWithAssociatedActionsList();
		for(let i=0;i<this.routesWithAssociatedActionsList[url].length;i++){
			if(userActionsList.indexOf(this.routesWithAssociatedActionsList[url][i]) == -1){
				return false;
			}
		}
		return true;
	}

	private apiUrl: string;

	constructor(private http: HttpClient,@Inject(APP_CONFIG) private config: IAppConfig,private state: Store<State>) { 
	
		if(isDevMode()){
			this.apiUrl = this.config.baseDevApiURL;
		}
	}

}
