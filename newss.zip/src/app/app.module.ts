import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MatCardModule,MatDialogModule, MatMenuModule, MatInputModule, MatButtonModule, MatToolbarModule, MatPaginatorModule, MatGridListModule,
  MatSelectModule, MatIconModule, MatIconRegistry, MatTabsModule,MatTableModule, MatCheckboxModule, MatProgressSpinnerModule, MatRadioModule, MatSlideToggleModule,MatExpansionModule,MatDividerModule} from '@angular/material';
import {MatSortModule} from '@angular/material/sort';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import { FormsModule, ReactiveFormsModule  }   from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {HttpModule} from '@angular/http';

import { AppComponent } from './app.component';

import {AuthInterceptorModule, AuthInterceptorService} from 'ui-auth-interceptor';

import {HeaderModule, HelpDialogModule} from 'ui-header-module';
import { ManageUsersComponent } from './manage-users/manage-users.component';
import { UsersComponent } from './manage-users/users/users.component';
import { AddNewUserComponent } from './manage-users/add-new-user/add-new-user.component';
import {HTTP_INTERCEPTORS } from '@angular/common/http';
// import { AuthInterceptor } from './auth.interceptor';
import {APP_CONFIG, AppConfig} from './app.config';
import { EditUserComponent } from './manage-users/edit-user/edit-user.component';
import { FilterPipe} from './manage-users/filter.pipe';
import {UserModalDialog} from './manage-users/users/users.component';
import {ErrorShowDialogComponent} from './error-show-dialog/error-show-dialog.component';
import { GroupsComponent } from './manage-groups/groups/groups.component';
import { DivisionsComponent } from './divisions/divisions.component';
import {CdkDetailRowDirective} from './divisions/cdk-detail-row.directive';
import { AddGroupComponent } from './manage-groups/add-group/add-group.component';
import { ManageGroupsComponent } from './manage-groups/manage-groups.component';
import { ConfirmationShowDialogComponent } from './confirmation-show-dialog/confirmation-show-dialog.component';
import { LandingComponent } from './landing/landing.component';
import { ManagePoliciesComponent } from './manage-policies/manage-policies.component';
import { AddNewPolicyComponent } from './manage-policies/add-new-policy/add-new-policy.component';
import { PoliciesComponent } from './manage-policies/policies/policies.component';
import { EditGroupComponent } from './manage-groups/edit-group/edit-group.component';
import { EditPolicyComponent } from './manage-policies/edit-policy/edit-policy.component';
import { ShowRelatedUsersComponent } from './manage-groups/show-related-users/show-related-users.component';
import { WarningMsgModalComponent } from './warning-msg-modal/warning-msg-modal.component';
import {NgxMaskModule} from 'ngx-mask';
import {AlwaysAuthGuard} from './always-auth-guard';
import {AuthGaurdService} from './auth-gaurd.service';
import { UnauthorisedUserComponent } from './unauthorised-user/unauthorised-user.component';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { ExpandButtonModule, BKSortHeaderModule, BigPlusButtonModule } from 'ui-widgets';

import { reducerMap } from './state/reducer';
import { Effects } from './state/effects';
import { EffectsModule } from '@ngrx/effects';
import { AddNewUserService } from './manage-users/add-new-user/add-new-user.service';
import { RoutingModule } from './routing.module';

@NgModule({
  declarations: [
    AppComponent,
    UsersComponent,
    ManageUsersComponent,
    AddNewUserComponent,
    EditUserComponent,
    FilterPipe,
    UserModalDialog,
    ErrorShowDialogComponent,
    GroupsComponent,
    PoliciesComponent,
    DivisionsComponent,
    CdkDetailRowDirective,
    AddGroupComponent,
    ManageGroupsComponent,
    ConfirmationShowDialogComponent,
    LandingComponent,
    AddNewPolicyComponent,
    ManagePoliciesComponent,
    EditGroupComponent,
    EditPolicyComponent,
    ShowRelatedUsersComponent,
    WarningMsgModalComponent,
    UnauthorisedUserComponent
  ],
  imports: [
    BrowserModule,
    RoutingModule,
    HttpClientModule,
    HttpModule,
    MatSelectModule,
    ReactiveFormsModule,
    FormsModule,
    BrowserModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatInputModule,
    MatMenuModule,
    MatDialogModule,
    MatToolbarModule,
    MatIconModule,
    MatCardModule,
    HeaderModule,
    HelpDialogModule,
    AuthInterceptorModule,
    MatTabsModule,
    MatPaginatorModule,
    MatTableModule,
    MatCheckboxModule,
    MatGridListModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatSortModule,
    MatAutocompleteModule,
    MatSlideToggleModule,
    MatExpansionModule,
    MatDividerModule,
    NgxMaskModule.forRoot(),
    StoreModule.forRoot(reducerMap),
    EffectsModule.forRoot([Effects])
  ],
  entryComponents: [UserModalDialog,ErrorShowDialogComponent,ConfirmationShowDialogComponent,WarningMsgModalComponent],
  providers: [{ provide: APP_CONFIG, useValue: AppConfig },AlwaysAuthGuard,AuthGaurdService,AddNewUserService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule { }
