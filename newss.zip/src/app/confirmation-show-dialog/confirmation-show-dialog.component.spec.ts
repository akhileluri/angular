import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmationShowDialogComponent } from './confirmation-show-dialog.component';

describe('ConfirmationShowDialogComponent', () => {
  let component: ConfirmationShowDialogComponent;
  let fixture: ComponentFixture<ConfirmationShowDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfirmationShowDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmationShowDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
