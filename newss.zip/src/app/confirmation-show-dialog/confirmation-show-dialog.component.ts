import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef, MatSelect, MatInput} from '@angular/material';

@Component({
  selector: 'app-confirmation-show-dialog',
  templateUrl: './confirmation-show-dialog.component.html',
  styleUrls: ['./confirmation-show-dialog.component.css']
})
export class ConfirmationShowDialogComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<ConfirmationShowDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
  }

  onYesClick(val): void {
    this.dialogRef.close(val);
  }

}
