import { Component, isDevMode } from '@angular/core';
import { Router ,ActivatedRoute,Params, NavigationStart} from '@angular/router';
import { Subscription, Observable } from 'rxjs';
import { AddNewUserService } from './manage-users/add-new-user/add-new-user.service';

import { Store } from '@ngrx/store';
import { State } from './state/state';
import * as AdminActions from './state/actions';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[AddNewUserService]
})
export class AppComponent {
  routeSub: Subscription;
  searchVal:String='';
  lastFilter:number;
  lastSearch:string;
  params:any;
  routeParamsSub: Subscription;
  searchAutoCompleteObj:any ={ searchOpts:[], value:'', placeholder:'Organization' };
  userObj:any = {userName:'',userEmail:'',actions:[]};
  account$:Observable<any>;
  userInfoSub: Subscription;
  isSearchEnabled:boolean=false;

  searchModules:string[] = ['/landing/manage-users/users', '/landing/manage-groups/groups','/landing/manage-policies/policies'];


  constructor(  protected router: Router,private activatedRoute: ActivatedRoute, private state: Store<State>){
    this.state.dispatch(new AdminActions.RequestedAccount());
    this.account$ = this.state.select(st => st.userInfo);
    
  }

  ngOnChanges(){
    
  }
  ngOnInit() {
    this.router.events.subscribe((event:any) => {
      
      if(event instanceof NavigationStart || event.constructor.name == "NavigationStart") {
        this.isSearchEnabled = event.url ? this.hasSearch(event.url) : false;
      }
    });
    this.routeSub = this.activatedRoute.queryParams.subscribe(params =>{
      if(params && params['search']){
        this.searchVal = params['search'];
      }
      if(params && params['organization']){
        this.searchAutoCompleteObj.value = params['organization'] ? params['organization'] : '';
      }
    }); 

    
    this.userInfoSub = this.account$.subscribe(data => {
      
      if(data){
        this.userObj = {userName:data.userName,userEmail:data.emailAddress,actions: data.actions};
        for(let division of data.divisions){
          this.searchAutoCompleteObj.searchOpts.push(division.name);
        }
      }
    }, (err) => {
        console.log('Error');
    });
  }
  
  ngOnDestroy() {
    if (this.routeSub) {
      this.routeSub.unsubscribe();
    }
    if (this.userInfoSub) {
      this.userInfoSub.unsubscribe();
    }
  }
  onSearchEvent(event) {
    if (event.type === 'search' || event.type === 'btnSearch') {
      var appendQryLink  = (event.value ? 'search='+encodeURIComponent(event.value)+'&' : "")
              +(event.adminSearch ? 'organization='+encodeURIComponent(event.adminSearch) : '');
      window.location.href = this.getWorkspacesLink()+'?'+appendQryLink;
    } else if (event.type === 'searchValueChange') {
      if(event.clickType === 'xClear' && window.location.href.indexOf('search') > -1) {
          window.location.href = this.getWorkspacesLink() ;
      }
      
    }
  }

  getWorkspacesLink() {
      const address = window.location.href.split('?')[0];
      return address;
  }

  hasSearch(eventUrl:string):boolean{  
    eventUrl = eventUrl.split('?')[0];
    return this.searchModules.findIndex(url => url == eventUrl) > -1;
  }
}
