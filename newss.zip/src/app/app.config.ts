import { InjectionToken } from '@angular/core';

export let APP_CONFIG = new InjectionToken('app.config');

export interface IAppConfig {
    finalURL: string;
    authToken: string;
    baseDevApiURL: string;
}

export const AppConfig: IAppConfig = {    
    finalURL: '/',
    authToken: 'eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE1MjA4OTIyNDIsInVzZXJfaWQiOiIxMjMzMzE1In0.vHH00OqFh5lUOhY0mOpNBKQ6pTz87276Jq4B9GXaptrOJPB8agyweN7u3q356IA9xzqLu_PdTYS6GxyOTi1IiA',
    baseDevApiURL: 'https://expedite500.qa.bkfstest.com'
};