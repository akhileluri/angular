import { Injectable, Inject, isDevMode} from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { catchError } from 'rxjs/internal/operators/catchError';
import {Observable} from 'rxjs';
import { APP_CONFIG, IAppConfig } from '../app.config';
import { AuthInterceptorService } from 'ui-auth-interceptor';

@Injectable()
export class SharedService {

	getEditGroupObj(){
		return this.groupObject;
	}

	setEditGroupObj(group){
		this.groupObject = group;
	}

	private apiUrl: string;

	private groupObject: Object;

	constructor(private http: HttpClient,@Inject(APP_CONFIG) private config: IAppConfig) { 
		if(isDevMode()){
			this.apiUrl = this.config.baseDevApiURL;
		}
	}
}
