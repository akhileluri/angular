import { Injectable, Inject, isDevMode} from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { catchError } from 'rxjs/internal/operators/catchError';

import {Observable} from 'rxjs';
import { APP_CONFIG, IAppConfig } from '../app.config';
import { AuthInterceptorService } from 'ui-auth-interceptor';

@Injectable()
export class ManageGroupsService {

	createGroup(data) : Observable<Object> {
		var payload = '?groupName='+data.groupName+'&externalGroupId='+data.externalGroupId;
		if(data.groupDescription){
			payload += '&groupDescription=' + data.groupDescription;
		}
		if(data.orgId){
			payload += '&orgId=' + data.orgId;
		}
		return this.http.post(this.createGroupsUrl+payload,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
		//.catch(AuthInterceptorService.handleError);
	}

	deleteGroup(data) : Observable<Object> {
		var payload = '';
		if(data && data.organizationId){
			payload = '?orgId=' + data.organizationId;
		}
		return this.http.delete(this.deleteGroupsUrl+data.externalGroupId+payload,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
		//.catch(AuthInterceptorService.handleError);
	}

	getPolicies(data) : Observable<Object> {
		var payload = '';
		if(data && data.id){
			payload = '?&orgId=' + data.id;
		}
		return this.http.get(this.getPoliciesUrl + payload,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError)).pipe(catchError( AuthInterceptorService.handleError));
		//.catch(AuthInterceptorService.handleError);
	}

	saveGroupPolicies(data,policyURI) : Observable<Object> {
		
		return this.http.post(this.saveGroupPoliciesUrl+'?policyURI='+policyURI+'&externalGroupId=' + data.externalGroupId,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
		//.catch(AuthInterceptorService.handleError);
	}

	getPoliciesForGroup(data) : Observable<Object> {
		var payload = '';
		if(data && data.organizationId){
			payload = '?orgId=' + data.organizationId;
		}
		return this.http.get(this.getPoliciesForGroupUrl + data.externalGroupId + '/policies' + payload,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
		//.catch(AuthInterceptorService.handleError);
	}

	mapPoliciesGroup(data,policyURI) : Observable<Object> {
		var payload = '';
		if(data && data.orgId){
			payload = '&orgId=' + data.orgId;
		}
		return this.http.post(this.mapPoliciesGroupUrl + data.externalGroupId + '/policies?'+policyURI + payload,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
		//.catch(AuthInterceptorService.handleError);
	}

	removePoliciesGroup(data,policyURI) : Observable<Object> {
		var payload = '';
		if(data && data.orgId){
			payload = '&orgId=' + data.orgId;
		}
		return this.http.delete(this.mapPoliciesGroupUrl + data.externalGroupId + '/policies?'+policyURI + payload,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
		//.catch(AuthInterceptorService.handleError);
	}

	getGroups(data) : Observable<Object> {
		var payload = '';
		
		if(data && data.organization){
			payload += '?orgId=' + data.organization;
		}
		return this.http.get(this.getGroupsUrl + payload,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
		//.catch(AuthInterceptorService.handleError);
	}


	updateGroup(data) : Observable<Object> {

		var payload = '?groupName='+data.name+'&externalGroupId='+data.externalGroupId;
		if(data.groupDescription){
			payload += '&groupDescription=' + data.groupDescription;
		}
		if(data.orgId){
			payload += '&orgId=' + data.orgId;
		}
		return this.http.put(this.updateGroupUrl + data.oldExternalGroupId +payload,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
		//.catch(AuthInterceptorService.handleError);
	}

	getUsersForGroup(data) : Observable<Object> {
		var payload = '';
		if(data && data.organizationId){
			payload = '?orgId=' + data.organizationId;
		}
		return this.http.get(this.getUsersForGroupUrl + data.externalGroupId + '/users'+payload,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
	}

	deleteUserForGroup(group,data) : Observable<Object> {
		var payload = '';
		if(data && group.organizationId){
			payload = '&orgId=' + group.organizationId;
		}
		return this.http.delete(this.deleteUserForGroupUrl + 'user?userURI='+data +'&groupURI='+group.self+payload,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
	}

	private apiUrl: string;

	private createGroupsUrl = '/rest/v1/authorization/groups';	//URL to save users group

	private deleteGroupsUrl = '/rest/v1/authorization/groups/';	//URL to delete a group

	private getPoliciesUrl = '/rest/v1/authorization/policies';	//URL to get policies list

	private saveGroupPoliciesUrl = '/rest/v1/authorization/groups/users';	//URL to save group policies

	private getPoliciesForGroupUrl = '/rest/v1/authorization/groups/';	//URL to get policies list for a group

	private mapPoliciesGroupUrl = '/rest/v1/authorization/groups/';	//URL to map policies list to group

	private getGroupsUrl = '/rest/v1/authorization/groups';	//URL to get groups list

	private updateGroupUrl = '/rest/v1/authorization/groups/';	//URL to update group

	private getUsersForGroupUrl = '/rest/v1/authorization/groups/';	//URL to get users list for a group

	private deleteUserForGroupUrl ='/rest/v1/authorization/groups/';

	constructor(private http: HttpClient,@Inject(APP_CONFIG) private config: IAppConfig) { 
		if(isDevMode()){
			this.apiUrl = this.config.baseDevApiURL;
			this.createGroupsUrl = this.apiUrl + this.createGroupsUrl;
			this.getPoliciesUrl = this.apiUrl + this.getPoliciesUrl;
			this.saveGroupPoliciesUrl = this.apiUrl + this.saveGroupPoliciesUrl;
			this.deleteGroupsUrl = this.apiUrl + this.deleteGroupsUrl;
			this.getPoliciesForGroupUrl = this.apiUrl + this.getPoliciesForGroupUrl;
			this.mapPoliciesGroupUrl = this.apiUrl + this.mapPoliciesGroupUrl;
			this.getGroupsUrl = this.apiUrl + this.getGroupsUrl;
			this.updateGroupUrl = this.apiUrl + this.updateGroupUrl;
			this.getUsersForGroupUrl = this.apiUrl + this.getUsersForGroupUrl;
			this.deleteUserForGroupUrl = this.apiUrl + this.deleteUserForGroupUrl;
		}
	}


}
