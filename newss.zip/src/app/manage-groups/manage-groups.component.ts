import { Component, OnInit } from '@angular/core';
import { SharedService } from './shared.service';

@Component({
  selector: 'app-manage-groups',
  templateUrl: './manage-groups.component.html',
  styleUrls: ['./manage-groups.component.css'],
  providers: [SharedService]
})
export class ManageGroupsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
