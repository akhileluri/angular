import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowRelatedUsersComponent } from './show-related-users.component';

describe('ShowRelatedUsersComponent', () => {
  let component: ShowRelatedUsersComponent;
  let fixture: ComponentFixture<ShowRelatedUsersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowRelatedUsersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowRelatedUsersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
