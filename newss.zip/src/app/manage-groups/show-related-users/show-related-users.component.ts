import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {Observable} from 'rxjs';
import {startWith, map} from 'rxjs/operators';
import {ViewChild} from '@angular/core';
import {MatPaginator, MatTableDataSource,MatSort} from '@angular/material';

import { ManageGroupsService } from '../manage-groups.service';
import { SharedService } from '../shared.service';

@Component({
  selector: 'app-show-related-users',
  templateUrl: './show-related-users.component.html',
  styleUrls: ['./show-related-users.component.css'],
  providers: [ManageGroupsService]
})
export class ShowRelatedUsersComponent implements OnInit {
	
	users = [
         
    ];
  	group = {} as any;
	errMessage: string = '';
	hasError: boolean = false;
	allSelected: boolean = false;
	itemSelectList = [];
	dataSource = new MatTableDataSource<any>(this.users);
	isActive=true;
	
	constructor(private manageGroupsService: ManageGroupsService,private sharedService:SharedService,private router:Router,private route: ActivatedRoute) 
	{  
		document.body.style.backgroundColor = "white";

  }

	ngOnInit() {
		/*if(this.sharedService.getEditGroupObj()){
	      this.group = this.sharedService.getEditGroupObj();
			this.route.queryParams.subscribe(params =>{
				if(params && params['organizationId'] && params['externalGroupId']){
					//this.group.self = params['self'];
					this.group.organizationId = params['organizationId'];
					this.group.externalGroupId = params['externalGroupId'];
					this.group.self= 'https://expedite500.qa.bkfstest.com'+'/rest/v1/authorization/groups/'+this.group.externalGroupId;
				}
			});*/
			this.route.params.subscribe( params =>{
				console.log(params);
				this.group.organizationId = params['organizationId'];
				this.group.externalGroupId = params['externalGroupId'];
				this.group.self= window.location.protocol+'//'+window.location.host+'/rest/v1/authorization/groups/'+this.group.externalGroupId;
				this.getUsersForGroup(this.group);
			});
	}
	ngOnDestroy(){
    document.body.style.backgroundColor="";
  }

	displayedColumns = ['select','firstName','delete'];

	@ViewChild(MatSort) sort: MatSort;

	@ViewChild(MatPaginator) paginator: MatPaginator;

	ngAfterViewInit() {
		this.dataSource.sort = this.sort;
		this.dataSource.paginator = this.paginator;
	}

	getUsersForGroup = function(group){
		
		this.manageGroupsService.getUsersForGroup(group).subscribe((data) => {
		  if(data.success && data.resource.user != null){
		    this.users = data.resource.user.items;
				this.dataSource = new MatTableDataSource<any>(this.users);
				this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
				this.isActive=false;
			}
			else {
				this.isActive=false;
			}
		}, (err) => {
			this.isActive=false;
		  this.errMessage = err.status + '-' + err.statusText;
		  this.hasError = true;
		});
	}

  	deleteUserForGroup = function(data){
		this.manageGroupsService.deleteUserForGroup(this.group,data).subscribe((data) => {
		  if(data.success){
				console.log('User Deleted.');
				window.location.reload();
		  }
		}, (err) => {
		  this.errMessage = err.status + '-' + err.statusText;
		  this.hasError = true;
		});
  	};

  	selectAllItem = function(){
	    this.itemSelectList = [];
	    for(let i=0;i<this.users.length;i++){
	      this.users[i].selected = this.allSelected;
	      if(this.allSelected){
	        this.itemSelectList.push(this.users[i]);
	      }
	    }
	};

	selectItem = function(item){
		let index = this.itemSelectList.indexOf(item);
		if(index >= 0){
		  this.itemSelectList.splice(index,1);
		}else{
		  this.itemSelectList.push(item);
		}
	};

	deleteAllItem = function(){
		let data = [];
		for(let i=0;i<this.itemSelectList.length;i++){
		  data.push(this.itemSelectList[i].self);
		}
		this.deleteUserForGroup(data);
	};

	deleteItem = function(item){
		this.deleteUserForGroup(item.self);
	};
}
