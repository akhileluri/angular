import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {Observable, Subscription} from 'rxjs';
import {startWith, map} from 'rxjs/operators';
import { ManageGroupsService } from '../manage-groups.service';
import { ManagePoliciesService } from '../../manage-policies/manage-policies.service';
import { AddNewUserService } from '../../manage-users/add-new-user/add-new-user.service';
import {ErrorShowDialogComponent} from '../../error-show-dialog/error-show-dialog.component';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { Store } from '@ngrx/store';
import { State } from '../../state/state';
import * as AdminActions from '../../state/actions';

@Component({
  selector: 'app-add-group',
  templateUrl: './add-group.component.html',
  styleUrls: ['./add-group.component.css'],
  providers: [ManageGroupsService,AddNewUserService,ManagePoliciesService]
})
export class AddGroupComponent implements OnInit {
	
	group = {} as any;
	errMessage: string = '';
  	grpNameFormControl: FormControl;
  	actionSelected = true;
  	actions = [];
  	externalGroupIdFormControl: FormControl;
		policies = [];
		defaultOrg: string = '';
		defaultDivisionCtrl: FormControl;
		filteredDivisions: Observable<any[]>;
		divisions = [];
		actionsList = [];
		finalActionsList=[];
		arrActionExternalId=[];
		userObj:any = {userName:'',userEmail:'',actions:[]};
		account$:Observable<any>;
		userInfoSub: Subscription;
		arrPolicyList = [];

	constructor(private managePoliciesService: ManagePoliciesService,
		private manageGroupsService: ManageGroupsService,
		private addNewUserService: AddNewUserService,
		private router:Router,public dialog: MatDialog,
		private route: ActivatedRoute,
		private state: Store<State>) { 
			this.account$ = this.state.select(st => st.userInfo); 
		this.defaultDivisionCtrl = new FormControl();
    this.filteredDivisions = this.defaultDivisionCtrl.valueChanges
    .pipe(
      startWith(''),
      map(division => division ? this.filterDivisions(division) : this.divisions.slice())
    );
		this.grpNameFormControl = new FormControl('', [
	      Validators.required
	    ]);

	    this.externalGroupIdFormControl = new FormControl('', [
	      Validators.required
	    ]);
	}

	filterDivisions(name: string) {
    return this.divisions.filter(division =>
      division.name.toLowerCase().indexOf(name.toLowerCase()) === 0);
  }

	ngOnInit() {
	
		this.getPolicies();

		this.userInfoSub = this.account$.subscribe(data => {
			if(data){
				this.divisions = data.divisions;
			
				this.userObj = {userName:data.userName,userEmail:data.emailAddress,actions: data.actions};
				}
			
		});
	}

	showErrorDialog(errMessage): void {
    let dialogRef = this.dialog.open(ErrorShowDialogComponent, {
      width: '500px',
      data: { text: errMessage}
    });
  }

    getPolicies = function(obj?){
	    this.manageGroupsService.getPolicies(obj).subscribe((data) => {
	      if(data.success){
			this.policies = data.resource.policy.items;
	      }
	    }, (err) => {
				if(err.status == 400){
          this.showErrorDialog('Bad Request');
        }
				if(err.status == 403){
					this.showErrorDialog('You are unauthorized to view policies.');
				}
				else if(err.status == 404){
					this.showErrorDialog('Not Found');
				}
				else if(err.status == 500){
					this.showErrorDialog('Fetching Data was unsuccessful!');
				}
				else{
					this.errMessage = err.status + '-' + err.statusText;
					this.hasError = true;
				}
	    });
	}

	divisionSelected = function(division){
		this.getPolicies(division);
		this.getActions();
	}

	getActions = function(){
		this.managePoliciesService.getActions().subscribe((data) => {
			if(data.success){
				this.actionsList = data.resource.action.items;
			}
		}, (err) => {
			if(err.status == 400){
				this.showErrorDialog('Bad Request');
			}
			else if(err.status == 403){
				this.showErrorDialog('You are unauthorized to view actions.');
			}
			else if(err.status == 'FAILURE' && err.developerMessage =='UnAuthorized' ){
				this.showErrorDialog('You do not have admin rights to make this change');
			}
			else if(err.status == 404){
				this.showErrorDialog('Not Found');
			}
			else if(err.status == 500){
				this.showErrorDialog('Fetching Data was unsuccessful!!');
			}
			else{
				this.errMessage = err.status + '-' + err.statusText;
				this.hasError = true;
			}
		});
}
	
selectPolicy = function(policy){
	if(policy.checked){
					this.arrPolicyList.push(policy);
			}
			else{
					let index = this.arrPolicyList.indexOf(policy);
					if(index > -1){
							this.arrPolicyList.splice(index,1);
					}
			}
			if(policy.checked){
					this.actions = policy.target.split(',');
					for(let i=0;i<this.actions.length;i++){
							for(let j=0;j<this.actionsList.length;j++){
									if(this.actionsList[j].externalActionId == this.actions[i]){
											let flag = false;
											for(let k=0;k<this.finalActionsList.length;k++){
													if(this.finalActionsList[k].resourceType ==  this.actionsList[j].resourceType){
															let index = this.finalActionsList[k].names.indexOf(this.actions[i]);
															if(index == -1){
																	this.finalActionsList[k].names.push(this.actions[i]);
																	this.finalActionsList[k].names2.push({'id' : this.actions[i], 'displayName' : this.actionsList[j].name});
																	this.arrActionExternalId[this.actions[i]] = 1;
															}
															else{
																	this.arrActionExternalId[this.actions[i]]++;
															}
															flag = true;
													}
											}
											if(!flag){
													let tempAction = {} as any;
													tempAction.resourceType = this.actionsList[j].resourceType;
													//tempAction.externalPolicyId = this.actions[i].externalPolicyId;
													tempAction.names = [];
													tempAction.names2 = [];
													tempAction.names.push(this.actions[i]);
													tempAction.names2.push({'id' : this.actions[i], 'displayName' : this.actionsList[j].name});
													this.finalActionsList.push(tempAction);
													this.arrActionExternalId[this.actions[i]] = 1;
											}
									}
							}
					}
			}
			else{
					let arr = policy.target.split(',');
					for(let k=0;k<arr.length;k++){
							if(this.arrActionExternalId[arr[k]] > 1){
								this.arrActionExternalId[arr[k]]--;
							}
							else{
									delete this.arrActionExternalId[arr[k]];
									//let indexAction = this.actions.indexOf(arr[k]);
									//this.actions.splice(indexAction,1);
									for(let i=0;i<this.finalActionsList.length;i++){
										let index = this.finalActionsList[i].names.indexOf(arr[k]);
										if(index > -1){
											for(let count=0;count<this.finalActionsList[i].names2.length;count++){
													if(this.finalActionsList[i].names[index] == this.finalActionsList[i].names2[count].id)
													this.finalActionsList[i].names2.splice(count,1);
											}
											this.finalActionsList[i].names.splice(index,1);
										}
									}
							}
					}
					for(let i=this.finalActionsList.length-1;i>=0;i--){
							if(this.finalActionsList[i].names.length == 0){
									this.finalActionsList.splice(i, 1);
							}
					}
			}
	}

	save = function(){
			console.log(this.group);
			for(let i=0;i<this.divisions.length;i++){
				if(this.divisions[i].name == this.defaultOrg){
					this.group.orgId = this.divisions[i].id;
				}
			} 
		this.group.externalGroupId ='Group' + Date.now();

	    //policy data 
	    var policyURI  = '';
	    for(let i=0;i<this.policies.length;i++){
	      if(this.policies[i].checked){
	        policyURI += '&policyURI='+this.policies[i].self;
	      }
	    }
	    this.manageGroupsService.createGroup(this.group).subscribe((data) => {
	    	if(data.success){
	    		this.manageGroupsService.mapPoliciesGroup(this.group,policyURI).subscribe((data) => {
		            if(data.success){
		              this.router.navigateByUrl('/landing/manage-groups/groups');
		            }
		        }, (err) => {
							if(err.status=403){
								this.showErrorDialog('You do not have admin rights to make this change.');
							}
							else{
								if(err.status == 400){
									this.showErrorDialog('Bad Request');
								}
								else if(err.status == 403){
									this.showErrorDialog('You are unauthorized to make this change.');
								}
								else if(err.status == 'FAILURE' && err.developerMessage =='UnAuthorized' ){
									this.showErrorDialog('You do not have admin rights to make this change');
								}
								else if(err.status == 404){
									this.showErrorDialog('Not Found');
								}
								else if(err.status == 500){
									this.showErrorDialog('User was created but Mapping policies to groups was unsuccessful!!');
								}
								else{
									this.errMessage = err.status + '-' + err.statusText;
									this.hasError = true;
								}
							}
							this.hasError = true;
		        });
	    	}
	    }, (err) => {
				if(err.status == 400){
          this.showErrorDialog('Bad Request');
        }
				else if(err.status == 403){
          this.showErrorDialog('You do not have admin rights to make this change.');
				}
				else if(err.status == 'FAILURE' && err.developerMessage =='UnAuthorized' ){
          this.showErrorDialog('You do not have admin rights to make this change');
        }
        else if(err.status == 404){
          this.showErrorDialog('Not Found');
        }
        else if(err.status == 500){
          this.showErrorDialog('Creating Data was unsuccessful!');
        }
        else{
          this.errMessage = err.status + '-' + err.statusText;
          this.hasError = true;
        }
	    });
	}

	cancel = function(){
		this.router.navigateByUrl('/landing/manage-groups/groups');
	}
}
