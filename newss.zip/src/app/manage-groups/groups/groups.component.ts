import { Component, OnInit, isDevMode } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {Observable, Subscription} from 'rxjs';
import {startWith, map} from 'rxjs/operators';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import {ViewChild} from '@angular/core';
import {MatPaginator, MatTableDataSource,MatSort} from '@angular/material';
import {ErrorShowDialogComponent} from '../../error-show-dialog/error-show-dialog.component';
import { ManageGroupsService } from '../manage-groups.service';
import { SharedService } from '../shared.service';
import {ConfirmationShowDialogComponent} from '../../confirmation-show-dialog/confirmation-show-dialog.component';
import { AddNewUserService } from '../../manage-users/add-new-user/add-new-user.service';
import { Store } from '@ngrx/store';
import { State } from '../../state/state';
import * as AdminActions from '../../state/actions';

@Component({
  selector: 'app-groups',
  templateUrl: './groups.component.html',
  styleUrls: ['./groups.component.css'],
  providers: [ManageGroupsService,AddNewUserService]
})
export class GroupsComponent implements OnInit {
	
	groups = [ ];
	errMessage: string = '';
	hasError: boolean = false;
	dataSource = new MatTableDataSource<any>(this.groups);
  groupDeleteConfirmMsg : string = 'Are you sure to delete this group ?'

  defaultOrg: string = '';
  defaultDivisionCtrl: FormControl;
  filteredDivisions: Observable<any[]>;
  divisions = [];
  routeSub:Subscription;
  isActive=true;

  searchParam: string = '';
  orgParam:string = '';
  searchVal:String='';
  lastFilter:number;
  lastSearch:string;
  params:any;
  routeParamsSub: Subscription;
  searchAutoCompleteObj:any ={ searchOpts:[], value:'', placeholder:'Organization' };
  userObj:any = {userName:'',userEmail:'',actions:[]};
  account$:Observable<any>;
  userInfoSub: Subscription;
  isSearchData: boolean = false;
  noSearchDataMessage: string = '';
  userActionsList=[];
  hasListUser : boolean = false;
  hasGroupEdit : boolean = false;
  
 
	constructor(
    private activatedRoute: ActivatedRoute,
    private manageGroupsService: ManageGroupsService,
    private sharedService:SharedService,
    public dialog: MatDialog,
    private router:Router,
    private route: ActivatedRoute,
    private addNewUserService: AddNewUserService,
    private state: Store<State>) { 
    this.account$ = this.state.select(st => st.userInfo); 
    this.defaultDivisionCtrl = new FormControl();
    this.filteredDivisions = this.defaultDivisionCtrl.valueChanges
    .pipe(
      startWith(''),
      map(division => division ? this.filterDivisions(division) : this.divisions.slice())
    );
  }

	ngOnInit() {
    this.userInfoSub = this.account$.subscribe(data => {
      if(data){
        this.divisions = data.divisions;
        this.userActionsList = data['actions'];  
        this.hasListUser  =  this.hasListUser  = this.includeAction(this.userActionsList,'ACCESS_POLICY_LIST') || this.includeAction(this.userActionsList,'ACCESS_POLICY_ACTION_LIST') ||  this.includeAction(this.userActionsList,'ACCESS_POLICY_GROUP_EDIT');
        this.hasGroupEdit = this.hasListUser  = this.includeAction(this.userActionsList,'ACCESS_POLICY_GROUP_EDIT');
        this.userObj = {userName:data.userName,userEmail:data.emailAddress,actions: data.actions};
        for(let division of data.divisions){
          this.searchAutoCompleteObj.searchOpts.push(division.name);
        }
        this.routeSub = this.activatedRoute.queryParams.subscribe(params =>{
          if(params  && params['organization']){
            let y = params['organization'];
            this.orgParam = params['organization'];
            this.getGroups({"organization" : y});
          }
          else if(params && params['divId']) {
            this.divisionSelected({"id": params['divId']});
          }
          else {
            this.getGroups();
          }
        }); 
      }
    }, (err) => {
        console.log('Error');
    });
  }

  ngOnDestroy(){
    
    if (this.routeSub) {
      this.routeSub.unsubscribe();
    }
    if (this.userInfoSub) {
      this.userInfoSub.unsubscribe();
    }
  }
  showErrorDialog(errMessage): void {
    let dialogRef = this.dialog.open(ErrorShowDialogComponent, {
      width: '500px',
      data: { text: errMessage}
    });
  }


	displayedColumns = ['name','users','delete'];

	@ViewChild(MatSort) sort: MatSort;

	@ViewChild(MatPaginator) paginator: MatPaginator;

	ngAfterViewInit() {
		this.dataSource.sort = this.sort;
		this.dataSource.paginator = this.paginator;
	}

  filterDivisions(name: string) {
    return this.divisions.filter(division => 
      division.name.toLowerCase().indexOf(name.toLowerCase()) === 0);
  }

  divisionSelected = function(obj){
    this.getGroups(obj);
  }

  getOrgId = function(organization){
    for(let i=0;i<this.divisions.length;i++){
      if(this.divisions[i].name == organization){
        organization = this.divisions[i].id;
        return organization;
      }
    }
  }

  includeAction(list,actionItem){
    if(list.indexOf(actionItem) > -1){
        return false;
    }
    else{
      return true;
    }
  }

	getGroups = function(obj?){
    if(obj && obj.organization){
      obj.organization = this.getOrgId(obj.organization);
    }
		this.manageGroupsService.getGroups(obj).subscribe((data) => {
		  if(data.success && data.resource.group != null){
        this.groups = data.resource.group.items;
        this.dataSource = new MatTableDataSource<any>(this.groups);
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
        this.isActive=false;
        this.isSearchData = false;
		  }else {
        this.isActive=false;
        this.noSearchDataMessage = 'No Groups were found for this organization';
        this.isSearchData = true;
      }
		}, (err) => {
      this.isActive=false;
      if(err.status == 403){
        this.showErrorDialog('You do not have admin rights to view groups.');
      }
     
      else if(err.status == 'FAILURE' && err.developerMessage =='UnAuthorized' ){
        this.showErrorDialog('You do not have admin rights to view groups.');
      }
      else if(err.status == 404){
        this.showErrorDialog('Not Found');
      }
      else if(err.status == 500){
        this.showErrorDialog('Creating Data was unsuccessful!');
      }
      else{
        this.errMessage = err.status + '-' + err.statusText;
        this.hasError = true;
      }
		});
	}

  showConfirmationDialog(currObj): void {
    let dialogRef = this.dialog.open(ConfirmationShowDialogComponent, {
      width: '600px',
      data: { text: this.groupDeleteConfirmMsg}
    });

    dialogRef.afterClosed().subscribe(result => {
      if(result){
        this.deleteGroup(currObj);
      }
    });
  }

  deleteGroup = function(currObj){
    this.manageGroupsService.deleteGroup(currObj).subscribe((data) => {
      if(data.success){
        window.location.reload();
      }
    }, (err) => {
      if(err.status == 403){
        this.showErrorDialog('Forbidden');
      }
      else if(err.status == 'FAILURE' && err.developerMessage =='UnAuthorized' ){
        this.showErrorDialog('You do not have admin rights to delete a group.');
      }
      else if(err.status == 404){
        this.showErrorDialog('Not Found');
      }
      else if(err.status == 500){
        this.showErrorDialog('Creating Data was unsuccessful!');
      }
      else if(err.status == 'FAILURE' && err.developerMessage =='Users in Group, Cannot Delete' ){
        this.showErrorDialog('Deletion of group was unsuccessful, Please remove user association and try again.');
      }
      else{
        this.errMessage = err.status + '-' + err.statusText;
        this.hasError = true;
      }
    });
  };

  editGroup=function(currObj){
    this.sharedService.setEditGroupObj(currObj);
    this.router.navigateByUrl('/landing/manage-groups/edit-group');
  };

  showRelatedUsers=function(currObj){
    this.router.navigate(['/landing/manage-groups/show-group-users', currObj.organizationId,currObj.externalGroupId]);
    
  };
}
