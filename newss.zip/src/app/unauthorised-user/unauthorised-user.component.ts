import { Component, OnInit } from '@angular/core';
import {AuthGaurdService} from '../auth-gaurd.service';

@Component({
  selector: 'app-unauthorised-user',
  templateUrl: './unauthorised-user.component.html',
  styleUrls: ['./unauthorised-user.component.css']
})
export class UnauthorisedUserComponent implements OnInit {

  returnUrl: string = '';

  constructor(private authGaurdService: AuthGaurdService) { }

  ngOnInit() {
      this.returnUrl = this.authGaurdService.getRedirectURL();

  }

  
}
