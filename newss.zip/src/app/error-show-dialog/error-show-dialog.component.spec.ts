import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecallPackageDialogComponent } from './recall-package-dialog.component';

describe('RecallPackageDialogComponent', () => {
  let component: RecallPackageDialogComponent;
  let fixture: ComponentFixture<RecallPackageDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecallPackageDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecallPackageDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
