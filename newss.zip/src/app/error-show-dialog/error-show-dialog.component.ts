import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef, MatSelect, MatInput} from '@angular/material';

@Component({
  selector: 'app-error-show-dialog',
  templateUrl: './error-show-dialog.component.html',
  styleUrls: ['./error-show-dialog.component.css']
})
export class ErrorShowDialogComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<ErrorShowDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  	ngOnInit() {}

  	onNoClick(): void {
		this.dialogRef.close();
	}
}
