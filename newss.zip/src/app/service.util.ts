
import {throwError as observableThrowError } from 'rxjs';
import { Observable, EMPTY, throwError } from 'rxjs';
import { Injectable, isDevMode } from '@angular/core';

export function handleError(error: Response | any) {
    console.error(JSON.stringify(error));
    if(error.status == 401){
        redirectToLogin();
        return EMPTY;
    }
    return observableThrowError(error.error);
}

function redirectToLogin(){
    if(isDevMode()){
        window.location.href="http://localhost:4200";
    }else{
        window.location.href="/mfalogin/";
    }
}

export function  getCookie(name) {
  var value = "; " + document.cookie;
  var parts = value.split("; " + name + "=");
  if (parts.length == 2) return parts.pop().split(";").shift();
}