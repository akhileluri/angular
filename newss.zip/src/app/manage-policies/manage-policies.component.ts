import { Component, OnInit } from '@angular/core';
import { SharedService } from './shared.service';

@Component({
  selector: 'app-manage-policies',
  templateUrl: './manage-policies.component.html',
  styleUrls: ['./manage-policies.component.css'],
  providers: [SharedService]
})
export class ManagePoliciesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
