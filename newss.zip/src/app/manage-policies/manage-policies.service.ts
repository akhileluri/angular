import { Injectable, Inject, isDevMode} from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';

import { catchError } from 'rxjs/internal/operators/catchError';
import {Observable} from 'rxjs';
import { APP_CONFIG, IAppConfig } from '../app.config';
import { AuthInterceptorService } from 'ui-auth-interceptor';

@Injectable()
export class ManagePoliciesService {

	createPolicy(data,target) : Observable<Object> {
		var condition = true;
		var payload = '?policyName='+data.name+'&externalPolicyId='+data.externalPolicyId+'&condition='+condition+'&policyDescription='+data.description+'&target='+target;

		if(data.orgId){
			payload += '&orgId=' + data.orgId;
		}
		
		return this.http.post(this.createPolicyUrl + payload,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
		
	}

	deletePolicy(data) : Observable<Object> {
             var payload = '';
		if(data.organizationId){
			payload += '?orgId=' + data.organizationId;
		}
		return this.http.delete(this.deletePolicyUrl+data.externalPolicyId +payload,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
		
	}

	getPolicies(data) : Observable<Object> {
		var payload = '';

		if(data && data.organization){
			payload += '?orgId=' + data.organization;
		}
		return this.http.get(this.getPoliciesUrl + payload,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
		
	}

	getActions() : Observable<Object> {
		return this.http.get(this.getActionsUrl,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
		
	}

	updatePolicy(data,target) : Observable<Object> {
		var condition = true;
		var payload = '?policyName='+data.name+'&condition='+condition+'&policyDescription='+data.description+'&target='+target;
		
		if(data.orgId){
			payload += '&orgId=' + data.orgId;
		}

		return this.http.put(this.updatePolicyUrl + data.externalPolicyId + payload,{headers: new HttpHeaders().set('Content-Type', 'application/json'), withCredentials: true }).pipe(catchError( AuthInterceptorService.handleError));
	}

	private apiUrl: string;

	private createPolicyUrl = '/rest/v1/authorization/policies';	//URL to create a policy

	private deletePolicyUrl = '/rest/v1/authorization/policies/';	//URL to delete a policy

	private getPoliciesUrl = '/rest/v1/authorization/policies';	//URL to get policies list

	private getActionsUrl = '/rest/v1/authorization/actions';	//URL to get actions list

	private updatePolicyUrl = '/rest/v1/authorization/policies/';	//URL to update a policy

	constructor(private http: HttpClient,@Inject(APP_CONFIG) private config: IAppConfig) { 
		if(isDevMode()){
			this.apiUrl = this.config.baseDevApiURL;
			this.createPolicyUrl = this.apiUrl + this.createPolicyUrl;
			this.deletePolicyUrl = this.apiUrl + this.deletePolicyUrl;
			this.getPoliciesUrl = this.apiUrl + this.getPoliciesUrl;
			this.getActionsUrl = this.apiUrl + this.getActionsUrl;
			this.updatePolicyUrl = this.apiUrl + this.updatePolicyUrl;
		}
	}

}
