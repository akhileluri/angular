import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ManagePoliciesService } from '../manage-policies.service';
import { ConfirmationShowDialogComponent } from '../../confirmation-show-dialog/confirmation-show-dialog.component';
import { SharedService } from '../shared.service';
import { AddNewUserService } from '../../manage-users/add-new-user/add-new-user.service';
import { ErrorShowDialogComponent } from '../../error-show-dialog/error-show-dialog.component';
import { Store } from '@ngrx/store';
import { State } from '../../state/state';
import * as AdminActions from '../../state/actions';

@Component({
	selector: 'app-policies',
	templateUrl: './policies.component.html',
	styleUrls: ['./policies.component.css'],
	providers: [ManagePoliciesService, AddNewUserService]
})
export class PoliciesComponent implements OnInit {

	policies = [];
	errMessage: string = '';
	hasError: boolean = false;
	dataSource = new MatTableDataSource<any>(this.policies);
	groupDeleteConfirmMsg: string = 'Are you sure to delete this policy ?'
	defaultOrg: string = '';
	defaultDivisionCtrl: FormControl;
	filteredDivisions: Observable<any[]>;
	divisions = [];
	routeSub: Subscription;
	isActive = true;
	params: any;
	routeParamsSub: Subscription;
	searchAutoCompleteObj: any = { searchOpts: [], value: '', placeholder: 'Organization' };
	userObj: any = { userName: '', userEmail: '', actions: [] };
	account$: Observable<any>;
	userInfoSub: Subscription;
	orgParam: string = '';
	isSearchData: boolean = false;
	noSearchDataMessage: string = '';
	userActionsList=[];
    hasListUser : boolean = false;

	constructor(private activatedRoute: ActivatedRoute,
		private managePoliciesService: ManagePoliciesService,
		public dialog: MatDialog, private router: Router,
		private route: ActivatedRoute,
		private sharedService: SharedService,
		private addNewUserService: AddNewUserService, private state: Store<State>) {
		this.account$ = this.state.select(st => st.userInfo);
		this.defaultDivisionCtrl = new FormControl();
		this.filteredDivisions = this.defaultDivisionCtrl.valueChanges
			.pipe(
				startWith(''),
				map(division => division ? this.filterDivisions(division) : this.divisions.slice())
			);
	}

	ngOnInit() {
		this.userInfoSub = this.account$.subscribe(data => {
			if (data) {
				this.divisions = data.divisions;
				this.userActionsList = data['actions'];
				this.hasListUser  =  this.hasListUser  = this.includeAction(this.userActionsList,'ACCESS_POLICY_LIST') ||
				this.includeAction(this.userActionsList,'ACCESS_POLICY_ACTION_LIST') ||  this.includeAction(this.userActionsList,'ACCESS_POLICY_EDIT');
				this.userObj = { userName: data.userName, userEmail: data.emailAddress, actions: data.actions };

				for (let division of data.divisions) {
					this.searchAutoCompleteObj.searchOpts.push(division.name);
				}

				this.routeSub = this.activatedRoute.queryParams.subscribe(params => {
					if (params && params['organization']) {
						let y = params['organization'];
						y = this.getOrgId(y);
						this.orgParam = params['organization'];
						this.getPolicies({ "organization": y });
					}
					else {
						this.getPolicies();
					}
				});
			}
		}, (err) => {
			console.log('Error');
		});
	}

	getOrgId = function (organization) {
		for (let i = 0; i < this.divisions.length; i++) {
			if (this.divisions[i].name == organization) {
				organization = this.divisions[i].id;
				return organization;
			}
		}

	}

	ngOnDestroy() {
		if (this.routeSub) {
			this.routeSub.unsubscribe();
		}
		if (this.userInfoSub) {
			this.userInfoSub.unsubscribe();
		}
	}

	displayedColumns = ['name', 'delete'];

	@ViewChild(MatSort) sort: MatSort;

	@ViewChild(MatPaginator) paginator: MatPaginator;

	ngAfterViewInit() {
		this.dataSource.sort = this.sort;
		this.dataSource.paginator = this.paginator;
	}

	showErrorDialog(errMessage): void {
		let dialogRef = this.dialog.open(ErrorShowDialogComponent, {
			width: '500px',
			data: { text: errMessage }
		});
	}

	filterDivisions(name: string) {
		return this.divisions.filter(division =>
			division.name.toLowerCase().indexOf(name.toLowerCase()) === 0);
	}



	divisionSelected = function (division) {
		this.getPolicies(division);
	}

	includeAction(list,actionItem){
		if(list.indexOf(actionItem) > -1){
			return false;
		}
		else{
		  return true;
		}
	  }

	getPolicies = function (obj?) {
		
		this.managePoliciesService.getPolicies(obj).subscribe((data) => {
			if (data.success) {
				this.policies = data.resource.policy.items;
				this.dataSource = new MatTableDataSource<any>(this.policies);
				this.dataSource.sort = this.sort;
				this.dataSource.paginator = this.paginator;
				this.isActive = false;
				this.isSearchData = false;
			}
		}, (err) => {
			this.isActive = false;
			if (err.status == 400) {
				this.showErrorDialog('Bad Request');
			}
			else if (err.status == 403) {
				this.showErrorDialog('You are unauthorized to view policies.');
			}
			else if (err.status == 'FAILURE' && err.developerMessage == 'UnAuthorized') {
				this.showErrorDialog('You do not have admin rights to make this change');
			}
			else if (err.status == 'FAILURE' && err.developerMessage == 'No Policies Found') {
				this.noSearchDataMessage = 'No Policies were found for this organization';
				this.isSearchData = true;
			}
			else if (err.status == 500) {
				this.showErrorDialog('Editing policy was unsuccessful!');
			}
			else {
				this.errMessage = err.status + '-' + err.statusText;
				this.hasError = true;
			}
		});
	}

	showConfirmationDialog(currObj) {
		this.router.navigate([], {
			relativeTo: this.route,
			queryParams: {
			  organization: this.orgParam
			},
			queryParamsHandling: 'merge', 
			// preserve the existing query params in the route
			skipLocationChange: true
			// do not trigger navigation
		  });

		let dialogRef = this.dialog.open(ConfirmationShowDialogComponent, {
			width: '600px',
			data: { text: this.groupDeleteConfirmMsg }
		});

		dialogRef.afterClosed().subscribe(result => {
			if (result) {
				this.deletePolicy(currObj);
			}
		});
	}

	deletePolicy = function (currObj) {

		this.router.navigate([], {
			relativeTo: this._route,
			queryParams: {
			  organization: this.orgParam
			},
			queryParamsHandling: 'merge', 
			// preserve the existing query params in the route
			skipLocationChange: true
			// do not trigger navigation
		  });
		  
		this.managePoliciesService.deletePolicy(currObj).subscribe((data) => {
			if (data.success) {
				console.log('Policy Deleted.');
				window.location.reload();
			}
		}, (err) => {
			if (err.status == 400) {
				this.showErrorDialog('Bad Request');
			}
			else if (err.status == 403) {
				this.showErrorDialog('You are unauthorized to delete policies');
			}
			else if (err.status == 'FAILURE' && err.developerMessage == 'UnAuthorized') {
				this.showErrorDialog('You do not have admin rights to make this change');
			}
			else if (err.status == 404) {
				this.showErrorDialog('Not Found');
			}
			else if (err.status == 500) {
				this.showErrorDialog('Editing policy was unsuccessful!');
			}
			else {
				this.errMessage = err.status + '-' + err.statusText;
				this.hasError = true;
			}
		});
	};

	editPolicy = function (currObj) {
		this.sharedService.setEditPolicyObj(currObj);
		this.router.navigateByUrl('/landing/manage-policies/edit-policy');
	};
}
