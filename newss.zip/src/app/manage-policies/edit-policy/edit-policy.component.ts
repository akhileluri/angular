import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {Observable, Subscription} from 'rxjs';
import {startWith, map} from 'rxjs/operators';

import { ManagePoliciesService } from '../manage-policies.service';
import { SharedService } from '../shared.service';
import { AddNewUserService } from '../../manage-users/add-new-user/add-new-user.service';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import {ErrorShowDialogComponent} from '../../error-show-dialog/error-show-dialog.component';
import { Store } from '@ngrx/store';
import { State } from '../../state/state';
import * as AdminActions from '../../state/actions';

@Component({
  selector: 'app-edit-policy',
  templateUrl: './edit-policy.component.html',
  styleUrls: ['./edit-policy.component.css'],
  providers: [ManagePoliciesService,AddNewUserService]
})
export class EditPolicyComponent implements OnInit {
		
		policy = {} as any;
		errMessage: string = '';
		policyNameFormControl: FormControl;
		externalPolicyIdFormControl: FormControl;
		actions = [	];
		defaultOrg: string = '';
		defaultDivisionCtrl: FormControl;
		filteredDivisions: Observable<any[]>;
		divisions = [];
		arrList = [];
		userObj:any = {userName:'',userEmail:'',actions:[]};
		account$:Observable<any>;
		userInfoSub: Subscription;

	constructor(private managePoliciesService: ManagePoliciesService,
		private router:Router,private route: ActivatedRoute,
		public dialog: MatDialog,
		private sharedService:SharedService,
		private addNewUserService: AddNewUserService,
		private state: Store<State>) { 
		
		this.account$ = this.state.select(st => st.userInfo); 
		this.defaultDivisionCtrl = new FormControl();
	    this.filteredDivisions = this.defaultDivisionCtrl.valueChanges
	    .pipe(
	      startWith(''),
	      map(division => division ? this.filterDivisions(division) : this.divisions.slice())
	    );
		this.policyNameFormControl = new FormControl('', [
	      Validators.required
	    ]);

	    this.externalPolicyIdFormControl = new FormControl('', [
	      Validators.required
	    ]);
	}

	filterDivisions(name: string) {
	    return this.divisions.filter(division =>
	      division.name.toLowerCase().indexOf(name.toLowerCase()) === 0);
	}

	ngOnInit() {
		if(this.sharedService.getEditPolicyObj()){
	      this.policy = this.sharedService.getEditPolicyObj();
	    }
	    
		this.getActions();
		this.userInfoSub = this.account$.subscribe(data => {
			if(data){
				this.divisions = data.divisions;
				for(let i=0;i<this.divisions.length;i++){
					if(this.divisions[i].id == this.policy.organizationId){
						this.defaultOrg  = this.divisions[i].name;
					}
				}
				this.userObj = {userName:data.userName,userEmail:data.emailAddress,actions: data.actions};
				}
			
		});
	}

	showErrorDialog(errMessage): void {
    let dialogRef = this.dialog.open(ErrorShowDialogComponent, {
      width: '500px',
      data: { text: errMessage}
    });
  }
    getActions = function(){
	    this.managePoliciesService.getActions().subscribe((data) => {
	      if(data.success){
			this.actions = data.resource.action.items;
			let arr2 = [];
			for(let j=0;j<this.actions.length;j++){
				if(arr2.indexOf(this.actions[j].resourceType) < 0){
					arr2.push(this.actions[j].resourceType);
					this.arrList.push({"resourceType" : this.actions[j].resourceType ,"names" : []});
				}
			}
			for(let i=0;i<this.arrList.length;i++){
				for(let j=0;j<this.actions.length;j++){
					if(this.arrList[i].resourceType == this.actions[j].resourceType){
						this.arrList[i].names.push(this.actions[j]);
					}
				}
			}
			this.getPolicyActions();
			this.getDivisions();
	      }
	    }, (err) => {
				if(err.status == 400){
          this.showErrorDialog('Bad Request');
        }
	        if(err.status == 403){
          this.showErrorDialog('You do not have admin rights to make this change');
				}
				else if(err.status == 'FAILURE' && err.developerMessage =='UnAuthorized' ){
          this.showErrorDialog('You do not have admin rights to make this change');
        }
        else if(err.status == 404){
          this.showErrorDialog('Not Found');
        }
        else if(err.status == 500){
          this.showErrorDialog('Fetching Data was unsuccessful!');
        }
        else{
          this.errMessage = err.status + '-' + err.statusText;
          this.hasError = true;
        }
	    });
	}

	getPolicyActions = function(){
		var array = this.policy.target.split(',');
		for(let i=0;i<this.actions.length;i++){
			for(let j=0;j<array.length;j++){
		      if(this.actions[i].externalActionId == array[j]){
		        this.actions[i].checked = true;
	    	  }
			}
	    }
	}

	getDivisions = function(){
	    this.addNewUserService.getDivisions().subscribe((data) => {
	      	this.divisions = data.divisions;
			for(let i=0;i<this.divisions.length;i++){
				if(this.divisions[i].id == this.policy.organizationId){
					this.defaultOrg  = this.divisions[i].name;
				}
			}
	    }, (err) => {
				if(err.status == 400){
          this.showErrorDialog('Bad Request');
        }
	      else if(err.status == 403){
          this.showErrorDialog('Forbidden');
				}
				else if(err.status == 'FAILURE' && err.developerMessage =='UnAuthorized' ){
          this.showErrorDialog('You do not have admin rights to make this change');
        }
        else if(err.status == 404){
          this.showErrorDialog('Not Found');
        }
        else if(err.status == 500){
          this.showErrorDialog('Fetching Data was unsuccessful!');
        }
        else{
          this.errMessage = err.status + '-' + err.statusText;
          this.hasError = true;
        }
	    });
	}

	disablebn(){
		let isDisabled = true;
				
		
				for(let i=0;i<this.actions.length;i++){
					if(this.actions[i].checked && this.policy.name){
						isDisabled=false;
					}
				}
		return isDisabled;
		
			}

	save = function(){
		for(let i=0;i<this.divisions.length;i++){
			if(this.divisions[i].name == this.defaultOrg){
				this.policy.orgId = this.divisions[i].id;
			}
		}
	    //action data list
	    var target  = [];
	    for(let j=0;j<this.arrList.length;j++){
				for(let i=0;i<this.arrList[j].names.length;i++){
					if(this.arrList[j].names[i].checked){
						target.push(this.arrList[j].names[i].externalActionId);
					}
				}
			}
	    this.managePoliciesService.updatePolicy(this.policy,target).subscribe((data) => {
	    	if(data.success){
	    		this.router.navigateByUrl('/landing/manage-policies/policies');
	    	}
	    }, (err) => {
				if(err.status == 400){
          this.showErrorDialog('Bad Request');
        }
				else if(err.status == 403){
          this.showErrorDialog('Forbidden');
				}
				else if(err.status == 'FAILURE' && err.developerMessage =='UnAuthorized' ){
          this.showErrorDialog('You do not have admin rights to make this change.');
        }
        else if(err.status == 404){
          this.showErrorDialog('Not Found');
        }
        else if(err.status == 500){
          this.showErrorDialog('Editing policy was unsuccessful!');
        }
        else{
          this.errMessage = err.status + '-' + err.statusText;
          this.hasError = true;
        }
	    });
	}

	cancel = function(){
		this.router.navigateByUrl('/landing/manage-policies/policies');
	}
}

