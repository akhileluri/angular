import { Injectable } from '@angular/core';
import { Actions, Effect } from '@ngrx/effects';
import { Action, Store } from '@ngrx/store';
import { MatDialog } from '@angular/material';
import * as AdminActions from './actions';
import { State } from './state';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs/internal/Subscription';
import { Observable } from 'rxjs/internal/Observable';
import { map } from 'rxjs/internal/operators/map';
import { merge } from 'rxjs/internal/observable/merge';
import { switchMap } from 'rxjs/internal/operators/switchMap';
import { catchError } from 'rxjs/internal/operators/catchError';
import { mergeMap } from 'rxjs/internal/operators/mergeMap';
import { of } from 'rxjs/internal/observable/of';
import { tap } from 'rxjs/internal/operators/tap';
import { empty } from 'rxjs/internal/observable/empty';
import { forkJoin } from 'rxjs/internal/observable/forkJoin';

import { AddNewUserService } from '../manage-users/add-new-user/add-new-user.service';
@Injectable()
export class Effects {

    constructor(  private actions$: Actions, private store: Store<State>,
        private dialog: MatDialog, private userService: AddNewUserService ) {
    }


    @Effect()
    loadAccount$: Observable<Actions> = this.actions$
        .ofType(AdminActions.REQUEST_ACCOUNT)
        .pipe(switchMap(payload => {
            return this.userService.loadUserInfo()
                .pipe(mergeMap(result => {
                    return [
                        new AdminActions.LoadedAccount(result)
                    ];
                }),
                catchError((error) => this.error(error)));
        }));

    private error(error): Observable<any> {
        //this.dialog.open(ErrorDialogComponent, { data: error });
        return empty();
    }
}
