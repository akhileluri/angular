export enum ViewType {
    Table = 1,
    Card
}
