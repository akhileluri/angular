
export interface State {
    searchFilterObj?: {
        search: string,
        searchType?: string
    };
    userInfo?: {
        accountId: number;
        userName?: string;
        emailAddress?: string;
        actions?: any;
        divisions?: [
            {
                id: number,
                name: string,
            }
        ];
    };
}
