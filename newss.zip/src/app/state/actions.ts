import { Action } from '@ngrx/store';

export const REQUEST_ACCOUNT = 'REQUEST_ACCOUNT';
export const LOADED_ACCOUNT = 'LOADED_ACCOUNT';


export class RequestedAccount implements Action {
    readonly type = REQUEST_ACCOUNT;
}
export class LoadedAccount implements Action {
    readonly type = LOADED_ACCOUNT;
    constructor(public payload) { }
}

export type Actions = RequestedAccount | LoadedAccount;
