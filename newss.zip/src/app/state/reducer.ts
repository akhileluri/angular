import { State } from './state';
import { ActionReducerMap } from '@ngrx/store';
import * as AdminActions from '../state/actions';
import { ViewType } from './viewtype.enum';

export function userInfoReducer(state = null, action): any {
    switch (action.type) {
        case AdminActions.LOADED_ACCOUNT: {
            const act: AdminActions.LoadedAccount = action;
            return act.payload;
        }
        default: {
            return state;
        }
    }
}

export const reducerMap: ActionReducerMap<State> = {
    userInfo: userInfoReducer
};
