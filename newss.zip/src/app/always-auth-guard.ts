import { Component, OnInit, Injectable } from '@angular/core';
import {Observable} from 'rxjs';
import { RouterStateSnapshot,  ActivatedRouteSnapshot, Router, CanActivate} from '@angular/router';
import {AuthGaurdService} from './auth-gaurd.service';
import {AddNewUserService} from './manage-users/add-new-user/add-new-user.service';


import { Store } from '@ngrx/store';
import { State } from './state/state';


@Injectable()
export class AlwaysAuthGuard implements CanActivate {
	account$:Observable<any>;

	constructor(private addNewUserService: AddNewUserService,
		private authGaurdService: AuthGaurdService,
		private store: Store<State>,
		private router:Router) {
			this.account$ = this.store.select( st => st.userInfo )
		}; 

	canActivate(route: ActivatedRouteSnapshot,state: RouterStateSnapshot): 
					Observable<boolean>|Promise<boolean>|boolean {
		
		this.account$.subscribe(data=> {
			
			if(data){
				if(this.authGaurdService.isValidUser(state.url,data['actions'])){
					return true;
				}
				else{
					this.router.navigateByUrl('/unauthorised-user');
				}
			}
			
		});
		return true;
	}
}