import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WarningMsgModalComponent } from './warning-msg-modal.component';

describe('WarningMsgModalComponent', () => {
  let component: WarningMsgModalComponent;
  let fixture: ComponentFixture<WarningMsgModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WarningMsgModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WarningMsgModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
