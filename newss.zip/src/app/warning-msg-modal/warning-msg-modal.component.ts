import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-warning-msg-modal',
  templateUrl: './warning-msg-modal.component.html',
  styleUrls: ['./warning-msg-modal.component.css']
})
export class WarningMsgModalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
