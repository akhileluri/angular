import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-ui-row',
  templateUrl: './ui-row.component.html',
  styleUrls: ['./ui-row.component.scss']
})
export class UiRowComponent implements OnInit {
  @Input('dateStr') dateStr;

  constructor() { }

  ngOnInit() {
  }

}
