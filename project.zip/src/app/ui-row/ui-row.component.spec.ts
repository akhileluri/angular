import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UiRowComponent } from './ui-row.component';
import { WhenPipe } from '../pipes/when.pipe';

describe('UiRowComponent', () => {
  let component: UiRowComponent;
  let fixture: ComponentFixture<UiRowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UiRowComponent, WhenPipe ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UiRowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
