import { WhenPipe } from './when.pipe';

describe('WhenPipePipe', () => {
  it('create an instance', () => {
    const pipe = new WhenPipe();
    expect(pipe).toBeTruthy();
  });

  it('Validate Today String', () => {
    const pipe = new WhenPipe();
    expect(pipe.transform(new Date().toDateString())).toEqual('Today');
  });

  it('Validate Just Now', () => {
    const pipe = new WhenPipe();
    expect(pipe.transform('2019-10-22T18:45:21.000').toString()).toEqual('Tue Oct 22 2019 18:45:21 GMT+0530 (India Standard Time)');
  });

});
