import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'when'
})
export class WhenPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    const dt = new Date(value);
    const today = new Date();
    if(dt.getFullYear() === today.getFullYear() && dt.getMonth() === today.getMonth() && dt.getDate() === today.getDate()){
      const hoursDiff = today.getHours() - dt.getHours();
      if(hoursDiff > 10){
        return 'Today'
      }
      const minsDiff = today.getMinutes() - dt.getMinutes();
      const secsDiff = today.getSeconds() - dt.getSeconds();
      if(hoursDiff > 0){
        return hoursDiff+' Hours '+(minsDiff <= 0 ? '' : minsDiff+' Mins ')+(secsDiff <= 0 ? '' : secsDiff+' Secs ')+'ago';
      }
      if(minsDiff > 0){
        return minsDiff+' Mins '+(secsDiff <= 0 ? '' : secsDiff+' Secs ')+' ago';
      }
      if(secsDiff < 30 && secsDiff >= 0){
        return 'Just Now';
      }
    }
    return new Date(value);
  }

}
