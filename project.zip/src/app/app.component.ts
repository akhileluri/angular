import { Component } from '@angular/core';
import * as moment from 'moment';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  datesList: String[] = [];

  constructor() { 
    this.datesList = [
      '2019-07-26T12:33:36.888',
      '2018-02-19T22:17:14.672',
      '2014-09-13T14:04:22.526',
      '2019-10-25T17:32:38.424'
    ];
    this.datesList.push(moment().format('YYYY-MM-DDTHH:mm:SS.sss'));
    this.datesList.push(moment().subtract(1,'d').format('YYYY-MM-DDTHH:mm:SS.sss'));
    this.datesList.push(moment().subtract(3,'h').format('YYYY-MM-DDTHH:mm:SS.sss'));
    this.datesList.push(moment().subtract(2,'m').format('YYYY-MM-DDTHH:mm:SS.sss'));
  }

  ngOnInit() {
    
  }

}
