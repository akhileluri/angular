export function hasForecastData(kpiDetails) {
    return kpiDetails && kpiDetails.forecastNumber && kpiDetails.forecastNumber.number;
}

export function hasActualNotForecastData(kpiDetails) {
    if (kpiDetails && kpiDetails.actualNumber && kpiDetails.actualNumber.number) {
        if (!kpiDetails.forecastNumber || !kpiDetails.forecastNumber.number) {
            return true;
        }
    }

    return false;
}

export function hasNoActualOrForecastData(kpiDetails) {
    if (kpiDetails) {
        if (!kpiDetails.forecastNumber && !kpiDetails.actualNumber) {
            return true;
        }
        else if (!kpiDetails.forecastNumber.number) {
            return (!(kpiDetails.actualNumber && kpiDetails.actualNumber.number));
        }
        else if (!kpiDetails.actualNumber.number) {
            return (!(kpiDetails.forecastNumber && kpiDetails.forecastNumber.number));
        }
    }

    return false;
}
