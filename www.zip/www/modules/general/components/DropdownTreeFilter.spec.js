// This file was generated from the component scaffold
// Copyright 2016

import {Component, Injector} from '@angular/core';
import DropdownFilter from './DropdownFilter';
import {
    it,
    describe,
    expect,
    async,
    inject,
    beforeEachProviders
} from '@angular/core/testing';
import {
    TestComponentBuilder,
    ComponentFixture
} from '@angular/compiler/testing';

@Component({
    selector: 'test-component',
    directives: [DropdownFilter],
    template: ''
})
class TestComponent {}

describe('general/DropdownFilter.js', () => {

    beforeEachProviders(() => [
        DropdownFilter
    ]);

    it('should return component name', inject([DropdownFilter], (dropdownFilter:DropdownFilter) => {
        expect(dropdownFilter.name).toBe('DropdownFilter');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<dropdown-filter></dropdown-filter>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('dropdown-filter h1').innerText).toBe('DropdownFilter');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<dropdown-filter name="TEST"></dropdown-filter>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('dropdown-filter h1').innerText).toBe('TEST');
            });
    })));

});
