// This file was generated from the component scaffold
// Copyright 2016

import {Component, Injector} from '@angular/core';
import TimelineFilter from './TimelineFilter';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [TimelineFilter],
    template: ''
})
class TestComponent {}

describe('general/TimelineFilter.js', () => {

    beforeEach(() => {
        addProviders([TimelineFilter]);
    });

    it('should return component name', inject([TimelineFilter], (timelineFilter:TimelineFilter) => {
        expect(timelineFilter.name).toBe('TimelineFilter');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<timeline-filter></timeline-filter>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('timeline-filter h1').innerText).toBe('TimelineFilter');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<timeline-filter name="TEST"></timeline-filter>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('timeline-filter h1').innerText).toBe('TEST');
            });
    })));

});
