// This file was generated from the component scaffold
// Copyright 2016

import {Component, Input, Output, EventEmitter, ViewEncapsulation} from '@angular/core';
import template from './MapCompare.html';
import styles from './MapCompare.scss';

@Component({
    selector: 'map-compare',
    template: template,
    styles: [styles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <map-compare name="MapCompare" (change)="onChange($event)"></map-compare>
 */
export default class MapCompare {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'MapCompare';

    @Input() data = {};
    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();

    constructor() {
        console.log('map init');
    }

    ngOnChanges() {
        console.log('map changes');
    }
}
