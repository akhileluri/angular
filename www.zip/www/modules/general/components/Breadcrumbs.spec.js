// This file was generated from the component scaffold
// Copyright 2017

import {Component, Injector} from '@angular/core';
import Breadcrumbs from './Breadcrumbs';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [Breadcrumbs],
    template: ''
})
class TestComponent {}

describe('general/Breadcrumbs.js', () => {

    beforeEach(() => {
        addProviders([Breadcrumbs]);
    });

    it('should return component name', inject([Breadcrumbs], (breadcrumbs:Breadcrumbs) => {
        expect(breadcrumbs.name).toBe('Breadcrumbs');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<breadcrumbs></breadcrumbs>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('breadcrumbs h1').innerText).toBe('Breadcrumbs');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<breadcrumbs name="TEST"></breadcrumbs>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('breadcrumbs h1').innerText).toBe('TEST');
            });
    })));

});
