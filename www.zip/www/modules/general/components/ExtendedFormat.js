// This file was generated from the component scaffold
// Copyright 2016

import {Component, Input, ViewEncapsulation} from '@angular/core';
import template from './ExtendedFormat.html';
import styles from './ExtendedFormat.scss';

const trillonThreshold = 0.9995e12;
const billonThreshold = 0.9995e9;
const millionThreshold = 0.9995e6;
const thousandThreshold = 0.995e3;
const defaultThreshold = 0;

const transformMap = {
    [trillonThreshold]: { div: 1e12, suffix: 'T' },
    [billonThreshold]: { div: 1e9, suffix: 'B' },
    [millionThreshold]: { div: 1e6, suffix: 'M' },
    [thousandThreshold]: { div: 1e3, suffix: 'K' },
    [defaultThreshold]: { div: 1, suffix: '' },
};

const thresholds = [trillonThreshold, billonThreshold, millionThreshold, thousandThreshold];

@Component({
    selector: 'extended-format',
    template: template,
    styles: [styles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <extended-format [number]="number"></extended-format>
 */



export default class ExtendedFormat {
    @Input() number:Object = {};

    formatNumber() {
        return Math.round(Math.abs(this.number.number) * 1000) / 10;
        // return this.getTransform(this.number.number);
    }


    getTransform(num) {
        const absNum = Math.abs(num);
        let t = transformMap[defaultThreshold];
        for (let i = 0; i < thresholds.length; i++) {
            if (absNum >= thresholds[i]) {
                t = transformMap[thresholds[i]];
                break;
            }
        }
        return t;
    }

    formatSymbol() {
        const t = this.getTransform(this.number.number);
        return t.suffix;
    }

    formatCurrency() {
        const t = this.getTransform(this.number.number);
        return (this.number.number / t.div).toFixed(1);
    }

}
