// This file was generated from the component scaffold
// Copyright 2016
/* global _ */
import {Component, Input, Output, SimpleChanges, EventEmitter, ViewEncapsulation} from '@angular/core';
import {getTrendImage} from '../../dashboard/util/trendImage';
import template from './dataTable.html';
import styles from './dataTable.scss';

const ASCENDING = 'asc';
const DESCENDING = 'desc';

@Component({
    selector: 'data-table',
    template: template,
    styles: [styles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <data-table name="DataTable" (change)="onChange($event)"></data-table>
 */
export default class DataTable {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'DataTable';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();

    @Input() headers = [];
    @Input() rows = [];
    @Input() data = [];

    activeSortIndex = 0;
    activeSortDirection = ASCENDING;

    constructor() {}

    ngOnChanges(changes: SimpleChanges) {
        if (changes && changes['data']) {
            this.getTableChart(changes['data'].currentValue);
        }

        if (_.has(this.rows, '0.trendData.lineGraphData.lines.0')) {
            this.rows.forEach((r) => {
                const line = r.trendData.lineGraphData.lines[0];
                const last = line[line.length - 1];
                r.trendData.trendValue = last.number;
            });
        }
    }

    sortColumn(header, colIndex) {
        let sortProp = '';

        if (this.activeSortIndex === colIndex) {
            this.activeSortDirection = this.activeSortDirection === ASCENDING ? DESCENDING : ASCENDING;
            this.rows = this.rows.reverse();
        }
        else {
            if (colIndex === 0) {
                // Sort by header
                sortProp = 'rowName';
            }
            else if (this.headers.length - 1 === colIndex && this.rows[0].trendData) {
                // Sort by trend data
                sortProp = 'trendData.lineGraphData.trendValue';
            }
            else {
                // Sort by num data
                const indexAdjust = colIndex - 1; // Assumes a rowName is always first.
                if (_.get(this, 'rows[0].numData[' + indexAdjust + '].format') === 'text') {
                    sortProp = `numData.${indexAdjust}.icon`;
                }
                else {
                    sortProp = `numData.${indexAdjust}.number`;
                }
            }

            this.rows = _.sortBy(this.rows, (row) => {
                return _.get(row, sortProp);
            });
            this.activeSortIndex = colIndex;
            this.activeSortDirection = ASCENDING;
        }
    }

    getTrendData(row) {
        const line = {
            css: 'trend-up', // TODO: Determine trend
            values: row.trendData.lineGraphData.lines[0],
        };

        line.values.forEach((point, i) => point.position = i);

        return line;
    }

    getColumnCss(index) {
        const isActive = this.activeSortIndex === index;

        return isActive ? `active ${this.activeSortDirection}` : '';
    }

    getTrendImage(number) {
        if (!number.trend) {
            return '';
        }

        return getTrendImage(number);
    }

    getTableHeaders(kpi) {
        const chartFirstRow = kpi.chartData.charts[0].lines[0].lines;
        const headers = [];
        headers.push('');
        for (let x = 0; x < chartFirstRow.length; x++) {
            headers.push(this.resolveDataSourceName(chartFirstRow[x].label, kpi.dataConfiguration.dataItemsMap));
        }
        return headers;
    }

    getTableRows(kpi) {
        const dataRows = kpi.chartData.charts[0].lines;
        const rows = [];
        for (let x = 0; x < dataRows.length; x++) {
            const dataRow = dataRows[x];
            const resultRow = [];
            for (let y = 0; y < dataRow.lines.length; y++) {
                const cell = dataRow.lines[y];
                resultRow.push(cell);
            }
            rows.push({rowName: resultRow[0].axisLabel, numData: resultRow});
        }
        return rows;
    }

    getTableChart(kpi) {
        this.headers = this.getTableHeaders(kpi);
        this.rows = this.getTableRows(kpi);
        return kpi;
    }

    // Look at the dataItemsMap property for a proper English title
    // If it does not exist, just use the existing label
    resolveDataSourceName(label, dataItemsMap) {
        const matchingDataItem = (_.find(dataItemsMap, function(dataItem) {
            return (dataItem.value === label);
        }) || {});

        return _.get(matchingDataItem, 'name', label);
    }
}
