export const GENERAL_COMPONENTS = [];

export DropdownFilter from './DropdownFilter';
GENERAL_COMPONENTS.push(exports.DropdownFilter);

export DropdownTreeFilter from './DropdownTreeFilter';
GENERAL_COMPONENTS.push(exports.DropdownTreeFilter);

export KpiFilter from './KpiFilter';
GENERAL_COMPONENTS.push(exports.KpiFilter);

export DataTable from './dataTable';
GENERAL_COMPONENTS.push(exports.DataTable);

export TimelineFilter from './TimelineFilter';
GENERAL_COMPONENTS.push(exports.TimelineFilter);

export MapCompare from './MapCompare';
GENERAL_COMPONENTS.push(exports.MapCompare);

export ExtendedFormat from './ExtendedFormat';
GENERAL_COMPONENTS.push(exports.ExtendedFormat);

export Breadcrumbs from './Breadcrumbs';
GENERAL_COMPONENTS.push(exports.Breadcrumbs);

export MenuFamily from './MenuFamily';
GENERAL_COMPONENTS.push(exports.MenuFamily);



