// This file was generated from the component scaffold
// Copyright 2017
/* global _  */

import {Component, Input, Output, EventEmitter, ViewEncapsulation} from '@angular/core';
import template from './Breadcrumbs.html';
import styles from './Breadcrumbs.scss';

@Component({
    selector: 'breadcrumbs',
    template: template,
    styles: [styles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <breadcrumbs name="Breadcrumbs" (change)="onChange($event)"></breadcrumbs>
 */
export default class Breadcrumbs {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'Breadcrumbs';

    @Input() families = [];

    @Input() viewType = '';

    // Called when a breadcrumb is clicked.
    @Output() activateSelection: EventEmitter = new EventEmitter();

    // Called when a breadcrumb is clicked.
    @Output() clearFamily: EventEmitter = new EventEmitter();

    constructor() {

    }

    getSelectionNames(index) {
        const currentMenu = this.selectedItems[index];
        let sectionString = '';

        for (let x = 0; x < currentMenu.length; x++) {
            sectionString += currentMenu[x].name;
            if (x < currentMenu.length - 1) {
                sectionString += ', ';
            }
        }
        return sectionString;
    }

    getSeparator(index) {
        const currentMenu = this.selectedItems[index];

        for (let x = 0; x < currentMenu.length; x++) {
            if (currentMenu[x].name.length > 0) {
                if (currentMenu[x].lastMenuGroup) {
                    return '';
                }
                this.isFamilySeparator = currentMenu[x].lastFamilyMember;
                return this.isFamilySeparator ? '|' : '>';
            }
        }
        return '';
    }

    clearBreadcrumbFamily(family) {
        this.clearFamily.emit(family);
    }

    navTo(option) {
        this.activateSelection.emit({menuId: option.selectedMenuOptions[0].menuId, selectedItems: option, isBreadCrumb: true});
    }

    getItems(family) {
        const crumbs = [];
        _.forEach(family.menus, (menu) => {
            const selectedMenuOptions = [];
            const selectedMenuNameOptions = [];
            _.forEach(menu.allOptions, (option) => {
                if (option.isSelected) {
                    selectedMenuOptions.push(option);
                    selectedMenuNameOptions.push(option.name);
                }
            });
            if (selectedMenuOptions.length > 0) {
                const crumbName = selectedMenuNameOptions.join();
                const menuObj = {'name': crumbName, 'selectedMenuOptions': selectedMenuOptions, 'isLast': false};
                crumbs.push(menuObj);
            }
        });
        crumbs[crumbs.length - 1].isLast = true;
        return crumbs;
    }



    hasSelectedMenus(fam) {
        for (let x = 0; x < fam.menus.length; x++) {
            if (_.some(fam.menus[x].allOptions, ['isSelected', true])) {
                return true;
            }
        }
        return false;
    }


}
