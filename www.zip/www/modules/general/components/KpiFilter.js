// This file was generated from the component scaffold
// Copyright 2016

import {Component, Input, Output, SimpleChanges, EventEmitter, ViewEncapsulation} from '@angular/core';
import template from './KpiFilter.html';
import styles from './KpiFilter.scss';

@Component({
    selector: 'kpi-filter',
    template: template,
    styles: [styles],
    host: {
        '(document:click)': 'onDocumentClick($event)',
        '(click)': 'onMenuClick($event)',
    },
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <kpi-filter name="KpiFilter" (change)="onChange($event)"></kpi-filter>
 */
export default class KpiFilter {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'KpiFilter';

    @Input() selectedFilters:any = {};

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();

    /**  Called whenever a selection change happens **/
    @Output() selectionChange: EventEmitter = new EventEmitter();

    @Input()
    filters = {};

    // Flag indicating menu visibility
    isMenuVisible = false;

    // selectedPeriod = null;
    selectedPeriodType = null
    selectedYear = null;
    selectedView = null;

    constructor() {}

    ngOnChanges(changes: SimpleChanges) {
        if (this.filters) {
            // Do Not show filters by default
        }

        if (changes['selectedFilters'] && changes['selectedFilters'].currentValue) {
            this.selectedPeriodType = this.selectedFilters.periodType;
            this.selectedYear = this.selectedFilters.year;
            this.selectedView = this.selectedFilters.view;
        }
    }


    onDocumentClick() {
        if (this.suppressDocClose) {
            this.suppressDocClose = false;
        }
        else {
            this.hideMenu();
        }
    }

    onMenuClick($event) {
        if (!this.suppressDocClose) {
            $event.stopImmediatePropagation();
        }
    }

    toggleMenu($event) {
        this.isMenuVisible = !this.isMenuVisible;

        if ($event) {
            if (this.isMenuVisible) {
                this.suppressDocClose = true;
            }
            else {
                $event.stopImmediatePropagation();
            }
        }
    }

    select() {
        const outputFilter = { periodType: this.selectedPeriodType, year: this.selectedYear, view: this.selectedView};
        this.selectionChange.emit(outputFilter);
    }

    showMenu() {
        // Shows the dropdown menu.
        this.isMenuVisible = true;
    }

    hideMenu() {
        this.isMenuVisible = false;
    }
}
