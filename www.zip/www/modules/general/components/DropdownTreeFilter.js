// This file was generated from the component scaffold
// Copyright 2016
/* globals _ */
import {Component, Input, Output, ElementRef, ViewChild, SimpleChanges, EventEmitter, ChangeDetectorRef, ViewEncapsulation} from '@angular/core';
import template from './DropdownTreeFilter.html';
import styles from './DropdownTreeFilter.scss';

// const MODE_LIST = 'list';
// const MODE_SELECT = 'select';
// const MODE_MUTLTISELECT = 'multiselect';

// const MODE_ADDCOMPAREITEM = 'addcompareitem';
const MODE_NO_FOOTER = 'no_footer';
const MODE_COMPARE = 'compare_mode';
const MODE_MENU = 'menu_mode';
const SEE_MORE = 'See More';
const SEE_LESS = 'See Less';


// Expose constants publicly.
export const MODES = {
    // LIST: MODE_LIST,
    // SELECT: MODE_SELECT,
    // MULTISELECT: MODE_MUTLTISELECT,
    MENU: MODE_MENU,
    COMPARE: MODE_COMPARE,
};

@Component({
    selector: 'dropdown-tree-filter',
    template: template,
    styles: [styles],
    host: {
        '(document:click)': 'onDocumentClick($event)',
        '(click)': 'onMenuClick($event)',
    },
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <dropdown-filter name='DropdownTreeFilter' (change)='onChange($event)'></dropdown-filter>
 */
export default class DropdownTreeFilter {
    // Expose constants to view.
    MODE_COMPARE = MODE_COMPARE;
    MODE_MENU = MODE_MENU;
    // MODE_LIST = MODE_LIST;
    // MODE_SELECT = MODE_SELECT;
    // MODE_MUTLTISELECT = MODE_MUTLTISELECT;
    MODE_NO_FOOTER = MODE_NO_FOOTER;

    @Input() name:string = 'DropdownTreeFilter';

    @Input() disabled:any = false;

    // Called when a menu is opened
    @Output() menuOpened:EventEmitter = new EventEmitter();

    // Called when a menu is closed
    @Output() menuClosed: EventEmitter = new EventEmitter();

    // Called when the compare menu item is clicked to launch into compare mode
    @Output() activateComparison: EventEmitter = new EventEmitter();

    // Called whenever a set of items are selected via the apply button .
    @Output() activateSelection: EventEmitter = new EventEmitter();

    /**
     * The tree of menu items.
     *
     * Each node must have a `name` and optionally an array of `options`. Note that the
     * root node must have a list of options; otherwise the menu is not useful.
     */
    @Input() menuTree = null;

    @Input() displayMode = MODE_MENU;

    @Input() displayFooter = true;

    @Input() addMode = '';

    @Input() selectLabel = 'Apply';

    @Input() selectMultiLabel = 'Compare';

    @Input() displayRootMenuItem = true;

    // the initial level of a selected item when the page is loaded
    @Input() initialLevel = { };

    // the initial Selected item when the page is loaded
    @Input() initialItem = { };

    // the default selected item in 'select' mode.
    @Input() defaultOption = null;

    // The root name to display inside the dropdown menu in 'select' mode.
    @Input() selectRootName = '';

    // A boolean that is set to true if the main view is Compare
    @Input() inCompareView = false;

    @ViewChild('filterMenu')
    filterMenu:ElementRef = this.filterMenu;

    @ViewChild('filterButton')
    filterButton:ElementRef = this.filterButton;

    @ViewChild('filterArrow')
    filterArrow:ElementRef = this.filterArrow;



    // Active list of items displayed (an item that has options)
    activeLevel = { options: [] };

    // The selected item to filter on. Can be a level (node w/ options) or an  item (leaf node)
    activeItem = null;

    // The display text
    activeLabel = null;

    // Flag indicating menu visibility
    isMenuVisible = false;

    // The search field text for the 'list' mode.
    search = '';


    // The search field text for the 'select' and 'multiselect' modes.
    searchCheck = '';

    // The searches of previous levels for the list view to maintain state.
    searches = [];

    // The option selected in 'select' mode.
    selectedSingleOption = null;

    // The state to restore the menu to if closed without changes selected.
    stateToRestore = null;

    suppressDocClose = false;

    // A flag used to toggle the compare button
    disableCompare = false;

    maxCompareItems = 4;

    compareButtonDisabled = true;

    // Text for the 'See More' / 'See Less' menu button
    moreLessText = SEE_MORE;

    // Boolean flag for the 'See More' / 'See Less' menu button
    allOptionsShown = false;

    applyButtonDisabled = false;
    constructor(changeDetectorRef:ChangeDetectorRef) {
        this._changeDetectorRef = changeDetectorRef;
    }

    ngOnInit() {
        if (matchMedia) {
            this.mq = window.matchMedia('(max-width: 1281px)');
            this.mqCallback = this.widthChange.bind(this);
            this.mq.addListener(this.mqCallback);
            this.widthChange(this.mq, this);
        }
    }

    ngAfterViewInit() {
        this.filterMenuElement = this.filterMenu.nativeElement;
        this.filterButtonElement = this.filterButton.nativeElement;
        this.filterArrowElement = this.filterArrow.nativeElement;
    }


    ngOnDestroy() {
        if (this.mq) {
            this.mq.removeListener(this.mqCallback);
            this.mq = null;
        }
    }

    toggleMoreItems() {
        this.allOptionsShown = !this.allOptionsShown;
        this.moreLessText = this.allOptionsShown ? SEE_LESS : SEE_MORE;
    }


    widthChange(mq) {
        const smallBrowserWidth = mq.matches;
        this.maxCompareItems = smallBrowserWidth ? 2 : 4;
        this.getCompareButtonState();
        this._changeDetectorRef.detectChanges();
    }

    getCompareButtonState() {
        this.compareButtonDisabled = _.filter(this.activeLevel.allOptions, 'isSelected').length > this.maxCompareItems;
    }

    getApplyButtonState() {
        // this.applyButtonDisabled = _.filter(this.activeLevel.allOptions, 'isSelected').length <= 0;// Need to figure out a way to enable button if user removes a selection
        this.applyButtonDisabled = false;
    }

    ngOnChanges(changes: SimpleChanges) {
        if (changes['menuTree'] && changes['menuTree'].currentValue) {
            this.activeLevel = this.menuTree;
            this.activeLabel = this.activeLevel.name;
        }

        if (changes['initialItem'] && changes['initialItem'].currentValue) { // item IS a level UNLESS it has no children
            this.activeLabel = this.activeLevel.name;
            this.activeItem = this.initialItem;

            this.searches = this.activeItem.searches ? this.activeItem.searches.slice() : [];
            this.search = '';
            if (this.initialItem.mode) { // TODO - The data in this if statement should be passed in NOT calculated -- refactor
                this.setMode(this.initialItem.mode);
            }
        }
        if (changes['inCompareView'] && changes['inCompareView'].currentValue) {
            this.displayMode = this.inCompareView ? MODE_COMPARE : this.displayMode;
        }
    }

    onDocumentClick() {
        if (this.suppressDocClose) {
            this.suppressDocClose = false;
        }
        else {
            this.hideMenu();
        }
    }

    onMenuClick($event) {
        if (!this.suppressDocClose) {
            $event.stopImmediatePropagation();
        }
        this.getCompareButtonState();
    }

    toggleMenu($event) {
        if (this.isMenuVisible) {
            this.hideMenu();
        }
        else {
            this.showMenu();
        }

        if ($event) {
            if (this.isMenuVisible) {
                this.suppressDocClose = true;
            }
            else {
                $event.stopImmediatePropagation();
            }
        }
    }

    showMenu() {
        // Shows the dropdown menu.
        this.isMenuVisible = true;
        this.stateToRestore = {
            activeLevel: this.activeLevel,
            activeLabel: this.activeLabel,
            activeItem: this.activeItem,
        };
        this.menuOpened.emit(this.menuTree);
    }

    hideMenu() {
        this.isMenuVisible = false;

        if (this.displayMode === MODE_COMPARE && !this.inCompareView) { // Always reset multiselect dropdowns on close
            this.setMode(MODE_MENU);
        }
        else if (this.inCompareView) {
            this.setMode(MODE_COMPARE);
        }

        if (this.stateToRestore) {
            this.activeLevel = this.stateToRestore.activeLevel;

            //  NOTE: This seems a bit specific, need to investigate further
            if (this.displayMode !== 'headlines') {
                this.activeLabel = this.stateToRestore.activeLabel;
            }
            this.activeItem = this.stateToRestore.activeItem;
        }
        this.menuClosed.emit(this.menuTree);
    }

    hasParent(level) {
        return level && level.parent;
    }

    // Prevent navigating to parents of subtree roots.
    canNavToParent(level) {
        return !level.isSubtreeRoot;
    }

    hasChildren(level) {
        return level && level.options && level.options.length;
    }

    select(item, level) {
        this.stateToRestore = null; // Clear because new state is being selected.
        this.activeLabel = item.name;
        this.activeItem = item;
        this.activeLevel = level || null; // Prevent drill down
        this.selectionChange.emit(this.activeItem, this.activeLevel);
        this.hideMenu();
    }

    setMode(newMode) {
        this.displayMode = newMode;

        // Clear checkmarks for the current level.
        if (newMode === MODE_MENU) {
            this.activeLevel.allOptions.forEach((item) => item.isSelected = false);
        }
    }

    compare() {
        const type = this.menuTree.compareType;
        const menuId = this.menuTree.id;
        const returnItem = {
            compareItems: _.filter(this.activeLevel.allOptions, 'isSelected'),
            type: type,
            menuId: menuId,
        };


        this.activateComparison.emit(returnItem);
        this.hideMenu();
    }

    // setSingleOption(item) {
    //     this.activeLevel.allOptions.forEach((c) => {
    //         if (c.isSelected && !c.isDisabled && c !== item) {
    //             c.isSelected = false;
    //         }
    //     });
    //     this.selectedSingleOption = item.isSelected ? item : null;
    // }

    selectMenuOption(option) { // fired when the select or apply button is triggered
        const selectedCollection = [];
        const selectedMenuObj = {};

        selectedMenuObj.menuId = this.menuTree.id;
        if (option) {
            _.forEach(this.activeLevel.allOptions, (c) => {
                c.isSelected = false;
            });
            option.isSelected = true;
            selectedCollection.push(option);
        }
        else {
            _.forEach(this.activeLevel.allOptions, (c) => {
                if (c.isSelected) {
                    selectedCollection.push(c);
                }
            });
        }
        selectedMenuObj.selectedItems = selectedCollection;
        this.activeLabel = selectedMenuObj.selectedItems[0].name;
        this.activateSelection.emit(selectedMenuObj);
        this.hideMenu();
    }

    resetMenuOpton(e) {
        e.stopImmediatePropagation();
        this.activeLevel = this.menuTree;
        this.activeLabel = this.activeLevel.name;
    }

    getLevelChildren(level) {
        return level && level.options || [];
    }


    getParentOrRootName(level) {
        return level.parent.name || level.name;
    }

    getHealthClass(numString) {
        if (numString) {
            return 'dropdown-filter-status health-level-' + numString;
        }
        else {
            return 'dropdown-filter-status health-level-0';
        }
    }

    cancel() {
        if (this.displayMode === MODE_COMPARE) {
            this.setMode(MODE_MENU);
        }
        else if (this.displayMode === MODE_MENU) {
            this.hideMenu();
        }
    }
}
