// This file was generated from the component scaffold
// Copyright 2016

import {Component, Injector} from '@angular/core';
import KpiFilter from './KpiFilter';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [KpiFilter],
    template: ''
})
class TestComponent {}

describe('general/KpiFilter.js', () => {

    beforeEach(() => {
        addProviders([KpiFilter]);
    });

    it('should return component name', inject([KpiFilter], (kpiFilter:KpiFilter) => {
        expect(kpiFilter.name).toBe('KpiFilter');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<kpi-filter></kpi-filter>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('kpi-filter h1').innerText).toBe('KpiFilter');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<kpi-filter name="TEST"></kpi-filter>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('kpi-filter h1').innerText).toBe('TEST');
            });
    })));

});
