// This file was generated from the component scaffold
// Copyright 2016

import {Component, Input, Output, SimpleChanges, EventEmitter, ViewEncapsulation} from '@angular/core';
import template from './TimelineFilter.html';
import styles from './TimelineFilter.scss';

const NONE = 'none';
const SPECIFIC = 'specific';
const CURRENT = 'current';

@Component({
    selector: 'timeline-filter',
    template: template,
    styles: [styles],
    host: {
        '(document:click)': 'onDocumentClick($event)',
        '(click)': 'onMenuClick($event)',
    },
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <timeline-filter name="TimelineFilter" (change)="onChange($event)"></timeline-filter>
 */
export default class TimelineFilter {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'TimelineFilter';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() selectionChange:EventEmitter = new EventEmitter();

    @Input() filters = {};

    @Input() selectedFilters:any = {};

    @Input() dateTimeText:string = '';

    // Flag indicating menu visibility
    isMenuVisible = false;

    selectedYearType = null;
    selectedView = null;
    selectedUpTo = CURRENT;
    selectedYear = null;
    selectedMonth = 'none';
    selectedQuarter = 'none';

    yearTypes = [''];
    currentFilter = {};

    constructor() {}

    reset() {
        if (this.currentFilter) {
            this.selectedYearType = this.currentFilter.yearTypes ? this.currentFilter.yearTypes[0] : null;
            this.selectedView = this.currentFilter.views ? this.currentFilter.views[0] : null;
            this.selectedYear = this.currentFilter.years ? this.currentFilter.years[0] : null;
        }
    }

    ngOnChanges(changes: SimpleChanges) {
        this.reset();
        // Check to see if filters changed. This only chages on a page load after that only the selectedFilter changes
        // Sets the default filter to the filterset whose name matches the first value in the yearType array
        // ( In this case that is 'Fiscal' ) We do this because the objects in yearTypeSets are not neccessarily in the same order
        // as the item in the yearType array -- so we use the name as a key to make sure we are using the correct yearTypeSet.
        if (changes['filters'] && this.filters && this.filters.yearTypeSets) {
            this.filters.yearTypeSets.forEach((typeSet) => {
                if (this.filters.yearTypes[0] === typeSet.name) {
                    this.currentFilter = typeSet.filterSet;
                }
            });
        }

        if (changes['selectedFilters'] && this.selectedFilters && this.selectedFilters.yearType) {
            this.selectedYearType = this.selectedFilters.yearType || this.currentFilter.yearTypes[0];
            this.filters.yearTypeSets.forEach((typeSet) => {
                if (this.selectedYearType === typeSet.name) {
                    this.currentFilter = typeSet.filterSet;
                }
            });

            this.selectedView = this.selectedFilters.view || this.currentFilter.views[0];
            this.selectedUpTo = this.selectedFilters.upTo || CURRENT;
            this.selectedYear = this.selectedFilters.year || this.currentFilter.years[0];
            this.selectedYear = this.selectedYear === NONE ? this.currentFilter.years[0] : this.selectedYear; // if selectedYear === none -- set it to the first available year
            this.selectedMonth = this.selectedFilters.month || NONE;
            this.selectedQuarter = this.selectedFilters.quarter || NONE;
        }
    }

    onDocumentClick() {
        if (this.suppressDocClose) {
            this.suppressDocClose = false;
        }
        else {
            this.hideMenu();
        }
    }

    onMenuClick($event) {
        if (!this.suppressDocClose) {
            $event.stopImmediatePropagation();
        }
    }

    onYearTypeSelect() {
        const selectedItem = this.selectedYearType;
        this.filters.yearTypeSets.forEach((typeSet) => {
            if (selectedItem === typeSet.name) {
                this.currentFilter = typeSet.filterSet;
            }
        });

        this.selectedView = this.currentFilter.views[0];
        this.selectedMonth = NONE;
        this.selectedQuarter = NONE;
        this.selectedUpTo = CURRENT;
    }

    toggleMenu($event) {
        this.isMenuVisible = !this.isMenuVisible;

        if ($event) {
            if (this.isMenuVisible) {
                this.suppressDocClose = true;
            }
            else {
                $event.stopImmediatePropagation();
            }
        }
    }

    showMenu() {
        // Shows the dropdown menu.
        this.isMenuVisible = true;
    }

    hideMenu() {
        this.isMenuVisible = false;
    }

    announceChange() {
        const timelineCriteria = {
            yearType: this.selectedYearType,
            view: this.selectedView,
            upTo: this.selectedUpTo,
        };

        if (this.selectedUpTo === SPECIFIC) {
            timelineCriteria.year = this.selectedYear;

            if (this.selectedMonth !== NONE) {
                timelineCriteria.month = this.selectedMonth;
            }
            else {
                timelineCriteria.quarter = this.selectedQuarter;
            }
        }

        this.selectionChange.emit(timelineCriteria);
        this.hideMenu();
    }

    cancel() {
        this.reset();
        this.hideMenu();
    }

    selectMonth() {
        this.selectedQuarter = NONE;
    }

    selectQuarter() {
        this.selectedMonth = NONE;
    }
}
