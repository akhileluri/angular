// This file was generated from the component scaffold
// Copyright 2017

import {Component, Injector} from '@angular/core';
import MenuFamily from './MenuFamily';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [MenuFamily],
    template: ''
})
class TestComponent {}

describe('general/MenuFamily.js', () => {

    beforeEach(() => {
        addProviders([MenuFamily]);
    });

    it('should return component name', inject([MenuFamily], (menuFamily:MenuFamily) => {
        expect(menuFamily.name).toBe('MenuFamily');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<menu-family></menu-family>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('menu-family h1').innerText).toBe('MenuFamily');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<menu-family name="TEST"></menu-family>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('menu-family h1').innerText).toBe('TEST');
            });
    })));

});
