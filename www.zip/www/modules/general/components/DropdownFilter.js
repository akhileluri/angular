// This file was generated from the component scaffold
// Copyright 2016
/* globals _ */
import {Component, Input, Output, SimpleChanges, EventEmitter, ChangeDetectorRef, ViewEncapsulation} from '@angular/core';
import template from './DropdownFilter.html';
import styles from './DropdownFilter.scss';

const MODE_LIST = 'list';
const MODE_SELECT = 'select';
const MODE_MUTLTISELECT = 'multiselect';
const MODE_ADDCOMPAREITEM = 'addcompareitem';
const MODE_NO_FOOTER = 'no_footer';


// Expose constants publicly.
export const MODES = {
    LIST: MODE_LIST,
    SELECT: MODE_SELECT,
    MULTISELECT: MODE_MUTLTISELECT,
};

@Component({
    selector: 'dropdown-filter',
    template: template,
    styles: [styles],
    host: {
        '(document:click)': 'onDocumentClick($event)',
        '(click)': 'onMenuClick($event)',
    },
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <dropdown-filter name='DropdownFilter' (change)='onChange($event)'></dropdown-filter>
 */
export default class DropdownFilter {
    // Expose constants to view.
    MODE_LIST = MODE_LIST;
    MODE_SELECT = MODE_SELECT;
    MODE_MUTLTISELECT = MODE_MUTLTISELECT;
    MODE_NO_FOOTER = MODE_NO_FOOTER;

    @Input() name:string = 'DropdownFilter';

    @Input() disabled:any = false;

    // Called when an option is selected
    @Output() optionChange:EventEmitter = new EventEmitter();

    // Called whenever a selection change happen
    @Output() selectionChange: EventEmitter = new EventEmitter();

    // Called when the compare menu item is clicked to launch into compare mode
    @Output() activateComparison: EventEmitter = new EventEmitter();

    /**
     * The tree of menu items.
     *
     * Each node must have a `name` and `health`. Optionally an array of `children`. Note that the
     * root node must have a list of children; otherwise the menu is not useful.
     */
    @Input() menuTree = null;

    @Input() displayMode = MODE_LIST;

    @Input() displayFooter = true;

    @Input() addMode = '';

    @Input() selectLabel = 'Select';

    @Input() selectMultiLabel = 'Compare';

    @Input() displayRootMenuItem = true;

    // the initial level of a selected item when the page is loaded
    @Input() initialLevel = { };

    // the initial Selected item when the page is loaded
    @Input() initialItem = { };

    // the default selected item in 'select' mode.
    @Input() defaultOption = null;

    // The root name to display inside the dropdown menu in 'select' mode.
    @Input() selectRootName = '';

    // Active list of items displayed (an item that has childrenTiles)
    activeLevel = { childrenTiles: [] };

    // The selected item to filter on. Can be a level (node w/ childrenTiles) or an  item (leaf node)
    activeItem = null;

    // The display text
    activeLabel = null;

    // Flag indicating menu visibility
    isMenuVisible = false;

    // The search field text for the 'list' mode.
    search = '';


    // The search field text for the 'select' and 'multiselect' modes.
    searchCheck = '';

    // The searches of previous levels for the list view to maintain state.
    searches = [];

    // The option selected in 'select' mode.
    selectedSingleOption = null;

    // The state to restore the menu to if closed without changes selected.
    stateToRestore = null;

    suppressDocClose = false;

    // A flag used to toggle the compare button
    disableCompare = false;

    maxCompareItems = 4;

    compareButtonDisabled = true;
    constructor(changeDetectorRef:ChangeDetectorRef) {
        this._changeDetectorRef = changeDetectorRef;
    }

    ngOnInit() {
        if (matchMedia) {
            this.mq = window.matchMedia('(max-width: 1281px)');
            this.mqCallback = this.widthChange.bind(this);
            this.mq.addListener(this.mqCallback);
            this.widthChange(this.mq, this);
        }
    }


    ngOnDestroy() {
        if (this.mq) {
            this.mq.removeListener(this.mqCallback);
            this.mq = null;
        }
    }


    widthChange(mq) {
        const smallBrowserWidth = mq.matches;
        this.maxCompareItems = smallBrowserWidth ? 2 : 4;
        this.getCompareButtonState();
        this._changeDetectorRef.detectChanges();
    }

    getCompareButtonState() {
        this.compareButtonDisabled = _.filter(this.activeLevel.childrenTiles, 'isChecked').length > this.maxCompareItems;
    }

    ngOnChanges(changes: SimpleChanges) {
        if (changes['menuTree'] && changes['menuTree'].currentValue) {
            this.activeLevel = this.menuTree;
        }

        if (changes['initialItem'] && changes['initialItem'].currentValue) { // item IS a level UNLESS it has no childrenTiles
            this.activeLabel = this.initialItem.name;
            this.activeItem = this.initialItem;

            // NOTE: This code is retained in order to restore old behavior if the team decides against
            //       the new behavior. These first two condition blocks would replace the `if` condition
            //       below.
            // if (this.activeItem && this.activeItem.childrenTiles && this.activeItem.childrenTiles.length > 0) {
            //     this.activeLevel = this.activeItem;
            // }
            // else if (this.activeItem && this.activeItem.parent) {
            //    this.activeLevel = this.activeItem.parent;
            // }
            if (this.activeItem && this.activeItem.parent && !this.activeItem.isSubtreeRoot) {
                this.activeLevel = this.activeItem.parent;
            }
            else {
                this.activeLevel = this.activeItem;
            }

            this.searches = this.activeItem.searches ? this.activeItem.searches.slice() : [];
            this.search = '';
            if (this.initialItem.mode) { // TODO - The data in this if statement should be passed in NOT calculated -- refactor
                this.setMode(this.initialItem.mode);
            }

            if (this.displayMode === MODE_SELECT && changes['defaultOption']) {
                this.selectedSingleOption = changes['defaultOption'].currentValue;
            }
        }
    }

    onDocumentClick() {
        if (this.suppressDocClose) {
            this.suppressDocClose = false;
        }
        else {
            this.hideMenu();
        }
    }

    onMenuClick($event) {
        if (!this.suppressDocClose) {
            $event.stopImmediatePropagation();
        }
        this.getCompareButtonState();
    }

    toggleMenu($event) {
        if (this.isMenuVisible) {
            this.hideMenu();
        }
        else {
            this.showMenu();
        }

        if ($event) {
            if (this.isMenuVisible) {
                this.suppressDocClose = true;
            }
            else {
                $event.stopImmediatePropagation();
            }
        }
    }

    showMenu() {
        // Shows the dropdown menu.
        this.isMenuVisible = true;
        this.stateToRestore = {
            activeLevel: this.activeLevel,
            activeLabel: this.activeLabel,
            activeItem: this.activeItem,
        };
    }

    hideMenu() {
        this.isMenuVisible = false;

        if (this.displayMode === MODE_MUTLTISELECT) { // Always reset multiselect dropdowns on close
            this.setMode(MODE_LIST);
        }

        if (this.stateToRestore) {
            this.activeLevel = this.stateToRestore.activeLevel;
            this.activeLabel = this.stateToRestore.activeLabel;
            this.activeItem = this.stateToRestore.activeItem;
        }
    }

    hasParent(level) {
        return level && level.parent;
    }

    // Prevent navigating to parents of subtree roots.
    canNavToParent(level) {
        return !level.isSubtreeRoot;
    }

    hasChildren(level) {
        return level && level.childrenTiles && level.childrenTiles.length;
    }

    select(item, level) {
        this.stateToRestore = null; // Clear because new state is being selected.
        this.activeLabel = item.name;
        this.activeItem = item;
        this.activeLevel = level || null; // Prevent drill down
        this.selectionChange.emit({item: this.activeItem, parent: this.activeLevel});
        this.hideMenu();
    }

    setMode(newMode) {
        this.displayMode = newMode;

        // Clear checkmarks for the current level.
        if (newMode === MODE_LIST) {
            this.activeLevel.childrenTiles.forEach((item) => item.isChecked = false);
        }
    }

    compare() {
        const type = this.menuTree.compareType;
        const returnItem = {
            compareItems: _.filter(this.activeLevel.childrenTiles, 'isChecked'),
            type: type,
        };


        this.activateComparison.emit(returnItem);
        this.hideMenu();
    }

    setSingleOption(item) {
        this.activeLevel.childrenTiles.forEach((c) => {
            if (c.isChecked && !c.isDisabled && c !== item) {
                c.isChecked = false;
            }
        });

        this.selectedSingleOption = item.isChecked ? item : null;
    }

    selectSingleOption() {
        const type = this.menuTree.compareType;
        const returnItem = {compareItems: [], type: type};


        if (this.addMode === MODE_ADDCOMPAREITEM) {
            const selectedCollection = [];

            _.forEach(this.activeItem.childrenTiles, (c) => {
                if (c.isChecked) {
                    selectedCollection.push(c);
                } });

            returnItem.compareItems = selectedCollection;
            this.optionChange.emit(returnItem);
        }
        else {
            this.optionChange.emit({id: this.selectedSingleOption.id, index: this.activeItem.index});
        }
        this.hideMenu();
    }

    getLevelChildren(level) {
        return level && level.childrenTiles || level || [];
    }

    goDown($event, newLevel) {
        if (newLevel.childrenTiles) {
            if (this.activeLevel) {
                newLevel.parent = this.activeLevel;
            }

            this.activeLevel = newLevel;
            this.activeItem = newLevel;
            this.activeLabel = this.activeLevel.name;
            this.searches.push(this.search);
            this.search = ''; // Clear search to prevent filtering on new level.
        }

        if ($event) {
            $event.stopImmediatePropagation();
        }
    }

    goUp($event) {
        if (this.activeLevel.parent) {
            this.activeLevel = this.activeLevel.parent;
            this.activeItem = this.activeLevel;
            this.activeLabel = this.activeLevel.name;
            this.search = this.searches.pop();
        }

        if ($event) {
            $event.stopImmediatePropagation();
        }
    }

    getParentOrRootName(level) {
        return level.parent.name || level.name;
    }

    getHealthClass(numString) {
        if (numString) {
            return 'dropdown-filter-status health-level-' + numString;
        }
        else {
            return 'dropdown-filter-status health-level-0';
        }
    }

    cancel() {
        if (this.displayMode === MODE_MUTLTISELECT) {
            this.setMode(MODE_LIST);
        }
        else if (this.displayMode === MODE_SELECT) {
            this.hideMenu();
        }
    }
}
