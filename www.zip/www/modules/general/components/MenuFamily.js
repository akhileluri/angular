// This file was generated from the component scaffold
// Copyright 2017
/* global */

import {Component, Input, Output, EventEmitter, QueryList, ViewChildren, SimpleChanges} from '@angular/core';
import {COMMON_DIRECTIVES} from '@angular/common';
import template from './MenuFamily.html';
import styles from './MenuFamily.scss';
import DropdownTreeFilter from './DropdownTreeFilter';



@Component({
    selector: 'menu-family',
    template: template,
    styles: [styles],
    directives: [
        COMMON_DIRECTIVES,
    ],
})

/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <menu-family name="MenuFamily" (change)="onChange($event)"></menu-family>
 */
export default class MenuFamily {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'MenuFamily';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();

    @Input() family = null;

    @Input() disableGatedMenus = null;

    @Input() viewType = null;

    // Called when a menu is opened
    @Output() menuOpened:EventEmitter = new EventEmitter();

    // Called when a menu is closed
    @Output() menuClosed: EventEmitter = new EventEmitter();

    // Called when the compare menu item is clicked to launch into compare mode
    @Output() activateComparison: EventEmitter = new EventEmitter();

    // Called whenever a set of items are selected via the apply button .
    @Output() activateSelection: EventEmitter = new EventEmitter();


    // NOTE: Must assign to ViewChild explictly due to bug in Babel/Angular2 decorator plugins.
    // See last comment on https://github.com/angular/angular/issues/7906
    @ViewChildren(DropdownTreeFilter) dropdownFilters: QueryList<DropdownTreeFilter> = this.dropdownFilters;

    @Input() filterActive = null;


    constructor() {

    }

    ngOnChanges(changes: SimpleChanges) {
        if (changes['filterActive'] && changes['filterActive'].currentValue) {
            setTimeout(() => {
                this.checkMenuPositions();
            });
        }
    }

    checkMenuPositions() {
        if (!this.dropdownFilters) {
            setTimeout(() => {
                this.checkMenuPositions();
            });
        }
        else {
            this.positionMenus();
        }
    }

    positionMenus() {
        if (this.dropdownFilters) {
            this.dropdownFilters.forEach((filter) => {
                const adjPos = parseInt(filter.filterButtonElement.offsetTop, 10) + 48 + 'px';
                filter.filterMenuElement.style.top = adjPos;
                filter.filterArrowElement.style.top = adjPos;
            });
        }
    }

    onMultiSelect(event) {
        this.activateSelection.emit(event);
    }

    onCompareItems(event) {
        this.activateComparison.emit(event);
    }

    onMenuOpened(menu) {
        this.menuOpened.emit({'family': this.family, 'menu': menu});
    }

    onMenuClosed(menu) {
        this.menuClosed.emit({'family': this.family, 'menu': menu});
    }

}
