// This file was generated from the component scaffold
// Copyright 2016

import {Component, Injector} from '@angular/core';
import DataTable from './dataTable';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [DataTable],
    template: ''
})
class TestComponent {}

describe('general/dataTable.js', () => {

    beforeEach(() => {
        addProviders([DataTable]);
    });

    it('should return component name', inject([DataTable], (dataTable:DataTable) => {
        expect(dataTable.name).toBe('DataTable');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<data-table></data-table>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('data-table h1').innerText).toBe('DataTable');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<data-table name="TEST"></data-table>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('data-table h1').innerText).toBe('TEST');
            });
    })));

});
