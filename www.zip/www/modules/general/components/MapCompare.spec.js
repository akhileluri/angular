// This file was generated from the component scaffold
// Copyright 2016

import {Component, Injector} from '@angular/core';
import MapCompare from './MapCompare';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [MapCompare],
    template: ''
})
class TestComponent {}

describe('general/MapCompare.js', () => {

    beforeEach(() => {
        addProviders([MapCompare]);
    });

    it('should return component name', inject([MapCompare], (mapCompare:MapCompare) => {
        expect(mapCompare.name).toBe('MapCompare');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<map-compare></map-compare>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('map-compare h1').innerText).toBe('MapCompare');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<map-compare name="TEST"></map-compare>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('map-compare h1').innerText).toBe('TEST');
            });
    })));

});
