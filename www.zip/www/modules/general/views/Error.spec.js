// This file was generated from the view scaffold
// Copyright 2016

import {Component, Injector, provide} from '@angular/core';
import Error from './Error';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [Error],
    template: ''
})
class TestComponent {}

describe('general/Error.js', () => {

    beforeEach(() => {
        addProviders([
            Error
        ]);
    });

    it('should initialize default name', inject([Error], (error:Error) => {
        expect(error.name).toBe('Error');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<error></error>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('error h1').innerText).toBe('Error');
            });
    })));

});
