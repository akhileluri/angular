export const GENERAL_VIEWS = [];

export Error from './Error';
GENERAL_VIEWS.push(exports.Error);
