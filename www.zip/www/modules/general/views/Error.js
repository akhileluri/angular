// This file was generated from the view scaffold
// Copyright 2016

import {Component} from '@angular/core';
// import {ROUTER_DIRECTIVES} from '@angular/router';
// import {COMMON_DIRECTIVES} from '@angular/common';
import template from './Error.html';
import styles from './Error.scss';

@Component({
    selector: 'error',
    template: template,
    styles: [styles],
    // directives: [
    //     COMMON_DIRECTIVES,
    //     ROUTER_DIRECTIVES,
    // ],
})
/**
 * @see https://angular.io/docs/ts/latest/guide/router.html
 */
export default class Error {

    /**
     * Default name for the class, passed by reference via RouteParams
     */
    name:string = 'Error';

    constructor() {

    }
}
