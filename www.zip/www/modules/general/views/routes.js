import { Routes } from '@angular/router';

const ROUTES: Routes = [];
export default ROUTES;

ROUTES.push({
    path: 'Error',
    component: require('./Error'),
});

ROUTES.push({
    path: '**',
    component: require('./Error'),
});
