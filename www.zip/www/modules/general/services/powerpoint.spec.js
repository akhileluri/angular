// This file was generated from the service scaffold
// Copyright 2018

import {Injector} from '@angular/core';
import {
    addProviders,
    TestComponentBuilder,
    ComponentFixture,
    inject
} from '@angular/core/testing';
import Powerpoint from './powerpoint';

describe('general/services/powerpoint.js', () => {

    beforeEach(() => {
        addProviders([Powerpoint]);
    });

    it('should return powerpoint instance', inject([Powerpoint], (powerpoint:Powerpoint) => {
        expect(powerpoint).toBeDefined();
    }));

    it('should return name', inject([Powerpoint], (powerpoint:Powerpoint) => {
        expect(powerpoint.getName()).toBe('powerpoint');
    }));

});
