// This file was generated from the service scaffold
// Copyright 2018

import {
    Injectable
} from '@angular/core';
import KpiService from '../../app/services/KpiService';
import KpiDetailService from '../../app/services/KpiDetailService';
import KpiCategoryService from '../../app/services/KpiCategoryService';
import SharedStateService from '../../app/services/SharedStateService';
import DataTable from '../components/dataTable';
import {
    formatShortNum,
    shortNumSymbol
} from '../../chart/util/numberAbbrv';
import {
    reformatPercent
} from '../../chart/util/format';

const _ = require('lodash');
const canvg = require('canvg-browser');
const pptx = require('pptxgenjs');

/**
 * @example
 * let injector = Injector.resolveAndCreate([Powerpoint]);
 * let powerpoint = new injector.get(Powerpoint);
 * @example
 * class Component {
 *         constructor(powerpoint:Powerpoint, powerpoint2:Powerpoint) {
 *            //injected via angular, a singleton by default in same injector context
 *            console.log(powerpoint === powerpoint2);
 *        }
 * }
 */
@Injectable()
export default class Powerpoint {
    constructor(kpiService: KpiService, kpiDetailService: KpiDetailService, kpiCategoryService: KpiCategoryService,
        sharedStateService: SharedStateService) {
        this._kpiService = kpiService;
        this._kpiDetailService = kpiDetailService;
        this._kpiCategoryService = kpiCategoryService;
        this._sharedStateService = sharedStateService;
    }

    getName(): string {
        return 'Powerpoint';
    }

    generateKPIs(tilekpi?) {
        const promise = new Promise((resolve) => {
            //  Determine which service to fetch the sorted KPIs from
            let kpis = [];
            const kpiMasterList = [];
            let kpiChildList = [];

            if (tilekpi) {
                kpis = [tilekpi];
            } else {
                const sort = this._kpiService.getActiveSort();
                if (sort.sortId === 'category') {
                    //  Category Sorting
                    kpis = this._kpiService.getSortedKpis();
                    // kpis = this._kpiCategoryService.getKpiCategories();
                } else {
                    //  All Other Types of Sorting (Currently: Priority, or Last Updated)
                    kpis = this._kpiService.getSortedKpis().slice();
                }
            }
            //  TODO: This should really be an ENUM type of thing
            let currenCount = 1;

            const loop = (kpi) => {
                // check for displayed kpis
                this._kpiDetailService.getKpiDetail({
                        kpi: kpi.tileConfiguration.detailLinkTileId
                    })
                    .then((response) => {
                        kpiMasterList.push(kpi);
                        currenCount++;
                        if (response && response.kpiCategories && response.kpiCategories.length) {
                            for (let y = 0; y < response.kpiCategories.length; y++) {
                                this._sharedStateService.setPowerpointState('Loading items from Section #' + currenCount);
                                kpiChildList = kpiChildList.concat(response.kpiCategories[y].kpis);
                            }
                        }
                        if (kpis.length) {
                            loop(kpis.shift());
                        } else {
                            //  Now render all the stuff out
                            window.requestAnimationFrame(function () {
                                resolve(kpiChildList);
                            });
                        }
                    });
            };

            loop(kpis.shift());

        });

        return promise;
    }

    generatePowerpoint(powerpointKPIContainer, kpis) {
        const self = this;
        self._sharedStateService.setPowerpointState('Creating Slides ');
        //  The actual markup of the visible KPIs - used to retrieve the rendered charts
      
        const $kpis = $(powerpointKPIContainer.nativeElement).find('kpi');

        console.log('akhil33', kpis, $kpis);
        if (($kpis.length > 0 && kpis.length > 0) || $kpis.length === 0) {
            console.log('akhil44', kpis, $kpis);
            if ($kpis.length === kpis.length || $kpis.length === 0) {
                //  Configure Slideshow
                //  NOTE: Update the slideDimensions to match the setLayout if it is changed!
                //  SEE: https://github.com/gitbrent/PptxGenJS#presentation-layout-options
                pptx.setLayout('LAYOUT_16x9');
                const slideDimensions = {
                    w: 10.0,
                    h: 5.625
                };

                const margins = {
                    top: 1.65,
                    right: 0.75,
                    bottom: 0.875,
                    left: 0.625,
                    topWithoutNarrative: 0.985,
                    betweenCharts: 0.125,
                    leftText: 0.185,
                    leftTextWithToC: 1.0,
                    leftChoroplethFirst: 0.425,
                    leftChoroplethSecond: 5.25,
                };

                const scalingFactor = 3;

                //  OPTIONAL: Switch to include a Table of Contents
                const includeToC = false;

                //  Colours
                const palette = {
                    black: '000000',
                    grey_light: 'F4F4F4',
                    grey_middle: 'C7C7C7',
                    purple: '46166B',
                };

                pptx.defineSlideMaster({
                    title: 'GRAPH_MASTER',
                    bkgd: palette.grey_light,
                    margin: 0.001,
                });

                const categoryTextOptions = {
                    x: (margins.leftTextWithToC),
                    y: 0.1,
                    font_size: 10,
                    bold: true,
                    color: palette.purple,
                };

                const titleTextOptions = {
                    x: (margins.leftTextWithToC),
                    y: 0.36,
                    font_size: 18,
                    bold: true,
                    color: palette.purple,
                };

                if (includeToC === false) {
                    categoryTextOptions.x = margins.leftText;
                    titleTextOptions.x = margins.leftText;
                }

                const titleHorizontalRule = {
                    x: (titleTextOptions.x + 0.1),
                    y: (titleTextOptions.y + 0.37),
                    w: (slideDimensions.w - titleTextOptions.x - 1.6),
                    h: 0.0,
                    line: palette.purple,
                    line_size: 1.5,
                };

                const logoImageOptions = {
                    x: (slideDimensions.w - 1.17),
                    y: 0.15,
                    w: 0.96,
                    h: 0.39,
                    data: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAaQAAACsCAYAAAA0aNjsAAAABmJLR0QA/wD/AP+gvaeTAAArU0lEQVR42u1dCZgcVbnteW48RZYw3TUJ+AyK+hSEKCqLCEMy090TBBEIoiwi4DBdVT0JEBZZI4ggKqJsRkAWiQJqcGWRx6pgWIIgBGUJW0wgQAgECNkI7/+r7mR6enqp6vvX2ud8X31AmPR036665/7bOZkMAABAStC3Rfk9u4/rf6/O1T3+4PWwkgAAAIAWCll7aj5nrdG5enPW8km5qQZWEwAAAGgZ240pb5A3rJd0SSlvmCdgNQEAAAAt5HPmKfqEZD27bab/XVhNAAAAoGX0bNy/Ya9hvahLSoWcvTdWEwAAANBCIVc6WaCWdDNWEgAAANCOkohUXtAlpcmG/UmsJgAAAKCFvFE6UbuWlDPPx0oCAAAAWujjjjv9KGnZbhuWNsZqAgAAAFooGNbx2s0NhjkVKwkAAABooTtrrk+k8pwmKf17RmbGf2E1AQAAAC3ks+ZxulFSMWcXsJIAAACAHiEZ09+Xz9mLNFvAf4+VBAAAAPRJKWcdrUlIq3qM0ofi+vmcNnfDPrQ3Z/+WVCb+Re95OV1vD12FnDMoPIf+eWk+a5fp5z7PRI07AwAAIIFREjVInBm3z1XotD5NKcmL6f29XklAHi8m2nkOieXM75N+3xFEWAcSYfX1Zs0JTHK4cwAAAILYvHPmUVpREskRsT1F1J9jypYz3t1rmF+l93RXCyTk91pC150UfZ3RQ3U0NHcAAAAIgMmENteFeqKr5UOiev/d4/o7C1nrWBXpeSAT8zH62cuJTE6gfz4kQ1Dm37s3mrYR7iYAAABNcFpKs+NubtjvuZizdqDU2hX0u9/0RBpZ61c92fKnRnxuN60nFDXZUK8AAADQjjLIDZatJfRIaXDH4ImTal6G3U+/7x++yCJrfWvUZ87MeCf9+SOCabyVfV3lLO4mAAAATbDygmaUdGVghElpOYqGvq1qNy2RBftBFTr7x/LrEXF8gv7sN9K1pV7DhnoFAACATJRkP6Nh3vfmxE0GNpV8T8XO0sdUWm5lCI0K+oSUtW7FnQQAACCAfLZU1jPvK50s8j4Me3NnNojmnJJARBXXm31blN+DOwkAAEAgSqI27qdbJyV7gY7F+eSs2UWvM5Ou1QkjouEoqdP+DO4kAAAAARSyJUsrSuoa3Nfv7+SoglJzR2rUiGKUtrOn4C4CAAAQgEMOGlESDafe5uf3ERF9mf7ek0knouGOPnMf3EUAAABCyOcGSloq4F3Txjf7HcWugfHUdv3H1BCRe73GaUfcQQAAAELQnUsqZq3J9V6ba0yusoL1RtrIqNhld+PuAQAAEEYxZx7egvr3cppn+ma91+SCP/3cwykjIkc6iFvUcdcAAAAEAI5kaLN93EeH3ROssl3rtVh8VBkCrkoREa2gazYNw+5BH7EDdwwAAECAoJO/6XEo9u4hFYRRUVF28CP0M3enhIRWkd3GNaT9t/sOmx3x37hDAAAA4hUlXVlvGJQ7zuj/L006EZFFx/1s0yGtRAEAAAD4iZLIcbW+MoPFygwddYhsZtJJiLXp8mPMD+AuAAAAiAHY+E7NCVU7xR5f6+fZF4hSfdcllIheYhsJev87ZlAXAgAAiB8KWfsbI8moNK3Wz7kq2myAl6zmBNeu3N6TyRffNgAAQJyjpMyUd1DjwiNuA4N5RK2foSHXnWNXLzLs24gg9+e0W49R+pCjCsF+Supi+/Gejfs3xDcMAACQIBDhfL2YKx1Z6/+RXNBX42IRQXWtF0n66EzMBQEAALQZeBBWpfKiJqMHemmYd4/OQ96PbwUAAKDdoqacdXT0YqbWLZx6w7cBAADQrpFR1rQjJKK32IK82GV+Ft8EAABAW0dGjoLD2giIiPXyrkB9CAAAABhqYIiiZvSXQlf5c/gGAAAAAErTlb8Qdjcddc09ihoRAAAAsA6TOq2P0izSyyGS0Sss3dOdmfFOrD4AAADgoG9MeYOQfYxm0+/cDCsPAAAAjAA1MVwbEhE9xwrhWPGEgwbC8r1Ze4rUlabTSbFrYLzk2lRfk7NmV6pTNZtamwS1dqwflqa16s6a64uuD23ObG4XKRm5at9hkNFlhc2OGBPn75dVzLvHT9uo0DltLLW9bzHZsD9ZyJW34fbzoYv/exJp+vH/zxsDuXrWHKkFyXlsLd2CSdIbV6eGrLPmwUE+SJTnPjfVp2PD+m6QdYKUHQxPktdjs/aL7DDCdaOc9UbQUVHBKPfE7btk7btC1+C+pETxHdoP/0Dv8ym/lu4V1wvUrj67kC1ZqW9Zp1PUVUEMnhW6rC1BSJ6uZZxjT+O9xa6YrA0GQmoOlqyhz7NE/MCTs+ZFESU5tuM5846AO+j+2jNu6v/E4fvry5Y/RR5IxzBx0HtbqEE+TS86uNzPIrWTclONlJ1eB7ZSU8uBhNAgJI+bRtay0khIynbgbRCSp4PhcYFt3Ib1pdR991nz5SmZ6OweOP1WNAYnUQT641p+TyFdy4gET02N/h6dYH4R5FQ050FBSJ70tB7JpNDQiz7bP0BIzcG1I9fcLbB1mhvm/cWWDJxmCvq5iWK+iIdrXRKyn4+IhGpdC4tJn7VS+d2gJ6Z/CkLyeIrtMndNVz3E/nwYsyapiCRz5lFp2rzp950VTiODeV0Yn4cbj9jhluq982JEQlVpPGtVPUv4ZGwYhvXzEG6aVXHJ8cadkFjsMVXRUTC1ydQR0u7j+t9Ln+P5ENbqrlAOulTXoN/1ZkjPzFo+WAf0UTooEvoi1Wtu5M0+rkQ0yho+Z52XwNqRvXneXeTgT/5Z8xwQkqdrdVra5flz8OcBIXkhbmswRKuFnYOPjK1vh6tRZ35fNH1Kyg6U/jqA05xJIaHRlzk9abn9mSHeNG8WOvvHgpA8bRinpSM6sk4LSx4myevEXYhUi1gU3rNo3xjk5+FCv+owC1M0dWnemP4+iUiVu+SC7pAL5TLslb3ZaRMS8RBMHmt9MKzoqMKb/gwQkqfrhaQPwnWPP3i9MAraaSAkev+l8FWvzR2Dy7xY+0Xhb8ROr3oRkXl4hJ1yQUVJdySinsQ5xghummVxn6KOCSFRi679tSRvsnTKPChMAc2krtOULWe8myLJZ8N+Fun5/32ABPu7KAiJ7rn7W4vky/vQ3/93uoioop4U91nQiZsMbEpvdEU0Lo32DBCSp+vOhJ/654KQPBC3YX4zIrfUtYVO69PidUOK7PngKaZJ5zdK6izt4v2ZHvyIIs81ab5iP9/IDQYR2ga/wvMJICQPV2dp2yRusiSXsn3Y91Qi05qUJqL3Pj+qZzEIaS9uKxeSOvoJD/K2MPx7jZd0MjUszKDGi+VpJyOVtrs8vhtrpz0uxHbMOh131rEgJE9T6BcnNDqaBUKK6T0VsLQXZ0AEyOjPQ/5FdLq/R7JLtZCz96bXf7Y9iEil7DyQdHSbBTUWSKgvaKbtFvEpBZtH02s5q2QnaZ1UOngVCKkxHI03UuaI9jl0Nv9LYnYYmVvZLddSlJSzT61+X7ttWNqYIqIr2omIYk9ILGNOb/B1zRtmIX2xRwqoW08FIXkq1B6VrOhI4ITcBoREaZT9BeqxP6N/3hwnaa8WIpoRe0uN0ZAO+vMHdWYelWX6k+1IRjEnJBELgKPVVPlizddZkKTW5gjTK09E7WXjs6C9GIQUTnTUlyt/mD3M4iTtpdExuKaefQQdXvfwOotErdt7Df09R/iUZ+FoHic+s0HWy1S7u5UOJD9zhHSpw6+YnbpTfhP7f7vH9XeOqndtNG0jFjDgn2GhWiKX0+l1/kLXq4kmJG63Vh9Ca/hsSFGWFvbEKOcG2infT6fOye1z6k8/IVENdV+Bz/zrijT8fXGR9mq1SYM9oBq8LEdJDzRpY3+UXQsqU8eUyflr9CRkP0RZjgvJcO+gPjLckzpcOnNTTGR0mKDvf0niCElCyoMepNMrc7IC7Z1PDhUvQUiNi7wJaWaYA0LyEB3lrIe1Dymd9mcqCOkrcZH2ajHyu73ZRt0oSuKZKlZKr3gPO0emtOCQg3m52zwxkBPZe+i75nuGXvOX3MVYvVZOxipbKtcz/4sdITlhHz20ugX26gUmkvuBQI3kIBBSpOKRMqd+luOPcJQgMZF2zvqygMrCTZWvOSUz5R30Z49pvu4bEhsovY+/+95XKF3l4aXrRUkXVB5q2bCODnArwvYj6mXr9K7ybtJlCIfYRrvtPklpv+OrRQaclDmXZapSlLEjJCFL5AuqX1d1VK3UPP3/Kwk1kqhbdJn8Y77RXgFC8rSpantD1aq19LqyN5FLe/GogmCqrqoGbu5e1dQxvZKUKVK6IMRUHIsG3543yocEYYzHZKOcGNY2KqHwCA3Xyqqi1J3p775YMYf0i9g8AUKWyKu5sFanUeISgVTgviCkcMQjgwD7xGgfTNqAkNjGQCB9e2+t13YbSrQFWrWlvYgUDvRxyHqapZP8PYduF19l96nbZGVeGxIZUR3ePJ/rQUGldHtdlfHFPmrM97DqxIhn0rA/OZS2pCjrpPg8BBKWyFnrV/Vev9hZ+piA/fkDmZgLAGoTEkWC+s0N5sGxXBtKH2jL2HBROt2E1CHQfED3gD0l0GddU9pLjZa86S1db/O+MZvWZaLXLInrTWQdOSKSyFl/C4GInirmSkdy+SOo+0Olcx9s9RnoyZo7jdibuenBoO8ia/fFo3YkY4lMm0V5mybF7NkCc0l7pJmQVGeVLnH/I27r4oiD6p7MqWmDXuPyNBOSjKSO+Rinpur9DlIo2MCJpPV+zxLdFBSl4S5sZQyEPY2KXeZnvZKTSmvdG3Cb9iPcbu03kvMKju44ImJhWIFMwevVWn6OlYZQc4VAQUzEEvn6Zr+HbyKB33N3qgmJhCzZhybOtgEtpqH2ywu0taedkNipVaDG0+8hWj0zamkvblLQNGZk25JZ3PDE6eAoyIiilfmsuB9EfZtfs9Bl7kpZgUsFhWiHh4sr0q6NDjChwjX90rdELnbZ3R5zu7cKLGZvqglpVFG2pWtWzDbaOzVtEB51i/3pJSROSUlsNF46uISswxfzyV0zSjpJaINd6zSC0Bquy/xQ2iwwMjKcjNLR0tJmTKzKkmVW8D5hsu65QrUjEUvkuzxHY1mzKHACvC3NhKRmUHTVnVfWOzWGDYnIeKg4nWZCkjis+YlaJJygdaW9+GQudEjlQ8sNQ51knDqj6OX/AoiIWH9xZi21BN+lEiIzHoOgGtmAknd6sEm3nOT1eFz2h6roSN8SmYtsPk/Lc/UfvPIX0kpIauOdLtBpdWJMoqPLdHPeQ0XitBKSGtLU7rDk+pDnepVR+pCA8Kq2tBfbzOhG0LQHzRuqaTkHOsO8KghX1WJu6tZ+ScdJTVLDAP19k6MSeq3fKPJZnY+m23RObOpFVRtFSYCM5mV8dr5J1BP4NJRmQlJDytoCt9WzB2FDpYY0TR7tnw3fsyklJBpijWI+iIch4yDtpUjproqOXT/v4VXu4q1Yy1OkB1qLNEhbzNqHcu2t8qL78WwVac5ym27oMzgqFM5BP1L7nppjOaTZF1TjhRbELJGz1iGthOkcMurXrczPppWQ3PSmdZE+cdt7R7oe+q3eb1d2b6aRkLgNV8SChMi/hft1gkCaSETai1+DU470nlYpUzyvmYD9Ku6PPdUwqlSKbnZfV6kv79ai3k7w9buesebH45uvNqzDBD7kM62ewCWiM17kVBMSbcQCB4ZboloLvjfU0J1O4fWOkfdN+giJPuN1USpxS0RnktJe7CRMhoD7qrT1Yq9utvkx5gfo7zwvRETLlbzQdwXGMKK6OMMys4eGX+NcOxWzRNbx4HFyq/r1q7U0hLZ1WglJbRZ36H5PUd2QPJwpkIb6SpoJSWgUYjXXg1p9DywxJFCvDETay9knqI299iCovWjImNLd05xnRYKMHu0zyturg/PNSSMi7kjlvZmFrTNJAJ2avy7wwV/SlaiRSOc0UodIBSEJKDTTg3t+RCd/XTL9T3UqKG2ExArUAhb2V2l/VwIpqaClvdj6grv6VFPU2kqtPm7BFmpcuJYiI37mFjoanFlznwSQ0EraB//IxF3sGhifSRJUdPS4ABGcpvte1MS4rrr4msqCZtoISX1fCzTX6DUuGodKRp2lbQXmJE4ZTXLpISS1Rrr1m6YKKd4OqSIbb2jSXpXK36wXp2pOOnYQK4uud9vM4e/EnqHMJF+IZxRkXcr7DX3+bCapEDJHe0OqbZBe6yyBL+fStBKSOkWfLOBjY4d6n+mL6a6sYVOdLkJy2391o98bJd6LowqgpxOoUnfm7iEvY0evYd6mGRm9xjXtGrI8/1EHwrMiJqDX2K6Dvp8f8ohNK80rsYSQJTIPw50r9Z6UArRue+SqeirjaSAkEZVs+t7DOr1yXj/vp0vKRyo2LYTU46osrxWosU0USx8a5jeTJu2lUto69hCL+gxrWj1pHiK7r7JCdggDq/z6z/HQPzeocGqSbeelHHpjCSFL5NXSeUqJ9mYWakwrIanT9Cz9g4Q1KaT77FjtRowqReK0ERITrkBK8++S70mlpxYK7BGhSHtx9EIb9zwdZW6K6I5rcti7XT1/fpsb3lJ2PvOdmhd1u7K4NGdzaBTjVFKnsGgG7EuUSdiOa1VRzwtGEx0JWCLTdaX4iZpcTgVaK1fwF5tWQirmrB0EvrvZIdUon9E89d9XP82VfEJSoqJv6aeq5WfMSFH6mKRIe9HvOVSLjHL2KV4iH8canBq4uJOx2UV18c2CMOJLHWQska21QbUQC+XTz04rIam6zL3aDSABd+EUc+ZeApHcYWkmJBHXXErBBtFmrYw6l+rXLIOX9qJ1/GeLZPTkrmOdhpLV3j6LdREYRLjwJ2GJzNIYgW1kMvMYb0St0RQkIUm40dLDdXqwn19bKPMl1lhMKyGpbMCaIElbP/JwhkFjLe1FnWW7tBwZ0QCtzzT4ilhqvyUVIpbI7qls50BrD646ry5pfjethKRy/Is11+gFacn84eiotLWANuIPGkfSySYkge5Dp/tLV9C08Xt03FyX677PIKW9qH52eQuWES/3ZqdNGH5WnWYFb4cDctmN+t7Zo/OY9ztST51sT2ObPHpDNbRz6BD4c/e5cC/aR8/jlnUSdC2zu8Kk3GGx6soTsURmNd7AH1Yqhgq8z1ejnFAOkpBU3vwM/U3fPiCY78+R0Nd5b2/15cofTishcSdo3rUv0E1NTw8+HdaSm2t108W1Qbw3p07p+hH5IaMVtToSfURJz0jo9fnZt1lZ3JUvYuVy+zHNbkL++2ex3UWkbCRjiUwbJXWEhPTQ3ieQLjg5rYTEbaD6svWy3VlOKkqg1ZtOe3/yQHrJJSQB/yE+5YdRNFfWFLr2CIFIe9GB6vN+N+RCrjRQ83OS4KjXBhO/Nju+idaVU9tTRX8Lg7NcN2+KjJhELJFz9kOZkGZYhFrTl0TV6RI0IanvdLZ2lESdQ8LRkb5/E3nGpJWQJo+1PigSHWXN74S2d0i0pgcg7UUpquN9bsCXNy4V2L/0+Hlulv4s3JhSpKChlz3D6LARHAmNiphWU5Dxo0b12iCijYlCtaOvh/WeXWsK8zGBtNQxaSUknicSKIr/XPI7owfqaQmL8rQSkpvX17eYCLO4rtTmdQdCxaW9Cm6azWuq7uFmNut+oiSpLmM+oCgFlqfCI6Ga63N3aLJiEtbAvNGEPbTFhl8CD+/zzW7EpBKSipL+qe2fo5SStTcIHvDTl5w5wmMkljhCckQ6tU0KoxHJ5W65uEl70Tr83auFRGUTg1A0eIHe/jBtAteElBX6mnhc5h1BNskMLfDOQrWjaWE/BG43mb61Oq3BYHoJie2Qtb/fo4U2Ld3uyHUW5WkkJLoPfyTi9hmBPFahy9xV4L2LSnt5ra+QFJLn9KaPKKkloWJnsN0gRW5B80DJqygglt3sS/uLwMnmRV2LidYfYkfSQ/dBWBA480dESN1Zc31dpXSOfjndplf8djTZQjOXSxohsUCshJU11zmiSjfK1KH1IouqA9BzTaMjkhTy++yzjYf0IZ3TnpQe/0McSai6C5HqyuMCSnk5XSgCgn/2jKgeAmVNoT8xToKRaSQkt0Zo/Viga+uLmulV3fbgteQOumVaCUlIKTpSI0oJ9Q1JaS8vEVLBGPTdFcw2Fh6jpMebqWRwlyI9G7+Ma0RUc8267G8E8xCQooKE5HlhsyPGZCIEnSzOFPgc88OcHwiTkGjobQsBTbTrWz6p0v3hqGPo/f7bfdYPEkNI7FOjbKTfjuo7EkIHRdPz4iLtpRwLGtSOnLGGjtZe21uUVK8j1Ck3GKUTlaXFmiRdgdj4CEnw8Mn5xxE/BBn2/ZCYGKeFPjCNhCRUdF7LcjatRUfWkWG7jCaJkFimSeJZLHbZ3VE/i0rINBbSXvQ6v25YD6E2ao1DhLcoqYaMWtEYnMRW7kkjouGo0rpG/iGQsERmOXal9xT5g0D1BQFy/VcQQpRxICQZWSj/J1e3Pd9pWdWq8fmNXpNCSCp6fDUJCilewJ222iruQlqKvZ3mSQ021gcF9pzZTdPM1MZfVV6YmaT0XCiEJGSJzMXuKzIxgZoY1xejzNpT0khIylZkvub6LPXbvCJBhK0oaiSFkBwtMZk67p5xeRbJUfWoOEh77erOR9Upzpf6BVKtjaKkBZW+Yr25cj7yWaLYEpKIhYP1FrdAZmIEugGuFvhcD2RCUJsIm5DU5jc97OYPts7WjcLZCTeNhMQt7LodkOp6OBOSQooXONYUrppA5NJeva57wai5I27JpkPs9n4aZTxHSWSyN3TPcmRfcGrcYUZF/Lvsh2g//BUdDk4q0iG72DX1s3UszTv4z3kd+PBIP3+qY/Vu2CtDISQxS+Ss9cdMzCA0Ma7dURZXQlIb4OsChO3tXnNnNnS/j1ktRh6xJyS6z04UmQHMBtT1pNdQcFocpL0KXYP71iCkGyrKFms509PKoUc9xxMq7vG17CIwNCLB5Qx67b+GQULs+URk8j3SnttNosmMh+Gpa/LwWk67ooQkY4mc+mtOGglJbdS6Stt1bcNr1CkFZHDMHdNISMrgbgmeteClvegeuq5qEHYqpwOrVDGWcAahlWFW1TzxRqWoaj43uGPewxyUFgkZ1j0FozSNyxWtrItq05/DYsU8z1krWnRS/dyoUqGaLkZIyhJ5DW50L6mpck8qCckY2Eo7avEghMkPtmppDcSiPOmEREX7Y/GceZP20hX2ZLtwIov/DKsNTN2pgYzVCo6Y/GjRuf5ewwcn2rz3o/vv9YCI6Dl676fzXt7qerhkXPdg+gCl7L5anQLmaI8bQUQJScQSuV1OZqTvl0ZCUie623UlXpoNL9Kpa6p+6tQ+NI2ExOoZjroJnjOv6u5l7QYEo7y9moVbw6lrUrQ4tVmNnGtBLL3FKhqeDxoGK4zL14to755DbeoH6CjKTNlyxrvVc/mSF8VyFnatTvlzTY6H3LUfAilL5LaKkrLlL6SRkCSsOxoVnFVH3+NBWpQnmZAk5rLa7FrAm6lAzW477nRr4f54i4VFnaYgeo06IwgdRcM8Q7w5gXTt2IZdsxswS+T6Lbqe9bnuz1Urf7j2KOb+EgXUS3Bjx2fyPUpCcpw06SHXbDNeVE/dnafTBdb+LL26QTwJiUlW1RbwfEUg7TXUSk61qd/qiPy6QsHmKaqBgMjI+om0OZ5XBfJ6NUo+eCoPJx0F+SU13Jk7NMlIyhK5/S5WtEgbIbkPpDM0GMjMlioia3njVKcL0kJInH7CcxW9tJeEOgZFuj/gzZk9w+RSc+b9tSzUPR0yKXpTM2DXy9iYrLvuFrUWElExaN9rdhoJSemn6d20hn3bqAIvmawJNE38Qf+ejx8huXYpupFpW3fcHSDaWNJZ2k3p3bWSsj7PiYzc9naJ9NwCli7zohTDNS22+6DoZ4B0Ks9Rti6vB7j2c8WctcUskdv3Wivl/hgnQlIHlSu1I8iqHLOEsniPhsZYnAmJNxA8T1oHlUekpb04sqAI5zB6/X/7aXhyJLFI7UGoffuiyRvRPk2O22w6yh2YnMFg0WhqQjhXDd/eqSSZVoS77uZNuooZ1d1O5+Jmjp/HTBwIiSfV9U+twx03SqtrmeZr/jsjoDoQN0LioryExhtIydwniMOC24hj76n84RqJpr7AfkAUGU0WcHN9isdLmIhi2HW5mOt2ogcAOUvktr/WcCoqbYTkvg/rHl37kaFhQkof2PrFaxnn4bgRkjqF41lKgLQXzy0p488Hq7Ml3LDjaNi50kgaFg7mhe4BTus+DeJiod+zWhkQ9lBAFbFExsWRABUu00hIfDoTSKUMuidM8zEpcksTIamuxvl4joSuEKS91t1HPBBq2JSaM6+liOjbqg44N9+64+pL9Hpf4ddUahFHx2NduavPnhKYc7aUJTKu4WHQYtfA+LQRknrAFmvezI9RdFSUTP+liZBESB9XqNJe9aDZ3v1gzzhzJ5UWJGI1j2DfJ8fGJ/w15LTkHG5dD6qTuLpgfRZuXOnLPj9thCR4rzyh30ZuTkgbIano6HE8O+IZi0lhk5FT72lZhcG8jrsEK2usFHE9zc0RalYo6DXjLrw73Z4Cc//ucf2doS2coCUyriqdq2aSOUkkpJ5xU/+HXnN1mqSa4kJIBcP+Gp6bQDrubgmTjLrHH7we3VOPtaK2QPWiY3rd+aA1NWSR+uiz7CxcA5rrWPGQ8jiTINe8hhTII4GUJTKumvMHP0wbITnvR29yPXbdU3EgJKeu1uKcCy451XmZPbV0bAv6c6v6qFZEe8alDfaTG1Ra9xZVZ6y8HmeBYecibTmu83Ati56Vi3tdj6XpbD1CUc8eLO4qYfsuDqWyvFTgC3+NlaFZ2jwNF8tf5PWttPlaJuE3EjdC4unwKLXKJKfw40JIbEcgVHC+Li3PIV/OQKpMlPSHMPZU9gaiA9tS/zp09qG92cGPNGkjf6uGNE96IGWJrGQxUgWJtmRXdNU6PW2EpGpJ/4yoa+rEAJ6DSAlJCcw+LHK/dZU/l7p9yo0IYivtNfKwZn3Xb2REZqEHDd+L5i+aEOuPUklGgpbIK6VqJXHC7uP63ys0gPaq7vRyTAmpFEVdjmueaSMkNWQpsT5/S+NeJRYlBSTtNSLj5GvmiGpG2ZJVdRDeokmN9hW2JInie+Da0p7MG+PMD6zLJtEcFv+Zdt1JyhKZH+bURpAy1srconxS2giJHwqhA42f68qAMgVRElJHgUUyRVSurS+l9FHsEIogA5H2GgLbePsaeKVaU5307RVN1GAGQtsDydyP3yfVoW4d8oiqHek5acqftuRIK2iJvJZrR6klJLfvX2I+a4mO4GAcCUmd5s4JVU09Z+2QNkKSOv3TJjYvE7AqQbTPIlljy9xHswJM193tR5OuwXPVMEoK+rvmFHIxV97L9XXy3ZyxnGemfG4kUpbI5nWZlIPW6iKhB+HoFBLSFk2KsJK1o3sD20giJCR34FBk1uawND+H7lC2vUhC2osNSINI8fuxjeCfb3JfXNbw++4s7RLAMncUugb37XXrw7pCsN48yiQtkVnWPO2EpCwSJDbd51t1NY0rIakH5/pQWuipZTVthEQbU14obb4oMBmXeEVJJwgdbi6Rfm/KKcFL3WgRSww1JWC303d1g/TsNaL1r7Hmx1VaTsw4kOfqPDwEYpbIczJtAqol/VFmUzXttBGSYMG5oZpwkBtuVIREf/cuoZbmb7XDc6j03F6Lm7SX8112lrb10sTQmyvnPT9bDWaSmKy4oUAiPUeZrumN6kMavk2LtmxkJy9picyWt+1CSMUuu1to43h2SqMvKIGE5IT5OevRYAeMze8FeuCIgJA4uyC0PstEPWhiHyU5+nASQ+vnSb4vTqE126Cp6eFsX2lKN0pa1aC54VS992yP63WGaKWJaPjq6bS7G5z0xSyRH49UXiKKByHCXH/MCSmjrJADs/PQtSiPIyFJzdbQez+7rZ5Dw95cSLpqBW/IYs+AKxjcaHN+spV2bU4vNvJbajVzoA7ZC4MkIxUlTW9QFJSxRCYtMSvTZqAbYz+hDXa+X6WBuBOSmml7PZjoyPp98IeNcAlJUI9spUTaJmng+kncBvp73NR1/eiI7Bo0alMr69eSPNRpau1lhtM9vCYEQppZ5xQrZon8QrMOkTTCsS8mxV2ZB8E+IE2EpCLImYEIqVLhP3WENGQpoN/l+otMG4Iim89IqVpLDVoXc3ahQYs3d4i23KbNenQNPsOdPiPMQwXca300NlhXj3oTspbI9oxMm8LxJJGpJT3ix+43CYRU6LK2dObSZFu9/5UJYbYmTEKiw8jnhdYn0CHPBKTQbxcS6v2ODEmWG9SQ7D11XrtZlMQE7S2yNKe2bokxLHVEr/FQr2HeRv8+m/bEqxwRV1f7sxYhXVOTFaVOFCwe2K4PgRooXiqTirL3ThMhiW4SFe6y4bzv8AiJSPbPQqnMGzJtDFe1WsaCgVPO2ik7OhzUjo7seX4On/VrVA3mIT20seezpbIGET1JxHI62180cmnOG4NbETmdX5kOHEVIspbIcqZzyX0QWMpd5EH4h9fTf1IIiW2NJb1adNQt4khILO6ZZNO5mKFDzK5DQLB3Um6qUTNCIH8jkRqV60NWL0pa3ihQKGQHixSUrPSvQE7jLmQBX93ANjlrdjXq7OzNTpvQ63IO2bDbV1XVjsyDhB4ClkjfvO0JiTpzpGyEeYYnTYSkDj8Lknb4CYuQ6Gd/J7OB2vdlAM789AvtbS8JHH5Ib89+YtSm7mEI1sf9M9OvEgwb7tE6LfGZlptTSzWeIz01x7pC/c6n2FW2lvIFa9rR53+easAXVm8QIpbI0pPBCc9fXxbmcHFSCEmlpE4UqY/Q5HiaCIksBrYRq7FRlxSewnWdw88JHYCm676f0eKq5kOSn7dRlDRkcT4ianO8mZwZQa9k9FzeKB9SK8XIz2ODlPyKWvp19Fq7ExkeV1HEkrNE9lo4a4+T2cBWUpuLl9RLkgiJu5a0BWlDtpwOg5Do534t9Cw+0W4zgI2J3jpZaF1blvaqiiD+um6DN0y2Mf8bP79SncmsqF3/oGLuXlVeuMaH2OufOe1YK9JR6uNrPETuZ4xKZY45/BPrFkcqx0pzR7fi1h/1INwgVLi/JU2E5D40TUzGBBs+kkBIquAtEx3RcDuevornkByZpWbgJOYr+UC2TpzUIOXrivuE01cFo9yjI4OlBoNX1YmSjqzIVOznkYyW0V524IjU+/iD16Pf8xVKx/3J7xBy3TENyQIzfVGTceuPOqn0Sq1vT9bcKVWEZFjb6cgrSVuUR01IRLC/FOqse7EdZwA9fH/nRyntVTO1ZpB/k2HX+11vON2WdLhg8eaMz9EG+vsX1KorDj03nKrzpsJgP8/P6hDRsYqMuldf0bhHH625hipFMF/7MuzbMin2WdFAh5J/EVhj6ydNNrS9dV6fZ4Qi2CRubO396ufy/YIn9jXW94FGr80dSUrrT+JZPAGPXY3ajavIP1/i8tpo1PQQ0ln2Izr8asFJ9RGxcqMGkUSjVnQWhq2Kkij6NnesuJ8v89LK7ervOWQu1IXNXYWOvh74AgAAIDZRG83sCGzwnPJ7gsmKoperXUNMe7qr0D0iKrxyOJsybUKz4Vcnpei8PxF/qXVD7Dz0jW8eAAAgZmCNQXZ2Dciscr8K9YbVrAq+jggNxyqnfmTEqcSuUp9OWq7qeoDfj8TwLwAAABAcOpxIxFXnWJ2XUzB5hDst2UKDR1CGfhnPDjVJ0z3Vs4m5FzcyaL6HBfS7f9iTLX8KXzEAAEDCwLVE6lqbqoR139QnJnN/bp6orA872nINuumKufJeRI4vt5Y6NO9gI0hqsJqAbxMAACAlUEapvSxU7RBUCyThdLNVzKOxIkQjFW8io8OVAGqz136DO/aczlPSkuSoa9tM/7vwrQEAALQJusf1d9IQ6vZsTUPE8m0ihll03a1IZGmdWtIX1xGS60RQp4nBaeWeOySQzR12dN1FSudXsRsz/XuJR3u4FoVaEAAAANAULGjKygk8V0hRzMTK1nDqwru1Tkfdo6zA4LSKG9Pfh1UEAAAAAgOl7t5dzwG2CFEDAAAAICxM3GRg09rpOvOm3hat0wEAAADAN4q50tY1UnXLnZkjqhVhhQAAAIBQwLJBNSKkO4eaH9gYEqsEAAAABI5Cl7lrtTEgWQ8Nt5JnzYuxSgAAAEDwEZIxMLEqXTdvtIHeQA4rBQAAAASKItnXjHJ+HTVIax6FlQIAAAACRSFX3qZSIohSdmd7sTgHAAAAAFlC6pw2tsKK/Bpl0LeskbIDAAAAAAQA9kdy0nRrCkZpGv8JKTmcUUNu6HqsFQAAABAoSJHhNJeQyj3833WipLWTOq2PYrUAAACAwLBH5yHvd23J7XFDf1bIWqePjpLss7FaAAAAQKCYSGrd3eNnrLeOkDY7YgyR0KtVpLQUIqsAAABA6Mi7qbyRHXeGdRhWBgAAAAgVbFFRw0/pAawMAAAAEDqU4V+1BfqOWBkAAAAgVPRs3L9hDZv0WVgZAAAAIHRQRHRKFSGtZCdZrAwAAAAQfpSUs5aMVG6wT8DKAAAAAKGjN2eeVBUlLdw20/8urAwAAAAQKvrGlDeojpKKOXMvrAwAAAAQOjhNVxUl3YxVAQAAAEJHd9Zcn0johZG1pIGtsDIAAABA+FFS1vrWSOUG+1ysCgAAABA+IZGWHRHR4gpSWsb1JawMAAAAEDpICfzYqlpSCasCAAAARB4lkbzQPPrjDqwMAAAAED4p5ayjR9SSOku7YFUAAACA0NGdmfHO3TYsbTx0dY8/eL2gftf/A+Ormw32VFvsAAAAAElFTkSuQmCC',
                };

                // TODO: 2018-MAR-19 Configurable Logo Text for Powerpoint
                const logoText = 'AMA Environmental Scan';
                const logoTextOptions = {
                    x: (slideDimensions.w - 1.34),
                    y: 0.45,
                    w: 1.325,
                    h: 0.25,
                    font_size: 8,
                    align: 'center',
                    bold: true,
                    color: palette.purple,
                };

                const slideNumberOptions = {
                    x: (slideDimensions.w - 0.675),
                    y: (slideDimensions.h - 0.725),
                    fontSize: 10,
                    color: palette.black,
                };

                const sourceTextOptions = {
                    x: (titleTextOptions.x + 0.3),
                    y: (slideDimensions.h - 0.875),
                    w: (slideDimensions.w - 4.425),
                    h: 0.75,
                    valign: 'bottom',
                    font_size: 10,
                    color: palette.black,
                };

                if (includeToC === false) {
                    sourceTextOptions.x = margins.leftText;
                }

                const copyrightText = '© 2019 American Medical Association. All rights reserved.';
                const copyrightTextOptions = {
                    x: (slideDimensions.w - 2.925),
                    y: (slideDimensions.h - 0.375),
                    w: 2.75,
                    h: 0.25,
                    align: 'right',
                    valign: 'bottom',
                    font_size: 7,
                    color: palette.purple,
                };

                const narrativeTextOptions = {
                    x: titleTextOptions.x,
                    y: (titleTextOptions.y + 0.4),
                    w: (slideDimensions.w - titleTextOptions.x - 1.25),
                    h: 1.0,
                    align: 'left',
                    valign: 'top',
                    font_size: 10,
                    color: palette.black,
                };

                const legendTextOptions = {
                    x: (slideDimensions.w - 1.85 - 0.4),
                    y: (titleTextOptions.y + 1.75),
                    w: 1.85,
                    h: (slideDimensions.h - (titleTextOptions.y + 1.75) - 0.9),
                    align: 'left',
                    valign: 'top',
                    font_size: 10,
                    lineSpacing: 17,
                    color: palette.black,
                    isTextBox: true,
                };

                const legendTextOptionsChoroplethFirst = {
                    x: (slideDimensions.w - 4.0 - 1.85 - 0.4),
                    y: (titleTextOptions.y + 1.75),
                    w: 1.5,
                    h: (slideDimensions.h - (titleTextOptions.y + 1.75) - 0.9),
                    align: 'left',
                    valign: 'top',
                    font_size: 9,
                    lineSpacing: 16,
                    color: palette.black,
                    isTextBox: true,
                };

                const legendTextOptionsChoroplethSecond = {
                    x: (slideDimensions.w - 1.125 - 0.4),
                    y: legendTextOptionsChoroplethFirst.y,
                    w: legendTextOptionsChoroplethFirst.w,
                    h: legendTextOptionsChoroplethFirst.h,
                    align: legendTextOptionsChoroplethFirst.align,
                    valign: legendTextOptionsChoroplethFirst.valign,
                    font_size: legendTextOptionsChoroplethFirst.font_size,
                    lineSpacing: legendTextOptionsChoroplethFirst.lineSpacing,
                    color: legendTextOptionsChoroplethFirst.color,
                    isTextBox: legendTextOptionsChoroplethFirst.isTextBox,
                };

                const tableTextOptions = {
                    align: 'left',
                    valign: 'middle',
                    font_size: 9,
                    color: palette.black,
                    border: {
                        pt: '1',
                        color: '#dddddd'
                    },
                    fill: '#ffffff',
                };

                const tableHeaderTextOptions = _.merge({}, tableTextOptions, {
                    color: palette.black,
                    bold: true,
                    fill: '#fafafa',
                });

                //  Generate Slides
                let kpiIndex = 0;

                //  Add list of slides in this category
                _.forEach(kpis, function (kpi) {
                    const charts = _.get(kpi, 'chartData.charts');
                    const chartType = _.get(kpi, 'tileConfiguration.chartType');

                    if (_.isArray(charts) === true && charts.length > 0) {
                        const slideTitle = _.get(kpi, 'tileConfiguration.name', '');
                        const slideCategory = _.get(kpi, 'tileConfiguration.category', '');

                        //  New graph slide
                        const slide = pptx.addNewSlide('GRAPH_MASTER', {
                            'bkgd': 'FFFFFF'
                        });
                        slide.slideNumber(slideNumberOptions);

                        //  Logo
                        slide.addImage(logoImageOptions);
                        slide.addText(logoText, logoTextOptions);

                        //  Slide title
                        slide.addText(slideCategory, categoryTextOptions);
                        slide.addText(slideTitle, titleTextOptions);
                        slide.addShape(pptx.shapes.LINE, titleHorizontalRule);

                        //  Slide source
                        const sourceText = _.get(kpi, 'source');
                        if (_.isEmpty(sourceText) === false) {
                            slide.addText(('Source: ' + sourceText), sourceTextOptions);
                        }

                        //  Slide copyright
                        slide.addText(copyrightText, copyrightTextOptions);

                        //  Narrative copy
                        const narrativeText = _.get(kpi, 'chartData.narrativeData', '');
                        if (_.isEmpty(narrativeText) === false) {
                            slide.addText(narrativeText, narrativeTextOptions);
                        }

                        //  Table
                        const tableData = _.get(kpi, 'chartData.charts[0]', '');
                        if (chartType === 'tableChart' && _.isEmpty(tableData) === false) {
                            const rows = _.get(tableData, 'lines');
                            const tableRows = [];

                            const dataTable = new DataTable();
                            const headers = dataTable.getTableHeaders(kpi);
                            let headerOffset = 0;

                            if (headers.length > 0) {
                                headerOffset = 1;
                                tableRows[0] = [];
                            }

                            _.forEach(headers, function (header) {
                                tableRows[0].push({
                                    text: header,
                                    options: tableHeaderTextOptions
                                });
                            });

                            _.forEach(rows, function (row, index) {
                                const cells = _.get(row, 'lines');

                                tableRows[(index + headerOffset)] = [];
                                const axisLabel = _.get(cells, '[0].axisLabel', '');
                                tableRows[(index + headerOffset)].push(axisLabel);

                                _.forEach(cells, function (cell) {
                                    const format = _.get(cell, 'format', '');
                                    const number = _.get(cell, 'number', '');
                                    let value = '';

                                    if (format === 'percentage' || format === 'percent') {
                                        value = reformatPercent(number * 100) + '%';
                                    } else if (format === 'text') {
                                        value = _.get(cell, 'indicator', '');
                                    } else if (format === 'date') {
                                        value = _.get(cell, 'number', '');
                                    } else {
                                        value = formatShortNum(number, 1) + shortNumSymbol(number);
                                    }

                                    tableRows[(index + headerOffset)].push(value);
                                });
                            });

                            const topMargin = (_.isEmpty(narrativeText) === true) ? margins.topWithoutNarrative : margins.top;

                            slide.addTable(
                                tableRows, _.merge({}, tableTextOptions, {
                                    x: margins.left,
                                    y: topMargin,
                                    newPageStartY: margins.topWithoutNarrative,
                                    w: slideDimensions.w - margins.left - margins.right,
                                })
                            );
                        }

                        //  Legend
                        let hasLegend = false;
                        if (chartType === 'choropleth') {
                            const orderedLabels = _.get(kpi, 'chartData.orderedLabels');

                            if (_.isEmpty(orderedLabels) === false) {
                                switch (chartType) {
                                    case 'choropleth': {
                                        //  Assemble legend text
                                        const legendText = [];
                                        _.forEach(orderedLabels, function (labels, index) {
                                            legendText[index] = '';
                                            _.forEach(labels, function (text) {
                                                legendText[index] += text + '\n';
                                            });

                                            if (_.isEmpty(legendText[index]) === false) {
                                                slide.addText(legendText[index], ((orderedLabels.length > 1 && index === 0) ? legendTextOptionsChoroplethSecond : legendTextOptionsChoroplethFirst));
                                                hasLegend = true;
                                            }
                                        });

                                        //  Add colour samples
                                        if (hasLegend === true && chartType === 'choropleth') {
                                            //  First legend
                                            const $legends = [];
                                            $legends[0] = $($kpis[kpiIndex]).find('.choropleth-category-legend:not(.secondary)');
                                            $legends[1] = $($kpis[kpiIndex]).find('.choropleth-category-legend.secondary');

                                            _.forEach($legends, function ($legend, legendIndex) {
                                                if ($legend.length > 0) {
                                                    $legend.find('.icon-seg').each(function (index, icon) {
                                                        const $icon = $(icon);
                                                        const cssValue = _.get(window.getComputedStyle($icon[0]), 'background-color');
                                                        const rgbValues = cssValue.match(/(\d{1,3})/g);
                                                        const hexValues = _.trimStart(self.rgbToHex(_.toNumber(rgbValues[0]), _.toNumber(rgbValues[1]), _.toNumber(rgbValues[2])), '#');

                                                        const x = ($legends[1].length > 0 && legendIndex === 0) ? legendTextOptionsChoroplethSecond.x : legendTextOptionsChoroplethFirst.x;

                                                        slide.addShape(pptx.shapes.OVAL, {
                                                            x: (x - 0.135),
                                                            y: (legendTextOptions.y + (0.222 * index) + 0.11),
                                                            w: 0.135,
                                                            h: 0.135,
                                                            fill: hexValues,
                                                        });
                                                    });
                                                }
                                            });
                                        }
                                        break;
                                    }
                                    default: {
                                        //  Assemble legend text
                                        let legendText = '';

                                        _.forEach(orderedLabels[0], function (text) {
                                            legendText += text + '\n';
                                        });

                                        if (_.isEmpty(legendText) === false) {
                                            slide.addText(legendText, legendTextOptions);
                                            hasLegend = true;
                                        }

                                        //  Add colour samples
                                        /* eslint-disable */
                                        if (hasLegend === true && chartType === 'choropleth') {
                                            const $legend = $($kpis[kpiIndex]).find('.choropleth-category-legend:not(.secondary)');
                                            if ($legend.length > 0) {
                                                $legend.find('.icon-seg').each(function (index, icon) {
                                                    const $icon = $(icon);
                                                    const cssValue = _.get(window.getComputedStyle($icon[0]), 'background-color');
                                                    const rgbValues = cssValue.match(/(\d{1,3})/g);
                                                    const hexValues = _.trimStart(self.rgbToHex(_.toNumber(rgbValues[0]), _.toNumber(rgbValues[1]), _.toNumber(rgbValues[2])), '#');

                                                    slide.addShape(pptx.shapes.OVAL, {
                                                        x: (legendTextOptions.x - 0.135),
                                                        y: (legendTextOptions.y + (0.236 * index) + 0.11),
                                                        w: 0.135,
                                                        h: 0.135,
                                                        fill: hexValues,
                                                    });
                                                });
                                            }
                                        }
                                        /* eslint-enable */
                                    }
                                }
                            }

                        } else if ((chartType === 'verticalSegmentBarChart') || (chartType === 'verticalSegmentBarChartStacked')) {

                            //  Assemble legend text
                            let legendText = '';
                            let lineNum = 0;


                            let chart = charts[0];
                            let lineGroup = chart.lines[0];
                            for (lineNum = 0; lineNum < lineGroup.lines.length; lineNum++) {

                                legendText += lineGroup.lines[lineNum].label + '\n';
                            }

                            if (_.isEmpty(legendText) === false) {
                                slide.addText(legendText, legendTextOptions);
                            }

                            //  Add colour samples
                            /* eslint-disable */
                            const $legend = $($kpis[kpiIndex]).find('.segments-legend');
                            $legend.find('.icon-segment-bar').each(function (index, icon) {
                                const $icon = $(icon);
                                const cssValue = _.get(window.getComputedStyle($icon[0]), 'background-color');
                                const rgbValues = cssValue.match(/(\d{1,3})/g);
                                const hexValues = _.trimStart(self.rgbToHex(_.toNumber(rgbValues[0]), _.toNumber(rgbValues[1]), _.toNumber(rgbValues[2])), '#');

                                slide.addShape(pptx.shapes.OVAL, {
                                    x: (legendTextOptions.x - 0.135),
                                    y: (legendTextOptions.y + (0.236 * index) + 0.11),
                                    w: 0.135,
                                    h: 0.135,
                                    fill: hexValues,
                                });
                            });

                        } else if (chartType === 'segmentedDonut') {

                            //  Assemble legend text
                            let legendText = '';
                            let lineNum = 0;


                            let chart = charts[0];
                            for (lineNum = 0; lineNum < chart.numbers.length; lineNum++) {

                                legendText += chart.numbers[lineNum].label + '\n';
                            }

                            if (_.isEmpty(legendText) === false) {
                                slide.addText(legendText, legendTextOptions);
                            }

                            //  Add colour samples
                            /* eslint-disable */
                            const $legend = $($kpis[kpiIndex]).find('.segment-legend');
                            $legend.find('.icon-seg').each(function (index, icon) {
                                const $icon = $(icon);
                                const cssValue = _.get(window.getComputedStyle($icon[0]), 'background-color');
                                const rgbValues = cssValue.match(/(\d{1,3})/g);
                                const hexValues = _.trimStart(self.rgbToHex(_.toNumber(rgbValues[0]), _.toNumber(rgbValues[1]), _.toNumber(rgbValues[2])), '#');

                                slide.addShape(pptx.shapes.OVAL, {
                                    x: (legendTextOptions.x - 0.135),
                                    y: (legendTextOptions.y + (0.236 * index) + 0.11),
                                    w: 0.135,
                                    h: 0.135,
                                    fill: hexValues,
                                });
                            });

                        } else if (chartType === 'lineGraph') {
                            //  Assemble legend text
                            let legendText = '';
                            let lineNum = 0;


                            // let chart = charts[0];
                            let lineGroup = charts[0].lines;
                            for (lineNum = 0; lineNum < lineGroup.length; lineNum++) {

                                legendText += lineGroup[lineNum].lines[0].label + '\n';
                            }

                            if (_.isEmpty(legendText) === false) {
                                slide.addText(legendText, legendTextOptions);
                            }

                            //  Add colour samples
                            /* eslint-disable */
                            const $legend = $($kpis[kpiIndex]).find('.full-line-legend');
                            $legend.find('.icon-line').each(function (index, icon) {
                                const $icon = $(icon);
                                const cssValue = _.get(window.getComputedStyle($icon[0]), 'border-color');
                                const rgbValues = cssValue.match(/(\d{1,3})/g);
                                const hexValues = _.trimStart(self.rgbToHex(_.toNumber(rgbValues[0]), _.toNumber(rgbValues[1]), _.toNumber(rgbValues[2])), '#');

                                slide.addShape(pptx.shapes.OVAL, {
                                    x: (legendTextOptions.x - 0.135),
                                    y: (legendTextOptions.y + (0.236 * index) + 0.11),
                                    w: 0.135,
                                    h: 0.135,
                                    fill: hexValues,
                                });
                            });
                        }


                        //  Add the chart(s)
                        const $charts = $($kpis[kpiIndex]).find('svg');
                        $charts.each(function (index, svg) {
                            const chartType = _.get(kpi, 'tileConfiguration.chartType');

                            //  Components
                            const $sourceSvg = $(svg);
                            const $svg = $(svg.outerHTML);
                            const $canvas = $('<canvas></canvas>');
                            const canvas = $canvas[0];
                            $sourceSvg.parent().append($svg);
                            $('body').append(canvas);

                            //  Remove extraneous elements
                            switch (chartType) {
                                case 'lineGraph':
                                    $svg.find('g.monte-overlay').remove();
                                    $svg.find('g.monte-selection').remove();
                                    break;
                                default:
                                    $svg.find('g.monte-selection').remove();
                            }

                            //  Work out sizing
                            const legendWidth = (hasLegend === true) ? legendTextOptions.w : 0;

                            const topMargin = (_.isEmpty(narrativeText) === true) ? margins.topWithoutNarrative : margins.top;
                            const width = _.toNumber($svg.attr('width'));
                            const height = _.toNumber($svg.attr('height'));
                            const widthRatio = (width) / (slideDimensions.w - (margins.left + margins.right + legendWidth));
                            const heightRatio = (height) / (slideDimensions.h - (topMargin + margins.bottom));
                            const scalingRatio = Math.max(widthRatio, heightRatio);
                            let centeredXPosition = ((slideDimensions.w - margins.left - margins.right - (width / scalingRatio)) / 2);
                            const centeredYPosition = ((slideDimensions.h - topMargin - margins.bottom - (height / scalingRatio)) / 2) + 0.25;

                            const textScalingFactor = ((width / height) * 0.3);

                            //  Set viewBox to improve resolution
                            $svg[0].setAttribute('viewBox', '0 0 ' + (width / scalingFactor) + ' ' + (height / scalingFactor));
                            $svg[0].setAttribute('width', (width * scalingFactor));
                            $svg[0].setAttribute('height', (height * scalingFactor));

                            //  Prevent lines from closing and filling by doubling back on themselves
                            const pathCoordsRegExp = /([ML]-?\d+(\.\d*)?),(-?\d+(\.\d*)?)/gi;
                            const vertexRegExp = /(-?\d+(\.\d*)?)/gi;
                            $svg.find('path.monte-line').each(function (index, element) {
                                const path = element.getAttribute('d');
                                if (_.isEmpty(path) === false) {
                                    const openCoords = path.match(pathCoordsRegExp);
                                    let closedCoords = openCoords.join('');
                                    if (openCoords.length > 1) {
                                        const retracedCoords = [];
                                        for (let i = openCoords.length - 1; i >= 0; i--) {
                                            const vertexPoints = openCoords[i].match(vertexRegExp);
                                            retracedCoords.push(('L' + vertexPoints[0] + ',' + (Number(vertexPoints[1]) - 0.1)));
                                        }
                                        closedCoords += retracedCoords.join('');
                                    }
                                    element.setAttribute('d', closedCoords);
                                }
                            });

                            //  Hard-code CSS values
                            self.setSVGAttr($svg, 'path.monte-point', 'fill');
                            self.setSVGAttr($svg, 'path.monte-point', 'stroke');
                            self.setSVGAttr($svg, 'path.monte-point', 'stroke-width');

                            self.setSVGAttr($svg, 'circle.monte-point', 'fill');
                            self.setSVGAttr($svg, 'circle.monte-point', 'stroke');
                            self.setSVGAttr($svg, 'circle.monte-point', 'stroke-width');

                            self.setSVGAttr($svg, 'path.monte-line', 'fill', 'none');
                            self.setSVGAttr($svg, 'path.monte-line', 'stroke');
                            self.setSVGAttr($svg, 'path.monte-line', 'stroke-width');

                            self.setSVGAttr($svg, 'path.ref-line', 'fill', 'none');

                            self.setSVGAttr($svg, 'path.monte-arc-bg', 'fill');
                            self.setSVGAttr($svg, 'path.monte-arc-wedge', 'fill');

                            self.setSVGAttr($svg, 'rect.monte-bar', 'fill');
                            self.setSVGAttr($svg, 'rect.monte-segment-bar-seg', 'fill');

                            self.setSVGAttr($svg, 'path.state', 'fill');

                            self.setSVGAttr($svg, 'text', 'fill', '#999999');
                            self.setSVGAttr($svg, 'text', 'font-family');

                            self.setSVGAttr($svg, 'g.x-axis > path.domain', 'stroke');
                            self.setSVGAttr($svg, 'g.y-axis > path.domain', 'stroke', '#EEEEEE');
                            self.setSVGAttr($svg, 'g.y-axis > path.domain', 'stroke-width');

                            self.setSVGAttr($svg, 'g.monte-ext-ref-line-grp > line', 'stroke');
                            self.setSVGAttr($svg, 'line.monte-ext-grid-line', 'stroke');

                            self.setSVGAttr($svg, '.projected-section > line', 'stroke');
                            self.setSVGAttr($svg, '.projected-section > line', 'stroke-dasharray');

                            $svg.find('tspan').remove();


                            //  Adjust font sizes
                            switch (chartType) {
                                case 'donut':
                                case 'segmentedDonut':
                                case 'donutVertical':
                                case 'donutSegmentVertical':
                                case 'donutMetric':

                                    if (index > 0) {
                                        $svg.find('text.date-label').each(function (index, element) {
                                            const $element = $(element);
                                            let cssValue = _.get(window.getComputedStyle($element[0]), 'font-size');
                                            cssValue = cssValue.match(/\d+/);
                                            if (_.isNull(cssValue) === false) {
                                                $element[0].style['font-size'] = (cssValue * textScalingFactor) + 'px';
                                            }
                                        });
                                    } else {
                                        $svg.find('text:not(.date-label)').each(function (index, element) {
                                            const $element = $(element);
                                            let cssValue = _.get(window.getComputedStyle($element[0]), 'font-size');
                                            cssValue = cssValue.match(/\d+/);
                                            if (_.isNull(cssValue) === false) {
                                                $element[0].style['font-size'] = (cssValue * textScalingFactor) + 'px';
                                            }
                                        });
                                    }
                                    break;
                                case 'choropleth':
                                    $svg.find('text.chart-label').each(function (index, element) {
                                        const $element = $(element);
                                        let cssValue = _.get(window.getComputedStyle($element[0]), 'font-size');
                                        cssValue = cssValue.match(/\d+/);
                                        if (_.isNull(cssValue) === false) {
                                            $element[0].style['font-size'] = (cssValue) + 'px';
                                        }
                                    });
                                    break;
                                default:
                                    $svg.find('text:not(.date-label)').each(function (index, element) {
                                        const $element = $(element);
                                        let cssValue = _.get(window.getComputedStyle($element[0]), 'font-size');
                                        cssValue = cssValue.match(/\d+/);
                                        if (_.isNull(cssValue) === false) {
                                            $element[0].style['font-size'] = (cssValue * textScalingFactor) + 'px';
                                        }
                                    });
                            }

                            //  Render the SVG to a canvas
                            canvg(canvas, $svg[0].outerHTML, {
                                scaleWidth: width,
                                scaleHeight: height,
                            });

                            if (chartType === 'imageChart') {
                                // const $canvas2 = $('<canvas></canvas>');
                                // const canvas2 = $canvas2[0];
                                const imgSiblingSrc = $sourceSvg.siblings('img').first().attr('src');
                                // const ctx = canvas2.getContext('2d');
                                // const imageObj = new Image();
                                // imageObj.onload = function() {
                                //     ctx.drawImage(imageObj,0,0);
                                //
                                // };
                                // imageObj.src = imgSiblingSrc;
                                slide.addImage({
                                    x: margins.left,
                                    y: topMargin,
                                    w: (width / scalingRatio),
                                    h: (height / scalingRatio),
                                    // hyperlink:{url:imgSiblingSrc}  ,
                                    path: imgSiblingSrc,
                                });
                            }


                            //  Add the data:url of the canvas(es) to the slide and position it/them
                            switch (chartType) {
                                case 'donut':
                                case 'gauges':
                                    if (charts.length > 1) {
                                        if (index > 0) {
                                            const leftIndent =
                                                (Math.floor(((index - 1) / 2)) * ((height / scalingRatio) / 2)) +
                                                (Math.floor(((index - 1) / 2)) * margins.betweenCharts) +
                                                margins.betweenCharts +
                                                (width / scalingRatio) +
                                                margins.left;

                                            const topIndent =
                                                (((index - 1) % 2) * ((height / scalingRatio) / 2)) +
                                                (((index - 1) % 2) * margins.betweenCharts) +
                                                topMargin;

                                            slide.addImage({
                                                x: leftIndent,
                                                y: topIndent,
                                                w: (((width / scalingRatio) / 2) - (margins.betweenCharts / 2)),
                                                h: (((height / scalingRatio) / 2) - (margins.betweenCharts / 2)),
                                                data: canvas.toDataURL(),
                                            });
                                        } else {
                                            slide.addImage({
                                                x: margins.left,
                                                y: topMargin,
                                                w: (width / scalingRatio),
                                                h: (height / scalingRatio),
                                                data: canvas.toDataURL(),
                                            });
                                        }
                                    } else {
                                        slide.addImage({
                                            x: (margins.left + centeredXPosition),
                                            y: (topMargin + centeredYPosition),
                                            w: (width / scalingRatio),
                                            h: (height / scalingRatio),
                                            data: canvas.toDataURL(),
                                        });
                                    }
                                    break;
                                case 'segmentedDonut':
                                case 'donutVertical':
                                case 'donutSegmentVertical':
                                case 'donutMetric':
                                    if (charts.length > 1) {
                                        const secondRatio = 1;
                                        if (index > 0) {
                                            const leftIndent =
                                                (Math.floor(((index - 1) / 2)) * ((height / scalingRatio) / 2)) +
                                                (Math.floor(((index - 1) / 2)) * margins.betweenCharts) +
                                                margins.betweenCharts +
                                                (width / scalingRatio) +
                                                margins.left + 2;

                                            // const topIndent =
                                            //     (((index - 1) % 2) * ((height / scalingRatio) / 2))
                                            //     + (((index - 1) % 2) * margins.betweenCharts)
                                            //     + topMargin;

                                            slide.addImage({
                                                x: leftIndent,
                                                y: topMargin,
                                                w: (((width / scalingRatio) / secondRatio) - (margins.betweenCharts / 2)),
                                                h: (((height / scalingRatio) / secondRatio) - (margins.betweenCharts / 2)),
                                                data: canvas.toDataURL(),
                                            });
                                        } else {
                                            slide.addImage({
                                                x: margins.left,
                                                y: topMargin,
                                                w: (width / scalingRatio),
                                                h: (height / scalingRatio),
                                                data: canvas.toDataURL(),
                                            });
                                        }
                                    } else {
                                        slide.addImage({
                                            x: (margins.left + centeredXPosition),
                                            y: (topMargin + centeredYPosition),
                                            w: (width / scalingRatio),
                                            h: (height / scalingRatio),
                                            data: canvas.toDataURL(),
                                        });
                                    }
                                    break;
                                case 'choropleth':
                                    if (charts.length > 1) {
                                        const dualChoroplethRation = 3 / (width / scalingRatio);

                                        if (index > 0) {
                                            slide.addImage({
                                                x: (margins.leftChoroplethFirst),
                                                y: legendTextOptionsChoroplethFirst.y,
                                                w: ((width / scalingRatio) * dualChoroplethRation),
                                                h: ((height / scalingRatio) * dualChoroplethRation),
                                                data: canvas.toDataURL(),
                                            });
                                        } else {
                                            slide.addImage({
                                                x: (margins.leftChoroplethSecond),
                                                y: legendTextOptionsChoroplethSecond.y,
                                                w: ((width / scalingRatio) * dualChoroplethRation),
                                                h: ((height / scalingRatio) * dualChoroplethRation),
                                                data: canvas.toDataURL(),
                                            });
                                        }
                                    } else {
                                        slide.addImage({
                                            x: (margins.left + centeredXPosition),
                                            y: (topMargin + centeredYPosition),
                                            w: (width / scalingRatio),
                                            h: (height / scalingRatio),
                                            data: canvas.toDataURL(),
                                        });
                                    }
                                    break;
                                default:

                                    //  Make sure there is space for the legend
                                    if (hasLegend === true) {
                                        centeredXPosition = 0;
                                    }

                                    slide.addImage({
                                        x: (margins.left + centeredXPosition),
                                        y: (topMargin + centeredYPosition),
                                        w: (width / scalingRatio),
                                        h: (height / scalingRatio),
                                        data: canvas.toDataURL(),
                                    });
                            }

                            //  Reset viewBox and remove canvas
                            $svg.remove();
                            $canvas.remove();
                        });
                    }
                    kpiIndex++;
                });

                _.delay(function () {
                    pptx.setBrowser(true);
                    pptx.save('Environmental Scan');
                    self._sharedStateService.setPowerpointState('Creation Complete... Cleaning up');
                }, 1500, pptx);
            } else {
                //  NOTE: There is a mismatch between the number of KPIs from the data provider, and the number shown in the view
            }
        } else {
            //  NOTE: There is no point in generating an empty PDF
        }
    }

    setSVGAttr($svg, selector, propertyKey, value) {
        $svg.find(selector).each(function (index, element) {
            const $element = $(element);

            $element[0].setAttribute(propertyKey, '');
            if (_.isUndefined(value) === false) {
                $element[0].style[propertyKey] = value;
            } else {
                const cssValue = _.get(window.getComputedStyle($element[0]), propertyKey);
                $element[0].style[propertyKey] = cssValue;
            }
        });
    }

    //  From: https://stackoverflow.com/questions/5623838/rgb-to-hex-and-hex-to-rgb
    componentToHex(c) {
        const hex = c.toString(16);
        return hex.length === 1 ? '0' + hex : hex;
    }

    rgbToHex(r, g, b) {
        return '#' + this.componentToHex(r) + this.componentToHex(g) + this.componentToHex(b);
    }
}
