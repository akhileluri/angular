export const GENERAL_PROVIDERS = [];

export Powerpoint from './powerpoint';
GENERAL_PROVIDERS.push(exports.Powerpoint);
