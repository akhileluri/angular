// This file was generated from the pipe scaffold
// Copyright 2017

import {Pipe} from '@angular/core';
import moment from 'moment';

@Pipe({
    name: 'timeSince',
    pure: true,
})
/**
 * @see https://angular.io/docs/ts/latest/guide/pipes.html
 * @example
 * <div>{{inputExpression | timeSince}}</div>
 * <div>{{inputExpression | timeSince:true}}</div>
 */
export default class TimeSince {
    transform(input:any, args:Array) {
        if (args && args.length === 1) {
            // NOTE: `fromNow` accepts an argument to suppress the suffix. In most cases (in English)
            //       the suffix is "ago".
            return moment(input).fromNow(args[0]);
        }

        return moment(input).fromNow();
    }
}
