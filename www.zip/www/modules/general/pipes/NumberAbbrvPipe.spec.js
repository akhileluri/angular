// This file was generated from the pipe scaffold
// Copyright 2016

import {Component} from '@angular2/core';
import NumberAbbrvPipe from './NumberAbbrvPipe';
import {
    addProviders,
    inject
} from '@angular/core/testing';

describe('dashboard/NumberAbbrvPipe.js', () => {

    beforeEach(() => {
        addProviders([NumberAbbrvPipe]);
    });

    it('should return formatted value', inject([NumberAbbrvPipe], (numberAbbrvPipe:NumberAbbrvPipe) => {
        expect(numberAbbrvPipe.transform('foo')).toBe('foo');
    }));

});
