export const GENERAL_PIPES = [];

export NameFilter from './NameFilter';
GENERAL_PIPES.push(exports.NameFilter);

export NumberAbbrvPipe from './NumberAbbrvPipe';
GENERAL_PIPES.push(exports.NumberAbbrvPipe);


export MetadataNumberFormat from './MetadataNumberFormatPipe';
GENERAL_PIPES.push(exports.MetadataNumberFormat);


export TimeSince from './TimeSince';
GENERAL_PIPES.push(exports.TimeSince);