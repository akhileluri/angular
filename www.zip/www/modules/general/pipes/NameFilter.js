// This file was generated from the pipe scaffold
// Copyright 2016

import {Pipe} from '@angular/core';

@Pipe({
    name: 'nameFilter',
    pure: true,
})
/**
 * @see https://angular.io/docs/ts/latest/guide/pipes.html
 * @example
 * <div>{{inputExpression | nameFilter}}</div>
 */
export default class NameFilter {
    constructor() {}

    transform(items:any, filter:string, field:string) {
        const filterOn = filter && filter.toLowerCase() || null;
        const nameField = field || 'name';

        if (filterOn) {
            return items.filter((item) => item[nameField].toLowerCase().indexOf(filterOn) > -1);
        }

        return items;
    }
}
