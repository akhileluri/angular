// This file was generated from the pipe scaffold
// Copyright 2016

import {Component} from '@angular2/core';
import NumberFormatPipe from './NumberFormatPipe';
import {
    addProviders,
    inject
} from '@angular/core/testing';

describe('general/NumberFormatPipe.js', () => {

    beforeEach(() => {
        addProviders([NumberFormatPipe]);
    });

    it('should return formatted value', inject([NumberFormatPipe], (numberFormatPipe:NumberFormatPipe) => {
        expect(numberFormatPipe.transform('foo')).toBe('foo');
    }));

});
