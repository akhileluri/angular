// This file was generated from the pipe scaffold
// Copyright 2016

import {Component} from '@angular2/core';
import NameFilter from './NameFilter';
import {
    it,
    describe,
    expect,
    inject,
    beforeEachProviders
} from '@angular/core/testing';

describe('general/NameFilter.js', () => {

    beforeEachProviders(() => [NameFilter]);

    it('should return formatted value', inject([NameFilter], (nameFilter:NameFilter) => {
        expect(nameFilter.transform('foo')).toBe('foo');
    }));

});
