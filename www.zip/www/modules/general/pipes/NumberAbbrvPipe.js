// This file was generated from the pipe scaffold
// Copyright 2016

import {formatAbbreviation} from '../../chart/util/numberAbbrv';
import {Pipe} from '@angular/core';

@Pipe({
    name: 'numberAbbrv',
    pure: true,
})
/**
 * @see https://angular.io/docs/ts/latest/guide/pipes.html
 * @example
 * <div>{{inputExpression | numberAbbrvPipe}}</div>
 */
export default class NumberAbbrvPipe {
    transform(input:any) {
        return formatAbbreviation(input);
    }
}
