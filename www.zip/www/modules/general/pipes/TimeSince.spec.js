// This file was generated from the pipe scaffold
// Copyright 2017

import {Component} from '@angular2/core';
import TimeSince from './TimeSince';
import {
    addProviders,
    inject
} from '@angular/core/testing';

describe('general/TimeSince.js', () => {

    beforeEach(() => {
        addProviders([TimeSince]);
    });

    it('should return formatted value', inject([TimeSince], (timeSince:TimeSince) => {
        expect(timeSince.transform('foo')).toBe('foo');
    }));

});
