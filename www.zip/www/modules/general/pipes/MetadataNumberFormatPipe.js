// This file was generated from the pipe scaffold
// Copyright 2016

import {Pipe} from '@angular/core';
import {formatMetdataNumber} from '../../chart/util/numberAbbrv';

@Pipe({
    name: 'metadataNumberFormat',
    pure: true,
})
/**
 * @see https://angular.io/docs/ts/latest/guide/pipes.html
 * @example
 * <div>{{inputExpression | metadataNumberFormat}}</div>
 */
export default class MetadataNumberFormatPipe {

    transform(input:any, precision) {
        if (precision === null || precision === undefined){
            return formatMetdataNumber(input, '-');
        }
        return formatMetdataNumber(input, '-', precision);
    }
}
