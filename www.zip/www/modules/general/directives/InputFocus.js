// This file was generated from the directive scaffold
// Copyright 2016

import {Directive, ElementRef, Input} from '@angular/core';

@Directive({
    selector: '[inputFocus]',
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Directive-decorator.html
 * @example
 * <div [inputFocus]="true"></div>
 */
export default class InputFocus {
    /**
     * An example input for this directive
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input('inputFocus') value:boolean = false;

    constructor(elementRef:ElementRef) {
        this.$element = elementRef.nativeElement;
    }

    ngAfterViewInit() {
        const childToFocus = this.$element.querySelector('input, textarea');
        childToFocus.focus();
    }
}
