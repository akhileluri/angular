// This file was generated from the directive scaffold
// Copyright 2016

import {Component} from '@angular/core';
import InputFocus from './InputFocus';
import {
    inject,
    async,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [InputFocus],
    template: ''
})
class TestComponent {}

describe('general/InputFocus.js', () => {

    it('should initialize default value', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<div inputFocus></div>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('[inputFocus]').classList.contains('inputFocus')).toBe(false);
            });
    })));

    it('should initialize custom value', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<div inputFocus="true"></div>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('[inputFocus]').classList.contains('inputFocus')).toBe(true);
            });
    })));

});
