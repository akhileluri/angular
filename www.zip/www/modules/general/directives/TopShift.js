// This file was generated from the directive scaffold
// Copyright 2016

import {Directive, ElementRef, Renderer, Input} from '@angular/core';

@Directive({
    selector: '[topShift]',
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Directive-decorator.html
 * @example
 * <div [topShift]="{min:5, max:50}"></div>
 */
export default class TopShift {
    /**
     * An example input for this directive
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input('topShift') value:any = {
        min: 0,
        max: Number.POSITIVE_INFINITY,
    };

    constructor(elementRef:ElementRef, renderer:Renderer) {
        this.$element = elementRef.nativeElement;
        this.renderer = renderer;
    }

    ngOnChanges() {
        if (this.value) {
            const height = this.$element.clientHeight;
            const parentHeight = this.$element.parentElement.clientHeight;

            if (parentHeight > (height + this.value.max)) {
                this.renderer.setElementStyle(this.$element, 'top', (this.value.max || 0) + 'px');
            }
            else if ((height + this.value.min) > parentHeight) {
                this.renderer.setElementStyle(this.$element, 'top', (this.value.min || 0) + 'px');
            }
            else {
                const shift = (parentHeight - height) / 2;
                this.renderer.setElementStyle(this.$element, 'top', (shift || 0) + 'px');
            }
        }
    }
}
