// This file was generated from the directive scaffold
// Copyright 2016

import {Component} from '@angular/core';
import TopShift from './TopShift';
import {
    inject,
    async,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [TopShift],
    template: ''
})
class TestComponent {}

describe('general/TopShift.js', () => {

    it('should initialize default value', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<div topShift></div>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('[topShift]').classList.contains('topShift')).toBe(false);
            });
    })));

    it('should initialize custom value', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<div topShift="true"></div>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('[topShift]').classList.contains('topShift')).toBe(true);
            });
    })));

});
