export const GENERAL_DIRECTIVES = [];

export TopShift from './TopShift';
GENERAL_DIRECTIVES.push(exports.TopShift);

export InputFocus from './InputFocus';
GENERAL_DIRECTIVES.push(exports.InputFocus);
