// TODO:FIXME: having issue with Promise and Zone getting resolved correctly, referencing Promise here fixes it
Promise.resolve();

// these prereqs are required to be bundled with app before everything else

// IE11 doesn't support Map very much
import 'babel/polyfill';

// import 'zone.js';

// https://github.com/angular/angular/issues/5632
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/observable/fromPromise';

import 'zone.js/dist/zone';
import 'zone.js/dist/long-stack-trace-zone';
import 'reflect-metadata';

import * as monte from 'monte';
window.monte = monte; // Register Monte globally so that it is available for `monte-ext-d3-tip`.
