// This file was generated from the component scaffold
// Copyright 2017

import {Component, Input, ViewEncapsulation} from '@angular/core';
import {COMMON_DIRECTIVES} from '@angular/common';
import template from './NotificationItem.html';
import styles from './NotificationItem.scss';

@Component({
    selector: 'notification-item',
    template: template,
    styles: [styles],
    directives: [
        COMMON_DIRECTIVES,
    ],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <notification-item name="NotificationItem" ></notification-item>
 */
export default class NotificationItem {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'NotificationItem';

    @Input() notification = {};
}
