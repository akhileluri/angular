// This file was generated from the component scaffold
// Copyright 2017

import {Component, Injector} from '@angular/core';
import NotificationItem from './NotificationItem';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [NotificationItem],
    template: ''
})
class TestComponent {}

describe('app/NotificationItem.js', () => {

    beforeEach(() => {
        addProviders([NotificationItem]);
    });

    it('should return component name', inject([NotificationItem], (NotificationItem:NotificationItem) => {
        expect(NotificationItem.name).toBe('NotificationItem');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<notification-summary></notification-summary>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('notification-summary h1').innerText).toBe('NotificationItem');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<notification-summary name="TEST"></notification-summary>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('notification-summary h1').innerText).toBe('TEST');
            });
    })));

});
