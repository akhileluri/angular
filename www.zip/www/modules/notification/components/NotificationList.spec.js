// This file was generated from the component scaffold
// Copyright 2017

import {Component, Injector} from '@angular/core';
import NotificationList from './NotificationList';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [NotificationList],
    template: ''
})
class TestComponent {}

describe('notification/NotificationList.js', () => {

    beforeEach(() => {
        addProviders([NotificationList]);
    });

    it('should return component name', inject([NotificationList], (notificationList:NotificationList) => {
        expect(notificationList.name).toBe('NotificationList');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<notification-list></notification-list>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('notification-list h1').innerText).toBe('NotificationList');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<notification-list name="TEST"></notification-list>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('notification-list h1').innerText).toBe('TEST');
            });
    })));

});
