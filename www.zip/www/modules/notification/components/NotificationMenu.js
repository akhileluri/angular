// This file was generated from the component scaffold
// Copyright 2017

import {Component, ViewChild, ViewEncapsulation} from '@angular/core';
import SharedStateService from '../../app/services/SharedStateService';
import {Router} from '@angular/router';
import {COMMON_DIRECTIVES} from '@angular/common';
import template from './NotificationMenu.html';
import styles from './NotificationMenu.scss';

@Component({
    selector: 'notification-menu',
    template: template,
    styles: [styles],
    directives: [
        COMMON_DIRECTIVES,
    ],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <notification-menu></notification-menu>
 */
export default class NotificationMenu {
    @ViewChild('arrow') arrow = this.arrow;
    @ViewChild('button') button = this.button;

    count = 0;

    constructor(router:Router, sharedStateService:SharedStateService) {
        this._router = router;
        this._sharedStateService = sharedStateService;

        this._sharedStateService.getNotifications().subscribe((v) => {
            this.notifications = v;
            this.refreshNewNotificationCount();
        });
    }

    ngOnChanges(changes) {
        this.count = changes.newNotificationsCount.currentValue;
    }

    checkArrow() {
        const rect = this.button.nativeElement.getBoundingClientRect();
        const btnOffsetLeft = rect.left;
        const btnWidth = rect.width;
        const arrowPlacement = this._sharedStateService.getBodyWidth() - btnOffsetLeft -
          20 /* margin adjust */ - (btnWidth / 2) /* button width adjust */ + 6;

        this.arrow.nativeElement.style.right = arrowPlacement + 'px';
    }

    showNavigationList() {
        this._router.navigate(['/notifications']);
    }

    showNotificationSettings() {
        this._router.navigate(['/UserPreferences']);
    }

    refreshNewNotificationCount() {
        this.count = 0;

        if (this.notifications) {
            this.notifications.forEach((n) => {
                if (n.new) {
                    this.count++;
                }
            });
        }
    }
}
