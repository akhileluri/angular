// This file was generated from the component scaffold
// Copyright 2017

import {Component, Input, ViewEncapsulation} from '@angular/core';
import {COMMON_DIRECTIVES} from '@angular/common';
import SharedStateService from '../../app/services/SharedStateService';
import {Router} from '@angular/router';
import template from './NotificationList.html';
import styles from './NotificationList.scss';

@Component({
    selector: 'notification-list',
    template: template,
    styles: [styles],
    directives: [
        COMMON_DIRECTIVES,
    ],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <notification-list name="NotificationList" (change)="onChange($event)"></notification-list>
 */
export default class NotificationList {
    @Input() notifications:Array = [];

    constructor(router:Router, sharedStateService:SharedStateService) {
        this._router = router;
        this._sharedStateService = sharedStateService;

        this.userSubscription = this._sharedStateService.getNotifications().subscribe((v) => {
            if (v) {
                this.notifications = v;
            }
        });
    }

    showNotification(notification) {
        notification.new = false;
        // Announce new flag change
        this._sharedStateService.setNotifications(this.items);

        // TODO: Notify server of state change.
        // TODO: Browse to notification
        //         If headline update for KPI, launch KPI Solo modal
        //         If comment on KPI, launch KPI modal
        //         If data update for KPI browse to KPI path
        //
        // For now:
        // use context to launch path
        // TODO DO WE WANT NOTIFICATIONS TO GO TO A KPI? -- RETHINK
        // this._router.navigate(['/list', notification.context.category.id, notification.context.geography.id]);
    }
}
