export const NOTIFICATION_COMPONENTS = [];

export NotificationMenu from './NotificationMenu';
NOTIFICATION_COMPONENTS.push(exports.NotificationMenu);

export NotificationItem from './NotificationItem';
NOTIFICATION_COMPONENTS.push(exports.NotificationItem);

export NotificationList from './NotificationList';
NOTIFICATION_COMPONENTS.push(exports.NotificationList);
