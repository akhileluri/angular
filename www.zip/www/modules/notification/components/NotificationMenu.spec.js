// This file was generated from the component scaffold
// Copyright 2017

import {Component, Injector} from '@angular/core';
import NotificationMenu from './NotificationMenu';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [NotificationMenu],
    template: ''
})
class TestComponent {}

describe('app/NotificationMenu.js', () => {

    beforeEach(() => {
        addProviders([NotificationMenu]);
    });

    it('should return component name', inject([NotificationMenu], (notificationMenu:NotificationMenu) => {
        expect(notificationMenu.name).toBe('NotificationMenu');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<notification-menu></notification-menu>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('notification-menu h1').innerText).toBe('NotificationMenu');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<notification-menu name="TEST"></notification-menu>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('notification-menu h1').innerText).toBe('TEST');
            });
    })));

});
