const ROUTES = [];
export default ROUTES;

ROUTES.push({
    path: 'notifications',
    component: require('./NotificationView'),
    data: {
        title: 'Notifications',
    },
});
