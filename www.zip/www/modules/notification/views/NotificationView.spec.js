// This file was generated from the view scaffold
// Copyright 2017

import {Component, Injector, provide} from '@angular/core';
import NotificationView from './NotificationView';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [NotificationView],
    template: ''
})
class TestComponent {}

describe('notification/NotificationView.js', () => {

    beforeEach(() => {
        addProviders([
            NotificationView
        ]);
    });

    it('should initialize default name', inject([NotificationView], (NotificationView:NotificationView) => {
        expect(NotificationView.name).toBe('NotificationView');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<notification-view></notification-view>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('notification-list h1').innerText).toBe('NotificationView');
            });
    })));

});
