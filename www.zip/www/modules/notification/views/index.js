export const NOTIFICATION_VIEWS = [];

export NotificationView from './NotificationView';
NOTIFICATION_VIEWS.push(exports.NotificationView);
