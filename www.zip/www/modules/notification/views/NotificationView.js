// This file was generated from the view scaffold
// Copyright 2017

import {Component, ViewEncapsulation} from '@angular/core';
import template from './NotificationView.html';
import styles from './NotificationView.scss';
import {Location} from '@angular/common';

import NotificationList from '../components';

@Component({
    selector: 'notification-view',
    template: template,
    styles: [styles],
    directives: [
        NotificationList,
    ],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/guide/router.html
 */
export default class NotificationView {

    /**
     * Default name for the class, passed by reference via RouteParams
     */
    name:string = 'NotificationView';
    location:Location;

    constructor(location:Location) {
        this._location = location;
    }

    goBack() {
        this._location.back();
    }
}
