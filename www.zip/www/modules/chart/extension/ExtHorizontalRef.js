/* global d3 */

// Avoids label over lap for exactly two reference line labels.
export function labelOverlapAvoidance(extEvent) {
    if (extEvent === 'refline:updated') {
        const lbls = this.support.selectAll('.monte-ext-ref-line-grp');
        const lblNodes = lbls.nodes();

        if (lblNodes.length === 2) {
            const lbl0 = lblNodes[0];
            const lbl1 = lblNodes[1];

            // If there is an overlap of the bounding boxes than move the lower one beneath
            // the line.
            const bbox0 = lbl0.getBBox();
            const bbox1 = lbl1.getBBox();

            const bbox0Top = bbox0.y;
            const bbox0Bottom = bbox0.y + bbox0.height;
            const bbox1Top = bbox1.y;
            const bbox1Bottom = bbox1.y + bbox1.height;

            if (bbox1Top <= bbox0Bottom && bbox0Bottom < bbox1Bottom) {
                // bbox0 is higher and overlaps with bbox1
                d3.select(lbl1).select('text').attr('dy', '1em');
            }
            else if (bbox0Top <= bbox1Bottom && bbox1Bottom < bbox0Bottom) {
                // bbox1 is higher and overlaps with bbox0Top
                d3.select(lbl0).select('text').attr('dy', '1em');
            }
        }
    }
}
