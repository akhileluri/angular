/* globals _ d3 */
import * as Monte from 'monte';

const directionStrategies = {
    'e': {
        arrowPath: function(arrowSize) {
            const arrowWidth = arrowSize / 2;
            return `M 0,${arrowSize / 2} ${arrowWidth},${arrowSize} ${arrowWidth},0 Z`;
        },
        arrowTranslate: function(arrowSize, flagWidth, flagHeight) {
            return `translate(0, ${(flagHeight - arrowSize) / 2 })`;
        },
        flagTranslate: function(tipX, tipY, arrowSize, flagWidth, flagHeight) {
            return `translate(${tipX + 2}, ${tipY - flagHeight / 2})`;
        },
        rectPlace: function(rect, arrowSize) {
            rect.attr('x', arrowSize / 2)
              .attr('y', 0);
        },
        txtPlace: function(txt, bbox, hPadding, vPadding, arrowSize) {
            const arrowWidth = arrowSize / 2;
            txt.attr('x', bbox.width / 2 + hPadding + arrowWidth)
              .attr('y', bbox.height + vPadding);
        },
    },
    's': {
        arrowPath: function(arrowSize) {
            const arrowHeight = arrowSize / 2;
            const arrowHalfWidth = arrowSize / 2;
            return `M -${arrowHalfWidth},0 ${arrowHalfWidth},0 0,-${arrowHeight} Z`;
        },
        arrowTranslate: function(arrowSize, flagWidth) {
            return `translate(${(flagWidth) / 2}, ${arrowSize / 2})`;
        },
        flagTranslate: function(tipX, tipY, arrowSize, flagWidth) {
            return `translate(${tipX - flagWidth / 2}, ${tipY})`;
        },
        rectPlace: function(rect, arrowSize) {
            rect.attr('x', 0)
              .attr('y', arrowSize / 2);
        },
        txtPlace: function(txt, bbox, hPadding, vPadding, arrowSize) {
            txt.attr('x', bbox.width / 2 + hPadding)
              .attr('y', bbox.height + vPadding + arrowSize / 2);
        },
    },
};

/**
 * Add an annotation flag to the chart with a left pointing arrow.
 *
 * @param {Selection} containGrp The group of elements.
 * @param {number}    tipX        The x coordinate for the tip of the arrow.
 * @param {number}    tipY        The y coordinate for the tip of the arrow.
 * @param {string}    flagText    The text of the flag.
 * @param {string}    opts        Additional options to modify the flag.
 *
 * @returns {undefined}
 */
export function addFlag(containGrp, tipX, tipY, flagText, opts = {}) {
    const hPadding = _.get(opts, 'hPadding', 5);
    const vPadding = _.get(opts, 'vPadding', 3);
    const arrowSize = _.get(opts, 'arrowSize', 7);
    const strat = directionStrategies[_.get(opts, 'dir', 'e')];
    const flagGrp = containGrp.append('g')
      .attr('class', 'annotate-flag');
    const txt = flagGrp.append('text').text(flagText);

    // Measure the text and draw a rectangle big enough.
    const bbox = txt.node().getBBox();
    const flagHeight = bbox.height + 2 * vPadding;
    const flagWidth = bbox.width + 2 * hPadding;
    const rect = flagGrp.append('rect')
      .attr('rx', 3)
      .attr('width', bbox.width + 2 * hPadding)
      .attr('height', flagHeight);

    strat.rectPlace(rect, arrowSize);

    // Raise text so it is above the rect.
    txt.raise()
    .attr('text-anchor', 'middle')
    .attr('dy', '-0.3em');
    strat.txtPlace(txt, bbox, hPadding, vPadding, arrowSize);

    flagGrp.append('path')
      .attr('d', strat.arrowPath(arrowSize, flagHeight))
      .attr('transform', strat.arrowTranslate(arrowSize, flagWidth, flagHeight));


    flagGrp.attr('transform', strat.flagTranslate(tipX, tipY, arrowSize, flagWidth, flagHeight));
}

export function updateFlag(containGrp, tipX, tipY, flagText, opts) {
    const hPadding = _.get(opts, 'hPadding', 5);
    const vPadding = _.get(opts, 'vPadding', 3);
    const arrowSize = _.get(opts, 'arrowSize', 7);
    const strat = directionStrategies[_.get(opts, 'dir', 'e')];
    const flagGrp = containGrp.select('.annotate-flag');
    const txt = flagGrp.select('text').text(flagText);
    const bbox = txt.node().getBBox();
    const flagHeight = bbox.height + 2 * vPadding;
    const flagWidth = bbox.width + 2 * hPadding;
    const rect = flagGrp.select('rect')
      .attr('rx', 3)
      .attr('width', bbox.width + 2 * hPadding)
      .attr('height', flagHeight);

    strat.rectPlace(rect, arrowSize);
    strat.txtPlace(txt, bbox, hPadding, vPadding, arrowSize);

    flagGrp.select('path')
      .attr('transform', strat.arrowTranslate(arrowSize, flagWidth, flagHeight));

    flagGrp.attr('transform', strat.flagTranslate(tipX, tipY, arrowSize, flagWidth, flagHeight));
}

export function getLargestFlag(chart, selector = '.flag-contain-grp') {
    const flags = chart.overlay.selectAll(selector);
    let width = 0;

    flags.each(function() {
        const b = this.getBBox();
        width = b.width;
    });

    return width;
}

// Performs the flag update cycle for the small and large line charts and places the flag on the
// right side.
export function lineChartFlagUpdateCycle(chart, flagData, options) {
    const opts = Monte.tools.mergeOptions({
        autoUpdateMargin: true,
        flagXShift: 5,
        marginRightWithoutFlags: chart.option('marginRightWithoutFlags') || 5,
    }, options);
    const flags = chart.overlay.selectAll('.flag-contain-grp').data(flagData);

    function placeFlag(fn, chart, grp, d) {
        const lastValue = d.values[d.values.length - 1];
        const x = chart.getScaledProp('x', lastValue) + opts.flagXShift;
        const y = chart.getScaledProp('y', lastValue);
        fn.call(chart, grp, x, y, lastValue.label);
    }

    flags.enter().append('g')
      .attr('class', 'flag-contain-grp')
      .each((d, i, nodes) => {
          const grp = d3.select(nodes[i]);

          if (d) { // Add annotation flag
              placeFlag(addFlag, chart, grp, d);
          }
      });

    flags.each((d, i, nodes) => {
        const grp = d3.select(nodes[i]);

        if (d) { // Update annotation flag
            placeFlag(updateFlag, chart, grp, d);
        }
    });

    flags.exit().remove();

    if (opts.autoUpdateMargin) {
        // Changing margins causes another render pass make sure not to trigger again
        // if the correct margin is set; otherwise an infinite dive will happen.
        const marginRight = flagData.length > 0 ?
          Math.round(getLargestFlag(chart) + opts.flagXShift + 2) : // Magic number 2 provides the extra clearance needed to fit properly after dealing with sizing and crispEdges inconsistencies
          opts.marginRightWithoutFlags;

        if (chart.option('margin.right') !== marginRight) {
            chart.option('margin.right', marginRight);
        }
    }
}
