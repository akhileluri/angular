// This file was generated from the chart scaffold
// Copyright 2016
/* global d3, _ */
import {Component, Input, Output, EventEmitter, ElementRef, ViewEncapsulation} from '@angular/core';
import * as Monte from 'monte';
import template from './FullSegmentsChart.html';
import styles from './FullSegmentsChart.scss';
import {percentFormat} from '../util/format';

@Component({
    selector: 'full-segments-chart',
    template: template,
    styles: [styles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <full-segments-chart name="FullSegmentsChart" (change)="onChange($event)"></full-segments-chart>
 */
export default class FullSegmentsChart {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'FullSegmentsChart';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();

    @Input() data = {};
    @Input() chartSize = '';

    hasChart = false;

    upperStackedHeight = 60;
    upperGroupedHeight = 80;
    lowerStackedHeight = 105;
    lowerGroupedHeight = 120;
    overallStackedHeight = '200px';
    overallGroupedHeight = '230px';

    legendItems = [];

    commonOpts = {
        css: 'monte-no-domain-lines monte-axis-no-ticks',
        boundingWidth: 600,
        transition: {
            duration: 750,
        },

        // Follows D3 Margin Convention: https://bl.ocks.org/mbostock/3019563
        margin: {
            top: 20,
            bottom: 0,
            left: 120,
            right: 0,
        },

        labelProp: 'label',
        labelX: function(d, i, nodes, allNodes) {
            const mode = this.option('segmentBarMode');

            if (mode === 'stacked') {
                return this._barXInnerStacked(d, i, nodes, allNodes) + this._barWidthStacked(d) / 2;
            }
            else if (mode === 'grouped') {
                return this._barWidthGrouped(d);
            }

            return 0;
        },
        labelXAdjust: function(d, i, nodes) {
            const mode = this.option('segmentBarMode');

            if (mode === 'stacked') {
                return '0em';
            }
            else if (mode === 'grouped') {
                const lbl = d3.select(nodes[i]);

                if (lbl.attr('exceeds') === 'true') {
                    return '0.1em';
                }

                return '-0.1em';
            }

            return '0em';
        },

        labelY: function(d, i, nodes, allNodes) {
            const mode = this.option('segmentBarMode');

            if (mode === 'stacked') {
                return -5;
            }
            else if (mode === 'grouped') {
                return this._barYInnerGrouped(d, i, nodes, allNodes) + this.yInner.bandwidth() / 2;
            }

            return 0;
        },

        yInnerProp: 'type',
        yProp: 'label',
        yAxisCustomize: function(axis) {
            axis.tickSize(0);
        },

        resize: new Monte.HorizontalResizer(),
        includeLabels: true,
    }

    largeOpts = Monte.tools.mergeOptions(this.commonOpts, {
        boundingHeight: this.upperStackedHeight,
    });

    smallOpts = Monte.tools.mergeOptions(this.commonOpts, {
        boundingHeight: this.lowerStackedHeight,
        yScale: function() {
            return d3.scaleBand().paddingInner(0.6).round(true);
        },
    });

    constructor(compEl: ElementRef) {
        this.contentSel = d3.select(compEl.nativeElement);
    }

    ngOnDestroy() {
        if (this.chart) {
            this.chart.destroy();
        }
    }

    ngOnChanges() {
        if (this.data && this.data.lines && this.data.lines.length) {
            const largeData = this.prepData([_.head(this.data.lines)]);
            const smallData = this.prepData(_.tail(this.data.lines));

            if (this.largeSeg && largeData && largeData.length) {
                this.largeSeg.updateData(largeData);
            }

            if (this.smallSegs && smallData && smallData.length) {
                this.smallSeg.updateData(smallData);
            }

            this.buildLegend(this.data.lines);
        }
    }

    ngDoCheck() {
        if (this.data && this.data.lines && this.data.lines.length) {
            this.hasChart = true;
        }
    }

    ngAfterViewInit() {
        this.largeSegEl = this.contentSel.select('.large-segment-bar').node();
        this.smallSegsEl = this.contentSel.select('.small-segment-bars').node();
        this.barGrpSel = this.contentSel.select('.segment-bar-grp');

        if (this.data && this.data.lines && this.data.lines.length) {
            this.buildLegend(this.data.lines);
            this.barGrpSel.style('height', this.overallStackedHeight);

            this.largeSeg = new Monte.HorizontalSegmentBarChart(this.largeSegEl, this.largeOpts)
                .classed('mode-stacked', true)
                .on('axisRendered', yAxisLabelPlacement)
                .on('updated', updated)
                .data(this.prepData([_.head(this.data.lines)]));

            if (this.data.lines.length > 1) {
                this.smallSegs = new Monte.HorizontalSegmentBarChart(this.smallSegsEl, this.smallOpts)
                    .classed('mode-stacked', true)
                    .on('axisRendered', yAxisLabelPlacement)
                    .on('updated', updated)
                    .data(this.prepData(_.tail(this.data.lines)));
            }
        }
    }

    prepData(lines) {
        const out = [];

        lines.forEach((d) => {
            if (d) {
                out.push({
                    label: d[0].label,
                    values: formatNumbers(filterNumbers(d)),
                });
            }
        });

        return out;
    }

    buildLegend(lines) {
        const pendingLegends = {};

        lines.forEach((d) => {
            if (d) {
                d.forEach((n, i) => {
                    if (!pendingLegends[n.label]) {
                        pendingLegends[n.label] = {
                            i: i,
                            label: n.label,
                            css: `segment-${i}`,
                        };
                    }
                });
            }
        });

        this.legendItems = Object.keys(pendingLegends).map((k) => pendingLegends[k]).sort((a, b) => {
            return a.i - b.i;
        });
    }

    checkSize() {
        if (this.largeSeg) {
            this.largeSeg.checkSize();
        }

        if (this.smallSegs) {
            this.smallSegs.checkSize();
        }
    }

    update() {
        if (this.largeSeg) {
            this.largeSeg.update();
        }

        if (this.smallSegs) {
            this.smallSegs.update();
        }
    }

    toggleMode() {
        if (!this.largeSeg) {
            return;
        }

        const mode = this.largeSeg.option('segmentBarMode');

        if (mode === 'stacked') {
            this.barGrpSel.transition()
              .duration(750)
              .ease(d3.easeCubicIn)
              .style('height', this.overallGroupedHeight);

            d3.transition()
              .delay(350)
              .on('end', () => {
                  this.largeSeg.setMode('grouped').classed('mode-grouped', true).classed('mode-stacked', false);
                  this.largeSeg.boundingRect(this.largeSeg.boundingRect()[0], this.upperGroupedHeight);

                  if (this.smallSegs) {
                      this.smallSegs.y.paddingInner(0.1);
                      this.smallSegs.setMode('grouped').classed('mode-grouped', true).classed('mode-stacked', false);
                      this.smallSegs.boundingRect(this.smallSegs.boundingRect()[0], this.lowerGroupedHeight);
                  }
              });
        }
        else if (mode === 'grouped') {
            this.largeSeg.setMode('stacked').classed('mode-stacked', true).classed('mode-grouped', false);
            this.largeSeg.boundingRect(this.largeSeg.boundingRect()[0], this.upperStackedHeight);

            if (this.smallSegs) {
                this.smallSegs.setMode('stacked').classed('mode-stacked', true).classed('mode-grouped', false);
                this.smallSegs.y.paddingInner(0.6);
                this.smallSegs.option('margin.bottom', 15);

                this.barGrpSel.transition()
                  .duration(650)
                  .delay(150)
                  .style('height', this.overallStackedHeight)
                  .on('end', () => {
                      this.smallSegs.option('margin.bottom', 0);
                      this.smallSegs.boundingRect(this.smallSegs.boundingRect()[0], this.lowerStackedHeight);
                      this.smallSegs.update();
                  });
            }
        }
    }
}

function getLabel(number) {
    if (number && number.percentOfTotal) {
        return `${number.number} / ${percentFormat(number.percentOfTotal)}`;
    }
    return number.label;
}

function filterNumbers(numbers) {
    const out = [];

    numbers.forEach((n) => {
        if (n.number > 0) {
            out.push(n);
        }
    });

    return out;
}

function formatNumbers(numbers) {
    const out = [];

    numbers.forEach((d, i) => {
        out.push({
            value: d.number,
            label: `${getLabel(d)}`,
            type: d.label,
            css: `segment-${i}`,
        });
    });

    return out;
}

// Shifts y-axis labels to the far left.
// Invoked in the context of a chart.
function yAxisLabelPlacement(scaleName, axis, transition) {
    this.support.selectAll('.y-axis .tick text')
      .transition(transition)
        .attr('x', () => {
            return -1 * this.opts.margin.left;
        });
}

function updated() {
    const mode = this.option('segmentBarMode');

    // Select each segment group
    // * Check each label within the group against its corresponding rect.
    // * If the label is wider than the bar then hide; otherwise show.
    this.draw.selectAll('.monte-segment-bar-grp')
      .transition()
      .on('end', function() {
          d3.active(this).each(function() {
              const rects = d3.select(this).selectAll('.monte-segment-bar-seg');
              const lbls = d3.select(this).selectAll('.monte-bar-label');

              rects.enter().append('title')
                .merge(rects)
                  .each(function(d) {
                      const title = d3.select(this).selectAll('title').data([d]);

                      title.enter().append('title')
                        .merge(title)
                          .text(d.label);

                      title.exit().remove();
                  });

              // Labels and rects appear in sequential order (i.e. the first rect matches up with
              // the first label, the second with the second and so on) so just match them together
              // using their relative indexes.
              const pairs = d3.zip(rects.nodes(), lbls.nodes());

              if (mode === 'stacked') {
                  pairs.forEach((p) => checkLabelSize(p[0], p[1]));
              }
              else if (mode === 'grouped') {
                  pairs.forEach((p) => checkLabelShift(p[0], p[1]));
              }
          });
      });
}

function checkLabelSize(rectEl, lblEl) {
    const rectSize = rectEl.getBBox();
    const lblSize = lblEl.getBBox();
    const lbl = d3.select(lblEl);

    lbl.style('opacity', lblSize.width >= rectSize.width ? 0 : 1)
      .attr('exceeds', lblSize.width >= rectSize.width)
      .classed('over-edge', false);
}

function checkLabelShift(rectEl, lblEl) {
    const rectSize = rectEl.getBBox();
    const lblSize = lblEl.getBBox();
    const lbl = d3.select(lblEl);

    lbl.style('opacity', 1);

    if (lblSize.width >= rectSize.width) {
        lbl.classed('over-edge', true)
          .attr('exceeds', true);
    }
}
