// This file was generated from the chart scaffold
// Copyright 2016
/* global d3, _ */
import {Component, Input, Output, EventEmitter, ElementRef, ViewEncapsulation} from '@angular/core';
import * as Monte from 'monte';
import template from './GaugeBarPair.html';
import styles from './GaugeBarPair.scss';
import {formatShortNum, shortNumSymbol} from '../util/numberAbbrv';
import {reformatPercent} from '../util/format';
import {applyBudgetCss, getHealthCss} from '../util/color';

@Component({
    selector: 'gauge-bar-pair',
    template: template,
    styles: [styles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <donut-bar-pair name="DonutBarPair" (change)="onChange($event)"></donut-bar-pair>
 */
export default class GaugeBarPair {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'GaugeBarPair';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();

    @Input() data = {};
    @Input() chartSize = '';
    @Input() footerPresent = false;

    donutEl: HTMLElement;
    barEl: HTMLElement;

    donutOpts = {
        boundingWidth: 140,
        boundingHeight: 140,
        margin: { top: 50, right: 0, left: 0, bottom: 0 },
        innerRadius: 55,
        outerRadius: 70,
        pieStartAngle: Math.PI * -0.8,
        pieEndAngle: Math.PI * 0.8,
        needleBase: 2,
        needlePath: Monte.needleRect(),
        needleHeight: 78,
        transition: {
            duration: 500,
        },
        extensions: [
            new Monte.ExtLabel({
                binding: ['updated'],
                anchor: 'middle',
                labelCss: 'value-label',
                text: function() {
                    let symbol = shortNumSymbol(this.chart.summaryData.number);
                    if (this.chart.summaryData.format === 'percentage' || this.chart.summaryData.format === 'percent') {
                        symbol = '%';
                        return reformatPercent(this.chart.summaryData.number * 100) + '<tspan class="superscript" textLength="20" dy="-20" text-anchor: "middle">' + symbol + '</tspan>';
                    }
                    return formatShortNum(this.chart.summaryData.number, 1) + '<tspan class="superscript" textLength="20" dy="-20" text-anchor: "middle">' + symbol + '</tspan>';
                },
                y: 60,
                maxWidth: 48, // Slightly smaller than the inner diameter
            }),
            new Monte.ExtPolarLine({
                layer: 'overlay',
                angle: function() {
                    return this.chart.budgetAngle;
                },
                lineCss: 'budget-line',
                innerRadius: 55,
                outerRadius: 70,
            }),
            new Monte.ExtArc({
                binding: ['updated'],
                arcCss: 'monte-arc-neg',
                innerRadius: 55,
                outerRadius: 70,
                startAngle: 0,
                cornerRadius: 0,
                endAngle: function() {
                    if (this.chart.needleValueAngle() < 0) {
                        return this.chart.needleValueAngle();
                    }

                    return null;
                },
            }),
            new Monte.ExtArc({
                binding: ['updated'],
                innerRadius: 58,
                outerRadius: 78,
                startAngle: 0,
                cornerRadius: 0,
                endAngle: function() {
                    if (this.chart.needleValueAngle() > 0) {
                        return this.chart.needleValueAngle();
                    }

                    return null;
                },
            }),
        ],
    };

    barOpts = {
        css: 'no-domain-lines',
        boundingWidth: 100,
        boundingHeight: 155,
        suppressAxes: ['y'],
        margin: {
            top: 30, bottom: 40, left: 10, right: 10,
        },
        xAxisCustomize: Monte.tools.invokeMany(Monte.axisNoTicks, (axis) => axis.tickPadding(8)),
        xProp: 'axisLabel',
        xScale: function() {
            return d3.scaleBand().paddingInner(0.55).paddingOuter(0).round(true);
        },
        yDomainCustomize: Monte.extentGeneratorZeroToMax(1),
        yProp: 'number',
        extensions: [
            new Monte.ExtBarBg({
                enlarge: 0,
                maxValue: 0,
            }),
        ],
    };

    constructor(compEl: ElementRef) {
        this.contentSel = d3.select(compEl.nativeElement);
    }

    ngOnDestroy() {
        if (this.donutLarge) {
            this.donutLarge.destroy();
        }

        if (this.donutSmall) {
            this.donutSmall.destroy();
        }
    }

    ngOnChanges() {
        if (this.data) {
            if (this.donut) {
                this.donut.summaryData = _.get(this, 'data[0].numbers[0]', '');
                this.donut.updateData(getDonutVal(this.data[0].numbers[0]));
            }

            if (this.bar && this.data[1].length > 1) {
                this.bar.updateData(this.data[1].numbers);
            }
        }
    }

    ngAfterViewInit() {
        const comp = this;

        //  Delay is required to allow the UI to paint and provide correct dimensions
        _.delay(function(comp) {
            comp.renderChart();
        }, 10, comp);
    }

    renderChart() {
        const comp = this;

        const $container = $($(this.contentSel.node()).closest('chart-selector'));

        const containerWidth = $container.width();
        const containerHeight = $container.height();

        this.donutOpts.boundingWidth = (containerWidth * 0.6);
        this.donutOpts.boundingHeight = containerHeight;

        this.donutOpts.outerRadius = (Math.min(this.donutOpts.boundingWidth, this.donutOpts.boundingHeight) / 2);
        this.donutOpts.innerRadius = this.donutOpts.outerRadius - 20;

        this.donutOpts.extensions[0].opts.maxWidth = ((this.donutOpts.innerRadius * 2) - 20);
        this.donutOpts.extensions[1].opts.outerRadius = this.donutOpts.outerRadius;
        this.donutOpts.extensions[1].opts.innerRadius = this.donutOpts.innerRadius;

        this.donutOpts.extensions[3].opts.outerRadius = this.donutOpts.outerRadius;
        this.donutOpts.extensions[3].opts.innerRadius = this.donutOpts.innerRadius;

        this.barOpts.boundingWidth = (containerWidth * 0.4);
        this.barOpts.boundingHeight = containerHeight;

        this.donutEl = this.contentSel.select('.donut-wrap').node();
        this.barEl = this.contentSel.select('.bar-wrap').node();

        if (!this.donut) {
            this.donut = new Monte.GaugeChart(this.donutEl, this.donutOpts)
                .call(function() {
                    // Bind summary data so it is accessible by the label extensions
                    this.summaryData = _.get(comp, 'data[0].numbers[0]', '');
                })
                .on('rendered', function() {
                    this.overlay.append('text')
                        .attr('class', 'date-label')
                        .attr('dy', '0.35em')
                        .attr('text-anchor', 'middle')
                        .attr('transform', 'translate(0, 30)')
                        .text(_.get(comp, 'data[0].label') === null ? 'Total' : _.get(comp, 'data[0].label'));  // ('Total');// if Chart has a label enter it here
                })
                .on('updated', function() {
                    this.classed(getHealthCss(comp.data[0].numbers[0].health), true);
                    const budgetVal = comp.data[0].numbers[0].budget; // TODO -- Use a different prop -- we dont have budgets anymore

                    if (budgetVal) {
                        const fData = this.pie([{ value: budgetVal }, { value: 1 - budgetVal }]);
                        const angle = fData[0].endAngle;
                        this.budgetAngle = angle;
                    }
                })
                .data(this.prepData(this.data[0]));
        }

        if (!this.bar) {
            this.bar = new Monte.BarChart(this.barEl, this.barOpts)
                .on('updated', function() {
                    const chart = this;

                    // Add budget lines
                    const fData = this.data().filter((d) => d.budget);  // TODO -- Use a different prop -- we dont have budgets anymore
                    const fLines = this.overlay.selectAll('.budget-line').data(fData);

                    fLines.enter().append('line')
                        .attr('class', 'budget-line')
                        .merge(fLines)
                        .attr('x1', (d) => this.getScaledProp('x', d))
                        .attr('x2', (d) => this.getScaledProp('x', d) + this.x.bandwidth())
                        .attr('y1', (d) => this.y(d.budget))
                        .attr('y2', (d) => this.y(d.budget))
                        .each(function(d) {
                            const nodeSel = d3.select(this);
                            applyBudgetCss(nodeSel, chart.getProp('y', d), d.budget);
                        });

                    fLines.exit();

                    this.draw.selectAll('.bar')
                        .each(function(d) {
                            const nodeSel = d3.select(this);
                            nodeSel.classed(getHealthCss(d.health), true);
                        });
                })
                .on('axisRendered', function(scaleName, axis, t) {
                    // Change x-axis formatting to include y-value percents.
                    t.on('end', () => {
                        const tickText = this.support.selectAll('.x-axis .tick text');
                        tickText.text('');

                        tickText.append('tspan')
                            .attr('class', 'bar-val')
                            .attr('x', 0)
                            .attr('dy', '0.65em')
                            .text(function(label) {
                                if (comp.barLabelDataMap && comp.barLabelDataMap[label]) {
                                    if (comp.barLabelDataMap[label].format === 'percentage' || comp.barLabelDataMap[label].format === 'percent') {
                                        return reformatPercent(comp.barLabelDataMap[label].number * 100) + '%';
                                    }
                                    else {
                                        return formatShortNum(comp.barLabelDataMap[label].number, 1) + shortNumSymbol(comp.barLabelDataMap[label].number);
                                    }
                                }
                                return '';
                            });

                        tickText.append('tspan')
                            .attr('x', 0)
                            .attr('dy', '1.2em')
                            .text((label) => label);
                    });
                })
                .data(this.data[1].numbers);

            this.barLabelDataMap = this.data[1].numbers.reduce((out, d) => {
                out[d.label] = d;
                out[d.axisLabel] = d;
                return out;
            }, {});
        }
    }

    prepData(data) {
        const initVal = data.numbers[0];
        const value = (initVal.format === 'percentage' || initVal.format === 'percent') ? (initVal.number * 100) : initVal.number;
        const extent = this.round10(Math.abs(value)) || 10; // `|| 10` Avoids having arcs of zero length.

        const out = {
            value,
            start: -extent,
            segments: [
                { interval: -extent, label: (-extent).toString() },
                { interval: extent, label: extent.toString() },
            ],
        };

        return out;
    }

    round10(value) {
        return Math.ceil(value / 10) * 10;
    }


    checkSize() {
        if (this.donut) {
            this.donut.checkSize();
        }

        if (this.bar) {
            this.bar.checkSize();
        }
    }

    update() {
        if (this.donut) {
            this.donut.update();
        }

        if (this.bar) {
            this.bar.update();
        }
    }
}

function getDonutVal(data) {
    return data.number * 100 || 0;
}
