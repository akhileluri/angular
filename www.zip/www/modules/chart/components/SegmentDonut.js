// This file was generated from the chart scaffold
// Copyright 2016
/* global d3, _ */
import {Component, Input, Output, EventEmitter, ElementRef, ViewEncapsulation} from '@angular/core';
import * as Monte from 'monte';
import * as monteExtD3Tip from 'monte-ext-d3-tip';
import template from './SegmentDonut.html';
import styles from './SegmentDonut.scss';
import {formatMetdataNumber as formatNumber, formatShortNum, shortNumSymbol} from '../util/numberAbbrv';
import {reformatPercent} from '../util/format';
import {resolveLegendName} from '../util/legend';

@Component({
    selector: 'segment-donut',
    template: template,
    styles: [styles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <segment-donut name="SegmentDonut" (change)="onChange($event)"></segment-donut>
 */
export default class SegmentDonut {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'SegmentDonut';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();

    @Input() data = null;
    @Input() dataConfig = null;
    @Input() chartData = null;
    @Input() chartSize: string = '';
    @Input() footerPresent = false;

    transformedData = [];
    displayLegend = false;

    opts = {
        boundingWidth: 140,
        boundingHeight: 140,
        margin: { top: 0, right: 0, left: 0, bottom: 0 },
        innerRadius: 55,
        piePadAngle: 0,
        chartCss: 'text-align: center',
        extensions: [
            new Monte.ExtLabel({
                binding: ['updated'],
                anchor: 'middle',
                labelCss: 'value-label',
                text: function() {
                    let symbol = shortNumSymbol(this.chart.summaryData.number);
                    if (this.chart.summaryData.format === 'percentage' || this.chart.summaryData.format === 'percent') {
                        symbol = '%';
                        return reformatPercent(this.chart.summaryData.number * 100) + '<tspan class="superscript" textLength="20" dy="-20" text-anchor: "middle">' + symbol + '</tspan>';
                    }
                    if(this.chart.summaryData.number) {
                        return formatShortNum(this.chart.summaryData.number, 1) + '<tspan class="superscript" textLength="20" dy="-20" text-anchor: "middle">' + symbol + '</tspan>';
                    }
                    return'';
                },
                y: 0,
                maxWidth: 80, // Slightly smaller than the inner diameter
            }),
            new Monte.ExtLabel({
                binding: ['updated'],
                anchor: 'middle',
                labelCss: 'sub-label',
                text: function() {
                    return this.chart.summaryData.axisLabel;
                },
                y: 30,
            }),
        ],
        labelRadius: 60,
    };

    tooltips = new monteExtD3Tip.ExtD3Tip({
        featurePrefix: 'wedge',
        offset: -5,
        css:'d3-tip',
        html: function(d, ref2) {
            const title = resolveLegendName(d.data.label, d.data.dataMap);
            const value = formatNumber(d.data.number, '');

            return `<div class='tooltip-title'>${title}</div>` +
                '<div class="tooltip-hr"></div>' +
                `<div><span class='subtle'>${value}</span></div>`;
        },
        hideEvents: ['click'],
    });


    constructor(chartEl: ElementRef) {
        this.chartWrap = d3.select(chartEl.nativeElement);
    }

    doubleWideOptions() {
        this.opts.margin = { top: 5, right: 0, left: 0, bottom: 0};
        this.opts.innerRadius = 55;
        this.opts.chartCss = 'text-align: left';
    }

    quadWideOptions() {
        this.opts.margin = { top: 5, right: 0, left: 0, bottom: 20};
        this.opts.innerRadius = 65;
        this.opts.outerRadius = 75;
        this.opts.chartCss = 'text-align: left';
    }

    ngOnDestroy() {
        if (this.chart) {
            this.chart.destroy();
        }
    }

    ngOnChanges() {
        this.transformedData = this.prepData(this.data);
        if (this.data &&  this.data.showIndicators === true) {
            this.displayLegend = true;
        }
        if (this.chart) {
            this.chart.summaryData = this.data.summaryNumber;
            this.chart.updateData(this.transformedData);
        }
    }

    ngAfterViewInit() {
        const comp = this;

        //  Delay is required to allow the UI to paint and provide correct dimensions
        _.delay(function(comp) {
            comp.renderChart();
        }, 10, comp);
    }

    getItemLabel(label) {
        return resolveLegendName(label, this.dataConfig.dataItemsMap);
    }

    renderChart() {
        const comp = this;

        const $container = $($(this.chartWrap.node()).closest('chart-selector'));
        const $overview = $($container.find('.overview-text'));
        let legendWidth = 0;
        let legendHeight = 0;

        if (this.displayLegend){
            const $legend = $($(this.chartWrap.node()).find('ul.segment-legend'));

            legendWidth = $legend.outerWidth();
            legendHeight = $legend.outerHeight();
        }


        //  Include option tooltips that appear over the bar when hovered
        if (comp.data && comp.data.enableTooltips === true) {
            this.opts.extensions.push(this.tooltips);
        }


        //  Set final dimensions based on the available space created by the flexbox layout
        this.opts.boundingWidth = $container.width();
        this.opts.boundingHeight = $container.height();

        switch (this.chartSize) {
        case 'quadruple':
            this.opts.boundingWidth -= legendWidth;
            break;
        case 'double':
            this.opts.boundingWidth -= legendWidth;
            break;
        case 'single':
            this.opts.boundingHeight -= legendHeight;
            break;
        default:
            this.opts.boundingHeight -= legendHeight;
        }

        //  Make room for the overview text
        const overviewWidth = $overview.outerWidth();

        if (this.chartSize === 'double' || this.chartSize === 'quadruple') {
            this.opts.boundingWidth -= overviewWidth;
        }

        this.opts.outerRadius = (Math.min(this.opts.boundingWidth, this.opts.boundingHeight) / 2);
        this.opts.innerRadius = this.opts.outerRadius - 20;

        this.opts.extensions[0].opts.maxWidth = ((this.opts.innerRadius * 2) - 20);

        this.chartEl = this.chartWrap.select('.segment-donut').node();
        this.chart = new Monte.ArcChart(this.chartEl, this.opts)
          .call(function() {
              // Bind summary data so it is accessible by the label extensions
              this.summaryData = comp.chartData.primaryDisplayNumbers[0];
          })
          .data(this.transformedData);
    }

    prepData(data) {
        if (data && data.numbers) {
            data.numbers.forEach((d, i) => {
                d.value = d.number;
                d.css = `segment-${i}`;
                d.dataMap = this.dataConfig.dataItemsMap;
            });

        }
        return data.numbers;
    }

    checkSize() {
        if (this.chart) {
            this.chart.checkSize();
        }
    }

    update() {
        if (this.chart) {
            this.chart.update();
        }
    }

    formattedValue(item) {
        return formatNumber(item, '', 0);
    }
}
