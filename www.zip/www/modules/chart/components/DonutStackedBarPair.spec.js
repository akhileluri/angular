// This file was generated from the chart scaffold
// Copyright 2016

import {Component, Injector} from '@angular/core';
import DonutStackedBarPair from './DonutStackedBarPair';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [DonutStackedBarPair],
    template: ''
})
class TestComponent {}

describe('chart/DonutStackedBarPair.js', () => {

    beforeEach(() => {
        addProviders([DonutStackedBarPair]);
    });

    it('should return component name', inject([DonutStackedBarPair], (donutStackedBarPair:DonutStackedBarPair) => {
        expect(donutStackedBarPair.name).toBe('DonutStackedBarPair');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<donut-stacked-bar-pair></donut-stacked-bar-pair>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('donut-stacked-bar-pair h1').innerText).toBe('DonutStackedBarPair');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<donut-stacked-bar-pair name="TEST"></donut-stacked-bar-pair>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('donut-stacked-bar-pair h1').innerText).toBe('TEST');
            });
    })));

});
