// This file was generated from the component scaffold
// Copyright 2016
/* global d3, _ */
import { Component, Input, Output, EventEmitter, ElementRef, ViewEncapsulation } from '@angular/core';
import * as Monte from 'monte';
import template from './HorizontalBarChart.html';
import styles from './HorizontalBarChart.scss';
import chartStyles from './chartCommon.scss';

import { formatShortNum, shortNumSymbol } from '../util/numberAbbrv';
import { percentFormat, reformatPercent } from '../util/format';

@Component({
    selector: 'horizontal-bar-chart',
    template: template,
    styles: [styles, chartStyles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <horizontal-bar-chart name="HorizontalBarChart" (change)="onChange($event)"></horizontal-bar-chart>
 */
export default class HorizontalBarChart {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'HorizontalBarChart';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();
    @Input() data = {};
    @Input() chartSize = '';
    @Input() footerPresent = false;

    opts = {
        css: 'no-domain-lines',
        boundingWidth: 230,
        boundingHeight: 90,
        barCss: function(d) {
            return d.health;
        },
        includeLabels: false,
        suppressAxes: ['x'],
        margin: {
            top: 20, bottom: 0, left: 60, right: 20,
        },
        extensions: [
            new Monte.ExtHorizontalBarBg({
                enlarge: 0,
                maxValue: 0,
            }),
        ],

        xProp: 'number',
        // xDomainCustomize: Monte.extentGeneratorZeroToMax(1),

        yProp: 'axisLabel',
        yAxisCustomize: Monte.tools.invokeMany(
            Monte.axisNoTicks,
            (axis) => {
                axis.tickPadding(10);
                return axis;
            }
        ),
        yScale: function() {
            return d3.scaleBand().paddingInner(0.3).paddingOuter(0).round(true);
        },

        resize: new Monte.HorizontalResizer(),
        showIndicators: false,
    };

    constructor(chartEl: ElementRef) {
        this.chartEl = d3.select(chartEl.nativeElement).node();
    }

    ngOnDestroy() {
        if (this.chart) {
            this.chart.destroy();
        }
    }

    ngOnChanges() {
        if (this.data && this.chart) {
            this.chart.updateData(this.prepData(this.data));
        }
    }

    quadWideOptions() {
        delete this.opts.suppressAxes;
        this.opts.chartCss = 'text-align: left';
    }

    doubleWideOptions() {
        this.opts.chartCss = 'text-align: left';
    }

    barLabelOptions() {
        this.opts.includeLabels = true;
        this.opts.label = function(value) {
            if (value.format === 'percentage' || value.format === 'percent') {
                return reformatPercent(value.number * 100) + '%';
            }
            return formatShortNum(value.number, 1) + shortNumSymbol(value.number);
        };
        this.opts.labelProp = 'number';
        this.opts.labelX = function() {
            return this.width + 4;
        };
        this.opts.labelYAdjust = function() {
            const labelHeight = 12; //  NOTE: This should match the value in chartCommon.scss
            const barHeight = this.y.bandwidth();
            return (((barHeight / 2) - (labelHeight / 2)) + 2);
        };
        this.opts.margin.right = 28;
    }

    barToolTipOptions() {
        this.opts.margin.right = 50;
    }

    barLabelAndToolTipOptions() {
        this.opts.margin.right = 50;
    }

    ngAfterViewInit() {
        const comp = this;

        //  Delay is required to allow the UI to paint and provide correct dimensions
        _.delay(function(comp) {
            comp.renderChart();

            //  Forces the overlay to be rendered
            comp.checkSize();
        }, 10, comp);
    }

    renderChart() {
        const comp = this;

        const $container = $($(this.chartEl).closest('chart-selector'));

        //  Set final dimensions based on the available space created by the flexbox layout
        this.opts.boundingWidth = $container.width();
        this.opts.boundingHeight = $container.height();

        if (this.chartSize === 'double') {
            this.doubleWideOptions();
        }
        else if (this.chartSize === 'quadruple') {
            this.quadWideOptions();
        }

        //  Include optional value labels above the bar
        if (this.data.showLabels === true) {
            this.barLabelOptions();
        }

        //  Include option tooltips that appear over the bar when hovered
        if (this.data.enableTooltips === true) {
            this.barToolTipOptions();
        }

        //  Include both the option value labels and toolstips
        if (this.data.showLabels === true && this.data.enableTooltips === true) {
            this.barLabelAndToolTipOptions();
        }

        if (this.data.showIndicators) {
            this.opts.showIndicators = true;
            this.opts.yScale = function() {
                return d3.scaleBand().paddingInner(0.7).paddingOuter(0).round(true);
            };
        }

        const initData = this.prepData(this.data);

        this.chart = new Monte.HorizontalBarChart(this.chartEl, this.opts)
          .on('rendered', function() {
              // For each bar draw a reference
              const data = this.data();
              const chart = this;

              this.overlay.selectAll('.bar-ref-zero').data(data)
                .enter().append('line')
                  .attr('class', 'bar-ref-zero')
                  .attr('x1', 0)
                  .attr('x2', 0)
                  .attr('y1', (d) => chart.getScaledProp('y', d) - 5)
                  .attr('y2', (d) => chart.getScaledProp('y', d) + chart.y.bandwidth());

              this.overlay.append('text')
                .attr('transform', 'translate(0, -5)')
                .attr('class', 'label-zero')
                .attr('dy', '-0.35em')
                .attr('text-anchor', 'middle')
                .text(0);
          })
          .on('updated', function() {
              if (this.option('showIndicators')) {
                  const flags = this.overlay.selectAll('.annotate-flag').data(this.data());

                  flags.enter().each((d) => {
                      const v = this.getProp('x', d);
                      const x = this.getScaledProp('x', d);
                      const y = this.getScaledProp('y', d);

                      addFlag.call(this, x, y, percentFormat(v));
                  });

                  // Update
                  flags.each((d, i, nodes) => {
                      const flagGrp = d3.select(nodes[i]);
                      const v = this.getProp('x', d);
                      const x = this.getScaledProp('x', d);
                      const y = this.getScaledProp('y', d);

                      updateFlag.call(this, flagGrp, x, y, percentFormat(v));
                  });

                  flags.exit().remove();

                  this.draw.selectAll('.bar').each((/* d, i, nodes */) => {
                      // TODO: Apply health status and trend for proper style.
                      // const nodeSel = d3.select(nodes[i]);
                      // applyBudgetCss(nodeSel, this.getProp('x', d), 100);
                  });
              }
          })
          .on('boundsUpdated', function() {
              if (comp.data.enableTooltips === true) {
                  comp.buildOverlay(comp.prepData(comp.data), this, comp);
              }
          })
          .data(initData)
          .checkSize();
    }

    buildOverlay(data, chart) {
        const self = this;
        const tooltipMargin = 7;
        const textSize = 10;
        const circleR = textSize / 1.5;
        const barHeight = chart.y.bandwidth();

        const maxValue = _.maxBy(data, (d) => {
            return (_.isNumber(d.number) === true) ? d.number : 0;
        });

        const getTranslate = function(element) {
            const transform = element.getAttribute('transform');
            return transform.substring(transform.indexOf('(') + 1, transform.indexOf(')')).split(',')
                .map((cur) => parseFloat(cur));
        };

        const highlightGroup = chart.overlay.selectAll('g.highlight-group').data(data);

        const highlightGroupEnter = highlightGroup
            .enter()
            .append('g')
            .classed('highlight-group', true)
            .attr('opacity', '0');

        highlightGroup
            .attr('transform', function(d) {
                const yVal = _.find(d, (val) => val);
                return 'translate(0, ' + chart.getScaledProp('y', yVal) + ')';
            });

        const tooltipGroup = highlightGroupEnter
            .append('g')
            .classed('tooltip-group', true);

        const allDataPointGroup = tooltipGroup
            .append('g')
            .classed('all-datapoint-group', true)
            .attr('transition', function() {
                return 'translate(0,' + textSize + ')';
            });

        const dataPointGroup = allDataPointGroup.selectAll('g.datapoint-group').data(function(d) {
            return [d];
        })
            .enter()
            .filter(function(d) {
                return d.number !== undefined;
            })
            .append('g')
            .classed('datapoint-group', true)
            .sort(function(a, b) {
                return a.y > b.y ? -1 : 1;
            })
            .attr('transform', function(d, i, nodes) {
                const transY = nodes[i - 1] ? getTranslate(nodes[i - 1])[1] + textSize + 10 : textSize + 9;
                return 'translate(0,' + transY + ')';
            });

        dataPointGroup
            .append('text')
            .text(function(value) {
                if (value.format === 'percentage' || value.format === 'percent') {
                    return reformatPercent(value.number * 100) + '%';
                }
                return formatShortNum(value.number, 1) + shortNumSymbol(value.number);
            })
            .attr('x', (textSize - 2))
            .attr('y', -4)
            .style('font-size', textSize)
            .style('fill', 'white');

        tooltipGroup
            .insert('rect', 'g')
            .attr('width', function() {
                return this.parentElement.getBBox().width + 2 * tooltipMargin;
            })
            .attr('height', function() {
                return this.parentElement.getBBox().height + 2 * tooltipMargin;
            })
            .attr('rx', circleR)
            .attr('ry', circleR)
            .style('fill', '#494949');

        const lineHighlightGroup = highlightGroupEnter
            .append('g')
            .classed('line-group', true);

        //  Draw the target to trigger the tooltip's appearance
        lineHighlightGroup
            .append('line')
            .classed('highlight-target', true)
            .attr('y1', (barHeight / 2))
            .attr('y2', (barHeight / 2))
            .attr('x1', '0')
            .attr('x2', chart.width)
            .attr('opacity', '0')
            .style('stroke-width', ((barHeight + 2) + 'px'))
            .style('stroke', 'red')
            .on('mouseover', function(d) {
                chart.overlay.selectAll('.highlight-group').filter(function(data) {
                    return _.find(data, (val) => val) === _.find(d, (val) => val);
                }).transition().duration(300).attr('opacity', '1');
                chart.support.selectAll('.highlight-group').filter(function(data) {
                    return _.find(data, (val) => val) === _.find(d, (val) => val);
                }).transition().duration(300).attr('opacity', '1');
            })
            .on('mouseout', function(d) {
                if (!self.showValues) {
                    chart.overlay.selectAll('.highlight-group').filter(function(data) {
                        return _.find(data, (val) => val) === _.find(d, (val) => val);
                    }).transition().duration(300).attr('opacity', '0');
                    chart.support.selectAll('.highlight-group').filter(function(data) {
                        return _.find(data, (val) => val) === _.find(d, (val) => val);
                    }).transition().duration(300).attr('opacity', '0');
                }
            });

        //  Position the tooltip
        tooltipGroup
            .attr('transform', function(d) {
                const ratioOfMaxNumber = Math.max(Math.min((d.number / maxValue.number), 1), 0);
                const xTrans = ((ratioOfMaxNumber * (this.parentElement.getBBox().width)) + 7);
                const yTrans = ((this.getBBox().height / -2) + (barHeight / 2));

                return 'translate(' + xTrans + ',' + yTrans + ')';
            });

        //  Draw the pointer (triangle) element of the tooltip
        tooltipGroup
            .append('path')
            .attr('d', function() {
                const baseX = 1;
                const tipX = -6;
                const height = 10;
                const startY = this.parentElement.getBBox().height / 2 - height / 2;
                const midY = this.parentElement.getBBox().height / 2;
                const endY = this.parentElement.getBBox().height / 2 + height / 2;

                return 'M ' + baseX + ' ' + startY + ' L ' + (baseX + tipX) + ' ' + midY + ' L ' + baseX + ' ' + endY;
            })
            .style('fill', '#494949');
    }

    prepData(d) {
        return d.numbers.sort((a, b) => {
            let aNum = parseInt(a.axisLabel, 10);
            let bNum = parseInt(b.axisLabel, 10);

            if (isNaN(aNum)) {
                aNum = 1e12;
            }

            if (isNaN(bNum)) {
                bNum = 1e12;
            }

            return aNum - bNum;
        });
    }

    checkSize() {
        if (this.chart) {
            this.chart.checkSize();
        }
    }

    update() {
        if (this.chart) {
            this.chart.update();
        }
    }
}

/**
 * Add an annotation flag to the chart with a downward pointing arrow.
 *
 * @param {number} tipX      The x coordinate for the tip of the arrow.
 * @param {number} tipY      The y coordinate for the tip of the arrow.
 * @param {string} flagText  The text of the flag.
 * @param {string} hPadding  The horizontal padding of the flag around the text.
 * @param {string} vPadding  The vertical padding of the flag around the text.
 * @param {string} arrowSize The width of the arrow.
 *
 * @returns {undefined}
 */
function addFlag(tipX, tipY, flagText, hPadding = 5, vPadding = 3, arrowSize = 7) {
    const flagGrp = this.overlay.append('g')
      .attr('class', 'annotate-flag');

    const txt = flagGrp.append('text').text(flagText);

    // Measure the text and draw a rectangle big enough.
    const bbox = txt.node().getBBox();
    const flagWidth = bbox.height + 2 * hPadding;
    const flagHeight = bbox.height + 2 * vPadding;
    flagGrp.append('rect')
      .attr('x', 0)
      .attr('y', arrowSize)
      .attr('rx', 3)
      .attr('width', flagWidth)
      .attr('height', flagHeight);

    flagGrp.append('path')
      .attr('d', `M 0,0 ${arrowSize},0 ${arrowSize / 2},${arrowSize / 2} Z`)
      .attr('transform', `translate(${flagWidth / 2 - arrowSize / 2}, ${flagHeight + arrowSize})`);

    // Raise text so it is above the rect.
    txt.raise()
      .attr('text-anchor', 'middle')
      .attr('x', flagWidth / 2)
      .attr('y', flagHeight + arrowSize - vPadding)
      .attr('dy', '-0.35em');

    flagGrp.attr('transform', `translate(${tipX - flagWidth / 2}, ${tipY - flagHeight - arrowSize - vPadding - 2})`);
}

function updateFlag(flagGrp, tipX, tipY, flagText, hPadding = 5, vPadding = 3, arrowSize = 7) {
    const txt = flagGrp.select('text').text(flagText);

    const bbox = txt.node().getBBox();
    const flagWidth = bbox.height + 2 * hPadding;
    const flagHeight = bbox.height + 2 * vPadding;
    flagGrp.select('rect')
      .attr('y', arrowSize)
      .attr('width', flagWidth)
      .attr('height', flagHeight);

    flagGrp.select('path')
      .attr('transform', `translate(${flagWidth / 2 - arrowSize / 2}, ${flagHeight + arrowSize})`);

    txt.attr('x', flagWidth / 2)
      .attr('y', flagHeight + arrowSize - vPadding);

    flagGrp.attr('transform', `translate(${tipX - flagWidth / 2}, ${tipY - flagHeight - arrowSize - vPadding - 2})`);
}
