// This file was generated from the chart scaffold
// Copyright 2018
/* global d3, _ */
import {Component, Input, Output, EventEmitter, ElementRef, ViewEncapsulation, ChangeDetectorRef} from '@angular/core';
import * as Monte from 'monte';
import template from './VerticalSegmentBarChart.html';
import styles from './VerticalSegmentBarChart.scss';
import chartStyles from './chartCommon.scss';
import {percentFormat, reformatPercent, leadYearFormat} from '../util/format';
import {formatAbbreviation, formatShortNum, shortNumSymbol} from '../util/numberAbbrv';
import {resolveLegendName} from '../util/legend';

@Component({
    selector: 'vertical-segment-bar-chart',
    template: template,
    styles: [styles, chartStyles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <vertical-segment-bar-chart name="VerticalSegmentBarChart" (change)="onChange($event)"></vertical-segment-bar-chart>
 */
export default class VerticalSegmentBarChart {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'VerticalSegmentBarChart';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();

    @Input() data = {};
    @Input() dataConfig = null;
    @Input() chartSize = '';
    @Input() footerPresent = false;
    @Input() isStacked = false;

    legend = [];

    opts = {
        css: 'no-domain-lines monte-axis-no-ticks',
        boundingWidth: 251,
        boundingHeight: 120,
        includeLabels: false,
        suppressAxes: ['y'],
        xAxisCustomize: Monte.tools.invokeMany(
            (axis) => axis.tickFormat(leadYearFormat),
            Monte.axisNoTicks
        ),
        resize: new Monte.HorizontalResizer(),
        margin: {
            top: 15, right: 5, bottom: 15, left: 38,
        },
        transition: {
            duration: 500,
        },
        segmentBarMode: 'grouped',
        xInnerProp: 'type',

        extensions: [
            // new Monte.ExtReferenceLine({
            //     layer: 'support',
            //     labelPlacement: 'nw',
            //     data: function() {
            //         const data = this.chart.data();
            //
            //         if (data && data.length > 1) {
            //             const chart = this.chart;
            //             const yProp = chart.option('yProp');
            //             const yInnerProp = chart.option('yInnerProp');
            //             const datumLast = data[data.length - 1][yProp];
            //             // const datumLastMaxVal = _.maxBy(datumLast, yInnerProp)[yInnerProp];
            //             const datumFormat = datumLast[0].format;
            //             const allValues = data.reduce((acc, d) => {
            //                 // Extract all values of individual segments
            //                 d[yProp].forEach((v) => acc.push(v[yInnerProp]));
            //
            //                 return acc;
            //             }, []);
            //             const maxVal = _.max(allValues);
            //             const y2 = chart.getScaledProp('y', maxVal);
            //             const l = chart.option('margin.left');
            //
            //             // let datumLastMaxValFormatted = ''; // TODO Determine is we need to track this val - MM 3/26/18
            //             let maxValFormatted = '';
            //             if (datumFormat === 'percentage' || datumFormat === 'percent') {
            //                 // datumLastMaxValFormatted = reformatPercent(datumLastMaxVal * 100) + '%';
            //                 maxValFormatted = reformatPercent(maxVal * 100) + '%';
            //             }
            //             else {
            //                 const symbol = shortNumSymbol(datumLast[0].value);
            //                 // datumLastMaxValFormatted = formatShortNum(datumLastMaxVal, 1) + symbol;
            //                 maxValFormatted = formatShortNum(maxVal, 1) + symbol;
            //             }
            //
            //             const max = {
            //                 x1: -l,
            //                 x2: chart.width,
            //                 y1: y2,
            //                 y2: y2,
            //                 text: maxValFormatted,
            //             };
            //
            //             return [max];
            //         }
            //
            //         return [];
            //     },
            // }),
            // new Monte.ExtReferenceLine({
            //     layer: 'support',
            //     labelPlacement: 'sw',
            //     data: function() {
            //         const data = this.chart.data();
            //
            //         if (data && data.length > 1) {
            //             const chart = this.chart;
            //             const yProp = chart.option('yProp');
            //             const yInnerProp = chart.option('yInnerProp');
            //             const datumLast = data[data.length - 1][yProp];
            //             const datumLastMaxVal = _.maxBy(datumLast, yInnerProp)[yInnerProp];
            //             const datumFormat = datumLast[0].format;
            //             const allValues = data.reduce((acc, d) => {
            //                 // Extract all values of individual segments
            //                 d[yProp].forEach((v) => acc.push(v[yInnerProp]));
            //
            //                 return acc;
            //             }, []);
            //             const maxVal = _.max(allValues);
            //             const y2 = chart.getScaledProp('y', maxVal);
            //             // const y1 = y2 + ((Math.max(30,chart.getScaledProp('y', datumLastMaxVal))) - y2);
            //             const y1 = chart.getScaledProp('y', datumLastMaxVal);
            //             if ((y2 - y1) < 10) {
            //                 this.opts.labelPlacement = 'sw';
            //             }
            //             const l = chart.option('margin.left');
            //
            //             let datumLastMaxValFormatted = '';
            //             if (datumFormat === 'percentage' || datumFormat === 'percent') {
            //                 datumLastMaxValFormatted = reformatPercent(datumLastMaxVal * 100) + '%';
            //             }
            //             else {
            //                 const symbol = shortNumSymbol(datumLast[0].value);
            //                 datumLastMaxValFormatted = formatShortNum(datumLastMaxVal, 1) + symbol;
            //             }
            //
            //             const last = {
            //                 x1: -l,
            //                 x2: chart.width,
            //                 y1: y1,
            //                 y2: y1,
            //                 text: datumLastMaxValFormatted,
            //             };
            //
            //             return [last];
            //         }
            //
            //         return [];
            //     },
            // }),
            new Monte.ExtReferenceLine({
                layer: 'support',
                css: 'monte-ext-ref-line-grp projected-section',
                data: function() {
                    const data = this.chart.data();

                    if (data && data.length > 1) {
                        const chart = this.chart;
                        const firstProjected = _.find(data, ['values[0].cssGroup', 'projected']);
                        const x1 = chart.getScaledProp('x', firstProjected);
                        const floor = {
                            x1: x1,
                            x2: chart.width,
                            y1: chart.height + 25,
                            y2: chart.height + 25,
                            text: 'projected',
                        };

                        if (firstProjected) {
                            return [floor];
                        }
                    }

                    return [];
                },
            }),
        ],
    };

    constructor(compEl:ElementRef, ref:ChangeDetectorRef) {
        this.compEl = d3.select(compEl.nativeElement);
        this.ref = ref;
    }

    ngOnDestroy() {
        if (this.chart) {
            this.chart.destroy();
        }
    }

    ngOnChanges() {
        if (this.data && this.chart) {
            this.chart.updateData(this.prepData(this.data));
        }
    }

    quadWideOptions() {
        this.opts.margin = { top: 20, right: 20, left: 65, bottom: 20 };
        delete this.opts.suppressAxes;
        // this.opts.chartCss = 'text-align: left';
        this.opts.extensions.push(new Monte.ExtHorizontalLines());
        this.opts.css += ' ref-line-focus'; // Give extra focus to ref lines because the y-axis is now showing.
    }

    barLabelOptions() {
        this.opts.includeLabels = true;
        this.opts.label = function(value) {
            if (value.format === 'percentage' || value.format === 'percent') {
                return reformatPercent(value.value * 100) + '%';
            }
            return formatShortNum(value.value, 1) + shortNumSymbol(value.value);
        };
        this.opts.labelProp = 'number';
        this.opts.labelXAdjust = function(value, index, textNodes) {
            const labelWidth = textNodes[index].getComputedTextLength();
            return ((labelWidth / 2) * -1);
        };
        this.opts.labelYAdjust = -5;
    }

    barToolTipOptions() {
        //  Make room for the tooltips
        this.opts.margin.top = 27 + (17 * _.get(this, 'data.lines[0].lines.length', 0));
    }

    barLabelAndToolTipOptions() {
        //  Make room for the tooltips
        this.opts.margin.top = 38 + (17 * _.get(this, 'data.lines[0].lines.length', 0));
    }

    adjustForProjected() {
        this.opts.margin.bottom += 15;
    }

    ngAfterViewInit() {
        const comp = this;

        comp.renderLegend(this.data.lines);

        //  Delay is required to allow the UI to paint and provide correct dimensions
        _.delay(function(comp) {
            comp.renderChart();

            //  Forces the overlay to be rendered
            comp.checkSize();
        }, 10, comp);
    }

    renderLegend(lines) {
        this.legend.length = 0; // Clear current legend

        if (lines.length) {
            lines[0].lines.forEach((d, i) => {
                if (this.dataConfig) {
                    this.legend.push({
                        label: resolveLegendName(d.label, this.dataConfig.dataItemsMap),
                        css: `segment-${i}`,
                    });
                }
            });
            this.ref.detectChanges();
        }
    }

    renderChart() {
        const comp = this;

        const $container = $($(this.compEl.node()).closest('chart-selector'));

        //  Set final dimensions based on the available space created by the flexbox layout
        comp.opts.boundingWidth = $container.width();
        comp.opts.boundingHeight = $container.height();

        //  Make room for the legend
        if (comp.legend.length > 0) {
            const $legend = $($(this.compEl.node()).children('.legend:first'));
            const legendHeight = $legend.outerHeight();

            comp.opts.boundingHeight -= legendHeight;
        }

        if (this.chartSize === 'quadruple') {
            this.quadWideOptions();
        }

        //  Include optional value labels above the bar
        if (comp.data && comp.data.showLabels === true) {
            this.barLabelOptions();
        }

        //  Include option tooltips that appear over the bar when hovered
        if (comp.data && comp.data.enableTooltips === true && comp.isStacked === false) {
            //  NOTE: Uncomment the below line to allow tooltips above the bars
            // this.barToolTipOptions();
        }

        //  Include both the option value labels and toolstips
        if (comp.data && comp.data.showLabels === true && comp.data.enableTooltips === true && comp.isStacked === false) {
            //  NOTE: Uncomment the below line to allow tooltips above the bars
            // this.barLabelAndToolTipOptions();
        }

        if (comp.data && comp.data.lines) {
            const projected = _.find(comp.data.lines, ['lines[0].css', 'projected']);
            if (projected) {
                this.adjustForProjected();
            }
        }

        if (comp.isStacked) {
            comp.opts.segmentBarMode = 'stacked';
        }

        //  Determine which formatter to use for the Y-axis
        switch (_.get(this.data.lines, '[0].lines[0].format', '')) {
        case 'percent':
            this.opts.yAxisCustomize = Monte.tools.invokeMany(
                (axis) => axis.tickFormat(d3.format('.0%')),
                Monte.axisNoTicks
            );
            break;
        case 'average/int':
            this.opts.yAxisCustomize = Monte.tools.invokeMany(
                (axis) => axis.tickFormat((d) =>{
                  return formatAbbreviation(d,2);
                }),
                Monte.axisNoTicks
            );
            break;
        case 'date':
            this.opts.yAxisCustomize = Monte.tools.invokeMany(
                (axis) => axis.tickFormat(d3.format('.2d')),
                Monte.axisNoTicks
            );
            break;
        case 'currency':
            this.opts.yAxisCustomize = Monte.tools.invokeMany(
                (axis) => axis.tickFormat((d) => {
                    return '$' + formatAbbreviation(d, 2);
                }),
                Monte.axisNoTicks
            );
            break;
        default:
        }

        this.chart = new Monte.SegmentBarChart(this.compEl.select('.chart-wrap').node(), this.opts)
            .on('boundsUpdated', function() {
                if (comp.data && comp.data.enableTooltips === true) {
                    comp.buildOverlay(comp.prepData(comp.data.lines), this, comp);
                }
            })
            .data(this.prepData(this.data.lines))
            .checkSize();
    }

    buildOverlay(data, chart, comp) {
        const self = this;
        const tooltipMargin = 7;
        const textSize = data[0].values.length > 5 ? 8 : 10;
        const circleR = data[0].values.length > 5 ? textSize / 2.0 : textSize / 1.5 ;
        const barWidth = chart.x.bandwidth();

        const maxValues = [];
        _.forEach(data, function(d) {
            const maxValue = _.maxBy(d.values, (l) => {
                return (_.isNumber(l.value) === true) ? l.value : 0;
            });
            maxValues.push(maxValue);
        });

        //  NOTE: Uncomment the below lines to allow tooltips above the bars
        // const maxValue = _.maxBy(maxValues, (v) => {
        //     return (_.isNumber(v.value) === true) ? v.value : 0;
        // });

        const getTranslate = function(element) {
            const transform = element.getAttribute('transform');
            return transform.substring(transform.indexOf('(') + 1, transform.indexOf(')')).split(',')
                .map((cur) => parseFloat(cur));
        };

        const highlightGroup = chart.overlay.selectAll('g.highlight-group').data(data);

        const highlightGroupEnter = highlightGroup
            .enter()
            .append('g')
            .classed('highlight-group', true)
            .attr('opacity', '0');

        highlightGroup
            .attr('transform', function(d) {
                const xVal = d.label;
                return 'translate(' + chart.getScaledProp('x', xVal) + ',' + 0 + ')';
            });

        const tooltipGroup = highlightGroupEnter
            .append('g')
            .classed('tooltip-group', true);

        const allDataPointGroup = tooltipGroup
            .append('g')
            .classed('all-datapoint-group', true)
            .attr('transition', function() {
                return 'translate(0,' + textSize + ')';
            });

        const dataPointGroup = allDataPointGroup.selectAll('g.datapoint-group').data(function(d) {
            if (comp.isStacked === true) {
                return d.values;
            }
            else {
                return _.reverse(d.values);
            }
        })
            .enter()
            .filter(function(d) {
                return d.value !== undefined;
            })
            .append('g')
            .classed('datapoint-group', true)
            .sort(function(a, b) {
                return a.y > b.y ? -1 : 1;
            })
            .attr('transform', function(d, i, nodes) {
                const transY = nodes[i - 1] ? getTranslate(nodes[i - 1])[1] + textSize + 9 : textSize + 8;
                return 'translate(0,' + transY + ')';
            });

        dataPointGroup
            .append('text')
            .text(function(value) {
                if (value.format === 'percentage' || value.format === 'percent') {
                    return reformatPercent(value.value * 100) + '%';
                }
                return formatShortNum(value.value, 1) + shortNumSymbol(value.value);
            })
            .attr('x', (textSize + 12))
            .attr('y', -3)
            .style('font-size', textSize)
            .style('fill', 'white');

        dataPointGroup
            .filter(function(d) {
                return d;
            })
            .append('circle')
            .attr('r', circleR)
            .attr('cx', circleR + 5)
            .attr('cy', -circleR)
            .attr('stroke-width', '2px')
            .style('stroke', 'rgba(255, 255, 255, .3)')
            .attr('class', (d) => d.css);

        tooltipGroup
            .insert('rect', 'g')
            .attr('width', function() {
                return this.parentElement.getBBox().width + 2 * tooltipMargin;
            })
            .attr('height', function() {
                return this.parentElement.getBBox().height + 2 * tooltipMargin;
            })
            .attr('rx', circleR)
            .attr('ry', circleR)
            .style('fill', '#494949');

        const lineHighlightGroup = highlightGroupEnter
            .append('g')
            .classed('line-group', true);

        //  Draw the target to trigger the tooltip's appearance
        lineHighlightGroup
            .append('line')
            .classed('highlight-target', true)
            .attr('x1', (barWidth / 2))
            .attr('x2', (barWidth / 2))
            .attr('y1', '0')
            .attr('y2', chart.height)
            .attr('opacity', '0')
            .style('stroke-width', ((barWidth + 2) + 'px'))
            .style('stroke', 'black')
            .on('mouseover', function(d) {
                chart.overlay.selectAll('.highlight-group').filter(function(data) {
                    return _.find(data, (val) => val) === _.find(d, (val) => val);
                }).transition().duration(300).attr('opacity', '1');
                chart.support.selectAll('.highlight-group').filter(function(data) {
                    return _.find(data, (val) => val) === _.find(d, (val) => val);
                }).transition().duration(300).attr('opacity', '1');
            })
            .on('mouseout', function(d) {
                if (!self.showValues) {
                    chart.overlay.selectAll('.highlight-group').filter(function(data) {
                        return _.find(data, (val) => val) === _.find(d, (val) => val);
                    }).transition().duration(300).attr('opacity', '0');
                    chart.support.selectAll('.highlight-group').filter(function(data) {
                        return _.find(data, (val) => val) === _.find(d, (val) => val);
                    }).transition().duration(300).attr('opacity', '0');
                }
            });

        //  Position the tooltip
        tooltipGroup
            .attr('transform', function(d, index) {
                //  NOTE: Uncomment the below line to allow tooltips above the bars
                // if (comp.opts.segmentBarMode === 'stacked') {

                let xTrans = (this.getBBox().width * -1) - 7;

                if (index === 0) {
                    xTrans = chart.x.bandwidth() + 7;
                }

                const yTrans = (this.parentElement.getBBox().height / 2) - (this.getBBox().height / 2);

                return 'translate(' + xTrans + ',' + yTrans + ')';

                //  NOTE: Uncomment the below lines to allow tooltips above the bars
                // }
                // else {
                //     const xTrans = ((this.getBBox().width / -2) + (barWidth / 2));
                //     const groupMaxValue = _.maxBy(d.values, (v) => {
                //         return (_.isNumber(v.value) === true) ? v.value : 0;
                //     });
                //     const ratioOfMaxNumber = Math.max(Math.min((groupMaxValue.value / maxValue.value), 1), 0);
                //     let yTrans = (((1 - ratioOfMaxNumber) * (this.parentElement.getBBox().height)) - this.getBBox().height - 7);

                //     if (comp.data.showLabels === true && comp.data.enableTooltips === true) {
                //         yTrans -= 16;
                //     }

                //     return 'translate(' + xTrans + ',' + yTrans + ')';
                // }
            });

        //  Draw the pointer (triangle) element of the tooltip
        tooltipGroup
            .append('path')
            .attr('d', function(d, index) {
                //  NOTE: Uncomment the below line to allow tooltips above the bars
                // if (comp.opts.segmentBarMode === 'stacked') {
                let baseX = this.parentElement.getBBox().width;
                let tipX = 5;

                if (index === 0) {
                    baseX = 0;
                    tipX = -5;
                }

                const height = 10;
                const startY = this.parentElement.getBBox().height / 2 - height / 2;
                const midY = this.parentElement.getBBox().height / 2;
                const endY = this.parentElement.getBBox().height / 2 + height / 2;

                return 'M ' + baseX + ' ' + startY + ' L ' + (baseX + tipX) + ' ' + midY + ' L ' + baseX + ' ' + endY;

                //  NOTE: Uncomment the below lines to allow tooltips above the bars
                // }
                // else {
                //     const baseY = this.parentElement.getBBox().height;
                //     const tipY = 5;
                //     const width = 10;
                //     const startX = this.parentElement.getBBox().width / 2 - width / 2;
                //     const midX = this.parentElement.getBBox().width / 2;
                //     const endX = this.parentElement.getBBox().width / 2 + width / 2;

                //     return 'M ' + startX + ' ' + baseY + ' L ' + midX + ' ' + (baseY + tipY) + ' L ' + endX + ' ' + baseY;
                // }
            })
            .style('fill', '#494949');
    }

    prepData(lines) {
        const out = [];

        lines.forEach((d) => {
            if (d) {
                out.push({
                    id: d.lines[0].axisLabel,
                    label: d.lines[0].axisLabel,
                    values: formatNumbers(filterNumbers(d.lines)),
                });
            }
        });

        return out;
    }

    checkSize() {
        if (this.chart) {
            this.chart.checkSize();
        }
    }
}

function filterNumbers(numbers) {
    const out = [];

    numbers.forEach((n) => {
        if (n.number > 0) {
            out.push(n);
        }
    });

    return out;
}

function formatNumbers(numbers) {
    const out = [];

    numbers.forEach((d, i) => {
        out.push({
            value: d.number,
            label: `${getLabel(d)}`,
            type: d.label,
            css: `segment-${i}`,
            cssGroup: d.css,
            format: d.format,
        });
    });

    return out;
}

function getLabel(number) {
    if (number && number.percentOfTotal) {
        return `${number.number} / ${percentFormat(number.percentOfTotal)}`;
    }
    return number.label;
}
