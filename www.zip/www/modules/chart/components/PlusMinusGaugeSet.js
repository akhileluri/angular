// This file was generated from the chart scaffold
// Copyright 2016
/* global d3 _ */
import {Component, Input, Output, EventEmitter, ElementRef, ViewEncapsulation, ViewChildren} from '@angular/core';
import template from './PlusMinusGaugeSet.html';
import styles from './PlusMinusGaugeSet.scss';
import PlusMinusGauge from './PlusMinusGauge';
import {resolveLegendName} from '../util/legend';

@Component({
    selector: 'plus-minus-gauge-set',
    template: template,
    styles: [styles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <plus-minus-gauge-set name="PlusMinusGaugeSet" (change)="onChange($event)"></plus-minus-gauge-set>
 */
export default class PlusMinusGaugeSet {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'PlusMinusGaugeSet';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();

    @Input() data = [];
    @Input() chartData = {};
    @Input() dataConfig = {};
    @Input() chartSize = '';
    @Input() footerPresent = false;

    @ViewChildren(PlusMinusGauge)
    gauges = this.gauges;

    constructor(chartsetEl: ElementRef) {
        this.chartset = d3.select(chartsetEl.nativeElement);
    }

    ngAfterViewInit() {
        const comp = this;

        //  Delay is required to allow the UI to paint and provide correct dimensions
        _.delay(function(comp) {
            comp.renderChart();
        }, 10, comp);
    }

    renderChart() {
        // const comp = this;

        // const $container = $($(this.chartset).closest('chart-selector'));

        // const containerWidth = $container.width();
        // const containerHeight = $container.height();
        this.gauges.forEach((gauge) => {
            gauge.renderChart();
        });
    }

    checkSize() {
        if (this.chartset) {
            this.chartset.selectAll('.plus-minus-gauge').each(function() {
                const gaugeInstance = d3.select(this);

                if (gaugeInstance && gaugeInstance.checkSize) {
                    gaugeInstance.checkSize();
                }
            });
        }
    }

    update() {
        if (this.chartset) {
            this.chartset.selectAll('.plus-minus-gauge').each(function() {
                const gaugeInstance = d3.select(this);

                if (gaugeInstance && gaugeInstance.checkSize) {
                    gaugeInstance.update();
                }
            });
        }
    }

    getLabel(d) {
        let label = '';

        if (d.numbers && d.numbers.length > 1 && d.numbers[1].health) {
            label = d.numbers[1].label;
        }
        label = resolveLegendName(label, this.dataConfig.dataItemsMap);

        return label;
    }

    getValueClass(d) {
        let css = 'no-health';

        if (d.numbers && d.numbers.length > 1 && d.numbers[1].health) {
            css = d.numbers[1].health;
        }

        return css;
    }

    formatDatum(d) {
        if (d.numbers && d.numbers.length > 1) {
            d.number = parseFloat(d.numbers[1].number).toFixed(2);
            return d.numbers[1];
        }
        return null;
    }
}
