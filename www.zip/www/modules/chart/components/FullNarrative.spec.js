// This file was generated from the chart scaffold
// Copyright 2017

import {Component, Injector} from '@angular/core';
import FullNarrative from './FullNarrative';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [FullNarrative],
    template: ''
})
class TestComponent {}

describe('chart/FullNarrative.js', () => {

    beforeEach(() => {
        addProviders([FullNarrative]);
    });

    it('should return component name', inject([FullNarrative], (fullNarrative:FullNarrative) => {
        expect(fullNarrative.name).toBe('FullNarrative');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<full-narrative></full-narrative>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('full-narrative h1').innerText).toBe('FullNarrative');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<full-narrative name="TEST"></full-narrative>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('full-narrative h1').innerText).toBe('TEST');
            });
    })));

});
