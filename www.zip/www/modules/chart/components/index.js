export const CHART_COMPONENTS = [];

export Donuts from './Donuts';
CHART_COMPONENTS.push(exports.Donuts);

export VerticalBarChart from './VerticalBarChart';
CHART_COMPONENTS.push(exports.VerticalBarChart);

export VerticalSegmentBarChart from './VerticalSegmentBarChart';
CHART_COMPONENTS.push(exports.VerticalSegmentBarChart);

export VerticalBarLineChart from './VerticalBarLineChart';
CHART_COMPONENTS.push(exports.VerticalBarLineChart);

export HorizontalBarChart from './HorizontalBarChart';
CHART_COMPONENTS.push(exports.HorizontalBarChart);

export FullLineChart from './FullLineChart';
CHART_COMPONENTS.push(exports.FullLineChart);

export LineChart from './LineChart';
CHART_COMPONENTS.push(exports.LineChart);

export SegmentChart from './SegmentChart';
CHART_COMPONENTS.push(exports.SegmentChart);

export Sparkline from './Sparkline';
CHART_COMPONENTS.push(exports.Sparkline);

export DonutBarPair from './DonutBarPair';
CHART_COMPONENTS.push(exports.DonutBarPair);

export ChartSelector from './ChartSelector';
CHART_COMPONENTS.push(exports.ChartSelector);

export FullSegmentsChart from './FullSegmentsChart';
CHART_COMPONENTS.push(exports.FullSegmentsChart);

export PlusMinusGauge from './PlusMinusGauge';
CHART_COMPONENTS.push(exports.PlusMinusGauge);

export PlusMinusGaugeSet from './PlusMinusGaugeSet';
CHART_COMPONENTS.push(exports.PlusMinusGaugeSet);

export SegmentDonut from './SegmentDonut';
CHART_COMPONENTS.push(exports.SegmentDonut);

export DonutStackedBarPair from './DonutStackedBarPair';
CHART_COMPONENTS.push(exports.DonutStackedBarPair);

export TornadoBarChart from './TornadoBarChart';
CHART_COMPONENTS.push(exports.TornadoBarChart);

export DonutMetric from './DonutMetric';
CHART_COMPONENTS.push(exports.DonutMetric);

export Choropleth from './Choropleth';
CHART_COMPONENTS.push(exports.Choropleth);

export FullNarrative from './FullNarrative';
CHART_COMPONENTS.push(exports.FullNarrative);

export ComparisonBarChart from './ComparisonBarChart';
CHART_COMPONENTS.push(exports.ComparisonBarChart);

export ImageChart from './ImageChart';
CHART_COMPONENTS.push(exports.ImageChart);

export GaugeBarPair from './GaugeBarPair';
CHART_COMPONENTS.push(exports.GaugeBarPair);

