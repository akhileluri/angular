// This file was generated from the chart scaffold
// Copyright 2016
/* global d3, _ */
import {Component, Input, Output, EventEmitter, ElementRef, ViewEncapsulation} from '@angular/core';
import * as Monte from 'monte';
import template from './TornadoBarChart.html';
import styles from './TornadoBarChart.scss';
import {reformatPercent} from '../util/format';
import {formatMetdataNumber as formatNumber} from '../util/numberAbbrv';
import {addFlag, updateFlag} from '../extension/edgeFlag';

const MODE_DIFFERENCE = 'difference';

@Component({
    selector: 'tornado-bar-chart',
    template: template,
    styles: [styles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <tornado-bar-chart name="TornadoBarChart" (change)="onChange($event)"></tornado-bar-chart>
 */
export default class TornadoBarChart {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'TornadoBarChart';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();

    @Input() data = {};
    @Input() mode = '';
    @Input() difference = null;
    @Input() callouts = null;
    @Input() chartSize = '';
    @Input() footerPresent = false;

    opts = {
        boundingWidth: 265,
        boundingHeight: 88,

        // Follows D3 Margin Convention: https://bl.ocks.org/mbostock/3019563
        margin: {
            top: 20,
            bottom: 0,
            left: 45,
            right: 50,
        },

        includeLabels: true,
        suppressAxes: true,
        resize: new Monte.HorizontalResizer(),

        extensions: [
            new Monte.ExtHorizontalBarBg({
                enlarge: 0,
                maxValue: 0,
            }),
        ],

        barCss: function(d) {
            return d.health || 'no-health';
        },

        labelProp: 'label',
        labelX: -5,

        xProp: 'number',
        xDomainCustomize: function(extent) {
            const absMin = Math.abs(extent[0]);
            const absMax = Math.abs(extent[1]);
            const extreme = absMax > absMin ? absMax : absMin;
            const roundedEx = round10(extreme);

            return [-roundedEx, roundedEx];
        },

        yProp: 'label',
        yScale: function() {
            return d3.scaleBand().paddingInner(0.5).paddingOuter(0).round(true);
        },

        transition: {
            duration: 0,
        },
    };

    constructor(chartEl: ElementRef) {
        this.chartEl = d3.select(chartEl.nativeElement).node();
    }

    ngOnDestroy() {
        if (this.chart) {
            this.chart.destroy();
        }
    }

    ngOnChanges() {
        if (this.data && this.chart) {
            this.chart.updateData(this.prepData(this.data));
        }
    }

    ngAfterViewInit() {
        const comp = this;

        //  Delay is required to allow the UI to paint and provide correct dimensions
        _.delay(function(comp) {
            comp.renderChart();
        }, 10, comp);
    }

    renderChart() {
        const comp = this;

        // const $container = $($(this.chartEl.node()).closest('chart-selector'));
        const $container = $($(this.chartEl).closest('chart-selector'));

        //  Set final dimensions based on the available space created by the flexbox layout
        this.opts.boundingWidth = $container.width();
        this.opts.boundingHeight = $container.height();

        if (comp.mode === MODE_DIFFERENCE) {
            this.opts.boundingHeight = 90;
            this.opts.margin.bottom = 0;
        }

        this.chart = new Monte.HorizontalBarChart(this.chartEl, this.opts);
        this.chart.differenceNumber = _.get(this, 'difference.numbers[0]');
        this.chart.callouts = this.data.callouts;

        this.chart.on('updated', function() {
            // Draw a bold overlay 0 line (overlaps the normal y domain, but on a higher layer)
            const zeroData = [0];

            const zeroLine = this.overlay.selectAll('.bar-ref-zero').data(zeroData);
            zeroLine.enter().append('line')
                .attr('class', 'bar-ref-zero')
                .merge(zeroLine)
                  .attr('x1', (d) => this.x(d))
                  .attr('x2', (d) => this.x(d))
                  .attr('y1', () => -3)
                  .attr('y2', () => this.height);

            const zeroLabel = this.overlay.selectAll('.label-zero').data(zeroData);
            zeroLabel.enter().append('text')
                .attr('class', 'label-zero')
                .attr('dy', '-0.35em')
                .attr('text-anchor', comp.mode === MODE_DIFFERENCE ? 'start' : 'middle')
                .merge(zeroLabel)
                  .attr('transform', (d) => `translate(${this.x(d)}, -5)`)
                  .text((d) => {
                      if (comp.mode === MODE_DIFFERENCE) {
                          return formatNumber(this.differenceNumber);
                      }
                      else {
                          return d;
                      }
                  });

            // Diff label & callout flags
            if (comp.mode === MODE_DIFFERENCE) {
                const diffLabel = this.overlay.selectAll('.label-diff').data([this.differenceNumber]);
                diffLabel.enter().append('text')
                    .attr('class', 'label-diff')
                    .attr('dy', '-0.35em')
                    .attr('text-anchor', 'end')
                    .merge(diffLabel)
                      .attr('transform', `translate(${this.x(0) - 2}, -5)`)
                      .text((d) => d.label);

                // Add callout
                if (this.callouts) {
                    const barData = this.data();
                    const flags = this.overlay.selectAll('.flag-contain-grp').data(this.callouts);

                    flags.enter().append('g')
                      .attr('class', 'flag-contain-grp')
                      .each((d, i, nodes) => {
                          const grp = d3.select(nodes[i]);

                          if (d) { // Add annotation flag
                              const bd = _.find(barData, (bd) => bd.label === d.axisLabel);
                              const lbl = d.label || formatNumber(d);
                              const x = this.getScaledProp('x', bd);
                              const y = this.height + 2;
                              addFlag.call(this, grp, x, y, lbl, { dir: 's' });
                          }
                      });

                    flags.each((d, i, nodes) => {
                        const grp = d3.select(nodes[i]);

                        if (d) { // Update annotation flag
                            const bd = _.find(barData, (bd) => bd.label === d.axisLabel);
                            const lbl = d.label || formatNumber(d);
                            const x = this.getScaledProp('x', bd);
                            const y = this.height + 2;
                            updateFlag.call(this, grp, x, y, lbl, { dir: 's' });
                        }
                    });

                    flags.exit().remove();
                }
            }

            // Far right labels
            const endLabels = this.overlay.selectAll('.value-label').data(this.data());
            endLabels.enter().append('text')
                .merge(endLabels)
                  .attr('class', (d) => `value-label ${d.health}`)
                  .attr('x', this.width + this.option('margin.right'))
                  .attr('y', (d) => this.getScaledProp('y', d))
                  .attr('dx', -15)
                  .attr('dy', '.70em')
                  .text('').append('tspan')
                .text((d) => posPlus(this.getProp('x', d)) + Math.abs(reformatPercent(this.getProp('x', d), 0)));

            // Far right %
            const percent = this.overlay.selectAll('.symbol-superscript').data(this.data());
            percent.enter().append('text')
             // .merge(endLabels)
                .attr('class', (d) => `symbol-superscript ${d.health}`)
                .attr('x', this.width + this.option('margin.right'))
                .attr('y', (d) => this.getScaledProp('y', d))
                .attr('dx', -15)
                .attr('dy', '.70em')
                .text('%');
        })
        .data(this.prepData(this.data));
    }

    prepData(data) {
        const out = [];

        data[0].numbers.forEach((d) => {
            if (d.number !== null && d.number !== undefined) {
                const newD = _.clone(d);

                if (newD.format === 'percentage' || newD.format === 'percent') {
                    newD.number *= 100;
                }

                out.push(newD);
            }
        });

        return out;
    }

    checkSize() {
        if (this.chart) {
            this.chart.checkSize();
        }
    }
}

// Adds a plus sign to positive numbers (or strings that can be processed like 7% becomes +7%).
function posPlus(val) {
    const v = parseFloat(val, 10);

    if (v > 0.5) {
        return '+';
    }
    else if (v < -0.5) {
        return '-';
    }
    else {
        return '';
    }
}

function round10(value) {
    return Math.ceil(value / 10) * 10;
}
