// This file was generated from the chart scaffold
// Copyright 2018

import {Component, Injector} from '@angular/core';
import ComparisonBarChart from './ComparisonBarChart';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [ComparisonBarChart],
    template: ''
})
class TestComponent {}

describe('chart/ComparisonBarChart.js', () => {

    beforeEach(() => {
        addProviders([ComparisonBarChart]);
    });

    it('should return component name', inject([ComparisonBarChart], (comparisonBarChart:ComparisonBarChart) => {
        expect(comparisonBarChart.name).toBe('ComparisonBarChart');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<comparison-bar-chart></comparison-bar-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('comparison-bar-chart h1').innerText).toBe('ComparisonBarChart');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<comparison-bar-chart name="TEST"></comparison-bar-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('comparison-bar-chart h1').innerText).toBe('TEST');
            });
    })));

});
