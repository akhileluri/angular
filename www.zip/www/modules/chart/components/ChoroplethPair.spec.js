// This file was generated from the chart scaffold
// Copyright 2018

import {Component, Injector} from '@angular/core';
import ChoroplethPair from './ChoroplethPair';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [ChoroplethPair],
    template: ''
})
class TestComponent {}

describe('chart/ChoroplethPair.js', () => {

    beforeEach(() => {
        addProviders([ChoroplethPair]);
    });

    it('should return component name', inject([ChoroplethPair], (choroplethPair:ChoroplethPair) => {
        expect(choroplethPair.name).toBe('ChoroplethPair');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<choropleth-pair></choropleth-pair>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('choropleth-pair h1').innerText).toBe('ChoroplethPair');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<choropleth-pair name="TEST"></choropleth-pair>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('choropleth-pair h1').innerText).toBe('TEST');
            });
    })));

});
