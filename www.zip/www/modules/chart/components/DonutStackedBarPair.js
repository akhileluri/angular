// This file was generated from the chart scaffold
// Copyright 2016
/* global d3, _ */
import {Component, Input, Output, EventEmitter, ElementRef, ViewEncapsulation} from '@angular/core';
import * as Monte from 'monte';
import template from './DonutStackedBarPair.html';
import styles from './DonutStackedBarPair.scss';
import {formatShortNum, shortNumSymbol} from '../util/numberAbbrv';
import {reformatPercent} from '../util/format';
import {getHealthCss} from '../util/color';


@Component({
    selector: 'donut-stacked-bar-pair',
    template: template,
    styles: [styles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <donut-stacked-bar-pair name="DonutStackedBarPair" (change)="onChange($event)"></donut-stacked-bar-pair>
 */
export default class DonutStackedBarPair {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'DonutStackedBarPair';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();

    @Input() data = {};
    @Input() chartSize = '';

    @Input() footerPresent = false;

    donutEl: HTMLElement;
    barEl: HTMLElement;

    donutOpts = {
        boundingWidth: 140,
        boundingHeight: 140,
        innerRadius: 55,
        margin: { top: 0, right: 0, left: 0, bottom: 0 },
        extensions: [
            new Monte.ExtLabel({
                binding: ['updated'],
                anchor: 'middle',
                labelCss: 'value-label',
                text: function() {
                    let symbol = shortNumSymbol(this.chart.summaryData.number);
                    if (this.chart.summaryData.format === 'percentage' || this.chart.summaryData.format === 'percent') {
                        symbol = '%';
                        return reformatPercent(this.chart.summaryData.number * 100) + '<tspan class="superscript" textLength="20" dy="-20" text-anchor: "middle">' + symbol + '</tspan>';
                    }
                    return formatShortNum(this.chart.summaryData.number, 1) + '<tspan class="superscript" textLength="20" dy="-20" text-anchor: "middle">' + symbol + '</tspan>';
                },
                maxWidth: 108, // Slightly smaller than the inner diameter
            }),
            new Monte.ExtPolarLine({
                layer: 'overlay',
                angle: function() {
                    return this.chart.budgetAngle;
                },
                lineCss: 'budget-line',
                innerRadius: 56,
                outerRadius: 70,
            }),
        ],
    };

    barOpts = {
        css: 'no-domain-lines',
        boundingWidth: 26,
        boundingHeight: 140,
        suppressAxes: true,
        margin: {
            top: 10, bottom: 10, left: 10, right: 10,
        },

        labelProp: 'label',
        labelX: function(d) {
            return this._barWidthStacked(d) + 3;
        },
        labelY: function(d, i, nodes, allNodes) {
            return this._barYInnerStacked(d, i, nodes, allNodes) + this._barHeightStacked(d) / 2;
        },
        labelYAdjust: '0.35em',
        xInnerProp: 'label',
        includeLabels: true,
    };

    constructor(compEl: ElementRef) {
        this.contentSel = d3.select(compEl.nativeElement);
    }

    ngOnDestroy() {
        if (this.donutLarge) {
            this.donutLarge.destroy();
        }

        if (this.donutSmall) {
            this.donutSmall.destroy();
        }
    }

    ngOnChanges() {
        if (this.data) {
            if (this.donut) {
                this.donut.summaryData = _.get(this, 'data[0].numbers[0]', '');
                this.donut.updateData(getDonutVal(this.data[0].numbers[0]));
            }

            if (this.bar) {
                this.bar.updateData(prepData(this.data[1]));
            }
        }
    }

    ngAfterViewInit() {
        const comp = this;

        //  Delay is required to allow the UI to paint and provide correct dimensions
        _.delay(function(comp) {
            comp.renderChart();
        }, 10, comp);
    }

    renderChart() {
        const comp = this;

        const $container = $($(this.contentSel.node()).closest('chart-selector'));

        const containerWidth = $container.width();
        const containerHeight = $container.height();

        this.donutOpts.boundingWidth = (containerWidth * 0.6);
        this.donutOpts.boundingHeight = containerHeight;

        this.donutOpts.outerRadius = (Math.min(this.donutOpts.boundingWidth, this.donutOpts.boundingHeight) / 2);
        this.donutOpts.innerRadius = this.donutOpts.outerRadius - 20;

        this.donutOpts.extensions[0].opts.maxWidth = ((this.donutOpts.innerRadius * 2) - 20);
        this.donutOpts.extensions[1].opts.outerRadius = this.donutOpts.outerRadius;
        this.donutOpts.extensions[1].opts.innerRadius = this.donutOpts.innerRadius;

        this.barOpts.boundingWidth = (containerWidth * 0.4);
        this.barOpts.boundingHeight = containerHeight;

        this.donutEl = this.contentSel.select('.donut-wrap').node();
        this.barEl = this.contentSel.select('.bar-wrap').node();

        if (!this.donut) {
            const initVal = getDonutVal(this.data[0].numbers[0]);

            this.donut = new Monte.WedgeChart(this.donutEl, this.donutOpts)
              .call(function() {
                  // Bind summary data so it is accessible by the label extensions
                  this.summaryData = _.get(comp, 'data[0].numbers[0]', '');
              })
              .on('rendered', function() {
                  this.overlay.append('text')
                    .attr('class', 'date-label')
                    .attr('dy', '0.35em')
                    .attr('text-anchor', 'middle')
                    .attr('transform', 'translate(0, 30)')
                    .text('Total');
              })
              .on('updated', function() {
                  this.overlay.select('.value-label').text(this.wedgeValue() + '%');
                  const budgetVal = comp.data[0].numbers[0].budget;

                  if (budgetVal) {
                      const fData = this.pie([{ value: budgetVal }, { value: 1 - budgetVal }]);
                      const angle = fData[0].endAngle;
                      this.budgetAngle = angle;
                  }
                  this.classed(getHealthCss(comp.data[0].numbers[0].health), true);
              })
              .data(initVal);
        }

        if (!this.bar) {
            this.bar = new Monte.SegmentBarChart(this.barEl, this.barOpts)
              .data(prepData(this.data[1]));
        }
    }

    checkSize() {
        if (this.donut) {
            this.donut.checkSize();
        }

        if (this.bar) {
            this.bar.checkSize();
        }
    }

    update() {
        if (this.donut) {
            this.donut.update();
        }

        if (this.bar) {
            this.bar.update();
        }
    }
}

function getDonutVal(data) {
    return data.number * 100 || 0;
}

function prepData(data) {
    const out = {
        id: '',
        values: [],
    };

    data.numbers.forEach((d, i) => {
        out.values.push({
            label: d.label.substring(0, 1),
            value: d.number,
            css: `segment-${i}`,
        });
    });

    return [out];
}
