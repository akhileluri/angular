// This file was generated from the chart scaffold
// Copyright 2016

import {Component, Injector} from '@angular/core';
import TornadoBarChart from './TornadoBarChart';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [TornadoBarChart],
    template: ''
})
class TestComponent {}

describe('chart/TornadoBarChart.js', () => {

    beforeEach(() => {
        addProviders([TornadoBarChart]);
    });

    it('should return component name', inject([TornadoBarChart], (tornadoBarChart:TornadoBarChart) => {
        expect(tornadoBarChart.name).toBe('TornadoBarChart');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<tornado-bar-chart></tornado-bar-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('tornado-bar-chart h1').innerText).toBe('TornadoBarChart');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<tornado-bar-chart name="TEST"></tornado-bar-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('tornado-bar-chart h1').innerText).toBe('TEST');
            });
    })));

});
