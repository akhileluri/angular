// This file was generated from the component scaffold
// Copyright 2016
/* global d3, _ */
import { Component, Input, Output, EventEmitter, ElementRef, ViewEncapsulation } from '@angular/core';
import * as Monte from 'monte';
import template from './FullLineChart.html';
import styles from './FullLineChart.scss';
import { formatAbbreviation, formatMetdataNumber as formatNumber, formatShortNum, shortNumSymbol } from '../util/numberAbbrv';
import { leadYearFormat, reformatPercent } from '../util/format';
import { labelOverlapAvoidance } from '../extension/ExtHorizontalRef';
import { lineChartFlagUpdateCycle } from '../extension/edgeFlag';
import {resolveLegendName} from '../util/legend';

@Component({
    selector: 'full-line-chart',
    template: template,
    styles: [styles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <full-line-chart name="FullLineChart" (change)="onChange($event)"></full-line-chart>
 */
export default class FullLineChart {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name: string = 'FullLineChart';

    @Input() chartSize = '';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change: EventEmitter = new EventEmitter();
    @Input() dataConfig = null;
    @Input() data = {};
    @Input() isDetail = false;

    // Indicates is any minor lines are included in the data set.
    hasMinorLines = false;

    // State of minor line toggle.
    // TODO: Watch for value change and toggle all minor lines.
    enableMinorLines = true;

    transformedData = [];
    majorLegendItems = [];
    minorLegendItems = [];

    showValues = false;

    axisFormat = {};

    axisFormatter(n) {
        const val = _.extend({ number: n }, this.axisFormat);
        return formatNumber(val);
    }

    opts = {
        boundingWidth: 700,
        boundingHeight: 220,

        marginRightWithoutFlags: 20,

        margin: {
            top: 20,
            bottom: 30,
            left: 55,
            right: 30,
        },
        extensions: [
            new Monte.ExtHorizontalLines(),
        ],
        resize: new Monte.HorizontalResizer(),
        xAxisConstructor: d3.axisTop,

        xAxisCustomize: (axis) => {
            // Map out tick values that match the indexes of the labels. That way the Axis label
            // text can be looked up and inserted directly.
            if (this.data.xaxisLabels) {
                const tickValues = this.data.xaxisLabels.map((d, i) => i);

                axis.tickSize(5)
                    .tickValues(tickValues)
                    .tickFormat((d, i) => {
                        if (Number.isInteger(d) && this.data.xaxisLabels.map((d, i) => i).length <= 20) {
                            return this.data.xaxisLabels[d];
                        }
                        else if (Number.isInteger(d) && (i % 2 === 0)) {
                            return this.data.xaxisLabels[d];
                        }
                        return '';
                    })
                    .tickPadding(5);
            }

            return axis;
        },

        yAxisCustomize: (axis) => {
            axis.tickFormat(this.axisFormatter.bind(this))
                .ticks(5)
                .tickPadding(-20)
                .tickSize(40);
            return axis;
        },

        yDomainCustomize: (extent) => {
            return extent;
        },

        includePoints: true,
        pointSize: (d) => (d.parent.isMinor ? 15 : 64),
    };

    singleOpts = {
        css: 'no-domain-lines',
        suppressAxes: ['y'],
        lineCss: 'positive',
        pointCss: 'positive',
        boundingWidth: 230,
        boundingHeight: 165,

        includePoints: true,

        // Follows D3 Margin Convention: https://bl.ocks.org/mbostock/3019563
        margin: {
            top: 14,
            bottom: 25,
            left: 30,
            right: 30,
        },

        marginRightWithoutFlags: 20,
        flagXShift: 5,

        xAxisCustomize: Monte.tools.invokeMany(
            (axis) => {
                // Map out tick values that match the indexes of the labels. That way the Axis label
                // text can be looked up and inserted directly.
                const tickValues = this.data.xaxisLabels.map((d, i) => i);
                const tickCount = tickValues.length;
                const labelsQuantity = 5;
                function indexMap(tickCount, labelsQuantity) {
                    const initialOffset = Math.round(tickCount / labelsQuantity);
                    let min = initialOffset - 1;
                    let max = (tickCount - initialOffset);
                    let range = max - min;
                    while (range % (range / (labelsQuantity - 2)) !== 0) {
                        if (range % 2 === 0) {
                            min += 1;
                            range = max - min;
                        }
                        else {
                            max -= 1;
                            range = max - min;
                        }
                    }
                    const labelPoints = [0];
                    for (let i = min; i <= max; i++) {
                        if (i % (range / (labelsQuantity - 2)) === 0) {
                            labelPoints.push(i);
                        }
                    }
                    labelPoints.push(tickCount - 1);
                    return labelPoints;
                }
                const labelPoints = indexMap(tickCount, labelsQuantity);
                axis.tickSize(0)
                    .tickValues(tickValues)
                    .tickFormat((d, i) => {
                        if (Number.isInteger(d) && tickCount <= labelsQuantity) {
                            const v = this.data.xaxisLabels[d];
                            return leadYearFormat(v, i);
                        }
                        else if (Number.isInteger(d) && labelPoints.indexOf(i) > -1) {
                            const v = this.data.xaxisLabels[d];
                            return leadYearFormat(v, i);
                        }
                        return '';
                    })
                    .tickPadding(10);
            },
            Monte.axisNoTicks
        ),

        extensions: [
            new Monte.ExtReferenceLine({

                layer: 'support',
                data: function() {
                    const data = this.chart.data();
                    const maxNumber = { number: data.maxNumber, format: data.format };
                    const minNumber = { number: data.minNumber, format: data.format };
                    const minLinePosition = 59;
                    const maxLinePosition = 0;
                    if (data && data.length >= 1) {
                        const chart = this.chart;
                        const l = chart.option('margin.left');
                        const max = {
                            x1: -l + 5,
                            x2: chart.width,
                            y1: maxLinePosition,
                            y2: maxLinePosition,
                            text: formatNumber(maxNumber),
                        };
                        const min = {
                            x1: -l + 5,
                            x2: chart.width,
                            y1: minLinePosition,
                            y2: minLinePosition,
                            text: formatNumber(minNumber),
                        };

                        return [min, max];
                    }
                    else {
                        return [];
                    }
                },
            }),
        ],

        resize: new Monte.HorizontalResizer(),
    };

    constructor(chartEl: ElementRef) {
        this.chartWrap = d3.select(chartEl.nativeElement);
    }

    ngOnDestroy() {
        if (this.chart) {
            this.chart.destroy();
        }
    }

    ngOnChanges() {
        this.transformedData = this.prepData(this.data);

        if (this.chart) {
            this.chart.option('refLines', this.transformedData.refLines);
            this.chart.updateData(this.transformedData.lines);
        }
    }

    singleWideOptions() {
        this.opts = this.singleOpts;
    }

    ngAfterViewInit() {
        const comp = this;

        //  Delay is required to allow the UI to paint and provide correct dimensions
        _.delay(function(comp) {
            comp.renderChart();
            comp.checkSize();
        }, 10, comp);
    }

    renderChart() {
        const comp = this;

        const $container = $($(this.chartWrap.node()).closest('chart-selector'));

        //  Set final dimensions based on the available space created by the flexbox layout
        this.opts.boundingWidth = $container.width();
        this.opts.boundingHeight = $container.height();

        //  Determine which formatter to use for the Y-axis
        switch (_.get(this.data, 'lines[0].lines[0].format', '')) {
        case 'percent':
            this.singleOpts.yAxisCustomize = this.opts.yAxisCustomize = Monte.tools.invokeMany(
                (axis) => axis.tickFormat(d3.format('.0%')),
                Monte.axisNoTicks
            );
            break;
        case 'average/int':
            this.singleOpts.yAxisCustomize = this.opts.yAxisCustomize = Monte.tools.invokeMany(
                (axis) => axis.tickFormat(d3.format('.2s')),
                Monte.axisNoTicks
            );
            break;
        case 'date':
            this.singleOpts.yAxisCustomize = this.opts.yAxisCustomize = Monte.tools.invokeMany(
                (axis) => axis.tickFormat(d3.format('.2d')),
                Monte.axisNoTicks
            );
            break;
        case 'currency':
            this.singleOpts.yAxisCustomize = this.opts.yAxisCustomize = Monte.tools.invokeMany(
                (axis) => axis.tickFormat((d) => {
                    return '$' + formatAbbreviation(d, 2);
                }),
                Monte.axisNoTicks
            );
            break;
        default:
        }

        if (this.chartSize === 'single') {
            this.singleWideOptions();
            this.opts.boundingHeight = $container.height();
            // const comp = this;
            this.chartEl = this.chartWrap.select('.full-line-chart').node();
            this.chart = new Monte.LineChart(this.chartEl, this.opts);

            this.chart.on('updated', function() {
                // Add flags for all suporting lines (i.e. exclude the top/primary line)
                const flagData = this.data().slice(0, -1);
                lineChartFlagUpdateCycle(this, flagData);
            })
                // .on('extension', function(extEv) {
                .on('extension', function() {
                    labelOverlapAvoidance.apply(this, arguments);
                })
                .data(this.transformedData.lines)
                .checkSize();
        }
        else {
            this.opts.boundingHeight = $container.height() - 60; // 40
            this.chartEl = this.chartWrap.select('.full-line-chart').node();
            this.chart = new Monte.LineChart(this.chartEl, this.opts)
                .call(function() {
                    this.option('refLines', comp.transformedData.refLines);
                })
                .on('updated', function() {
                    this.support.selectAll('.y-axis.axis text')
                        .attr('dy', '-.8em');

                    // Draw reference lines and flags
                    const refLines = this.support.selectAll('.ref-line').data(this.option('refLines'));

                    refLines.enter().append('path')
                        .classed('ref-line', true)
                        .merge(refLines)
                        .attr('d', (d) => this.line(d.values)); // Use the line chart's line generator to create the path.

                    refLines.exit().remove();

                    // Add flags for all suporting lines (i.e. exclude the top/primary line)
                    const flagData = this.option('refLines');
                    lineChartFlagUpdateCycle(this, flagData);
                })
                .on('axisRendered', function(scaleName, axis, t) {
                    this.support.select('.x-axis.axis')
                        .attr('transform', `translate(0, ${this.height + this.option('margin.bottom') - 5})`);

                    this.support.select('.x-axis.axis .domain')
                        .transition(t)
                        .attr('d', `M -40,0V0.5H${this.width + this.option('margin.right')}V0`);
                })
                .on('boundsUpdated', function() {
                    comp.buildOverlay(this.displayData, this, comp);
                })
                .data(this.transformedData.lines)
                .checkSize();
        }
    }

    buildOverlay(data, chart) {
        const self = this;
        const overlayData = [];
        const tooltipMargin = 7;
        const textSize = 10;
        const circleR = textSize / 1.5;

        let maxLength = _.maxBy(data, (d) => {
            return d.values.length;
        });
        maxLength = _.get(maxLength, 'values.length', 0);

        const normalizedData = [];
        for (let i = 0; i < data.length; i++) {
            const normalizedLine = [];
            for (let j = 0; j < maxLength; j++) {
                const val = data[i].values[j];
                if (val) {
                    normalizedLine[val.x] = val;
                    if (val.x !== j) {
                        normalizedLine[j] = { x: j };
                    }
                }
                else {
                    if (!normalizedLine[j]) {
                        normalizedLine[j] = { x: j };
                    }
                }
            }
            normalizedData.push(normalizedLine);
        }

        const getTranslate = function(element) {
            const transform = element.getAttribute('transform');
            return transform.substring(transform.indexOf('(') + 1, transform.indexOf(')')).split(',')
                .map((cur) => parseFloat(cur));
        };


        for (let i = 0; i < maxLength; i++) {
            const arr = [];
            for (let j = 0; j < normalizedData.length; j++) {
                const value = normalizedData[j][i];
                arr.push(value);
            }
            overlayData.push(arr);
        }


        const highlightGroup = chart.overlay.selectAll('g.highlight-group').data(overlayData);
        const supportGroup = chart.support.selectAll('g.highlight-group').data(overlayData);

        const highlightGroupEnter = highlightGroup
            .enter()
            .append('g')
            .classed('highlight-group', true)
            .attr('opacity', '0');

        const supportGroupEnter = supportGroup
            .enter()
            .append('g')
            .classed('highlight-group', true)
            .attr('opacity', '0');

        highlightGroup
            .attr('transform', function(d) {
                const xVal = _.find(d, (val) => val).x;
                return 'translate(' + chart.getScaledProp('x', xVal) + ',' + 0 + ')';
            });
        supportGroup
            .attr('transform', function(d) {
                const xVal = _.find(d, (val) => val).x;
                return 'translate(' + chart.getScaledProp('x', xVal) + ',' + 0 + ')';
            });
        const circleGroup = highlightGroupEnter.selectAll('g.circle-group').data(function(d) {
            return d;
        })
            .enter()
            .append('g')
            .classed('circle-group', true);

        circleGroup
            .filter(function(d) {
                return d.parent;
            })
            .filter(function(d) {
                return !d.parent.isMinor;
            })
            .append('circle')
            .attr('r', '20')
            .attr('cy', function(d) {
                return chart.getScaledProp('y', d);
            })
            .attr('opacity', '.3')
            .style('fill', function(d) {
                return d3.select('.' + d.parent.css.split(' ').join('.')).style('stroke');
            })
            .on('mouseover', function(d) {
                chart.overlay.selectAll('.highlight-group').filter(function(data) {
                    return data[0].x === d.x;
                }).transition().duration(300).attr('opacity', '1');
                chart.support.selectAll('.highlight-group').filter(function(data) {
                    return data[0].x === d.x;
                }).transition().duration(300).attr('opacity', '1');
            })
            .on('mouseout', function(d) {
                if (!self.showValues) {
                    chart.overlay.selectAll('.highlight-group').filter(function(data) {
                        return data[0].x === d.x;
                    }).transition().duration(300).attr('opacity', '0');
                    chart.support.selectAll('.highlight-group').filter(function(data) {
                        return data[0].x === d.x;
                    }).transition().duration(300).attr('opacity', '0');
                }
            });

        const tooltipGroup = highlightGroupEnter
            .append('g')
            .classed('tooltip-group', true);

        const allDataPointGroup = tooltipGroup
            .append('g')
            .classed('all-datapoint-group', true)
            .attr('transition', function() {
                return 'translate(0,' + textSize + ')';
            });

        const dataPointGroup = allDataPointGroup.selectAll('g.datapoint-group').data(function(d) {
            return d;
        })
            .enter()
            .filter(function(d) {
                return d.y !== undefined;
            })
            .append('g')
            .classed('datapoint-group', true)
            .sort(function(a, b) {
                return a.y > b.y ? -1 : 1;
            })
            .attr('transform', function(d, i, nodes) {
                const transY = nodes[i - 1] ? getTranslate(nodes[i - 1])[1] + textSize + 10 : textSize + 9;
                return 'translate(0,' + transY + ')';
            });

        dataPointGroup
            .append('text')
            .text(function(value) {
                if (value.format === 'percentage' || value.format === 'percent') {
                    return reformatPercent(value.y * 100) + '%';
                }
                return formatShortNum(value.y, 1) + shortNumSymbol(value.number);
            })
            .attr('x', textSize + 10)
            .attr('y', -2)
            .style('font-size', textSize)
            .style('fill', 'white');

        dataPointGroup
            .filter(function(d) {
                return d;
            })
            .append('circle')
            .attr('r', function(d) {
                return d.parent.isMinor ? circleR / 2 : circleR;
            })
            .attr('cx', circleR + 5)
            .attr('cy', -circleR)
            .attr('stroke-width', '2px')
            .style('stroke', 'rgba(255, 255, 255, .3)')
            .style('fill', function(d) {
                return d3.select('.' + d.parent.css.split(' ').join('.')).style('stroke');
            });

        tooltipGroup
            .insert('rect', 'g')
            .attr('width', function() {
                return this.parentElement.getBBox().width + 2 * tooltipMargin;
            })
            .attr('height', function() {
                return this.parentElement.getBBox().height + 2 * tooltipMargin;
            })
            .attr('rx', circleR)
            .attr('ry', circleR)
            .style('fill', '#494949');

        const lineGroup = supportGroupEnter
            .append('g')
            .classed('line-group', true);

        const lineHighlightGroup = highlightGroupEnter
            .append('g')
            .classed('line-group', true);

        lineGroup
            .append('line')
            .classed('highlight-line', true)
            .attr('x1', '0')
            .attr('x2', '0')
            .attr('y1', '0')
            .attr('y2', chart.height)
            .style('stroke', 'black')
            .style('stroke-width', '1px');

        lineHighlightGroup
            .append('line')
            .classed('highlight-target', true)
            .attr('x1', '0')
            .attr('x2', '0')
            .attr('y1', '0')
            .attr('y2', chart.height)
            .attr('opacity', '0')
            .style('stroke-width', '20px')
            .style('stroke', 'black')
            .on('mouseover', function(d) {
                chart.overlay.selectAll('.highlight-group').filter(function(data) {
                    return data[0].x === d[0].x;
                }).transition().duration(300).attr('opacity', '1');
                chart.support.selectAll('.highlight-group').filter(function(data) {
                    return data[0].x === d[0].x;
                }).transition().duration(300).attr('opacity', '1');
            })
            .on('mouseout', function(d) {
                if (!self.showValues) {
                    chart.overlay.selectAll('.highlight-group').filter(function(data) {
                        return data[0].x === d[0].x;
                    }).transition().duration(300).attr('opacity', '0');
                    chart.support.selectAll('.highlight-group').filter(function(data) {
                        return data[0].x === d[0].x;
                    }).transition().duration(300).attr('opacity', '0');
                }
            });

        tooltipGroup
            .attr('transform', function(d, i, nodes) {
                const xTrans = (i === nodes.length - 1) ? -this.getBBox().width - 5 : 5;
                const yTrans = (this.parentElement.getBBox().height - this.getBBox().height) / 2;
                return 'translate(' + xTrans + ',' + yTrans + ')';
            });

        tooltipGroup
            .append('path')
            .attr('d', function(d, i, nodes) {
                const baseX = (i === nodes.length - 1) ? this.parentElement.getBBox().width : 0;
                const tipX = (i === nodes.length - 1) ? 5 : -5;
                const height = 10;
                const startY = this.parentElement.getBBox().height / 2 - height / 2;
                const midY = this.parentElement.getBBox().height / 2;
                const endY = this.parentElement.getBBox().height / 2 + height / 2;

                return 'M ' + baseX + ' ' + startY + ' L ' + (baseX + tipX) + ' ' + midY + ' L ' + baseX + ' ' + endY;
            })
            .style('fill', '#494949');
    }

    toggleValues() {
        this.showValues = !this.showValues;

        d3.selectAll('.highlight-group').transition().duration(300).attr('opacity', this.showValues ? '1' : '0');
    }

    checkMinorLinesEnabled() {
        this.chart.draw.selectAll('.monte-line.minor').classed('dimmed', (d) => !d.isEnabled);
        this.chart.draw.selectAll('.monte-point.minor').classed('dimmed', (d) => !d.parent.isEnabled);

        const allLinesEnabled = _.every(this.minorLegendItems, (item) => item.line.isEnabled);
        const allLinesDisabled = _.every(this.minorLegendItems, (item) => !item.line.isEnabled);

        if (allLinesDisabled && !allLinesEnabled) {
            this.enableMinorLines = false;
            this.mixedMinorLinesState = false;
        }
        else if (!allLinesDisabled && allLinesEnabled) {
            this.enableMinorLines = true;
            this.mixedMinorLinesState = false;
        }
        else {
            // Handle mixed state
            this.enableMinorLines = false;
            this.mixedMinorLinesState = true;
        }
    }

    prepData(data) {
        if (data) {
            let out = [];
            this.majorLegendItems.length = 0;
            this.minorLegendItems.length = 0;

            // Process support lines first and have them layer beneath the major / primary lines.
            if (data && data.supportLines && data.supportLines.length && data.supportLines !== null) {
                this.enableMinorLines = this.hasMinorLines = true;
                out = this.buildLines(data.supportLines, this.minorLegendItems, data.xaxisLabels, true);
            }
            else {
                this.enableMinorLines = this.hasMinorLines = false;
            }

            // Process the major / primary lines.
            if (data && data.lines) {
                // const lines = this.buildLines(data.lines, this.majorLegendItems, data.xaxisLabels, false);
                const lines = this.buildLines(data.lines, this.majorLegendItems, data.xaxisLabels, false);
                out = out.concat(lines);
            }

            if (out[out.length - 1] && out[out.length - 1].values && out[out.length - 1].values.length > 0) { // see it the last added line has a values array
                this.axisFormat = _.clone(out[out.length - 1].values[0].data);
                delete this.axisFormat.number;
            }

            const refLines = this.buildRefLines(data.referenceLines, data.xaxisLabels);
            return { lines: out, refLines };
        }
        return {};
    }

    buildRefLines(refLines, axisLabels) {
        const out = [];

        if (refLines && refLines.length > 0) {
            refLines.forEach((refLine) => {
                if (refLine.lines.length > 0) {
                    const values = [];
                    const label = refLine.lines[0].label;
                    // if (refLine.lines.length === 1) {
                    if (refLines.length === 1) { // if there is one ref line draw a horizontal line
                        // Draw a horizontal line
                        values.push({ x: 0, y: refLine.lines[refLine.lines.length - 1].number, label });
                        values.push({ x: axisLabels.length - 1, y: refLine.lines[refLine.lines.length - 1].number, label });
                    }
                    else {
                        refLine.lines.forEach((v, i) => values.push({ x: i, y: v.number, label }));
                    }

                    if (values.length) {
                        out.push({
                            values,
                            label: refLine.lines[0].label,
                        });
                    }
                }
            });
        }

        return out;
    }

    buildLines(lines, legend, axisLabels, isMinor) {
        const out = [];
        lines.forEach((line, lineIndex) => {
            if (line.lines.length > 0) {
                let lineLabel = null;
                for (let i = 0; i < line.lines.length; i++) {
                    if (line.lines[i].label !== null) {
                        lineLabel = line.lines[i].label;
                        break;
                    }
                }

                const newLine = {
                    css: `line-${lineIndex} ` + lineLabelToCssName('_' + lineLabel) + (isMinor ? ' minor' : ''),
                    label: lineLabel,
                    values: null,
                    isMinor,
                    isEnabled: true,
                };

                newLine.values = this.buildLineValues(axisLabels, line.lines, newLine);

                out.push(newLine);
                legend.push({ label: this.getItemLabel(newLine.label), css: newLine.css, line: newLine });
            }
        });

        return out;
    }

    buildLineValues(axisLabels, lines, parentData) {
        const values = [];
        // -- this code assumes all axis labels are unique
        /**
        lines.forEach((line) => {
            if (line.number !== null && line.number !== undefined) {
                axisLabels.forEach((label, index) => {
                    if (line.axisLabel === label) {
                        values.push({
                            x: index,
                            y: line.number,
                            format: line.format,
                            data: lines,
                            parent: parentData,
                        });
                    }
                });
            }
        });
        //
         -**/
        for (let xx = 0; xx < lines.length; xx++){
            let line = lines[xx];
            if (line.number !== null && line.number !== undefined) {
                values.push({
                    x: xx,
                    y: line.number,
                    format: line.format,
                    data: lines,
                    parent: parentData,
                });
            }
        }

        return values;
    }

    toggleMinorLine(item) {
        item.line.isEnabled = !item.line.isEnabled;
        this.checkMinorLinesEnabled();

        this.chart.overlay.selectAll('.datapoint-group')
            .attr('opacity', function(d) {
                return d.parent.isEnabled ? '1' : '.25';
            });
    }

    toggleAllMinorLines() {
        this.minorLegendItems.forEach((item) => {
            item.line.isEnabled = this.enableMinorLines;
        });

        this.checkMinorLinesEnabled();
    }

    checkSize() {
        if (this.chart) {
            this.chart.checkSize();
        }
    }

    update() {
        if (this.chart) {
            this.chart.update();
        }
    }

    getItemLabel(label) {
        return resolveLegendName(label, this.dataConfig.dataItemsMap);
    }
}

function lineLabelToCssName(label) {
    let returnString = '';
    if (label) {
        returnString = label.toLowerCase().replace(/\s+/g, '-');
        returnString = returnString.replace(/&/g, 'and');
        returnString = returnString.replace(/>/g, 'gt');
        returnString = returnString.replace(/</g, 'lt');
        returnString = returnString.replace(/#/g, 'num');
        returnString = returnString.replace(/%/g, 'pct');
        returnString = returnString.replace(/\(/g, 'op');
        returnString = returnString.replace(/\)/g, 'cp');
        returnString = returnString.replace(/\+/g, 'plus');
        returnString = returnString.replace(/=/g, 'eq');
        returnString = returnString.replace(/\$/g, 'dollar');
        returnString = returnString.replace(/[!"'\*,\.\/:;<=>\?@\[\\\]\^`\{\|\}~]/g, '');
    }
    return returnString;
}
