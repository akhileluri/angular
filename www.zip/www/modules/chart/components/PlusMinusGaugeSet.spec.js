// This file was generated from the chart scaffold
// Copyright 2016

import {Component, Injector} from '@angular/core';
import PlusMinusGaugeSet from './PlusMinusGaugeSet';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [PlusMinusGaugeSet],
    template: ''
})
class TestComponent {}

describe('chart/PlusMinusGaugeSet.js', () => {

    beforeEach(() => {
        addProviders([PlusMinusGaugeSet]);
    });

    it('should return component name', inject([PlusMinusGaugeSet], (plusMinusGaugeSet:PlusMinusGaugeSet) => {
        expect(plusMinusGaugeSet.name).toBe('PlusMinusGaugeSet');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<plus-minus-gauge-set></plus-minus-gauge-set>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('plus-minus-gauge-set h1').innerText).toBe('PlusMinusGaugeSet');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<plus-minus-gauge-set name="TEST"></plus-minus-gauge-set>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('plus-minus-gauge-set h1').innerText).toBe('TEST');
            });
    })));

});
