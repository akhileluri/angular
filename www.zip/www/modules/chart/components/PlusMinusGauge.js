// This file was generated from the chart scaffold
// Copyright 2016
/* global d3, _ */
import {Component, Input, Output, EventEmitter, ElementRef, ViewEncapsulation} from '@angular/core';
import * as Monte from 'monte';
import template from './PlusMinusGauge.html';
import styles from './PlusMinusGauge.scss';
import {getHealthCss} from '../util/color';

const OPTION_SETS = {
    tight: {
        boundingWidth: 80,
        boundingHeight: 55,
    },
    labeled: {
        boundingWidth: 80,
        boundingHeight: 55,
        labelPlacement: Monte.polarLabelOuterFactor(1.5),
        labelYAdjust: '-1.5em',
        labelXAdjust: function(d) {
            const shift = Math.abs(d.value) > 100 ? 4 : 2;

            if (d.value > 0) {
                return shift;
            }

            return -shift;
        },
    },
};

@Component({
    selector: 'plus-minus-gauge',
    template: template,
    styles: [styles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <plus-minus-gauge name="PlusMinusGauge" (change)="onChange($event)"></plus-minus-gauge>
 */
export default class PlusMinusGauge {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'PlusMinusGauge';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();

    @Input() data = {};
    @Input() chartData = {};
    @Input() optionSet = 'tight';
    @Input() footerPresent = false;

    opts = {
        boundingHeight: 53,
        boundingWidth: 63,
        pieStartAngle: Math.PI * -0.8,
        pieEndAngle: Math.PI * 0.8,
        needleBase: 2,
        needlePath: Monte.needleRect(),
        needleHeight: 28,
        innerRadius: 14,
        outerRadius: 28,
        cornerRadius: 0,
        transition: {
            duration: 500,
        },

        extensions: [
            new Monte.ExtArc({
                binding: ['updated'],
                arcCss: 'monte-arc-neg',
                innerRadius: 14,
                outerRadius: 28,
                startAngle: 0,
                cornerRadius: 0,
                endAngle: function() {
                    if (this.chart.needleValueAngle() < 0) {
                        return this.chart.needleValueAngle();
                    }

                    return null;
                },
            }),
            new Monte.ExtArc({
                binding: ['updated'],
                innerRadius: 14,
                outerRadius: 28,
                startAngle: 0,
                cornerRadius: 0,
                endAngle: function() {
                    if (this.chart.needleValueAngle() > 0) {
                        return this.chart.needleValueAngle();
                    }

                    return null;
                },
            }),
        ],
    };

    constructor(chartEl: ElementRef) {
        this.chartEl = d3.select(chartEl.nativeElement).node();
    }

    ngOnDestroy() {
        if (this.chart) {
            this.chart.destroy();
        }
    }

    ngOnChanges() {
        if (this.data && this.chart) {
            this.chart.updateData(this.prepData(this.data));
        }
    }

    ngAfterViewInit() {
        // const comp = this;

        //  Delay is required to allow the UI to paint and provide correct dimensions
        // _.delay(function(comp) {
        //     comp.renderChart();
        // }, 10, comp);
    }

    renderChart() {
        this.opts = _.merge(this.opts, OPTION_SETS[this.optionSet]);

        // const $container = $($(this.chartEl.node()).closest('chart-selector'));

        //  Set final dimensions based on the available space created by the flexbox layout
        // this.opts.boundingWidth = $container.width();
        // this.opts.boundingHeight = $container.height();

        this.chart = new Monte.GaugeChart(this.chartEl, this.opts)
          .classed(getHealthCss(this.data.health), true)
          .data(this.prepData(this.data));
    }


    prepData(data) {
        const initVal = data.numbers[1];
        const value = (initVal.format === 'percentage' || initVal.format === 'percent') ? (initVal.number * 100) : initVal.number;
        const extent = this.round10(Math.abs(value)) || 10; // `|| 10` Avoids having arcs of zero length.

        const out = {
            value,
            start: -extent,
            segments: [
              { interval: -extent, label: (-extent).toString() },
              { interval: extent, label: extent.toString() },
            ],
        };

        return out;
    }

    round10(value) {
        return Math.ceil(value / 10) * 10;
    }

    checkSize() {
        if (this.chart) {
            this.chart.checkSize();
        }
    }
}

// resolveLegendName(d.label, this.dataConfig.dataItemsMap),

// function getVal(data) {
//     return _.get(data, 'number', 0);
// }
