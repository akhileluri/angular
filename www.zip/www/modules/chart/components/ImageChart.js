// This file was generated from the chart scaffold
// Copyright 2018
/* global */
import {Component, Input, Output, EventEmitter, ViewEncapsulation} from '@angular/core';
// import * as Monte from 'monte';/**/
import template from './ImageChart.html';
import styles from './ImageChart.scss';

@Component({
    selector: 'image-chart',
    template: template,
    styles: [styles],
    encapsulation: ViewEncapsulation.None, // Disable view encapsulation for better theme support.
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <image-chart name="ImageChart" (change)="onChange($event)"></image-chart>
 */
export default class ImageChart {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'ImageChart';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();

    @Input() data = {};
    @Input() chartSize = {};

    @Input() footerPresent = false;

    chartImage='';

    constructor() {
    }


    ngOnChanges() {
        this.chartImage = this.data && this.data.length && this.data[0].label;
    }

    ngAfterViewInit() {
        this.chartImage = this.data && this.data.length && this.data[0].label;
    }
}
