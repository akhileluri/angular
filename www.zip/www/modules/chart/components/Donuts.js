// This file was generated from the component scaffold
// Copyright 2016
/* global d3, _ */
import {Component, Input, Output, EventEmitter, ElementRef, ViewEncapsulation} from '@angular/core';
import * as Monte from 'monte';
import template from './Donuts.html';
import styles from './Donuts.scss';
import {formatMetdataNumber, formatShortNum, shortNumSymbol} from '../util/numberAbbrv';
import {reformatPercent} from '../util/format';
import {getHealthCss} from '../util/color';

@Component({
    selector: 'donuts',
    template: template,
    styles: [styles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <donuts name="Donuts" (change)="onChange($event)"></donuts>
 */
export default class Donuts {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'Donuts';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();

    @Input() data = null;

    @Input() chartSize = '';

    @Input() footerPresent = false;

    @Input() metricDonut = false;

    largeDonutEl: HTMLElement;
    smallDonutEl: HTMLElement;
    smallDonut2El: HTMLElement;

    largeOpts = {
        css: 'nps-large',
        boundingWidth: 140,
        boundingHeight: 140,
        margin: { top: 0, right: 0, left: 0, bottom: 0 },
        innerRadius: 55,
        extensions: [
            new Monte.ExtLabel({
                binding: ['updated'],
                anchor: 'middle',
                labelCss: 'value-label',
                text: function() {
                    let symbol = shortNumSymbol(this.chart.summaryData.number);
                    if (this.chart.summaryData.format === 'percentage' || this.chart.summaryData.format === 'percent') {
                        symbol = '%';
                        return reformatPercent(this.chart.summaryData.number * 100) + '<tspan class="superscript" textLength="20" dy="-20" text-anchor: "middle">' + symbol + '</tspan>';
                    }
                    return formatShortNum(this.chart.summaryData.number, 1) + '<tspan class="superscript" textLength="20" dy="-20" text-anchor: "middle">' + symbol + '</tspan>';
                },
                maxWidth: 108, // Slightly smaller than the inner diameter
            }),
            new Monte.ExtPolarLine({
                layer: 'overlay',
                angle: function() {
                    return budgetLineAngle(this.chart, this.chart.option('needleVal'));
                },
                lineCss: 'budget-line',
                innerRadius: 55,
                outerRadius: 67.5,
            }),
        ],
    };

    smallOptsFirst = {
        css: 'nps-small',
        boundingWidth: 78,
        boundingHeight: 78,
        innerRadius: 28,
        extensions: [
            new Monte.ExtLabel({
                binding: ['updated'],
                anchor: 'middle',
                labelCss: 'value-label',
                text: function() {
                    let symbol = shortNumSymbol(this.chart.summaryData.number);
                    if (this.chart.summaryData.format === 'percentage' || this.chart.summaryData.format === 'percent') {
                        symbol = '%';
                        return reformatPercent(this.chart.summaryData.number * 100) + '<tspan class="superscript-small" textLength="20" dy="-5" text-anchor: "middle">' + symbol + '</tspan>';
                    }
                    return formatShortNum(this.chart.summaryData.number, 1) + '<tspan class="superscript-small" textLength="20" dy="-5" text-anchor: "middle">' + symbol + '</tspan>';
                },
                maxWidth: 50, // Slightly smaller than the inner diameter
            }),
            new Monte.ExtPolarLine({
                layer: 'overlay',
                angle: function() {
                    return budgetLineAngle(this.chart, this.chart.option('needleVal'));
                },
                lineCss: 'budget-line',
                innerRadius: 28,
                outerRadius: 39,
            }),
        ],
    };

    smallOptsSecond = {
        css: 'nps-small',
        boundingWidth: 78,
        boundingHeight: 78,
        innerRadius: 28,
        extensions: [
            new Monte.ExtLabel({
                binding: ['updated'],
                anchor: 'middle',
                labelCss: 'value-label',
                text: function() {
                    let symbol = shortNumSymbol(this.chart.summaryData.number);
                    if (this.chart.summaryData.format === 'percentage' || this.chart.summaryData.format === 'percent') {
                        symbol = '%';
                        return reformatPercent(this.chart.summaryData.number * 100) + '<tspan class="superscript-small" textLength="20" dy="-5" text-anchor: "middle">' + symbol + '</tspan>';
                    }
                    return formatShortNum(this.chart.summaryData.number, 1) + '<tspan class="superscript-small" textLength="20" dy="-5" text-anchor: "middle">' + symbol + '</tspan>';
                },
                maxWidth: 50, // Slightly smaller than the inner diameter
            }),
            new Monte.ExtPolarLine({
                layer: 'overlay',
                angle: function() {
                    return budgetLineAngle(this.chart, this.chart.option('needleVal'));
                },
                lineCss: 'budget-line',
                innerRadius: 28,
                outerRadius: 39,
            }),
        ],
    };

    constructor(compEl: ElementRef) {
        this.contentSel = d3.select(compEl.nativeElement);
    }

    ngOnDestroy() {
        if (this.donutLarge) {
            this.donutLarge.destroy();
        }

        if (this.donutSmall) {
            this.donutSmall.destroy();
        }

        if (this.donutSmall2) {
            this.donutSmall2.destroy();
        }
    }

    ngOnChanges() {
        if (this.data) {
            if (this.donutLarge) {
                this.donutLarge.summaryData = _.get(this, 'data[0].numbers[0]', '');
                this.donutLarge.option('needleVal', this.data.charts[0].numbers[0].number);
                this.donutLarge.updateData(getVal(this.data.charts[0].numbers[1]));
                this.donutLarge.call(changeLabel, this.data.charts[0].numbers[1].axisLabel);
            }

            if (this.donutSmall && this.data.donutCharts > 1) {
                this.donutSmall.summaryData = _.get(this, 'data[1].numbers[0]', '');
                this.donutSmall.option('needleVal', this.data.charts[1].numbers[0].number);
                this.donutSmall.updateData(getVal(this.data.charts[1].numbers[1]));
                this.donutSmall.call(changeLabel, this.data.charts[1].numbers[1].axisLabel);
            }

            if (this.donutSmall2 && this.data.donutCharts > 2) {
                this.donutSmall2.summaryData = _.get(this, 'data[2].numbers[0]', '');
                this.donutSmall2.option('needleVal', this.data.charts[2].numbers[0].number);
                this.donutSmall2.updateData(getVal(this.data.charts[2].numbers[1]));
                this.donutSmall2.call(changeLabel, this.data.charts[2].numbers[1].axisLabel);
            }
        }
    }

    ngAfterViewInit() {
        const comp = this;

        //  Delay is required to allow the UI to paint and provide correct dimensions
        _.delay(function(comp) {
            comp.renderChart();
        }, 10, comp);
    }

    renderChart() {
        const comp = this;

        const $container = $($(this.contentSel.node()).closest('chart-selector'));

        const containerWidth = $container.width();
        const containerHeight = $container.height();

        //  Set final dimensions based on the available space created by the flexbox layout and how many donuts are present
        if (this.data.length > 1) {
            //  All donuts
            this.largeOpts.boundingWidth = (containerWidth * 0.55);
            this.largeOpts.boundingHeight = containerHeight;

            this.smallOptsFirst.boundingWidth = (containerWidth * 0.4);
            this.smallOptsFirst.boundingHeight = (containerHeight / 2);

            this.smallOptsSecond.boundingWidth = (containerWidth * 0.4);
            this.smallOptsSecond.boundingHeight = (containerHeight / 2);
        }
        else {
            //  Large donut only
            this.largeOpts.boundingWidth = this.metricDonut ? containerWidth * 0.75 : containerWidth;
            this.largeOpts.boundingHeight = this.metricDonut ? containerHeight * 0.80 : containerHeight;
        }

        this.largeOpts.outerRadius = (Math.min(this.largeOpts.boundingWidth, this.largeOpts.boundingHeight) / 2);
        this.largeOpts.innerRadius = this.largeOpts.outerRadius - 20;

        this.largeOpts.extensions[0].opts.maxWidth = ((this.largeOpts.innerRadius * 2) - 20);
        this.largeOpts.extensions[1].opts.outerRadius = this.largeOpts.outerRadius;
        this.largeOpts.extensions[1].opts.innerRadius = this.largeOpts.innerRadius;

        if (this.data.length > 1) {
            this.smallOptsFirst.outerRadius = (Math.min(this.smallOptsFirst.boundingWidth, this.smallOptsFirst.boundingHeight) / 2);
            this.smallOptsFirst.innerRadius = this.smallOptsFirst.outerRadius - 20;

            this.smallOptsFirst.extensions[0].opts.maxWidth = ((this.smallOptsFirst.innerRadius * 2) - 15);
            this.smallOptsFirst.extensions[1].opts.outerRadius = this.smallOptsFirst.outerRadius;
            this.smallOptsFirst.extensions[1].opts.innerRadius = this.smallOptsFirst.innerRadius;
        }

        if (this.data.length > 2) {
            this.smallOptsSecond.outerRadius = (Math.min(this.smallOptsSecond.boundingWidth, this.smallOptsSecond.boundingHeight) / 2);
            this.smallOptsSecond.innerRadius = this.smallOptsSecond.outerRadius - 20;

            this.smallOptsSecond.extensions[0].opts.maxWidth = ((this.smallOptsSecond.innerRadius * 2) - 15);
            this.smallOptsSecond.extensions[1].opts.outerRadius = this.smallOptsSecond.outerRadius;
            this.smallOptsSecond.extensions[1].opts.innerRadius = this.smallOptsSecond.innerRadius;
        }

        this.largeDonutEl = this.contentSel.select('.donut-large').node();
        this.smallDonutEl = this.contentSel.select('.donut-small').node();
        this.smallDonut2El = this.contentSel.select('.donut-small-2').node();

        if (!this.donutLarge) {
            const initVal = getVal(this.data[0].numbers[1]);
            const initFormat = this.data[0].numbers[1].format;
            const needleVal = this.data[0].numbers[0].number;

            const initLabel = _.get(this.data[0], 'numbers[1].axisLabel', '');
            if (initFormat === 'percentage') {
                this.largeOpts.extensions[0].opts.text = function() {
                    return reformatPercent(this.chart.wedgeValue()) + '<tspan  style="font-size:18px;font-weight:300;line-height:3.39;" dy="-20px">%</tspan>';
                };
            }

            const initTopLabel = getTopLabelText(this.data[0].numbers);

            this.donutLarge = new Monte.WedgeChart(this.largeDonutEl, this.largeOpts)
              .on('rendered.common', onRendered(30, initLabel))
              .call(function() {
                  this.option('needleVal', needleVal);
                  // Bind summary data so it is accessible by the label extensions
                  this.summaryData = _.get(comp, 'data[0].numbers[0]', '');
              })
              .on('rendered.large', function() {
                  this.overlay.append('text')
                    .attr('class', 'top-label')
                    .attr('dy', '0.35em')
                    .attr('text-anchor', 'middle')
                    .attr('transform', 'translate(0, -30)')
                    .text(initTopLabel);
              })
              .on('updated.large', function() {
                  this.overlay.select('.top-label')
                    .text(getTopLabelText(comp.data[0].numbers));
              })
              .classed(getHealthCss(_.get(this.data[0], 'numbers[1].health')), true)
              .data(initVal);
        }

        if (!this.donutSmall && this.data.length > 1) {
            this.donutSmall = this.setupSmallDonut(this.smallDonutEl, this.data[1], this.smallOptsFirst);
        }

        if (!this.donutSmall2 && this.data.length > 2) {
            this.donutSmall2 = this.setupSmallDonut(this.smallDonut2El, this.data[2], this.smallOptsSecond);
        }
    }

    setupSmallDonut(el, chartData, opts) {
        const initVal = getVal(chartData.numbers[1]);
        const needleVal = chartData.numbers[0].number;
        const initLabel = _.get(chartData, 'numbers[1].axisLabel', '');

        return new Monte.WedgeChart(el, opts)
          .on('rendered', onRendered(12, initLabel))
          .call(function() {
              this.option('needleVal', needleVal);
              // Bind summary data so it is accessible by the label extensions
              this.summaryData = _.get(chartData, 'numbers[0]', '');
          })
          .classed(getHealthCss(_.get(chartData, 'numbers[1].health')), true)
          .data(initVal);
    }

    checkSize() {
        if (this.donutLarge) {
            this.donutLarge.checkSize();
        }

        if (this.donutSmall) {
            this.donutSmall.checkSize();
        }

        if (this.donutSmall2) {
            this.donutSmall2.checkSize();
        }
    }

    update() {
        if (this.donutLarge) {
            this.donutLarge.update();
        }

        if (this.donutSmall) {
            this.donutSmall.update();
        }

        if (this.donutSmall2) {
            this.donutSmall2.update();
        }
    }

    getDonutCount() {
        return _.get(this, 'data.length', 0);
    }
}

function getTopLabelText(numbers) {
    let lbl = '';

    // Start at 3, because index 0-2 are the donut ring values.
    for (let i = 3; i < numbers.length; i++) {
        if (i > 1) {
            lbl += '/';
        }

        lbl += formatMetdataNumber(numbers[i]);
    }

    return lbl;
}

function getVal(data) {
    return _.get(data, 'number', 0) * 100;
}

function onRendered(yShift, defaultLabel) {
    return function() {
        this.overlay.append('text')
          .attr('class', 'date-label')
          .attr('dy', '0.35em')
          .attr('text-anchor', 'middle')
          .attr('transform', `translate(0, ${yShift})`)
          .text(defaultLabel);
    };
}

function budgetLineAngle(chart, needleVal) {
    if (needleVal) {
        const fData = chart.pie([{ value: needleVal }, { value: 1 - needleVal }]);
        const angle = fData[0].endAngle;
        return angle;
    }
    else {
        return null;
    }
}

function changeLabel(label) {
    this.overlay.select('.date-label').text(label);
}
