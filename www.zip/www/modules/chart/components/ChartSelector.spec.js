// This file was generated from the component scaffold
// Copyright 2016

import {Component, Injector} from '@angular/core';
import ChartSelector from './ChartSelector';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [ChartSelector],
    template: ''
})
class TestComponent {}

describe('chart/ChartSelector.js', () => {

    beforeEach(() => {
        addProviders([ChartSelector]);
    });

    it('should return component name', inject([ChartSelector], (chartSelector:ChartSelector) => {
        expect(chartSelector.name).toBe('ChartSelector');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<chart-selector></chart-selector>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('chart-selector h1').innerText).toBe('ChartSelector');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<chart-selector name="TEST"></chart-selector>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('chart-selector h1').innerText).toBe('TEST');
            });
    })));

});
