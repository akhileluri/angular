// This file was generated from the chart scaffold
// Copyright 2016
/* global d3, _ */
import {Component, Input, Output, EventEmitter, ElementRef, ViewEncapsulation} from '@angular/core';
import * as Monte from 'monte';
import template from './SegmentChart.html';
import styles from './SegmentChart.scss';

@Component({
    selector: 'segment-chart',
    template: template,
    styles: [styles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <segment-chart name="SegmentChart" (change)="onChange($event)"></segment-chart>
 */
export default class SegmentChart {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'SegmentChart';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();

    @Input() data = null;
    @Input() chartSize = '';
    @Input() footerPresent = false;

    transformedData = [];

    opts = {
        boundingWidth: 140,
        boundingHeight: 140,

        // Follows D3 Margin Convention: https://bl.ocks.org/mbostock/3019563
        margin: {
            top: 10,
            bottom: 20,
            left: 20,
            right: 10,
        },

        innerRadius: 40,
        piePadAngle: 0,
    };

    constructor(chartEl: ElementRef) {
        this.chartWrap = d3.select(chartEl.nativeElement);
    }

    ngOnDestroy() {
        if (this.chart) {
            this.chart.destroy();
        }
    }

    ngOnChanges() {
        this.transformedData = this.prepData(this.data);

        if (this.chart) {
            this.chart.updateData(this.transformedData);
        }
    }

    ngAfterViewInit() {
        const comp = this;

        //  Delay is required to allow the UI to paint and provide correct dimensions
        _.delay(function(comp) {
            comp.renderChart();
        }, 10, comp);
    }

    renderChart() {
        this.chartEl = this.chartWrap.select('.segment-chart').node();

        const $container = $($(this.chartWrap.node()).closest('chart-selector'));

        //  Set final dimensions based on the available space created by the flexbox layout
        this.opts.boundingWidth = $container.width();
        this.opts.boundingHeight = $container.height();

        this.chart = new Monte.ArcChart(this.chartEl, this.opts)
          .on('rendered', function() {
            // Static features, first render
          })
          .on('updated', function() {
            // Dynamic / changing features based data changes
          })
          .data(this.transformedData);
    }

    prepData(data) {
        if (data) {
            data.forEach((d, i) => {
                d.value = d.numData.number;
                d.css = `segment-${i}`;
            });
        }

        return data;
    }

    getTrend(item) {
        let out = '-';

        if (item.numData.trend) {
            out = item.numData.trend;
        }

        return out;
    }

    getTrendCss(item) {
        let out = '';

        if (item.numData.trend) {
            const trendValue = parseInt(item.numData.trend, 10);
            out = (isNaN(trendValue) || trendValue === 0) ? '' :
              trendValue > 0 ? 'trend-up' : 'trend-down';
        }

        return out;
    }

    checkSize() {
        if (this.chart) {
            this.chart.checkSize();
        }
    }

    update() {
        if (this.chart) {
            this.chart.update();
        }
    }
}
