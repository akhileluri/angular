// This file was generated from the chart scaffold
// Copyright 2017

import {Component, Injector} from '@angular/core';
import DonutMetric from './DonutMetric';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [DonutMetric],
    template: ''
})
class TestComponent {}

describe('chart/DonutMetric.js', () => {

    beforeEach(() => {
        addProviders([DonutMetric]);
    });

    it('should return component name', inject([DonutMetric], (donutMetric:DonutMetric) => {
        expect(donutMetric.name).toBe('DonutMetric');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<donut-metric></donut-metric>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('donut-metric h1').innerText).toBe('DonutMetric');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<donut-metric name="TEST"></donut-metric>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('donut-metric h1').innerText).toBe('TEST');
            });
    })));

});
