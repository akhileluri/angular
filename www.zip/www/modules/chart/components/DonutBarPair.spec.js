// This file was generated from the chart scaffold
// Copyright 2016

import {Component, Injector} from '@angular/core';
import DonutBarPair from './DonutBarPair';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [DonutBarPair],
    template: ''
})
class TestComponent {}

describe('chart/DonutBarPair.js', () => {

    beforeEach(() => {
        addProviders([DonutBarPair]);
    });

    it('should return component name', inject([DonutBarPair], (donutBarPair:DonutBarPair) => {
        expect(donutBarPair.name).toBe('DonutBarPair');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<donut-bar-pair></donut-bar-pair>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('donut-bar-pair h1').innerText).toBe('DonutBarPair');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<donut-bar-pair name="TEST"></donut-bar-pair>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('donut-bar-pair h1').innerText).toBe('TEST');
            });
    })));

});
