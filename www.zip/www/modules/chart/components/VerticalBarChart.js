// This file was generated from the component scaffold
// Copyright 2016
/* global d3, _ */
import { Component, Input, Output, EventEmitter, ElementRef, ViewEncapsulation } from '@angular/core';
import * as Monte from 'monte';
import template from './VerticalBarChart.html';
import styles from './VerticalBarChart.scss';
import chartStyles from './chartCommon.scss';

import { formatAbbreviation, formatMetdataNumber as formatNumber, formatShortNum, shortNumSymbol } from '../util/numberAbbrv';
import { leadYearFormat, percentFormat, reformatPercent } from '../util/format';
import { getHealthCss } from '../util/color';
import { labelOverlapAvoidance } from '../extension/ExtHorizontalRef';
import { addFlag, updateFlag } from '../extension/edgeFlag';

@Component({
    selector: 'vertical-bar-chart',
    template: template,
    styles: [styles, chartStyles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <vertical-bar-chart name="VerticalBarChart" (change)="onChange($event)"></vertical-bar-chart>
 */
export default class VerticalBarChart {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name: string = 'VerticalBarChart';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change: EventEmitter = new EventEmitter();

    @Input() data = {};
    @Input() chartData = null;
    @Input() chartSize = '';
    @Input() footerPresent = false;

    opts = {
        css: 'no-domain-lines',
        boundingWidth: 230,
        boundingHeight: 165,   // 90
        suppressAxes: ['y'],
        barCss: function(d) {
            return d.health || 'no-health';
        },
        includeLabels: false,
        margin: {
            top: 20, bottom: 15, left: 30, right: 5,
        },
        xAxisCustomize: Monte.tools.invokeMany(
            (axis) => axis.tickFormat(leadYearFormat),
            Monte.axisNoTicks
        ),
        xProp: 'axisLabel',
        xScale: function() {
            return d3.scaleBand().paddingInner(0.58).paddingOuter(0.2).round(true);
        },
        yProp: 'number',
        resize: new Monte.HorizontalResizer(),

        extensions: [
            new Monte.ExtReferenceLine({
                layer: 'support',
                labelPlacement: 'nw',
                data: function() {
                    const data = this.chart.data();

                    if (data && data.length > 1) {
                        const chart = this.chart;
                        const maxVal = _.maxBy(data, chart.option('yProp'));
                        const y2 = chart.getScaledProp('y', maxVal);
                        const l = chart.option('margin.left');
                        const max = {
                            x1: -l,
                            x2: chart.width,
                            y1: y2,
                            y2: y2,
                            text: formatNumber(maxVal),
                        };

                        return [max];
                    }

                    return [];
                },
            }),
            new Monte.ExtReferenceLine({
                layer: 'support',
                labelPlacement: 'sw',
                data: function() {
                    const data = this.chart.data();

                    if (data && data.length > 1) {
                        const chart = this.chart;
                        const datumLast = data[data.length - 1];
                        const maxVal = _.maxBy(data, chart.option('yProp'));
                        const y1 = chart.getScaledProp('y', datumLast);
                        const y2 = chart.getScaledProp('y', maxVal);
                        const l = chart.option('margin.left');
                        const last = {
                            x1: -l,
                            x2: chart.width,
                            y1: y1,
                            y2: y1,
                            text: formatNumber(datumLast),
                        };
                        const max = {
                            x1: -l,
                            x2: chart.width,
                            y1: y2,
                            y2: y2,
                            text: formatNumber(maxVal),
                        };

                        // If values are identical return only one.
                        if (_.isEqual(last, max)) {
                            return [];
                        }

                        return [last];
                    }

                    return [];
                },
            }),
            new Monte.ExtReferenceLine({
                layer: 'support',
                css: 'monte-ext-ref-line-grp projected-section',
                data: function() {
                    const data = this.chart.data();

                    if (data && data.length > 1) {
                        const chart = this.chart;
                        const firstProjected = _.find(data, ['css', 'projected']);
                        // const maxVal = _.maxBy(data, chart.option('yProp'));
                        const x1 = chart.getScaledProp('x', firstProjected);
                        const floor = {
                            x1: x1,
                            x2: chart.width,
                            y1: chart.height + 25,
                            y2: chart.height + 25,
                            text: 'projected',
                        };

                        if (firstProjected) {
                            return [floor];
                        }
                    }

                    return [];
                },
            }),
        ],
    };

    constructor(chartEl: ElementRef) {
        this.chartEl = d3.select(chartEl.nativeElement).node();
    }

    ngOnDestroy() {
        if (this.chart) {
            this.chart.destroy();
        }
    }

    ngOnChanges() {
        if (this.data && this.chart) {
            this.chart.updateData(this.data.numbers);
        }
    }

    quadWideOptions() {
        delete this.opts.suppressAxes;
        this.opts.chartCss = 'text-align: left';
        this.opts.extensions.push(new Monte.ExtHorizontalLines());
    }

    doubleWideOptions() {
        this.opts.chartCss = 'text-align: left';
    }

    barLabelOptions() {
        this.opts.includeLabels = true;
        this.opts.label = function(value) {
            if (value.format === 'percentage' || value.format === 'percent') {
                return reformatPercent(value.number * 100) + '%';
            }
            return formatShortNum(value.number, 1) + shortNumSymbol(value.number);
        };
        this.opts.labelProp = 'number';
        this.opts.labelXAdjust = function(value, index, bars) {
            const labelWidth = d3.select(bars[index]).select('text').node().getComputedTextLength();
            return ((labelWidth / 2) * -1);
        };
        this.opts.labelYAdjust = -5;
    }

    barToolTipOptions() {
        this.opts.margin.top = 32;
    }

    barLabelAndToolTipOptions() {
        this.opts.margin.top = 48;
    }

    adjustForProjected() {
        this.opts.margin.bottom += 15;
    }

    ngAfterViewInit() {
        const comp = this;

        //  Delay is required to allow the UI to paint and provide correct dimensions
        _.delay(function(comp) {
            comp.renderChart();

            //  Forces the overlay to be rendered
            comp.checkSize();
        }, 10, comp);
    }

    renderChart() {
        const comp = this;

        const $container = $($(this.chartEl).closest('chart-selector'));
        const $overview = $($container.find('.overview-text'));

        //  Set final dimensions based on the available space created by the flexbox layout
        this.opts.boundingWidth = $container.width();
        this.opts.boundingHeight = $container.height();

        if (this.chartSize === 'double') {
            this.doubleWideOptions();
        }
        else if (this.chartSize === 'quadruple') {
            this.quadWideOptions();
            this.opts.margin.left = 70;
        }
        else if (this.chartSize === 'expand') {
            this.opts.boundingHeight = 100;
            delete this.opts.suppressAxes;
            delete this.opts.extensions;

            this.opts.extensions = [
                new Monte.ExtHorizontalLines(),
            ];

            this.opts.margin.left = 40;
        }

        //  Include optional value labels above the bar
        if (comp.data && comp.data.length > 0 && comp.data[0].showLabels === true) {
            this.barLabelOptions();
        }

        //  Include option tooltips that appear over the bar when hovered
        if (comp.data && comp.data.length > 0 && comp.data[0].enableTooltips === true) {
            this.barToolTipOptions();
        }

        //  Include both the option value labels and toolstips
        if (comp.data && comp.data.length > 0 && comp.data[0].showLabels === true && comp.data && comp.data.length > 0 && comp.data[0].enableTooltips === true) {
            this.barLabelAndToolTipOptions();
        }

        if (comp.data && comp.data.length > 0 && comp.data[0].numbers) {
            const projected = _.find(comp.data[0].numbers, ['css', 'projected']);
            if (projected) {
                this.adjustForProjected();
            }
        }

        //  Make room for the overview text
        const overviewWidth = $overview.outerWidth();

        if (this.chartSize === 'double' || this.chartSize === 'quadruple') {
            this.opts.boundingWidth -= overviewWidth;
        }

        //  Determine which formatter to use for the Y-axis
        switch (_.get(this.data, '[0].numbers[0].format', '')) {
        case 'percent':
            this.opts.yAxisCustomize = Monte.tools.invokeMany(
                (axis) => axis.tickFormat(d3.format('.0%')),
                Monte.axisNoTicks
            );
            break;
        case 'average/int':
            this.opts.yAxisCustomize = Monte.tools.invokeMany(
                (axis) => axis.tickFormat(d3.format('.2s')),
                Monte.axisNoTicks
            );
            break;
        case 'date':
            this.opts.yAxisCustomize = Monte.tools.invokeMany(
                (axis) => axis.tickFormat(d3.format('.2d')),
                Monte.axisNoTicks
            );
            break;
        case 'currency':
            this.opts.yAxisCustomize = Monte.tools.invokeMany(
                // (axis) => axis.tickFormat(d3.format('$.2s')),
                (axis) => axis.tickFormat((d) => {
                    return '$' + formatAbbreviation(d, 2);
                }),
                Monte.axisNoTicks
            );
            break;
        default:
        }

        this.chart = new Monte.BarChart(this.chartEl, this.opts)
            .on('updated', function() {
                const data = this.data();
                const cur = data[data.length - 1];  // Last item, the current time period.
                const curVal = this.getProp('y', cur);
                const y1 = this.y(curVal);

                const forecast = this.overlay.selectAll('.forecast-grp').data([cur.budget]);

                forecast.enter().append('g')
                    .attr('class', 'forecast-grp')
                    .each((d, i, nodes) => {
                        const forecastGrp = d3.select(nodes[i]);

                        if (d) {
                            const fy = this.y(d);
                            const fx1 = this.getScaledProp('x', cur);
                            const fx2 = fx1 + this.x.bandwidth();

                            forecastGrp.append('line')
                                .attr('class', 'budget-line')
                                .attr('x1', fx1)
                                .attr('x2', fx2)
                                .attr('y1', fy)
                                .attr('y2', fy);

                            // Add annotation flag
                            const flagPercent = percentFormat(curVal / d);
                            addFlag.call(this, forecastGrp, fx2, y1, flagPercent);

                            // TODO: Apply health status and trend for proper style.
                            // applyBudgetCss(this, cur.number, d);
                            forecastGrp.classed(getHealthCss(d.health), true);
                        }
                    });

                forecast.each((d, i, nodes) => {
                    const forecastGrp = d3.select(nodes[i]);

                    if (d) {
                        const fy = this.y(d);
                        const fx1 = this.getScaledProp('x', cur);
                        const fx2 = fx1 + this.x.bandwidth();

                        forecastGrp.select('.budget-line')
                            .attr('x1', fx1)
                            .attr('x2', fx2)
                            .attr('y1', fy)
                            .attr('y2', fy);

                        // Add annotation flag
                        const flagPercent = percentFormat(curVal / d);
                        updateFlag.call(this, forecastGrp, fx2, y1, flagPercent);

                        // Apply health status and trend for proper style.
                        forecastGrp.classed(getHealthCss(d.health), true);
                    }
                });

                forecast.exit().remove();
            })
            .on('extension', labelOverlapAvoidance)
            .on('boundsUpdated', function() {
                if (comp.data && comp.data.length > 0 && comp.data[0].enableTooltips === true) {
                    comp.buildOverlay(comp.data[0].numbers, this, comp);
                }
            })
            .data(this.prepData(this.data[0].numbers))
            .checkSize();
    }

    buildOverlay(data, chart, comp) {
        const self = this;
        const tooltipMargin = 7;
        const textSize = 10;
        const circleR = textSize / 1.5;
        const barWidth = chart.x.bandwidth();

        const maxValue = _.maxBy(data, (d) => {
            return (_.isNumber(d.number) === true) ? d.number : 0;
        });

        const getTranslate = function(element) {
            const transform = element.getAttribute('transform');
            return transform.substring(transform.indexOf('(') + 1, transform.indexOf(')')).split(',')
                .map((cur) => parseFloat(cur));
        };

        const highlightGroup = chart.overlay.selectAll('g.highlight-group').data(data);

        const highlightGroupEnter = highlightGroup
            .enter()
            .append('g')
            .classed('highlight-group', true)
            .attr('opacity', '0');

        highlightGroup
            .attr('transform', function(d) {
                const xVal = _.find(d, (val) => val);
                return 'translate(' + chart.getScaledProp('x', xVal) + ',' + 0 + ')';
            });

        const tooltipGroup = highlightGroupEnter
            .append('g')
            .classed('tooltip-group', true);

        const allDataPointGroup = tooltipGroup
            .append('g')
            .classed('all-datapoint-group', true)
            .attr('transition', function() {
                return 'translate(0,' + textSize + ')';
            });

        const dataPointGroup = allDataPointGroup.selectAll('g.datapoint-group').data(function(d) {
            return [d];
        })
            .enter()
            .filter(function(d) {
                return d.number !== undefined;
            })
            .append('g')
            .classed('datapoint-group', true)
            .sort(function(a, b) {
                return a.y > b.y ? -1 : 1;
            })
            .attr('transform', function(d, i, nodes) {
                const transY = nodes[i - 1] ? getTranslate(nodes[i - 1])[1] + textSize + 10 : textSize + 9;
                return 'translate(0,' + transY + ')';
            });

        dataPointGroup
            .append('text')
            .text(function(value) {
                if (value.format === 'percentage' || value.format === 'percent') {
                    return reformatPercent(value.number * 100) + '%';
                }
                return formatShortNum(value.number, 1) + shortNumSymbol(value.number);
            })
            .attr('x', (textSize - 2))
            .attr('y', -4)
            .style('font-size', textSize)
            .style('fill', 'white');

        tooltipGroup
            .insert('rect', 'g')
            .attr('width', function() {
                return this.parentElement.getBBox().width + 2 * tooltipMargin;
            })
            .attr('height', function() {
                return this.parentElement.getBBox().height + 2 * tooltipMargin;
            })
            .attr('rx', circleR)
            .attr('ry', circleR)
            .style('fill', '#494949');

        const lineHighlightGroup = highlightGroupEnter
            .append('g')
            .classed('line-group', true);

        //  Draw the target to trigger the tooltip's appearance
        lineHighlightGroup
            .append('line')
            .classed('highlight-target', true)
            .attr('x1', (barWidth / 2))
            .attr('x2', (barWidth / 2))
            .attr('y1', '0')
            .attr('y2', chart.height)
            .attr('opacity', '0')
            .style('stroke-width', ((barWidth + 2) + 'px'))
            .style('stroke', 'black')
            .on('mouseover', function(d) {
                chart.overlay.selectAll('.highlight-group').filter(function(data) {
                    return _.find(data, (val) => val) === _.find(d, (val) => val);
                }).transition().duration(300).attr('opacity', '1');
                chart.support.selectAll('.highlight-group').filter(function(data) {
                    return _.find(data, (val) => val) === _.find(d, (val) => val);
                }).transition().duration(300).attr('opacity', '1');
            })
            .on('mouseout', function(d) {
                if (!self.showValues) {
                    chart.overlay.selectAll('.highlight-group').filter(function(data) {
                        return _.find(data, (val) => val) === _.find(d, (val) => val);
                    }).transition().duration(300).attr('opacity', '0');
                    chart.support.selectAll('.highlight-group').filter(function(data) {
                        return _.find(data, (val) => val) === _.find(d, (val) => val);
                    }).transition().duration(300).attr('opacity', '0');
                }
            });

        //  Position the tooltip
        tooltipGroup
            .attr('transform', function(d) {
                const xTrans = ((this.getBBox().width / -2) + (barWidth / 2));
                const ratioOfMaxNumber = Math.max(Math.min((d.number / maxValue.number), 1), 0);
                let yTrans = (((1 - ratioOfMaxNumber) * (this.parentElement.getBBox().height)) - this.getBBox().height - 7);

                if (comp.data.showLabels === true && comp.data[0].enableTooltips === true) {
                    yTrans -= 16;
                }

                return 'translate(' + xTrans + ',' + yTrans + ')';
            });

        //  Draw the pointer (triangle) element of the tooltip
        tooltipGroup
            .append('path')
            .attr('d', function() {
                const baseY = this.parentElement.getBBox().height;
                const tipY = 5;
                const width = 10;
                const startX = this.parentElement.getBBox().width / 2 - width / 2;
                const midX = this.parentElement.getBBox().width / 2;
                const endX = this.parentElement.getBBox().width / 2 + width / 2;

                return 'M ' + startX + ' ' + baseY + ' L ' + midX + ' ' + (baseY + tipY) + ' L ' + endX + ' ' + baseY;
            })
            .style('fill', '#494949');
    }

    prepData(data) {
        if (this.chartData.charts[0].sortAscending) {
            return _.orderBy(data, ['number'], ['asc']);
        }
        else if (this.chartData.charts[0].sortDescending) {
            return _.orderBy(data, ['number'], ['desc']);
        }
        return data;
    }

    ngAfterViewInit2() {
        this.chart = new Monte.BarChart(this.chartEl, this.opts);
        this.chart.on('updated', function() {

        }).data(this.prepData(this.data));
    }

    prepData2(data) {
        const src = data.lines;
        const out = [];

        out.maxNumber = data.maxNumber;
        out.minNumber = data.minNumber;
        out.format = data.lines[0].lines[0].format;

        src.forEach((lines, j) => {
            const newLine = {
                values: [],
                css: `line-${j}`,
            };

            if (lines.lines.length === 1) {
                // Handle special case to draw a stright line when only one data point is given.
                newLine.values.push({
                    x: 0,
                    y: lines.lines[0].number,
                    data: lines.lines[0],
                    label: lines.lines[0].label,
                });

                newLine.values.push({
                    x: data.xaxisLabels.length - 1,
                    y: lines.lines[0].number,
                    data: lines.lines[0],
                    label: lines.lines[0].label,
                });
            }
            else {
                data.xaxisLabels.forEach((x, i) => {
                    newLine.values.push({
                        x: i,
                        y: lines.lines[i].number,
                        data: lines.lines[i],
                        label: lines.lines[i].label,
                    });
                });
            }

            out.push(newLine);
        });

        // Reverse lines so lead lines stack on top by default
        return out.reverse();
    }

    checkSize() {
        if (this.chart) {
            this.chart.checkSize();
        }
    }

    update() {
        if (this.chart) {
            this.chart.update();
        }
    }
}
