// This file was generated from the chart scaffold
// Copyright 2018
/* global d3, _ */
import {Component, Input, Output, EventEmitter, ElementRef, ViewEncapsulation} from '@angular/core';
import * as Monte from 'monte';
import template from './VerticalSegmentBarChart.html';
import styles from './VerticalSegmentBarChart.scss';
import chartStyles from './chartCommon.scss';
import {percentFormat, reformatPercent, leadYearFormat} from '../util/format';
import {formatAbbreviation, formatMetdataNumber as formatNumber, formatShortNum, shortNumSymbol} from '../util/numberAbbrv';
import {extendBoundingHeight} from '../util/size';

@Component({
    selector: 'vertical-segment-bar-chart-stacked',
    template: template,
    styles: [styles, chartStyles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <vertical-segment-bar-chart name="VerticalSegmentBarChart" (change)="onChange($event)"></vertical-segment-bar-chart>
 */
export default class VerticalSegmentBarChartStacked {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'VerticalSegmentBarChart';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();

    @Input() data = {};
    @Input() chartSize = '';
    @Input() footerPresent = false;

    legend = [];

    opts = {
        // css: 'no-domain-lines',
        css: 'no-domain-lines monte-axis-no-ticks',
        boundingWidth: 251,
        boundingHeight: 120,
        suppressAxes: ['y'],
        xAxisCustomize: Monte.tools.invokeMany(
            (axis) => axis.tickFormat(leadYearFormat),
            Monte.axisNoTicks
        ),
        yAxisCustomize: (axis) => axis.tickFormat((d) => {
            return formatAbbreviation(d, 1);
        }),
        resize: new Monte.HorizontalResizer(),

        // Follows D3 Margin Convention: https://bl.ocks.org/mbostock/3019563
        margin: {
            top: 15, bottom: 20, left: 35, right: 10,
        },

        transition: {
            duration: 500,
        },

        segmentBarMode: 'stacked',
        xInnerProp: 'type',

        extensions: [
            new Monte.ExtReferenceLine({
                layer: 'support',
                data: function() {
                    const data = this.chart.data();

                    if (data && data.length > 1) {
                        const chart = this.chart;
                        const yProp = chart.option('yProp');
                        const yInnerProp = chart.option('yInnerProp');
                        const datumLast = data[data.length - 1][yProp];
                        const datumLastMaxVal = _.maxBy(datumLast, yInnerProp)[yInnerProp];
                        const allValues = data.reduce((acc, d) => {
                            // Extract all values of individual segments
                            d[yProp].forEach((v) => acc.push(v[yInnerProp]));

                            return acc;
                        }, []);
                        const maxVal = _.max(allValues);
                        const y1 = chart.getScaledProp('y', datumLastMaxVal);
                        const y2 = chart.getScaledProp('y', maxVal);
                        const l = chart.option('margin.left');
                        const last = {
                            x1: -l,
                            x2: chart.width,
                            y1: y1,
                            y2: y1,
                            text: formatNumber(datumLastMaxVal),
                        };
                        const max = {
                            x1: -l,
                            x2: chart.width,
                            y1: y2,
                            y2: y2,
                            text: formatNumber(maxVal),
                        };

                        // If values are identical return only one.
                        if (_.isEqual(last, max)) {
                            return [max];
                        }

                        return [last, max];
                    }

                    return [];
                },
            }),
        ],
    };

    constructor(compEl: ElementRef) {
        this.compEl = d3.select(compEl.nativeElement);
    }

    ngOnDestroy() {
        if (this.chart) {
            this.chart.destroy();
        }
    }

    ngOnChanges() {
        if (this.data && this.chart) {
            this.chart.updateData(this.prepData(this.data));
        }
    }

    quadWideOptions() {
        this.opts.boundingWidth = 670;
        this.opts.boundingHeight = 300;
        this.opts.margin = { top: 20, right: 20, left: 65, bottom: 20 };
        delete this.opts.suppressAxes;
        // this.opts.chartCss = 'text-align: left';
        this.opts.extensions.push(new Monte.ExtHorizontalLines());
        this.opts.css += ' ref-line-focus'; // Give extra focus to ref lines because the y-axis is now showing.
    }

    doubleWideOptions() {
        this.opts.boundingWidth = 385; // 230 / 90
        this.opts.boundingHeight = 250;
        // this.opts.chartCss = 'text-align: left';
    }

    barLabelOptions() {
        this.opts.includeLabels = true;
        this.opts.label = function(value) {
            if (value.format === 'percentage' || value.format === 'percent') {
                return reformatPercent(value.value * 100) + '%';
            }
            return formatShortNum(value.value, 1) + shortNumSymbol(value.value);
        };
        this.opts.labelProp = 'number';
        this.opts.labelXAdjust = function(value, index, textNodes) {
            const labelWidth = textNodes[index].getComputedTextLength();
            return ((labelWidth / 2) * -1);
        };
        this.opts.labelYAdjust = -5;
    }

    barToolTipOptions() {
        //  Make room for the tooltips
        this.opts.margin.top = 27 + (17 * _.get(this, 'data.lines[0].lines.length', 0));
    }

    barLabelAndToolTipOptions() {
        //  Make room for the tooltips
        this.opts.margin.top = 38 + (17 * _.get(this, 'data.lines[0].lines.length', 0));
    }

    ngAfterViewInit() {
        const comp = this;

        //  Delay is required to allow the UI to paint and provide correct dimensions
        _.delay(function(comp) {
            comp.renderChart();

            //  Forces the overlay to be rendered
            comp.checkSize();
        }, 10, comp);
    }

    renderChart() {
        const comp = this;

        if (this.chartSize === 'double') {
            this.doubleWideOptions();
        }
        else if (this.chartSize === 'quadruple') {
            this.quadWideOptions();
        }

        if (!this.footerPresent) {
            extendBoundingHeight(this.opts);
        }

        //  Include optional value labels above the bar
        if (comp.data && comp.data.showLabels === true) {
            this.barLabelOptions();
        }

        //  Include option tooltips that appear over the bar when hovered
        if (comp.data && comp.data.enableTooltips === true) {
            this.barToolTipOptions();
        }

        //  Include both the option value labels and toolstips
        if (comp.data && comp.data.showLabels === true && comp.data && comp.data.enableTooltips === true) {
            this.barLabelAndToolTipOptions();
        }

        this.chart = new Monte.SegmentBarChart(this.compEl.select('.chart-wrap').node(), this.opts)
            .on('boundsUpdated', function() {
                if (comp.data && comp.data.enableTooltips === true) {
                    comp.buildOverlay(comp.prepData(comp.data.lines), this, comp);
                }
            })
            .data(comp.prepData(this.data.lines))
            .checkSize();
    }

    buildOverlay(data, chart, comp) {
        const self = this;
        const tooltipMargin = 7;
        const textSize = 10;
        const circleR = textSize / 1.5;
        const barWidth = chart.x.bandwidth();

        const maxValues = [];
        _.forEach(data, function(d) {
            const maxValue = _.maxBy(d.values, (l) => {
                return (_.isNumber(l.value) === true) ? l.value : 0;
            });
            maxValues.push(maxValue);
        });
        const maxValue = _.maxBy(maxValues, (v) => {
            return (_.isNumber(v.value) === true) ? v.value : 0;
        });

        const getTranslate = function(element) {
            const transform = element.getAttribute('transform');
            return transform.substring(transform.indexOf('(') + 1, transform.indexOf(')')).split(',')
                .map((cur) => parseFloat(cur));
        };

        const highlightGroup = chart.overlay.selectAll('g.highlight-group').data(data);

        const highlightGroupEnter = highlightGroup
            .enter()
            .append('g')
            .classed('highlight-group', true)
            .attr('opacity', '0');

        highlightGroup
            .attr('transform', function(d) {
                const xVal = d.label;
                return 'translate(' + chart.getScaledProp('x', xVal) + ',' + 0 + ')';
            });

        const tooltipGroup = highlightGroupEnter
            .append('g')
            .classed('tooltip-group', true);

        const allDataPointGroup = tooltipGroup
            .append('g')
            .classed('all-datapoint-group', true)
            .attr('transition', function() {
                return 'translate(0,' + textSize + ')';
            });

        const dataPointGroup = allDataPointGroup.selectAll('g.datapoint-group').data(function(d) {
            return d.values;
        })
            .enter()
            .filter(function(d) {
                return d.value !== undefined;
            })
            .append('g')
            .classed('datapoint-group', true)
            .sort(function(a, b) {
                return a.y > b.y ? -1 : 1;
            })
            .attr('transform', function(d, i, nodes) {
                const transY = nodes[i - 1] ? getTranslate(nodes[i - 1])[1] + textSize + 10 : textSize + 9;
                return 'translate(0,' + transY + ')';
            });

        dataPointGroup
            .append('text')
            .text(function(value) {
                if (value.format === 'percentage' || value.format === 'percent') {
                    return reformatPercent(value.value * 100) + '%';
                }
                return formatShortNum(value.value, 1) + shortNumSymbol(value.value);
            })
            .attr('x', (textSize + 12))
            .attr('y', -3)
            .style('font-size', textSize)
            .style('fill', 'white');

        dataPointGroup
            .filter(function(d) {
                return d;
            })
            .append('circle')
            .attr('r', circleR)
            .attr('cx', circleR + 5)
            .attr('cy', -circleR)
            .attr('stroke-width', '2px')
            .style('stroke', 'rgba(255, 255, 255, .3)')
            .attr('class', (d) => d.css);

        tooltipGroup
            .insert('rect', 'g')
            .attr('width', function() {
                return this.parentElement.getBBox().width + 2 * tooltipMargin;
            })
            .attr('height', function() {
                return this.parentElement.getBBox().height + 2 * tooltipMargin;
            })
            .attr('rx', circleR)
            .attr('ry', circleR)
            .style('fill', '#494949');

        const lineHighlightGroup = highlightGroupEnter
            .append('g')
            .classed('line-group', true);

        //  Draw the target to trigger the tooltip's appearance
        lineHighlightGroup
            .append('line')
            .classed('highlight-target', true)
            .attr('x1', (barWidth / 2))
            .attr('x2', (barWidth / 2))
            .attr('y1', '0')
            .attr('y2', chart.height)
            .attr('opacity', '0')
            .style('stroke-width', ((barWidth + 2) + 'px'))
            .style('stroke', 'black')
            .on('mouseover', function(d) {
                chart.overlay.selectAll('.highlight-group').filter(function(data) {
                    return _.find(data, (val) => val) === _.find(d, (val) => val);
                }).transition().duration(300).attr('opacity', '1');
                chart.support.selectAll('.highlight-group').filter(function(data) {
                    return _.find(data, (val) => val) === _.find(d, (val) => val);
                }).transition().duration(300).attr('opacity', '1');
            })
            .on('mouseout', function(d) {
                if (!self.showValues) {
                    chart.overlay.selectAll('.highlight-group').filter(function(data) {
                        return _.find(data, (val) => val) === _.find(d, (val) => val);
                    }).transition().duration(300).attr('opacity', '0');
                    chart.support.selectAll('.highlight-group').filter(function(data) {
                        return _.find(data, (val) => val) === _.find(d, (val) => val);
                    }).transition().duration(300).attr('opacity', '0');
                }
            });

        //  Position the tooltip
        tooltipGroup
            .attr('transform', function(d) {
                const xTrans = ((this.getBBox().width / -2) + (barWidth / 2));
                const groupMaxValue = _.maxBy(d.values, (v) => {
                    return (_.isNumber(v.value) === true) ? v.value : 0;
                });
                const ratioOfMaxNumber = Math.max(Math.min((groupMaxValue.value / maxValue.value), 1), 0);
                let yTrans = (((1 - ratioOfMaxNumber) * (this.parentElement.getBBox().height)) - this.getBBox().height - 7);

                if (comp.data.includeBarLabels === true && comp.data.enableTooltips === true) {
                    yTrans -= 16;
                }

                return 'translate(' + xTrans + ',' + yTrans + ')';
            });

        //  Draw the pointer (triangle) element of the tooltip
        tooltipGroup
            .append('path')
            .attr('d', function() {
                const baseY = this.parentElement.getBBox().height;
                const tipY = 5;
                const width = 10;
                const startX = this.parentElement.getBBox().width / 2 - width / 2;
                const midX = this.parentElement.getBBox().width / 2;
                const endX = this.parentElement.getBBox().width / 2 + width / 2;

                return 'M ' + startX + ' ' + baseY + ' L ' + midX + ' ' + (baseY + tipY) + ' L ' + endX + ' ' + baseY;
            })
            .style('fill', '#494949');
    }

    prepData(lines) {
        const out = [];
        this.legend.length = 0; // Clear current legend

        lines.forEach((d) => {
            if (d) {
                out.push({
                    id: d.lines[0].axisLabel,
                    label: d.lines[0].axisLabel,
                    values: formatNumbers(filterNumbers(d.lines)),
                });
            }
        });

        if (lines.length) {
            lines[0].lines.forEach((d, i) => {
                this.legend.push({
                    label: d.label,
                    css: `segment-${i}`,
                });
            });
        }

        return out;
    }

    checkSize() {
        if (this.chart) {
            this.chart.checkSize();
        }
    }
}

function filterNumbers(numbers) {
    const out = [];

    numbers.forEach((n) => {
        if (n.number > 0) {
            out.push(n);
        }
    });

    return out;
}

function formatNumbers(numbers) {
    const out = [];

    numbers.forEach((d, i) => {
        out.push({
            value: d.number,
            label: `${getLabel(d)}`,
            type: d.label,
            css: `segment-${i}`,
        });
    });

    return out;
}

function getLabel(number) {
    if (number && number.percentOfTotal) {
        return `${number.number} / ${percentFormat(number.percentOfTotal)}`;
    }
    return number.label;
}
