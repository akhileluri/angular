// This file was generated from the chart scaffold
// Copyright 2017

import {Component, Injector} from '@angular/core';
import Choropleth from './Choropleth';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [Choropleth],
    template: ''
})
class TestComponent {}

describe('chart/Choropleth.js', () => {

    beforeEach(() => {
        addProviders([Choropleth]);
    });

    it('should return component name', inject([Choropleth], (choropleth:Choropleth) => {
        expect(choropleth.name).toBe('Choropleth');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<choropleth></choropleth>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('choropleth h1').innerText).toBe('Choropleth');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<choropleth name="TEST"></choropleth>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('choropleth h1').innerText).toBe('TEST');
            });
    })));

});
