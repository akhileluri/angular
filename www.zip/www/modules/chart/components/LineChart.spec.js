// This file was generated from the chart scaffold
// Copyright 2016

import {Component, Injector} from '@angular/core';
import LineChart from './LineChart';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [LineChart],
    template: ''
})
class TestComponent {}

describe('chart/LineChart.js', () => {

    beforeEach(() => {
        addProviders([LineChart]);
    });

    it('should return component name', inject([LineChart], (lineChart:LineChart) => {
        expect(lineChart.name).toBe('LineChart');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<line-chart></line-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('line-chart h1').innerText).toBe('LineChart');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<line-chart name="TEST"></line-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('line-chart h1').innerText).toBe('TEST');
            });
    })));

});
