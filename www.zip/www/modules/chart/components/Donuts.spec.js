// This file was generated from the component scaffold
// Copyright 2016

import {Component, Injector} from '@angular/core';
import Donuts from './Donuts';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [Donuts],
    template: ''
})
class TestComponent {}

describe('chart/Donuts.js', () => {

    beforeEach(() => {
        addProviders([Donuts]);
    });

    it('should return component name', inject([Donuts], (Donuts:Donuts) => {
        expect(Donuts.name).toBe('Donuts');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<donuts></donuts>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('donuts h1').innerText).toBe('Donuts');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<donuts name="TEST"></donuts>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('donuts h1').innerText).toBe('TEST');
            });
    })));

});
