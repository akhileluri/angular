// This file was generated from the chart scaffold
// Copyright 2018

import {Component, Injector} from '@angular/core';
import VerticalBarLineChart from './VerticalBarLineChart';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [VerticalBarLineChart],
    template: ''
})
class TestComponent {}

describe('chart/VerticalBarLineChart.js', () => {

    beforeEach(() => {
        addProviders([VerticalBarLineChart]);
    });

    it('should return component name', inject([VerticalBarLineChart], (verticalBarLineChart:VerticalBarLineChart) => {
        expect(verticalBarLineChart.name).toBe('VerticalBarLineChart');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<vertical-bar-line-chart></vertical-bar-line-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('vertical-bar-line-chart h1').innerText).toBe('VerticalBarLineChart');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<vertical-bar-line-chart name="TEST"></vertical-bar-line-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('vertical-bar-line-chart h1').innerText).toBe('TEST');
            });
    })));

});
