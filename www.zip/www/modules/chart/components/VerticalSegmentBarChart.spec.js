// This file was generated from the chart scaffold
// Copyright 2018

import {Component, Injector} from '@angular/core';
import VerticalSegmentBarChart from './VerticalSegmentBarChart';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [VerticalSegmentBarChart],
    template: ''
})
class TestComponent {}

describe('chart/VerticalSegmentBarChart.js', () => {

    beforeEach(() => {
        addProviders([VerticalSegmentBarChart]);
    });

    it('should return component name', inject([VerticalSegmentBarChart], (verticalSegmentBarChart:VerticalSegmentBarChart) => {
        expect(verticalSegmentBarChart.name).toBe('VerticalSegmentBarChart');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<vertical-segment-bar-chart></vertical-segment-bar-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('vertical-segment-bar-chart h1').innerText).toBe('VerticalSegmentBarChart');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<vertical-segment-bar-chart name="TEST"></vertical-segment-bar-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('vertical-segment-bar-chart h1').innerText).toBe('TEST');
            });
    })));

});
