// This file was generated from the chart scaffold
// Copyright 2016
/* global d3, _ */
import { Component, Input, Output, EventEmitter, ElementRef, ViewEncapsulation } from '@angular/core';
import * as Monte from 'monte';
import template from './LineChart.html';
import styles from './LineChart.scss';

import { formatMetdataNumber as formatNumber } from '../util/numberAbbrv';
import { leadYearFormat } from '../util/format';
import { labelOverlapAvoidance } from '../extension/ExtHorizontalRef';
import { addFlag, updateFlag, lineChartFlagUpdateCycle } from '../extension/edgeFlag';

const MODE_DIFFERENCE = 'difference';

@Component({
    selector: 'line-chart',
    template: template,
    styles: [styles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <line-chart name='LineChart' (change)='onChange($event)'></line-chart>
 */
export default class LineChart {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name: string = 'LineChart';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change: EventEmitter = new EventEmitter();

    @Input() data = {};
    @Input() mode = '';
    @Input() difference = null;
    @Input() chartSize = '';
    @Input() footerPresent = false;

    opts = {
        css: 'no-domain-lines',
        boundingWidth: 240,
        boundingHeight: 90,
        suppressAxes: ['y'],
        lineCss: 'positive',
        pointCss: 'positive',

        includePoints: true,

        // Follows D3 Margin Convention: https://bl.ocks.org/mbostock/3019563
        margin: {
            top: 14,
            bottom: 17,
            left: 30,
            right: 30,
        },

        marginRightWithoutFlags: 20,
        flagXShift: 5,

        xAxisCustomize: Monte.tools.invokeMany(
            (axis) => {
                // Map out tick values that match the indexes of the labels. That way the Axis label
                // text can be looked up and inserted directly.
                const tickValues = this.data.xaxisLabels.map((d, i) => i);
                const tickCount = tickValues.length;
                const labelsQuantity = 5;
                function indexMap(tickCount, labelsQuantity) {
                    const initialOffset = Math.round(tickCount / labelsQuantity);
                    let min = initialOffset - 1;
                    let max = (tickCount - initialOffset);
                    let range = max - min;
                    while (range % (range / (labelsQuantity - 2)) !== 0) {
                        if (range % 2 === 0) {
                            min += 1;
                            range = max - min;
                        }
                        else {
                            max -= 1;
                            range = max - min;
                        }
                    }
                    const labelPoints = [0];
                    for (let i = min; i <= max; i++) {
                        if (i % (range / (labelsQuantity - 2)) === 0) {
                            labelPoints.push(i);
                        }
                    }
                    labelPoints.push(tickCount - 1);
                    return labelPoints;
                }
                const labelPoints = indexMap(tickCount, labelsQuantity);
                axis.tickSize(0)
                    .tickValues(tickValues)
                    .tickFormat((d, i) => {
                        if (Number.isInteger(d) && tickCount <= labelsQuantity) {
                            const v = this.data.xaxisLabels[d];
                            return leadYearFormat(v, i);
                        }
                        else if (Number.isInteger(d) && labelPoints.indexOf(i) > -1) {
                            const v = this.data.xaxisLabels[d];
                            return leadYearFormat(v, i);
                        }
                        return '';
                    })
                    .tickPadding(10);
            },
            Monte.axisNoTicks
        ),

        extensions: [
            new Monte.ExtReferenceLine({

                layer: 'support',
                data: function() {
                    const data = this.chart.data();
                    const maxNumber = { number: data.maxNumber, format: data.format };
                    const minNumber = { number: data.minNumber, format: data.format };
                    const minLinePosition = 59;
                    const maxLinePosition = 0;
                    if (data && data.length >= 1) {
                        const chart = this.chart;
                        const l = chart.option('margin.left');
                        const max = {
                            x1: -l + 5,
                            x2: chart.width,
                            y1: maxLinePosition,
                            y2: maxLinePosition,
                            text: formatNumber(maxNumber),
                        };
                        const min = {
                            x1: -l + 5,
                            x2: chart.width,
                            y1: minLinePosition,
                            y2: minLinePosition,
                            text: formatNumber(minNumber),
                        };

                        return [min, max];
                    }
                    else {
                        return [];
                    }
                },
            }),
        ],

        resize: new Monte.HorizontalResizer(),
    };

    differenceOpts = {
        margin: { right: 50 },
        extensions: [
            new Monte.ExtReferenceLine({
                layer: 'support',
                data: function() {
                    const data = this.chart.data();
                    if (data && data.length >= 1) {
                        const line = data[0].values;
                        const chart = this.chart;
                        const datumLast = line[line.length - 1];
                        const diffVal = {
                            data: this.chart.differenceNumber,
                            y: this.chart.differenceNumber.number,
                        };
                        const y1 = chart.getScaledProp('y', datumLast);
                        const y2 = chart.getScaledProp('y', diffVal);
                        const l = chart.option('margin.left');
                        const last = {
                            x1: -l,
                            x2: chart.width,
                            y1: y1,
                            y2: y1,
                            text: formatNumber(datumLast.data),
                            data: datumLast,
                        };
                        const diff = {
                            x1: -l,
                            x2: chart.width,
                            y1: y2,
                            y2: y2,
                            text: formatNumber(diffVal.data),
                            isDiffLine: true,
                            diffLabel: this.chart.differenceNumber.label,
                            data: diffVal,
                        };

                        // If values are identical return only one.
                        if (_.isEqual(last, diff)) {
                            return [diff];
                        }

                        return [last, diff];
                    }
                    else {
                        return [];
                    }
                },
            }),
        ],
    };

    constructor(chartEl: ElementRef) {
        this.chartEl = d3.select(chartEl.nativeElement).node();
    }

    ngOnDestroy() {
        if (this.chart) {
            this.chart.destroy();
        }
    }

    ngOnChanges() {
        if (this.data && this.chart) {
            this.chart.updateData(this.prepData(this.data));
        }
    }

    ngAfterViewInit() {
        const comp = this;

        //  Delay is required to allow the UI to paint and provide correct dimensions
        _.delay(function(comp) {
            comp.renderChart();
        }, 10, comp);
    }

    renderChart() {
        const comp = this;
        let opts = this.opts;

        if (this.mode === MODE_DIFFERENCE) {
            opts = Monte.tools.mergeOptions(this.differenceOpts, opts);
        }

        const $container = $($(this.chartEl.node()).closest('chart-selector'));

        //  Set final dimensions based on the available space created by the flexbox layout
        this.opts.boundingWidth = $container.width();
        this.opts.boundingHeight = $container.height();

        this.chart = new Monte.LineChart(this.chartEl, opts);
        this.chart.differenceNumber = _.get(this, 'difference.numbers[0]');

        this.chart.on('updated', function() {
            if (comp.mode === MODE_DIFFERENCE) {
                return;
            }

            // Add flags for all suporting lines (i.e. exclude the top/primary line)
            const flagData = this.data().slice(0, -1);
            lineChartFlagUpdateCycle(this, flagData);
        })
        .on('extension', function(extEv) {
            if (comp.mode === MODE_DIFFERENCE) {
                if (extEv === 'refline:updated') {
                    const refData = [];
                    // Find the "diff" line. Add class and extra label.
                    const grps = this.support.selectAll('.monte-ext-ref-line-grp')
                        .classed('diff-line', (d) => d.isDiffLine)
                        .each((d) => refData.push(d.data));

                    // Add tspan with Diff Label
                    const diffLabel = grps.filter((d) => d.isDiffLine).select('text');
                    const curLabel = diffLabel.text();
                    if (curLabel) {
                        diffLabel.attr('dy', '-1.35em');
                        diffLabel.text('').append('tspan').text((d) => d.diffLabel);
                        diffLabel.append('tspan')
                            .attr('dy', '1em')
                            .attr('x', diffLabel.attr('x'))
                            .text(curLabel);
                    }

                    // Draw a line between the two ref lines.
                    if (grps.nodes().length === 2) {
                        const l0 = d3.select(grps.nodes()[0]).select('line');
                        const l1 = d3.select(grps.nodes()[1]).select('line');
                        const x = l0.attr('x2');
                        const y1 = l0.attr('y1');
                        const y2 = l1.attr('y1');

                        // Draw "gap" line connecting the two ref lines.
                        const gap = this.support.selectAll('.gap-line').data([{ x, y1, y2 }]);
                        gap.enter().append('line')
                            .classed('gap-line', true)
                            .merge(gap)
                            .attr('x1', (d) => d.x)
                            .attr('x2', (d) => d.x)
                            .attr('y1', (d) => d.y1)
                            .attr('y2', (d) => d.y2);

                        // Add flags for gap line
                        const flags = this.overlay.selectAll('.flag-contain-grp').data(refData);

                        flags.enter().append('g')
                            .attr('class', 'flag-contain-grp')
                            .each((d, i, nodes) => {
                                const grp = d3.select(nodes[i]);

                                if (d) { // Add annotation flag
                                    const flagX = +x + this.option('flagXShift');
                                    const flagY = (+y1 + +y2) / 2;
                                    const lbl = {
                                        number: Math.abs(refData[1].data.number - refData[0].data.number),
                                        format: refData[0].data.format,
                                        currencyCode: refData[0].data.currencyCode,
                                    };
                                    addFlag.call(this, grp, flagX, flagY, formatNumber(lbl));
                                }
                            });

                        flags.each((d, i, nodes) => {
                            const grp = d3.select(nodes[i]);

                            if (d) { // Update annotation flag
                                const flagX = +x + this.option('flagXShift');
                                const flagY = (+y1 + +y2) / 2;
                                const lbl = {
                                    number: Math.abs(refData[1].data.number - refData[0].data.number),
                                    format: refData[0].data.format,
                                    currencyCode: refData[0].data.currencyCode,
                                };
                                updateFlag.call(this, grp, flagX, flagY, formatNumber(lbl));
                            }
                        });

                        flags.exit().remove();
                    }
                }
            }

            labelOverlapAvoidance.apply(this, arguments);
        })
        .data(this.prepData(this.data));
    }

    prepData(data) {
        const src = data.lines;
        const out = [];
        out.maxNumber = data.maxNumber;
        out.minNumber = data.minNumber;
        out.format = data.lines[0].lines[0].format;

        src.forEach((lines, j) => {
            const newLine = {
                values: [],
                css: `line-${j}`,
            };

            if (lines.lines.length === 1) {
                // Handle special case to draw a stright line when only one data point is given.
                newLine.values.push({
                    x: 0,
                    y: lines.lines[0].number,
                    data: lines.lines[0],
                    label: lines.lines[0].label,
                });

                newLine.values.push({
                    x: data.xaxisLabels.length - 1,
                    y: lines.lines[0].number,
                    data: lines.lines[0],
                    label: lines.lines[0].label,
                });
            }
            else {
                data.xaxisLabels.forEach((x, i) => {
                    newLine.values.push({
                        x: i,
                        y: lines.lines[i].number,
                        data: lines.lines[i],
                        label: lines.lines[i].label,
                    });
                });
            }

            out.push(newLine);
        });

        // Reverse lines so lead lines stack on top by default
        return out.reverse();
    }

    checkSize() {
        if (this.chart) {
            this.chart.checkSize();
        }
    }

    update() {
        if (this.chart) {
            this.chart.update();
        }
    }
}
