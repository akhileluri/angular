// This file was generated from the chart scaffold
// Copyright 2018

import {Component, Injector} from '@angular/core';
import GaugeBarPair from './GaugeBarPair';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [GaugeBarPair],
    template: ''
})
class TestComponent {}

describe('chart/GaugeBarPair.js', () => {

    beforeEach(() => {
        addProviders([GaugeBarPair]);
    });

    it('should return component name', inject([GaugeBarPair], (gaugeBarPair:GaugeBarPair) => {
        expect(gaugeBarPair.name).toBe('GaugeBarPair');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<gauge-bar-pair></gauge-bar-pair>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('gauge-bar-pair h1').innerText).toBe('GaugeBarPair');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<gauge-bar-pair name="TEST"></gauge-bar-pair>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('gauge-bar-pair h1').innerText).toBe('TEST');
            });
    })));

});
