// This file was generated from the chart scaffold
// Copyright 2016

import {Component, Injector} from '@angular/core';
import Sparkline from './Sparkline';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [Sparkline],
    template: ''
})
class TestComponent {}

describe('chart/Sparkline.js', () => {

    beforeEach(() => {
        addProviders([Sparkline]);
    });

    it('should return component name', inject([Sparkline], (sparkline:Sparkline) => {
        expect(sparkline.name).toBe('Sparkline');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<sparkline></sparkline>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('sparkline h1').innerText).toBe('Sparkline');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<sparkline name="TEST"></sparkline>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('sparkline h1').innerText).toBe('TEST');
            });
    })));

});
