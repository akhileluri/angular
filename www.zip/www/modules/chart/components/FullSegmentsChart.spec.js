// This file was generated from the chart scaffold
// Copyright 2016

import {Component, Injector} from '@angular/core';
import FullSegmentsChart from './FullSegmentsChart';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [FullSegmentsChart],
    template: ''
})
class TestComponent {}

describe('chart/FullSegmentsChart.js', () => {

    beforeEach(() => {
        addProviders([FullSegmentsChart]);
    });

    it('should return component name', inject([FullSegmentsChart], (fullSegmentsChart:FullSegmentsChart) => {
        expect(fullSegmentsChart.name).toBe('FullSegmentsChart');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<full-segments-chart></full-segments-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('full-segments-chart h1').innerText).toBe('FullSegmentsChart');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<full-segments-chart name="TEST"></full-segments-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('full-segments-chart h1').innerText).toBe('TEST');
            });
    })));

});
