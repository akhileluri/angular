// This file was generated from the component scaffold
// Copyright 2016

import {Component, Injector} from '@angular/core';
import VerticalBarChart from './VerticalBarChart';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [VerticalBarChart],
    template: ''
})
class TestComponent {}

describe('chart/VerticalBarChart.js', () => {

    beforeEach(() => {
        addProviders([VerticalBarChart]);
    });

    it('should return component name', inject([VerticalBarChart], (verticalBarChart:VerticalBarChart) => {
        expect(verticalBarChart.name).toBe('VerticalBarChart');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<vertical-bar-chart></vertical-bar-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('vertical-bar-chart h1').innerText).toBe('VerticalBarChart');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<vertical-bar-chart name="TEST"></vertical-bar-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('vertical-bar-chart h1').innerText).toBe('TEST');
            });
    })));

});
