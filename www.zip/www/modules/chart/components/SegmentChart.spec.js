// This file was generated from the chart scaffold
// Copyright 2016

import {Component, Injector} from '@angular/core';
import SegmentChart from './SegmentChart';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [SegmentChart],
    template: ''
})
class TestComponent {}

describe('chart/SegmentChart.js', () => {

    beforeEach(() => {
        addProviders([SegmentChart]);
    });

    it('should return component name', inject([SegmentChart], (segmentChart:SegmentChart) => {
        expect(segmentChart.name).toBe('SegmentChart');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<segment-chart></segment-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('segment-chart h1').innerText).toBe('SegmentChart');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<segment-chart name="TEST"></segment-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('segment-chart h1').innerText).toBe('TEST');
            });
    })));

});
