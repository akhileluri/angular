// This file was generated from the chart scaffold
// Copyright 2017
/* global d3 _ */
import {Component, Input, Output, EventEmitter, ElementRef, ViewEncapsulation, ChangeDetectorRef} from '@angular/core';
import * as Monte from 'monte';
import * as monteExtD3Tip from 'monte-ext-d3-tip';
import template from './Choropleth.html';
import styles from './Choropleth.scss';

import {formatMetdataNumber} from '../util/numberAbbrv';

import usGeodata from '../geodata/us.json';
// import chinaGeodata from '../geodata/china.json';

const HEIGHT_SCALE_RATIO = 1.9;
const MAX_SCALE = 2800;

@Component({
    selector: 'choropleth',
    template: template,
    styles: [styles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <choropleth name="Choropleth" (change)="onChange($event)"></choropleth>
 */
export default class Choropleth {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'Choropleth';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();

    @Input() data = {};
    @Input() chartSize = {};
    @Input() isMinWidth: string = 'medium';

    @Input() footerPresent = false;

    displayCount = 1;

    transformedData = {
        values: [],
        legend: [],
    };

    legend = [];
    secondaryLegend = [];

    opts = {
        directUse: true,
        chartCss: 'monte-map',

        boundingWidth: 260,
        boundingHeight: 110,

        // Follows D3 Margin Convention: https://bl.ocks.org/mbostock/3019563
        margin: {
            top: 0, bottom: 0, left: 0, right: 0,
        },
        projectionScale: 150 * HEIGHT_SCALE_RATIO,

        // D3 Projection
        projection: function() {
            const w = this.width;
            const h = this.height;
            let scale = this.option('projectionScale');

            if (scale > MAX_SCALE) {
                scale = MAX_SCALE;
            }

            return d3.geoAlbersUsa()
              .translate([w / 2, h / 2])  // translate to center of screen
              .scale([scale]);            // scale things down so see entire US
        },

        // Define path generator
        path: function(projection) {
            return d3.geoPath()         // path generator that will convert GeoJSON to SVG paths
              .projection(projection);  // tell path generator to use albersUsa projection
        },

        usGeodata,

        // Must use a function to generate the extensions so that two maps don't attempt to use the
        // same extension instance.
        extensions: function() {
            const isSecondary = this.opts.isSecondary;
            const css = 'd3-tip breakdown choropleth-tip' + (isSecondary ? ' secondary' : '');

            return [
                new monteExtD3Tip.ExtD3Tip({
                    featurePrefix: 'state',
                    offset: -5,
                    css,
                    html: function(d) {
                        const title = d.properties.name;
                        const displaySwitch = d.stateValue.number.trend && d.stateValue.number.trend === 'noDisplayValue';
                        const displayRaw = d.stateValue.number.trend && d.stateValue.number.trend === 'dontFormatValue';
                        const displayValue = displaySwitch ? '' : displayRaw ? +(d.stateValue.number.number).toFixed(4) : formatMetdataNumber(d.stateValue.number, 'N/A', 2);

                        const percentageChange = formatMetdataNumber(d.stateValue.number, '', 2, true);
                        const percentString = percentageChange === '' ? '' : '% Change: ' + percentageChange;
                        const rangeClass = d.stateValue.className;
                        const rangeValue = d.stateValue.value;

                        return `<div class='tooltip-title'>${title}</div>` +
                            `<div class='tooltip-major-value'>${displayValue}</div>` +
                            '<div class="tooltip-hr"></div>' +
                            `<div><span class='subtle'>${percentString}</span></div>` +
                            `<div><span class='indicator ${rangeClass}'></span> <span class='subtle'>${rangeValue}</span></div>`;
                    },
                    hideEvents: ['click'],
                }),
            ];
        },

        customEvents: Monte.tools.commonEventNames('state'),
        includeTitle: false,
    };

    constructor(compEl: ElementRef, ref:ChangeDetectorRef) {
        this.compEl = d3.select(compEl.nativeElement).node();
        this.ref = ref;
    }

    ngOnDestroy() {
        if (this.chart) {
            this.chart.destroy();
        }

        if (this.secondaryChart) {
            this.secondaryChart.destroy();
        }
    }

    ngOnChanges() {
        const comp = this;

        this.displayCount = this.hasSecondChart();
        if (this.data && this.chart) {
            this.chart.updateData(this.prepData(this.data));

            if (this.displayCount === 2) {
                if (!this.secondaryChart) {
                    this.secondaryChart = this.buildMap(this.compEl.querySelector('#secondary-choropleth'), this.prepData(this.data, 1), comp);
                }
                else {
                    this.secondaryChart.updateData(this.prepData(this.data), 1);
                }
            }
        }
    }

    ngOnInit() {
        if (matchMedia) {
            this.mediaQuery = window.matchMedia('(max-width: 767px)');
            this.mediaQuery.addListener(this.widthChange.bind(this));
            this.widthChange(this.mediaQuery);
        }
    }

    widthChange(mq) {
        if (mq.matches) {
            this.isMinWidth = 'small';
        }
        else {
            this.isMinWidth = 'large';
        }
        this.displayCount = this.hasSecondChart();
    }

    ngAfterViewInit() {
        const comp = this;
        if (this.data.charts[0].showIndicators === true) {
            comp.renderLegend(this.data, 0);

            if (this.displayCount === 2) {
                comp.renderLegend(this.data, 1);
            }
        }


        //  Delay is required to allow the UI to paint and provide correct dimensions
        _.delay(function(comp) {
            comp.renderChart();
        }, 10, comp);
    }

    renderLegend(data, activeChartIndex = 0) {
        const legendMap = {};
        let activeLegend;

        if (activeChartIndex === 0) {
            activeLegend = this.legend;
            this.legend.length = 0; // Clear array, but keep same reference.
        }
        else if (activeChartIndex === 1) {
            activeLegend = this.secondaryLegend;
            this.secondaryLegend.length = 0; // Clear array, but keep same reference.
        }

        let classCount = 0;
        const classMap = {};
        let className = '';
        _.forEach(data.stateCategoriesData[activeChartIndex], (v) => {
            if (v !== null) {
                if (!classMap[v]) {
                    className = 'color' + data.orderedLabels[activeChartIndex].indexOf(v);
                    classCount++;
                }
                else {
                    className = classMap[v].className;
                }

                if (!legendMap[v]) {
                    legendMap[v] = {
                        label: v,
                        css: className,
                        count: 0,
                    };
                }

                legendMap[v].count++;
            }
        });

        for (let i = 0; i < data.orderedLabels[activeChartIndex].length; i++) {
            if (legendMap[data.orderedLabels[activeChartIndex][i]]) {
                activeLegend.push(legendMap[data.orderedLabels[activeChartIndex][i]]);
            }
        }

        this.ref.detectChanges();
    }

    renderChart() {
        const comp = this;

        const $container = $($(this.compEl).closest('chart-selector'));
        const $overview = $($container.find('.overview-text'));
        const legends = $(this.compEl).find('ul.choropleth-category-legend');

        //  Set final dimensions based on the available space created by the flexbox layout
        this.opts.boundingWidth = $container.width();
        this.opts.boundingHeight = $container.height();

        // const stateScale = d3.scaleOrdinal;
        // this.transformedData = this.prepData(this.data);

        //  Make room for the overview text
        const overviewWidth = $overview.outerWidth();

        if (this.chartSize === 'double') {
            this.opts.boundingWidth -= overviewWidth;
        }


        //  Handle the existence of a second chart (modifies the first chart to include a title)
        if (this.displayCount === 2) {
            this.opts.includeTitle = true;
            this.opts.margin.top = 20;
            this.opts.boundingWidth = (this.opts.boundingWidth / 2);
        }

        //  Make room for the first legend
        const $legend = $(legends[0]);
        const legendWidth = $legend.outerWidth();
        const legendHeight = $legend.outerHeight();

        switch (this.chartSize) {
        case 'quadruple':
            this.opts.boundingWidth -= legendWidth;
            this.opts.boundingWidth = Math.min(450, Math.max(this.opts.boundingWidth, 200));
            this.opts.boundingHeight = this.opts.boundingWidth / 1.5282;
            break;
        case 'double':
            this.opts.boundingHeight -= legendHeight;
            break;
        case 'single':
            this.opts.boundingHeight -= legendHeight;
            break;
        default:
            this.opts.boundingHeight -= legendHeight;
        }

        //  Calculate a pleasing projection scale
        this.opts.projectionScale = this.calculateProjectionScale(this.opts.boundingWidth, this.opts.boundingHeight);

        //  Render the primary chart
        this.chart = this.buildMap(this.compEl.querySelector('#primary-choropleth'), this.prepData(this.data), comp);

        if (this.displayCount === 2) {
            // NOTE: Updating options isn't an issue because Monte does deep clones and changing
            //       by-value options won't affect other charts.
            this.opts.isSecondary = true;

            //  Make room for the second legend
            const $secondaryLegend = $(legends[1]);
            const secondaryLegendWidth = $secondaryLegend.outerWidth();
            const secondaryLegendHeight = $secondaryLegend.outerHeight();

            switch (this.chartSize) {
            case 'quadruple':
                this.opts.boundingWidth = (this.opts.boundingWidth + legendWidth) - secondaryLegendWidth;
                this.opts.boundingWidth = Math.max(this.opts.boundingWidth, 200);
                // this.opts.boundingHeight = this.opts.boundingWidth / 1.5282;
                break;
            case 'double':
                this.opts.boundingHeight = (this.opts.boundingHeight + legendHeight) - secondaryLegendHeight;
                break;
            case 'single':
                this.opts.boundingHeight = (this.opts.boundingHeight + legendHeight) - secondaryLegendHeight;
                break;
            default:
                this.opts.boundingHeight = (this.opts.boundingHeight + legendHeight) - secondaryLegendHeight;
            }

            // Render the secondary chart
            this.secondaryChart = this.buildMap(this.compEl.querySelector('#secondary-choropleth'), this.prepData(this.data, 1), comp);
        }
    }

    buildMap(el, data, comp) {
        return new Monte.Chart(el, this.opts)
            .call(function() {
                // Create function for updating projection when demensions of the chart change.
                this.updateProjection = () => {
                    this.projection = this.option('projection').call(this);
                    this.path = this.option('path').call(this, this.projection);
                };
            })
            .on('beforeRender', function() {
                this.updateProjection();
            })
            .on('boundsUpdated', function() {
                window.console.info('boundsUpdated');
                this.option('projectionScale', comp.calculateProjectionScale(this.width, this.height));
                this.updateProjection();
            })
            .on('updated', function() {
                // Bind the data to the SVG and create one path per GeoJSON feature
                const states = this.draw.selectAll('.state').data(this.option('usGeodata').features);
                const stateValues = this.data().states;

                states.enter().append('path')
                    .attr('class', (d) => d.properties.name.toLowerCase().replace(/\s+/, '-'))
                    .classed('state', true)
                    .call(this.__bindCommonEvents('state'))
                    .each((d) => d.stateValue = stateValues[d.properties.name])
                    .merge(states)
                        .attr('class', (d) => `state ${d && d.properties && d.properties.name && stateValues[d.properties.name] ? stateValues[d.properties.name].className : ''}`)
                        .attr('d', this.path);

                states.exit().remove();

                const titleData = this.option('includeTitle') ? [this.data().label] : [];
                const label = this.support.selectAll('.chart-label').data(titleData);
                label.enter().append('text')
                    .attr('class', 'chart-label')
                    .attr('y', 1)
                    .attr('text-anchor', 'middle')
                    .merge(label)
                        .attr('x', this.width / 2)
                        .text((d) => d);

                label.exit().remove();
            })
            .data(data);
    }

    prepData(data, activeChartIndex = 0) {
        const catClass = {}; // Keys: state name, Values: category transformed to kebab case.

        let classCount = 0;
        const classMap = {};
        let className = '';
        _.forEach(data.stateCategoriesData[activeChartIndex], (v, k) => {
            if (v !== null) {
                if (!classMap[v]) {
                    className = 'color' + data.orderedLabels[activeChartIndex].indexOf(v);
                    classMap[v] = { className };
                    classCount++;
                }
                else {
                    className = classMap[v].className;
                }

                catClass[k] = {
                    className,
                    value: v,
                    number: _.find(data.charts[activeChartIndex].numbers, { indicator: k }),
                };
            }
        });

        return {
            states: catClass,
            label: data.charts[activeChartIndex].label,
        };
    }

    checkSize() {
        if (this.chart) {
            this.chart.checkSize();
        }

        if (this.secondaryChart) {
            this.secondaryChart.checkSize();
        }
    }

    hasSecondChart() {
        if (_.get(this.data, 'charts.length', 0) > 1 && this.chartSize === 'quadruple' && this.isMinWidth !== 'small') {
            return 2;
        }
        else {
            return 1;
        }
    }

    calculateProjectionScale(width, height) {
        const boundsRatio = Math.min((width / height), 1.9);

        let projectionScale = width * 1.35;

        if (boundsRatio >= 1.8) {
            projectionScale = Math.min(width, (boundsRatio * height));
        }
        else if (boundsRatio < 1.8 && boundsRatio >= 1.4) {
            projectionScale = width * 1.25;
        }
        else if (boundsRatio < 1.4 && boundsRatio >= 1.3) {
            projectionScale = width * 1.35;
        }
        else if (boundsRatio < 1.3 && boundsRatio >= 1.2) {
            projectionScale = width * 1.4;
        }

        return projectionScale;
    }
}
