// This file was generated from the component scaffold
// Copyright 2016

import {Component, Injector} from '@angular/core';
import FullLineChart from './FullLineChart';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [FullLineChart],
    template: ''
})
class TestComponent {}

describe('chart/FullLineChart.js', () => {

    beforeEach(() => {
        addProviders([FullLineChart]);
    });

    it('should return component name', inject([FullLineChart], (fullLineChart:FullLineChart) => {
        expect(fullLineChart.name).toBe('FullLineChart');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<full-line-chart></full-line-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('full-line-chart h1').innerText).toBe('FullLineChart');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<full-line-chart name="TEST"></full-line-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('full-line-chart h1').innerText).toBe('TEST');
            });
    })));

});
