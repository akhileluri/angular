// This file was generated from the chart scaffold
// Copyright 2018
/* global d3 */
import {Component, Input, Output, EventEmitter, ElementRef} from '@angular/core';
import {COMMON_DIRECTIVES} from '@angular/common';
import * as Monte from 'monte';
import template from './ChoroplethPair.html';
import styles from './ChoroplethPair.scss';

@Component({
    selector: 'choropleth-pair',
    template: template,
    styles: [styles],
    directives: [
        COMMON_DIRECTIVES,
    ],
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <choropleth-pair name="ChoroplethPair" (change)="onChange($event)"></choropleth-pair>
 */
export default class ChoroplethPair {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'ChoroplethPair';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();

    @Input() data = {};
    @Input() chartSize = '';

    firstEl: HTMLElement;
    secondEl: HTMLElement;

    opts = {
        boundingWidth: 250,
        boundingHeight: 150,

        // Follows D3 Margin Convention: https://bl.ocks.org/mbostock/3019563
        margin: {
            top: 10,
            bottom: 20,
            left: 20,
            right: 10,
        },
    };

    constructor(chartEl: ElementRef) {
        this.chartEl = d3.select(chartEl.nativeElement).node();
    }

    ngOnDestroy() {
        if (this.chart) {
            this.chart.destroy();
        }
    }

    ngOnChanges() {
        if (this.data && this.chart) {
            this.chart.updateData(this.prepData(this.data));
        }
    }

    ngAfterViewInit() {
        this.chart = new Monte.Chart(this.chartEl, this.opts)
          .on('rendered', function() {
            // Static features, first render
          })
          .on('updated', function() {
            // Dynamic / changing features based data changes
          })
          .data(this.prepData());
    }

    prepData() {
        // const src = data;
        const out = [];

        // TODO: Transform data

        return out;
    }

    checkSize() {
        if (this.chart) {
            this.chart.checkSize();
        }
    }
}
