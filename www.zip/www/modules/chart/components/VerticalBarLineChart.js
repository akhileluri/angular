// This file was generated from the chart scaffold
// Copyright 2018
/* global d3, _ */
import { Component, Input, Output, EventEmitter, ElementRef, ViewEncapsulation } from '@angular/core';
import * as Monte from 'monte';
import template from './VerticalBarLineChart.html';
import styles from './VerticalBarLineChart.scss';

import { formatAbbreviation, formatMetdataNumber as formatNumber, formatShortNum, shortNumSymbol } from '../util/numberAbbrv';
import { leadYearFormat, reformatPercent } from '../util/format';

@Component({
    selector: 'vertical-bar-line-chart',
    template: template,
    styles: [styles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <vertical-bar-line-chart name="VerticalBarLineChart" (change)="onChange($event)"></vertical-bar-line-chart>
 */
export default class VerticalBarLineChart {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'VerticalBarLineChart';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();

    @Input() data = {};
    @Input() chartData = null;
    @Input() chartSize = '';
    @Input() footerPresent = false;

    barEl: HTMLElement; // Element placeholder
    bar: Monte.Chart; // Chart placeholder

    barOpts = {
        css: 'no-domain-lines',
        boundingWidth: 230,
        boundingHeight: 165,
        suppressAxes: ['y'],
        barCss: function(d) {
            return d.health || 'no-health';
        },
        includeLabels: false,
        margin: {
            top: 20, right: 1, bottom: 16, left: 1,
        },
        xAxisCustomize: Monte.tools.invokeMany(
            (axis) => axis.tickFormat(leadYearFormat),
            Monte.axisNoTicks
        ),
        xProp: 'axisLabel',
        xScale: function() {
            return d3.scaleBand().paddingInner(0.58).paddingOuter(0.2).round(true);
        },
        yAxisCustomize: Monte.axisNoTicks,
        yProp: 'number',
        yDomainCustomize: function(domain) {
            // Evaluate Y scale to ensure that the trendline can fit on the chart.
            const maxBarY = this.comp.data[0].maxNumber;
            const maxLineY = this.comp.data[1].maxNumber;

            if (maxBarY < maxLineY) {
                domain[1] = maxLineY;
            }

            return Monte.extentBalanced(domain);
        },

        resize: new Monte.HorizontalResizer(),
        extensions: [
            new Monte.ExtReferenceLine({
                layer: 'support',
                labelPlacement: 'nw',
                data: function() {
                    const data = this.chart.data();

                    if (data && data.length > 1) {
                        const chart = this.chart;
                        const maxVal = _.maxBy(data, chart.option('yProp'));
                        const y2 = chart.getScaledProp('y', maxVal);
                        const l = chart.option('margin.left');
                        const max = {
                            x1: -l,
                            x2: chart.width,
                            y1: y2,
                            y2: y2,
                            text: formatNumber(maxVal),
                        };

                        return [max];
                    }

                    return [];
                },
            }),
        ],
    };

    constructor(compEl: ElementRef) {
        this.contentSel = d3.select(compEl.nativeElement);
    }

    ngOnDestroy() {
        if (this.chart) {
            this.chart.destroy();
        }
    }

    ngOnChanges() {
        if (this.data && this.bar) {
            this.bar.updateData(this.data[0].numbers);
        }
    }

    quadWideOptions() {
        this.barOpts.extensions.push(new Monte.ExtHorizontalLines());
        this.barOpts.margin.left = 40;
        delete this.barOpts.suppressAxes;
        this.barOpts.css += ' ref-line-focus'; // Give extra focus to ref lines because the y-axis is now showing.
    }

    barLabelOptions() {
        this.barOpts.includeLabels = true;
        this.barOpts.label = function(value) {
            if (value.format === 'percentage' || value.format === 'percent') {
                return reformatPercent(value.number * 100) + '%';
            }
            return formatShortNum(value.number, 1) + shortNumSymbol(value.number);
        };
        this.barOpts.labelProp = 'number';
        this.barOpts.labelXAdjust = function(value, index, bars) {
            const labelWidth = d3.select(bars[index]).select('text').node().getComputedTextLength();
            return ((labelWidth / 2) * -1);
        };
        this.barOpts.labelYAdjust = -5;
    }

    barToolTipOptions() {
        this.barOpts.margin.top = 32;
    }

    barLabelAndToolTipOptions() {
        this.barOpts.margin.top = 48;
    }

    ngAfterViewInit() {
        const comp = this;

        //  Delay is required to allow the UI to paint and provide correct dimensions
        _.delay(function(comp) {
            comp.renderChart();

            //  Forces the overlay to be rendered
            comp.checkSize();
        }, 10, comp);
    }

    renderChart() {
        const comp = this;

        const $container = $($(this.contentSel.node()).closest('chart-selector'));

        //  Set final dimensions based on the available space created by the flexbox layout
        this.barOpts.boundingWidth = $container.width();
        this.barOpts.boundingHeight = $container.height();

        if (this.chartSize === 'quadruple') {
            this.quadWideOptions();
        }

        //  Include optional value labels above the bar
        if (comp.data && comp.data.length > 0 && comp.data[0].showLabels === true) {
            this.barLabelOptions();
        }

        //  Include option tooltips that appear over the bar when hovered
        if (comp.data && comp.data.length > 0 && comp.data[0].enableTooltips === true) {
            this.barToolTipOptions();
        }

        //  Include both the option value labels and toolstips
        if (comp.data && comp.data.length > 0 && comp.data[0].showLabels === true && comp.data && comp.data.length > 0 && comp.data[0].enableTooltips === true) {
            this.barLabelAndToolTipOptions();
        }

        this.barEl = this.contentSel.select('.bar-wrap').node();

        //  Determine which formatter to use for the Y-axis
        switch (_.get(this.data, '[0].numbers[0].format', '')) {
        case 'percent':
            this.barOpts.yAxisCustomize = Monte.tools.invokeMany(
                (axis) => axis.tickFormat(d3.format('.0%')),
                Monte.axisNoTicks
            );
            break;
        case 'average/int':
            this.barOpts.yAxisCustomize = Monte.tools.invokeMany(
                (axis) => axis.tickFormat(d3.format('.2s')),
                Monte.axisNoTicks
            );
            break;
        case 'date':
            this.barOpts.yAxisCustomize = Monte.tools.invokeMany(
                (axis) => axis.tickFormat(d3.format('.2d')),
                Monte.axisNoTicks
            );
            break;
        case 'currency':
            this.barOpts.yAxisCustomize = Monte.tools.invokeMany(
                (axis) => axis.tickFormat((d) => {
                    return '$' + formatAbbreviation(d, 2);
                }),
                Monte.axisNoTicks
            );
            break;
        default:
        }

        if (!this.bar) {
            this.bar = new Monte.BarChart(this.barEl, this.barOpts)
                .call(function() {
                    // Associate additional data from the component for line drawing.
                    this.lineData = comp.data[1];

                    // Create line generator
                    this.line = d3.line()
                        .x((d) => this.x(d.x))
                        .y((d) => this.y(d.y));

                    this.trend = this.overlay.append('g').classed('trend', true);

                    this.comp = comp;
                })
                .on('updated', function() {
                    // Shift trend area by half the width of a bar for alignment.
                    const xShift = this.x.bandwidth() / 2;
                    this.trend.attr('transform', `translate(${xShift}, 0)`);

                    // Draw the associated line and points.
                    const line = {
                        css: 'trend-line',
                        points: this.lineData.numbers.map((d) => {
                            return { x: d.axisLabel, y: d.number };
                        }),
                    };

                    // Draw the line
                    const lines = this.trend.selectAll('.monte-line').data([line]);

                    lines.enter().append('path')
                        .attr('class', (d) => `monte-line ${d.css}`)
                        .merge(lines)
                            .attr('d', (d) => this.line(d.points));

                    lines.exit().remove();

                    // Draw the points
                    const points = this.trend.selectAll('.monte-point').data(line.points);

                    points.enter().append('circle')
                        .attr('class', 'monte-point trend-point')
                        .attr('r', 5)
                        .merge(points)
                            .attr('cx', (d) => this.x(d.x))
                            .attr('cy', (d) => this.y(d.y));

                    points.exit().remove();

                    //  Adjust margin to ensure the entire line graph fits
                    this.margin.top = Math.max(this.margin.top, (Math.abs(this.trend.node().getBBox().y) + 2));
                })
                .on('boundsUpdated', function() {
                    if (comp.data && comp.data.length > 0 && comp.data[0].enableTooltips === true) {
                        comp.buildOverlay(comp.data[0].numbers, this, comp);
                    }
                })
                .data(this.data[0].numbers)
                .checkSize();
        }
    }

    buildOverlay(data, chart, comp) {
        const self = this;
        const tooltipMargin = 7;
        const textSize = 10;
        const circleR = textSize / 1.5;
        const barWidth = chart.x.bandwidth();

        const maxValue = _.maxBy(data, (d) => {
            return (_.isNumber(d.number) === true) ? d.number : 0;
        });

        const getTranslate = function(element) {
            const transform = element.getAttribute('transform');
            return transform.substring(transform.indexOf('(') + 1, transform.indexOf(')')).split(',')
                .map((cur) => parseFloat(cur));
        };

        const highlightGroup = chart.overlay.selectAll('g.highlight-group').data(data);

        const highlightGroupEnter = highlightGroup
            .enter()
            .append('g')
            .classed('highlight-group', true)
            .attr('opacity', '0');

        highlightGroup
            .attr('transform', function(d) {
                const xVal = _.find(d, (val) => val);
                return 'translate(' + chart.getScaledProp('x', xVal) + ',' + 0 + ')';
            });

        const tooltipGroup = highlightGroupEnter
            .append('g')
            .classed('tooltip-group', true);

        const allDataPointGroup = tooltipGroup
            .append('g')
            .classed('all-datapoint-group', true)
            .attr('transition', function() {
                return 'translate(0,' + textSize + ')';
            });

        const dataPointGroup = allDataPointGroup.selectAll('g.datapoint-group').data(function(d) {
            return [d];
        })
            .enter()
            .filter(function(d) {
                return d.number !== undefined;
            })
            .append('g')
            .classed('datapoint-group', true)
            .sort(function(a, b) {
                return a.y > b.y ? -1 : 1;
            })
            .attr('transform', function(d, i, nodes) {
                const transY = nodes[i - 1] ? getTranslate(nodes[i - 1])[1] + textSize + 10 : textSize + 9;
                return 'translate(0,' + transY + ')';
            });

        dataPointGroup
            .append('text')
            .text(function(value) {
                if (value.format === 'percentage' || value.format === 'percent') {
                    return reformatPercent(value.number * 100) + '%';
                }
                return formatShortNum(value.number, 1) + shortNumSymbol(value.number);
            })
            .attr('x', (textSize - 2))
            .attr('y', -4)
            .style('font-size', textSize)
            .style('fill', 'white');

        tooltipGroup
            .insert('rect', 'g')
            .attr('width', function() {
                return this.parentElement.getBBox().width + 2 * tooltipMargin;
            })
            .attr('height', function() {
                return this.parentElement.getBBox().height + 2 * tooltipMargin;
            })
            .attr('rx', circleR)
            .attr('ry', circleR)
            .style('fill', '#494949');

        const lineHighlightGroup = highlightGroupEnter
            .append('g')
            .classed('line-group', true);

        //  Draw the target to trigger the tooltip's appearance
        lineHighlightGroup
            .append('line')
            .classed('highlight-target', true)
            .attr('x1', (barWidth / 2))
            .attr('x2', (barWidth / 2))
            .attr('y1', '0')
            .attr('y2', chart.height)
            .attr('opacity', '0')
            .style('stroke-width', ((barWidth + 2) + 'px'))
            .style('stroke', 'black')
            .on('mouseover', function(d) {
                chart.overlay.selectAll('.highlight-group').filter(function(data) {
                    return _.find(data, (val) => val) === _.find(d, (val) => val);
                }).transition().duration(300).attr('opacity', '1');
                chart.support.selectAll('.highlight-group').filter(function(data) {
                    return _.find(data, (val) => val) === _.find(d, (val) => val);
                }).transition().duration(300).attr('opacity', '1');
            })
            .on('mouseout', function(d) {
                if (!self.showValues) {
                    chart.overlay.selectAll('.highlight-group').filter(function(data) {
                        return _.find(data, (val) => val) === _.find(d, (val) => val);
                    }).transition().duration(300).attr('opacity', '0');
                    chart.support.selectAll('.highlight-group').filter(function(data) {
                        return _.find(data, (val) => val) === _.find(d, (val) => val);
                    }).transition().duration(300).attr('opacity', '0');
                }
            });

        //  Position the tooltip
        tooltipGroup
            .attr('transform', function(d) {
                const xTrans = ((this.getBBox().width / -2) + (barWidth / 2));
                const ratioOfMaxNumber = Math.max(Math.min((d.number / maxValue.number), 1), 0);
                let yTrans = (((1 - ratioOfMaxNumber) * (this.parentElement.getBBox().height)) - this.getBBox().height - 7);

                if (comp.data && comp.data.length > 0 && comp.data[0].showLabels === true && comp.data && comp.data.length > 0 && comp.data[0].enableTooltips === true) {
                    yTrans -= 16;
                }

                return 'translate(' + xTrans + ',' + yTrans + ')';
            });

        //  Draw the pointer (triangle) element of the tooltip
        tooltipGroup
            .append('path')
            .attr('d', function() {
                const baseY = this.parentElement.getBBox().height;
                const tipY = 5;
                const width = 10;
                const startX = this.parentElement.getBBox().width / 2 - width / 2;
                const midX = this.parentElement.getBBox().width / 2;
                const endX = this.parentElement.getBBox().width / 2 + width / 2;

                return 'M ' + startX + ' ' + baseY + ' L ' + midX + ' ' + (baseY + tipY) + ' L ' + endX + ' ' + baseY;
            })
            .style('fill', '#494949');
    }

    prepData(data) {
        const src = data.numbers;
        const out = [];
        const newLine = {
            values: [],
            css: 'line-1',
        };

        src.forEach((x, i) => {
            newLine.values.push({
                x: i,
                y: x.number,
                data: x,
                label: x.label,
            });
        });

        out.push(newLine);

        // Reverse lines so lead lines stack on top by default
        return out.reverse();
    }

    checkSize() {
        if (this.bar) {
            this.bar.checkSize();
        }
    }

    update() {
        if (this.bar) {
            this.bar.update();
        }
    }
}
