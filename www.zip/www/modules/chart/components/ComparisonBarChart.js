// This file was generated from the chart scaffold
// Copyright 2018
/* global d3, _ */
import {Component, Input, Output, EventEmitter, ElementRef, ViewEncapsulation} from '@angular/core';
import * as Monte from 'monte';
import template from './ComparisonBarChart.html';
import styles from './ComparisonBarChart.scss';

import { formatMetdataNumber as formatNumber, formatShortNum, shortNumSymbol } from '../util/numberAbbrv';
import { leadYearFormat, reformatPercent } from '../util/format';

@Component({
    selector: 'comparison-bar-chart',
    template: template,
    styles: [styles],
    encapsulation: ViewEncapsulation.None, // Disable view encapsulation for better theme support.
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <comparison-bar-chart name="ComparisonBarChart" (change)="onChange($event)"></comparison-bar-chart>
 */
export default class ComparisonBarChart {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'ComparisonBarChart';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();
    @Input() data = {};
    @Input() chartSize = '';
    @Input() footerPresent = false;

    opts = {
        css: 'no-domain-lines',
        boundingWidth: 250,
        boundingHeight: 150,

        suppressAxes: ['y'],
        xAxisCustomize: Monte.tools.invokeMany(
            (axis) => axis.tickFormat(leadYearFormat),
            Monte.axisNoTicks
        ),
        yDomainCustomize: function() {
            const yMin = 0;
            const yMax = this.yAxisMax;

            return [yMin, yMax];
        },

        // Follows D3 Margin Convention: https://bl.ocks.org/mbostock/3019563
        margin: {
            top: 20, bottom: 30, left: 35, right: 10,
        },
        resize: new Monte.HorizontalResizer(),

        xProp: 'axisLabel',
        yProp: 'number',

        extensions: [
            new Monte.ExtReferenceLine({
                layer: 'support',
                labelPlacement: 'nw',
                data: function() {
                    const data = this.chart.backgroundBars;

                    if (data && data.length > 1) {
                        const chart = this.chart;
                        // const datumLast = data[data.length - 1];
                        const maxVal = _.maxBy(data, chart.option('yProp'));
                        const y2 = chart.getScaledProp('y', maxVal);
                        const l = chart.option('margin.left');
                        const max = {
                            x1: -l,
                            x2: chart.width,
                            y1: y2,
                            y2: y2,
                            text: formatNumber(maxVal, undefined, 1),
                        };

                        return [ max];
                    }

                    return [];
                },
            }),
            new Monte.ExtReferenceLine({
                layer: 'support',
                labelPlacement: 'sw',
                data: function() {
                    const data = this.chart.backgroundBars;

                    if (data && data.length > 1) {
                        const chart = this.chart;
                        const datumLast = data[data.length - 1];
                        const maxVal = _.maxBy(data, chart.option('yProp'));
                        const y1 = chart.getScaledProp('y', datumLast);
                        const y2 = chart.getScaledProp('y', maxVal);
                        const l = chart.option('margin.left');
                        const last = {
                            x1: -l,
                            x2: chart.width,
                            y1: y1,
                            y2: y1,
                            text: formatNumber(datumLast, undefined, 1),
                        };
                        const max = {
                            x1: -l,
                            x2: chart.width,
                            y1: y2,
                            y2: y2,
                            text: formatNumber(maxVal, undefined, 1),
                        };

                        // If values are identical return only one.
                        if (_.isEqual(last, max)) {
                            return [];
                        }

                        return [last];
                    }

                    return [];
                },
            }),
        ],
    };

    constructor(chartEl: ElementRef) {
        this.chartEl = d3.select(chartEl.nativeElement).node();
    }

    ngOnDestroy() {
        if (this.chart) {
            this.chart.destroy();
        }
    }

    ngOnChanges() {
        if (this.data && this.chart) {
            const foregroundBars = this.data.charts[1].numbers;
            const backgroundBars = this.data.charts[0].numbers;
            const comparisonData = this.data.comparisonData;

            this.chart.backgroundBars = backgroundBars;
            this.chart.comparisonData = comparisonData;
            this.chart.updateData(foregroundBars);
        }
    }

    barLabelOptions() {
        this.opts.includeLabels = true;
        this.opts.label = function(value) {
            if (value.format === 'percentage' || value.format === 'percent') {
                return reformatPercent(value.value * 100) + '%';
            }
            return formatShortNum(value.value, 1) + shortNumSymbol(value.value);
        };
        this.opts.labelProp = 'number';
        this.opts.labelXAdjust = function(value, index, textNodes) {
            const labelWidth = textNodes[index].getComputedTextLength();
            return ((labelWidth / 2) * -1);
        };
        this.opts.labelYAdjust = -5;
    }

    barToolTipOptions() {
        //  Make room for the tooltips
        this.opts.margin.top = 27 + (17 * _.get(this, 'data.lines[0].lines.length', 0));
    }

    barLabelAndToolTipOptions() {
        //  Make room for the tooltips
        this.opts.margin.top = 38 + (17 * _.get(this, 'data.lines[0].lines.length', 0));
    }

    ngAfterViewInit() {
        const comp = this;

        //  Delay is required to allow the UI to paint and provide correct dimensions
        _.delay(function(comp) {
            comp.renderChart();
        }, 10, comp);
    }

    renderChart() {
        const comp = this;

        const $container = $($(this.chartEl).closest('chart-selector'));

        //  Set final dimensions based on the available space created by the flexbox layout
        comp.opts.boundingWidth = $container.width();
        comp.opts.boundingHeight = $container.height();

        const foregroundBars = comp.data.charts[1].numbers;
        const backgroundBars = comp.data.charts[0].numbers;
        const comparisonData = comp.data.comparisonData;
        const yAxisMax = comp.data.charts[0].maxNumber;

        //  Include optional value labels above the bar
        if (comp.data && comp.data.showLabels === true) {
            comp.barLabelOptions();
        }

        //  Include option tooltips that appear over the bar when hovered
        if (comp.data && comp.data.enableTooltips === true) {
            comp.barToolTipOptions();
        }

        //  Include both the option value labels and toolstips
        if (comp.data && comp.data.showLabels === true && comp.data && comp.data.enableTooltips === true) {
            comp.barLabelAndToolTipOptions();
        }

        comp.chart = new Monte.BarChart(comp.chartEl, comp.opts)
            .call(function() {
                this.backgroundBars = backgroundBars;
                this.comparisonData = comparisonData;
                this.yAxisMax = yAxisMax;
            })
            .on('updated', function() {
                // Dynamic / changing features based data changes
                // Add change/difference labels to x-axis
                const comparisonLabels = this.support.selectAll('.comparison-label').data(this.comparisonData);
                const comparisonLabelsEnter = comparisonLabels.enter().append('text').classed('comparison-label', true);

                comparisonLabels.merge(comparisonLabelsEnter)
                    .classed('trend positive', (d) => d.number > 0)
                    .classed('trend negative', (d) => d.number < 0)
                    .attr('x', (d) => (this.getScaledProp('x', d) + (this.x.bandwidth() / 2)))
                    .attr('y', this.height + this.option('margin.bottom') - 5)
                    .attr('text-anchor', 'middle')
                    .text((d) => formatNumber(d, '--', 1));

                comparisonLabels.exit().remove();

                // Draw secondary bars
                const bgBars = this.support.selectAll('.monte-bar-bg').data(this.backgroundBars);
                const bgBarsEnter = bgBars.enter().append('rect').classed('monte-bar-bg', true);

                bgBars.merge(bgBarsEnter)
                    .attr('x', (d) => this.getScaledProp('x', d))
                    .attr('y', (d) => this.getScaledProp('y', d))
                    .attr('width', this.x.bandwidth)
                    .attr('height', (d) => this.height - this.getScaledProp('y', d));

                bgBars.exit().remove();
            })
            .data(foregroundBars);
    }

    checkSize() {
        if (this.chart) {
            this.chart.checkSize();
        }
    }
}
