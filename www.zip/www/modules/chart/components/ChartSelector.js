// This file was generated from the component scaffold
// Copyright 2016

import {Component, Input, ViewChild} from '@angular/core';
import template from './ChartSelector.html';
import styles from './ChartSelector.scss';


@Component({
    selector: 'chart-selector',
    template: template,
    styles: [styles],
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <chart-selector name="ChartSelector" (change)="onChange($event)"></chart-selector>
 */
export default class ChartSelector {
    // Assume the tile has a footer present for single and double sized tiles. Use this flag to
    // encourage height changes to charts.
    @Input() footerPresent: boolean = true;

    @Input() chartType:string = '';
    @Input() chartSize:string = '';
    @Input() data = null;
    @Input() dataConfig = null;
    @Input() isDetail = false;



    // The active chart
    @ViewChild('chart')
    chart = this.chart;

    async ngOnInit() {
        if (matchMedia) {
            this.mediaQuery = window.matchMedia('(max-width: 480px)');
            this.mediaQuery.addListener(this.widthChange.bind(this));
            this.widthChange(this.mediaQuery);
        }
    }

    widthChange(mq) {
        if (mq.matches) {
            this.isMinWidth = 'small';
        }
        else {
            this.isMinWidth = 'large';
        }
    }

    checkSize() {
        if (this.chart && this.chart.checkSize) {
            this.chart.checkSize();
        }
    }

    update() {
        if (this.chart && this.chart.update) {
            this.chart.update();
        }
    }

    getChart() {
        return this.data && this.data.charts && this.data.charts.length > 0 ? this.data.charts[0] : null;
    }

    getChartData() {
        return this.data && this.data.charts && this.data.charts.length > 0 ? this.data.charts : null;
    }

    getChartDatas() {
        return this.data;
    }
}
