// This file was generated from the chart scaffold
// Copyright 2017
/* global */
import {Component, Input, ViewChild} from '@angular/core';
import {COMMON_DIRECTIVES} from '@angular/common';
// import * as Monte from 'monte';
import template from './FullNarrative.html';
import styles from './FullNarrative.scss';
// import {extendBoundingHeight} from '../util/size';

@Component({
    selector: 'full-narrative',
    template: template,
    styles: [styles],
    directives: [
        COMMON_DIRECTIVES,
    ],
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <full-narrative name="FullNarrative" (change)="onChange($event)"></full-narrative>
 */
export default class FullNarrative {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'FullNarrative';
    @Input() chartType:string = '';
    @Input() chartSize:string = '';
    @Input() mode = '';
    @Input() difference = null;
    @Input() isStacked = false;
    @Input() footerPresent = false;
    @Input() isDetail = false;

    @Input() chartData = {};
    @Input() data = {};
    @Input() dataConfig = null;

    @ViewChild('chart')
    chart = this.chart;

    checkSize() {
        if (this.chart) {
            this.chart.checkSize();
        }
    }

    update() {
        if (this.chart) {
            this.chart.update();
        }
    }
}
