// This file was generated from the chart scaffold
// Copyright 2018

import {Component, Injector} from '@angular/core';
import ImageChart from './ImageChart';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [ImageChart],
    template: ''
})
class TestComponent {}

describe('chart/ImageChart.js', () => {

    beforeEach(() => {
        addProviders([ImageChart]);
    });

    it('should return component name', inject([ImageChart], (imageChart:ImageChart) => {
        expect(imageChart.name).toBe('ImageChart');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<image-chart></image-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('image-chart h1').innerText).toBe('ImageChart');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<image-chart name="TEST"></image-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('image-chart h1').innerText).toBe('TEST');
            });
    })));

});
