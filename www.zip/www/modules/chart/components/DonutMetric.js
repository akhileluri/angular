// This file was generated from the chart scaffold
// Copyright 2017
import {Component, Input, ViewChild, ViewEncapsulation} from '@angular/core';
import template from './DonutMetric.html';
import styles from './DonutMetric.scss';

@Component({
    selector: 'donut-metric',
    template: template,
    styles: [styles],
    encapsulation: ViewEncapsulation.None,
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <donut-metric name="DonutMetric" (change)="onChange($event)"></donut-metric>
 */
export default class DonutMetric {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'DonutMetric';

    @Input() data = [];
    @Input() chartSize = '';
    @Input() footerPresent = false;

    @ViewChild('chart')
    chart = this.chart;

    checkSize() {
        if (this.chart) {
            this.chart.checkSize();
        }
    }

    update() {
        if (this.chart) {
            this.chart.update();
        }
    }

    getChartNumbers() {
        return this.data && this.data.length > 0 ? this.data[0].numbers : [];
    }
}
