// This file was generated from the chart scaffold
// Copyright 2016

import {Component, Injector} from '@angular/core';
import PlusMinusGauge from './PlusMinusGauge';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [PlusMinusGauge],
    template: ''
})
class TestComponent {}

describe('chart/PlusMinusGauge.js', () => {

    beforeEach(() => {
        addProviders([PlusMinusGauge]);
    });

    it('should return component name', inject([PlusMinusGauge], (plusMinusGauge:PlusMinusGauge) => {
        expect(plusMinusGauge.name).toBe('PlusMinusGauge');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<plus-minus-gauge></plus-minus-gauge>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('plus-minus-gauge h1').innerText).toBe('PlusMinusGauge');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<plus-minus-gauge name="TEST"></plus-minus-gauge>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('plus-minus-gauge h1').innerText).toBe('TEST');
            });
    })));

});
