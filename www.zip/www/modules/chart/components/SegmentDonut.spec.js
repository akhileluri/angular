// This file was generated from the chart scaffold
// Copyright 2016

import {Component, Injector} from '@angular/core';
import SegmentDonut from './SegmentDonut';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [SegmentDonut],
    template: ''
})
class TestComponent {}

describe('chart/SegmentDonut.js', () => {

    beforeEach(() => {
        addProviders([SegmentDonut]);
    });

    it('should return component name', inject([SegmentDonut], (segmentDonut:SegmentDonut) => {
        expect(segmentDonut.name).toBe('SegmentDonut');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<segment-donut></segment-donut>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('segment-donut h1').innerText).toBe('SegmentDonut');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<segment-donut name="TEST"></segment-donut>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('segment-donut h1').innerText).toBe('TEST');
            });
    })));

});
