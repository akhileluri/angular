// This file was generated from the component scaffold
// Copyright 2016

import {Component, Injector} from '@angular/core';
import HorizontalBarChart from './HorizontalBarChart';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [HorizontalBarChart],
    template: ''
})
class TestComponent {}

describe('chart/HorizontalBarChart.js', () => {

    beforeEach(() => {
        addProviders([HorizontalBarChart]);
    });

    it('should return component name', inject([HorizontalBarChart], (horizontalBarChart:HorizontalBarChart) => {
        expect(horizontalBarChart.name).toBe('HorizontalBarChart');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<horizontal-bar-chart></horizontal-bar-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('horizontal-bar-chart h1').innerText).toBe('HorizontalBarChart');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<horizontal-bar-chart name="TEST"></horizontal-bar-chart>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('horizontal-bar-chart h1').innerText).toBe('TEST');
            });
    })));

});
