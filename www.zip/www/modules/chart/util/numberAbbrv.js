/* global _ */
import { percentFormatWithPrecision } from './format';
import { CurrencyPipe, DecimalPipe } from '@angular/common';

const CurPipe = new CurrencyPipe();
const DecPipe = new DecimalPipe();

const trillonThreshold = 0.9995e12;
const billonThreshold = 0.9995e9;
const millionThreshold = 0.9995e6;
const thousandThreshold = 0.995e3;
const defaultThreshold = 0;

const transformMap = {
    [trillonThreshold]: { div: 1e12, suffix: 'T' },
    [billonThreshold]: { div: 1e9, suffix: 'B' },
    [millionThreshold]: { div: 1e6, suffix: 'M' },
    [thousandThreshold]: { div: 1e3, suffix: 'K' },
    [defaultThreshold]: { div: 1, suffix: '' },
};

const thresholds = [trillonThreshold, billonThreshold, millionThreshold, thousandThreshold];

function getTransform(num) {
    const absNum = Math.abs(num);
    let t = transformMap[defaultThreshold];

    for (let i = 0; i < thresholds.length; i++) {
        if (absNum >= thresholds[i]) {
            t = transformMap[thresholds[i]];
            break;
        }
    }
    return t;
}

/**
 * Returns a string with a number formatted with an Abbreviation
 *
 * @param {number} num        The number to be formatted
 * @param {number} precision  Restricts the number of numerals after the decimal point. Optional
 *
 * @returns {string}       A String version of the formatted text with suffix for percentage or currency amoun
 */


export function formatAbbreviation(num, precision) {
    const absNum = Math.abs(num);

    if (!absNum) {
        return absNum === 0 ? '0' : '--';
    }

    const t = getTransform(num);
    if (precision >= 0) {
        return DecPipe.transform((num / t.div), '1.0-' + precision) + t.suffix;
    }
    else {
        return (num / t.div) + t.suffix;
    }
}

export function formatShortNum(num, precision) {
    const absNum = Math.abs(num);

    if (!absNum) {
        return absNum === 0 ? '0' : '--';
    }

    const t = getTransform(num);
    if (precision >= 0) {
        return DecPipe.transform((num / t.div), '1.0-' + precision);
    }
    else {
        return (num / t.div);
    }
}

export function shortNumSymbol(num) {
    const t = getTransform(num);
    return t.suffix;
}

export function formatCurrency(num, currCode) {
    const t = getTransform(num);
    const shortNum = num / t.div;

    return CurPipe.transform(shortNum, currCode, true, '1.0-1') + t.suffix;
}

/**
 * Takes a KPI MetaData number field and determines the appropriate format.
 *
 * Expects:
 * `{ number: <number>, format: <string>, trend: <'positive'|'negative'> }`
 *
 * If format is "currency", it also expects a `currencyCode` field.
 *
 * @param {object} kpiMetdataNumber A field `*Number` from API services.
 * @param {string} emptyValue       A value to return if `kpiMetdataNumber` is null or undefined.
 * @param {int} precision           A number that restricts the number of numerals after the decimal point. Optional
 * @param {boolean} isDisplay       A flag to determine if we use the number or displayNumber. Optional
 * @return {string}                 A formatted string.
 */
export function formatMetdataNumber(kpiMetdataNumber, emptyValue = '', precision, isDisplay) {
    let num = _.isObject(kpiMetdataNumber) ? kpiMetdataNumber.number : kpiMetdataNumber;
    if (isDisplay) {
        num = _.isObject(kpiMetdataNumber) ? kpiMetdataNumber.displayNumber : kpiMetdataNumber;
    }
    let out;

    // Precision default is one (1) for all types except for precentage which is zero (0).
    if (precision === undefined && kpiMetdataNumber !== undefined) {
        precision = kpiMetdataNumber.format === 'percentage' ? 0 : 1;
    }

    if (num === null || num === undefined) {
        return emptyValue;
    }

    if (kpiMetdataNumber) {
        let formatter = null;
        switch (kpiMetdataNumber.format) {
        case 'percent':
            formatter = percentFormatWithPrecision(2);
            out = formatter(num);
            break;
        case 'percentage':
            formatter = percentFormatWithPrecision(precision);
            out = formatter(num);
            break;
        case 'currency':
            out = formatCurrency(num, kpiMetdataNumber.currencyCode); // all currency has single precision
            break;
        default:
            out = formatAbbreviation(num, precision);
        }
    }
    return out;
}
