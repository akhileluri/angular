/* global d3 */

const PATTERN_FY_FULL = /^FY\d{4}/;

// * For four-digit numbers: the first item is all four digits (`i === 0`), subsequent values are
//   reduced to their two digits.
//
// * For strings that begin with 'FY' and contain four digits: the first item is all six characters
//   (`i === 0`), subsequent values are reduced to 'FY' and last digits.
export function leadYearFormat(v, i) {
    if (i > 0) {
        if (PATTERN_FY_FULL.test(v) && v.length === 6) {
            return 'FY' + v.substring(4);
        }
        else if (v.length === 4) {
            return v.substring(2);
        }
    }

    // else: is full item because it is the lead item or does not match a know pattern
    return v;
}

export const percentFormat = d3.format('.0%');

export function percentFormatWithPrecision(precision = 0) {
    return d3.format('.' + precision + '%');
}

// Takes an already scaled `value` such as 50 (equivalent to 0.5 or 50%) rounds it to a given
// `precision` and adds '%'.
export function reformatPercent(value, precision = 1) {
    const factor = Math.pow(10, precision);
    const roundedValue = Math.round(value * factor) / factor;

    return roundedValue;
}
