const FOOTER_ADJUST = 38; // The footer is 38px tall

export function extendBoundingHeight(options, adjustment = FOOTER_ADJUST) {
    options.boundingHeight += adjustment;
}
