export const CSS_FORMAT_CLASSES = {
    above: 'above-budget',
    at: 'at-budget',
    below: 'below-budget',
};

/**
 * Select the proper CSS class
 * @param  {number} actualVal   The actual value
 * @param  {number} budgetVal The budgeted value
 * @return {string}             The CSS class
 */
export function budgetCss(actualVal, budgetVal) {
    let css = '';

    if (budgetVal !== null && budgetVal !== undefined) {
        if (budgetVal < actualVal) {
            css = CSS_FORMAT_CLASSES.above;
        }
        else if (budgetVal === actualVal) {
            css = CSS_FORMAT_CLASSES.at;
        }
        else {
            css = CSS_FORMAT_CLASSES.below;
        }
    }

    return css;
}

/**
 * Select a CSS class based on the health parameter
 * @param  {string} healthString   The actual value
 * @param  {boolean} noClassIfEmpty a flag that returns no class string if no healthString is passed in
 * @return {string}             The CSS class
 */
export function getHealthCss(healthString, noClassIfEmpty) {
    if (healthString) {
        return healthString;
    }
    else if (noClassIfEmpty) {
        return '';
    }

    return 'no-health';
}


/**
 * Applies the proper class while clearing old to an object that has the `classed` method (a Monte
 * chart or a D3 selection).
 * @param  {object} classedObj  The item to adjust classes on.
 * @param  {number} budgetVal The budgeted value
 * @param  {number} actualVal   The actual value
 * @return {void}
 */
export function applyBudgetCss(classedObj, budgetVal, actualVal) {
    // Clear classes
    for (const key in CSS_FORMAT_CLASSES) {
        if (CSS_FORMAT_CLASSES.hasOwnProperty(key)) {
            classedObj.classed(key, false);
        }
    }

    // Apply class
    classedObj.classed(budgetCss(budgetVal, actualVal), true);
}
