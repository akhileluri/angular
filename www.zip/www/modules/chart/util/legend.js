/* globals _ */

// Look at the dataItemsMap property for a proper English title
// If it does not exist, just use the existing label
export function resolveLegendName(label, dataItemsMap) {
    const matchingDataItem = _.find(dataItemsMap, { value: label }) || {};

    return _.get(matchingDataItem, 'name', label);
}
