// This file was generated from the service scaffold
// Copyright 2017

import {Injectable} from '@angular/core';
import Client from '../../api/api.v1';

/**
 * @example
 * let injector = Injector.resolveAndCreate([KpiDefinitionService]);
 * let kpiDefinitionService = new injector.get(KpiDefinitionService);
 * @example
 * class Component {
 *         constructor(kpiDefinitionService:KpiDefinitionService, kpiDefinitionService2:KpiDefinitionService) {
 *            //injected via angular, a singleton by default in same injector context
 *            console.log(kpiDefinitionService === kpiDefinitionService2);
 *        }
 * }
 */
@Injectable()
export default class KpiDefinitionService {
    constructor(client:Client) {
        this._client = client;
    }

    getName():string {
        return 'KpiDefinitionService';
    }

    async getDataDefinitions() {
        return await this._client.resources.kpiDefinitions.dataSources.get();
    }

    async getDataDefinition(param) {
        const dataSource = this._client.resources.kpiDefinitions.dataSources.dataId(param);
        return await dataSource.get();
    }

    async updateDataDefinition(dataSource) {
        const dataSourceId = this._client.resources.kpiDefinitions.dataSources.dataId(dataSource.dataId);
        return await dataSourceId.put(dataSource);
    }

    async deleteDataDefinition(dataSource) {
        const dataSourceId = this._client.resources.kpiDefinitions.dataSources.dataId(dataSource.dataId);
        return await dataSourceId.delete();
    }

    async getTileDefinitions() {
        return await this._client.resources.kpiDefinitions.tiles.get();
    }

    async getTileDefinition(tileId) {
        const tileRef = this._client.resources.kpiDefinitions.tiles.tileId(tileId);
        return await tileRef.get();
    }

    async updateTileDefinition(tile) {
        const tileRef = this._client.resources.kpiDefinitions.tiles.tileId(tile.tileId);
        return await tileRef.put(tile);
    }

    async deleteTileDefinition(tile) {
        const tileRef = this._client.resources.kpiDefinitions.tiles.tileId(tile.tileId);
        return await tileRef.delete();
    }


}


