// This file was generated from the service scaffold
// Copyright 2017

import {Injector} from '@angular/core';
import {
    addProviders,
    TestComponentBuilder,
    ComponentFixture,
    inject
} from '@angular/core/testing';
import TileEditorOptionsService from './TileEditorOptionsService';

describe('app/services/TileEditorOptionsService.js', () => {

    beforeEach(() => {
        addProviders([TileEditorOptionsService]);
    });

    it('should return TileEditorOptionsService instance', inject([TileEditorOptionsService], (tileEditorOptionsService:TileEditorOptionsService) => {
        expect(tileEditorOptionsService).toBeDefined();
    }));

    it('should return name', inject([TileEditorOptionsService], (tileEditorOptionsService:TileEditorOptionsService) => {
        expect(tileEditorOptionsService.getName()).toBe('TileEditorOptionsService');
    }));

});
