// This file was generated from the service scaffold
// Copyright 2016

import {Injectable} from '@angular/core';
import Client from '../../api/api.v1';

/**
 * @example
 * let injector = Injector.resolveAndCreate([CompareService]);
 * let compareService = new injector.get(CompareService);
 * @example
 * class Component {
 *         constructor(compareService:CompareService, compareService2:CompareService) {
 *            //injected via angular, a singleton by default in same injector context
 *            console.log(compareService === compareService2);
 *        }
 * }
 */
@Injectable()
export default class CompareService {
    constructor(client:Client) {
        this._client = client;
    }

    async getCompare(compareObj) {
        return await this._client.resources.compare.get(compareObj);
    }

    getName():string {
        return 'CompareService';
    }
}
