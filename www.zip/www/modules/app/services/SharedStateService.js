// This file was generated from the service scaffold
// Copyright 2016

import {Injectable} from '@angular/core';
import {Location} from '@angular/common';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';

const PATHS_TO_TRACK = 20;

/**
 * @example
 * let injector = Injector.resolveAndCreate([SharedStateService]);
 * let sharedStateService = new injector.get(SharedStateService);
 * @example
 * class Component {
 *         constructor(sharedStateService:SharedStateService, sharedStateService2:SharedStateService) {
 *            //injected via angular, a singleton by default in same injector context
 *            console.log(sharedStateService === sharedStateService2);
 *        }
 * }
 */
@Injectable()
export default class SharedStateService {
    user = new BehaviorSubject();
    notifications = new BehaviorSubject();
    body = null;
    recentPaths = [];
    sectionTitle = new BehaviorSubject('');
    filterState = new BehaviorSubject('');
    powerpoint = new BehaviorSubject('');
    appConfig = new BehaviorSubject();
    minWidth = new BehaviorSubject('large');


    constructor(location: Location) {
        this._location = location;
    }

    getName():string {
        return 'SharedStateService';
    }

    setUser(user) {
        this.user.next(user);
    }

    getUser() {
        return this.user;
    }

    setConfig(appConfig) {
        this.appConfig.next(appConfig);
    }

    getConfig() {
        return this.appConfig;
    }

    setNotifications(notifications) {
        this.notifications.next(notifications);
    }

    getNotifications() {
        return this.notifications;
    }

    setBodyElement(body) {
        this.body = body;
    }

    getBodyScrollTop() {
        return this.body.scrollTop;
    }

    getBodyWidth() {
        return this.body.getBoundingClientRect().width;
    }

    getRecentPaths() {
        return this.recentPaths;
    }

    pushRecentPath(path) {
        const fullPath = {
            external: this._location.prepareExternalUrl(path),
            internal: path,
        };

        this.recentPaths.unshift(fullPath);

        if (this.recentPaths.length > PATHS_TO_TRACK) {
            this.recentPaths.pop();
        }
    }

    setSectionTitle(title) {
        this.sectionTitle.next(title);
    }

    getSectionTitle() {
        return this.sectionTitle;
    }

    setFilterState(state) {
        this.filterState.next(state);
    }

    getFilterState() {
        return this.filterState;
    }

    setPowerpointState(state) {
        this.powerpoint.next(state);
    }

    getPowerpointState() {
        return this.powerpoint;
    }

    setMinWidth(state) {
        this.minWidth.next(state);
    }

    getMinWidth() {
        return this.minWidth;
    }
}
