// This file was generated from the service scaffold
// Copyright 2016

import {Injectable} from '@angular/core';
import Client from '../../api/api.v1';
const _ = require('lodash');

/**
 * @example
 * let injector = Injector.resolveAndCreate([KpiService]);
 * let kpiService = new injector.get(KpiService);
 * @example
 * class Component {
 *         constructor(kpiService:KpiService, kpiService2:KpiService) {
 *            //injected via angular, a singleton by default in same injector context
 *            console.log(kpiService === kpiService2);
 *        }
 * }
 */
@Injectable()
export default class KpiService {
    _sortedKpis:Array = [];
    _activeSort:Object = {};

    constructor(client:Client) {
        this._client = client;
    }

    getName():string {
        return 'KpiService';
    }

    async getNpsKpis() {
        // where resource URI is defined as /kpis/nps-kpi
        // eslint-disable-next-line no-undef
        return await this._client.resources.kpi.npsKpi.get();
    }

    async getNetSalesKpis() {
        // where resource URI is defined as /kpis/nps-kpi
        // eslint-disable-next-line no-undef
        return await this._client.resources.kpi.netSalesKpi.get();
    }

    setSortedKpis(val:Array) {
        this._sortedKpis = val;
    }

    getSortedKpis():Array {
        return this._sortedKpis;
    }

    setActiveSort(val:Object) {
        this._activeSort = val;
    }

    getActiveSort():Object {
        return this._activeSort;
    }

    sortKpis(kpis, activeSort):Array {
        const kpiCollection = kpis.slice(); // create copy of kpis collection
        let sortedKpis = [];
        const mySort = activeSort && activeSort.sortProperty;
        if (activeSort) {
            if (activeSort.sortProperty && activeSort.sortProperty.indexOf('tileConfiguration') > -1) {
                const sortProp = mySort.split('.')[1]; // Need some error checking here
                sortedKpis = _.sortBy(kpiCollection, [function(q) {
                    return q.tileConfiguration[sortProp];
                }]);
            }
            else {
                sortedKpis = _.sortBy(kpiCollection, [function(q) {
                    return q[mySort];
                }]);
            }
        }
        if (activeSort.sortType === 'Descending') {
            sortedKpis = _.reverse(sortedKpis);
        }
        this.setSortedKpis(sortedKpis);
        this.setActiveSort(activeSort);
        return this.getSortedKpis();
    }
}
