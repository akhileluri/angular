// This file was generated from the service scaffold
// Copyright 2017

import {Injector} from '@angular/core';
import {
    addProviders,
    TestComponentBuilder,
    ComponentFixture,
    inject
} from '@angular/core/testing';
import DataConfiguration from './DataConfigurationService';

describe('app/services/DataConfigurationService.js', () => {

    beforeEach(() => {
        addProviders([DataConfigurationService]);
    });

    it('should return DataConfiguration instance', inject([DataConfigurationService], (dataConfigurationService:DataConfigurationService) => {
        expect(dataConfigurationService).toBeDefined();
    }));

    it('should return name', inject([DataConfiguration], (dataConfigurationService:DataConfigurationService) => {
        expect(dataConfigurationService.getName()).toBe('DataConfigurationService');
    }));

});
