// This file was generated from the service scaffold
// Copyright 2017

import {Injectable} from '@angular/core';
import Client from '../../api/api.v1';

/**
 * @example
 * let injector = Injector.resolveAndCreate([DataConfiguration]);
 * let dataConfiguration = new injector.get(DataConfiguration);
 * @example
 * class Component {
 *         constructor(dataConfiguration:DataConfiguration, dataConfiguration2:DataConfiguration) {
 *            //injected via angular, a singleton by default in same injector context
 *            console.log(dataConfiguration === dataConfiguration2);
 *        }
 * }
 */
@Injectable()
export default class DataConfigurationService {
    constructor(client:Client) {
        this._client = client;
    }

    getName():string {
        return 'DataConfigurationService';
    }

    async getConfig(kpiId) {
        const kpi = this._client.resources.dataConfigurations.kpi(kpiId);
        return await kpi.get();
    }

    async updateConfig(kpiId, config) {
        const kpi = this._client.resources.dataConfigurations.kpi(kpiId);
        return await kpi.put(config);
    }
}
