// This file was generated from the service scaffold
// Copyright 2016

import {Injectable} from '@angular/core';
import Client from '../../api/api.v1';

/**
 * @example
 * let injector = Injector.resolveAndCreate([KpiCategoryService]);
 * let kpiCategoryService = new injector.get(KpiCategoryService);
 * @example
 * class Component {
 *         constructor(kpiCategoryService:KpiCategoryService, kpiCategoryService2:KpiCategoryService) {
 *            //injected via angular, a singleton by default in same injector context
 *            console.log(kpiCategoryService === kpiCategoryService2);
 *        }
 * }
 */
@Injectable()
export default class KpiCategoryService {
    constructor(client:Client) {
        this._client = client;
    }

    getName():string {
        return 'KpiCategoryService';
    }

    async getKpiCategories(params) {
        // where resource URI is defined as /geographies
        return await this._client.resources.kpiCategories.get(params);  // TODO -- Make sure menu data is returned --generics refactor
    }

    async getKpi(kpiId) {
        const kpiRef = this._client.resources.kpiCategories.tileId(kpiId);
        return await kpiRef.get();
    }
}
