// This file was generated from the service scaffold
// Copyright 2017

import {Injectable} from '@angular/core';
import Client from '../../api/api.v1';

/**
 * @example
 * let injector = Injector.resolveAndCreate([InsightService]);
 * let insightService = new injector.get(InsightService);
 * @example
 * class Component {
 *         constructor(insightService:InsightService, insightService2:InsightService) {
 *            //injected via angular, a singleton by default in same injector context
 *            console.log(insightService === insightService2);
 *        }
 * }
 */
@Injectable()
export default class InsightService {
    constructor(client:Client) {
        this._client = client;
    }

    getName():string {
        return 'InsightService!';
    }

    async getInsight(tileId, queryParams) {
        const kpiRes = this._client.resources.insights.tileId(tileId);
        return await kpiRes.get(queryParams);
    }

    async updateInsight(tileId, queryParams, insight) {
        const kpiRes = this._client.resources.insights.tileId(tileId);
        return await kpiRes.put(insight, { query: queryParams });
    }
}
