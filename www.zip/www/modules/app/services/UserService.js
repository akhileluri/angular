// This file was generated from the service scaffold
// Copyright 2016

import {Injectable} from '@angular/core';
import Client from '../../api/api.v1';

/**
 * @example
 * let injector = Injector.resolveAndCreate([UserService]);
 * let userService = new injector.get(UserService);
 * @example
 * class Component {
 *         constructor(userService:UserService, userService2:UserService) {
 *            //injected via angular, a singleton by default in same injector context
 *            console.log(userService === userService2);
 *        }
 * }
 */
@Injectable()
export default class UserService {
    constructor(client:Client) {
        this._client = client;
    }

    async getCurrentUser() {
        // where resource URI is defined as /users
        return await this._client.resources.users.get();
    }

    async updateCurrentUser(user) {
        // where resource URI is defined as /users
        // const usrObj = this._client.resources.users;
        return await this._client.resources.users.put(user);
    }

    async getKpiWatchList() {
        // where resource URI is defined as /users/watch
        return await this._client.resources.users.watch.get();
    }

    async setKpiWatchList(kpiList) {
        // where resource URI is defined as /users/watch
        return await this._client.resources.users.watch.put(kpiList);
    }

    async getKpiDisplayList() {
        // where resource URI is defined as /users/hidden
        return await this._client.resources.users.hidden.get();
    }

    async setKpiWatch(kpi) {
        // where resource URI is defined as /users/{kpiId}/watch
        const ep = this._client.resources.users.kpi(kpi.tileConfiguration.kpiId);
        return await ep.watch.put();
    }

    async clearKpiWatch(kpi) {
        // where resource URI is defined as /users/{kpiId}/watch
        const ep = this._client.resources.users.kpi(kpi.tileConfiguration.kpiId);
        return await ep.watch.delete();
    }

    getName():string {
        return 'UserService';
    }
}
