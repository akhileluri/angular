// This file was generated from the service scaffold
// Copyright 2016

import {Injector} from '@angular/core';
import {
    addProviders,
    TestComponentBuilder,
    ComponentFixture,
    inject
} from '@angular/core/testing';
import FilterService from './FilterService';

describe('app/services/FilterService.js', () => {

    beforeEach(() => {
        addProviders([FilterService]);
    });

    it('should return FilterService instance', inject([FilterService], (filterService:FilterService) => {
        expect(filterService).toBeDefined();
    }));

    it('should return name', inject([FilterService], (filterService:FilterService) => {
        expect(filterService.getName()).toBe('FilterService');
    }));

});
