// This file was generated from the service scaffold
// Copyright 2016

import {Injectable} from '@angular/core';
import Client from '../../api/api.v1';

/**
 * @example
 * let injector = Injector.resolveAndCreate([BusinessService]);
 * let businessService = new injector.get(BusinessService);
 * @example
 * class Component {
 *         constructor(businessService:BusinessService, businessService2:BusinessService) {
 *            //injected via angular, a singleton by default in same injector context
 *            console.log(businessService === businessService2);
 *        }
 * }
 */
@Injectable()
export default class BusinessService {
    constructor(client:Client) {
        this._client = client;
    }

    async getBusinesses() {
        // where resource URI is defined as /geographies
        return await this._client.resources.businesses.get();
    }

    getName():string {
        return 'BusinessService';
    }
}
