// This file was generated from the service scaffold
// Copyright 2016

import {Injectable} from '@angular/core';
import Client from '../../api/api.v1';

/**
 * @example
 * let injector = Injector.resolveAndCreate([FilterService]);
 * let filterService = new injector.get(FilterService);
 * @example
 * class Component {
 *         constructor(filterService:FilterService, filterService2:FilterService) {
 *            //injected via angular, a singleton by default in same injector context
 *            console.log(filterService === filterService2);
 *        }
 * }
 */
@Injectable()
export default class FilterService {
    constructor(client:Client) {
        this._client = client;
    }

    getName():string {
        return 'FilterService';
    }

    async getFilters() {
        // where resource URI is defined as /geographies
        return await this._client.resources.filters.get();
    }
}
