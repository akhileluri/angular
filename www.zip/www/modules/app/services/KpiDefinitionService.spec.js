// This file was generated from the service scaffold
// Copyright 2017

import {Injector} from '@angular/core';
import {
    addProviders,
    TestComponentBuilder,
    ComponentFixture,
    inject
} from '@angular/core/testing';
import KpiDefinitionService from './KpiDefinitionService';

describe('app/services/KpiDefinitionService.js', () => {

    beforeEach(() => {
        addProviders([KpiDefinitionService]);
    });

    it('should return KpiDefinitionService instance', inject([KpiDefinitionService], (kpiDefinitionService:KpiDefinitionService) => {
        expect(kpiDefinitionService).toBeDefined();
    }));

    it('should return name', inject([KpiDefinitionService], (kpiDefinitionService:KpiDefinitionService) => {
        expect(kpiDefinitionService.getName()).toBe('KpiDefinitionService');
    }));

});
