// This file was generated from the service scaffold
// Copyright 2017

import {Injector} from '@angular/core';
import {
    addProviders,
    TestComponentBuilder,
    ComponentFixture,
    inject
} from '@angular/core/testing';
import AppConfiguration from './AppConfiguration';

describe('app/services/AppConfiguration.js', () => {

    beforeEach(() => {
        addProviders([AppConfiguration]);
    });

    it('should return AppConfiguration instance', inject([AppConfiguration], (appConfiguration:AppConfiguration) => {
        expect(appConfiguration).toBeDefined();
    }));

    it('should return name', inject([AppConfiguration], (appConfiguration:AppConfiguration) => {
        expect(appConfiguration.getName()).toBe('AppConfiguration');
    }));

});
