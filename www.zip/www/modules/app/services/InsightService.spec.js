// This file was generated from the service scaffold
// Copyright 2017

import {Injector} from '@angular/core';
import {
    addProviders,
    TestComponentBuilder,
    ComponentFixture,
    inject
} from '@angular/core/testing';
import InsightService from './InsightService';

describe('app/services/InsightService.js', () => {

    beforeEach(() => {
        addProviders([InsightService]);
    });

    it('should return InsightService instance', inject([InsightService], (insightService:InsightService) => {
        expect(insightService).toBeDefined();
    }));

    it('should return name', inject([InsightService], (insightService:InsightService) => {
        expect(insightService.getName()).toBe('InsightService');
    }));

});
