// This file was generated from the service scaffold
// Copyright 2016

import {Injector} from '@angular/core';
import {
    addProviders,
    TestComponentBuilder,
    ComponentFixture,
    inject
} from '@angular/core/testing';
import BusinessService from './BusinessService';

describe('app/services/BusinessService.js', () => {

    beforeEach(() => {
        addProviders([BusinessService]);
    });

    it('should return BusinessService instance', inject([BusinessService], (businessService:BusinessService) => {
        expect(businessService).toBeDefined();
    }));

    it('should return name', inject([BusinessService], (businessService:BusinessService) => {
        expect(businessService.getName()).toBe('BusinessService');
    }));

});
