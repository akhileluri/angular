// This file was generated from the service scaffold
// Copyright 2016

import {Injector} from '@angular/core';
import {
    addProviders,
    TestComponentBuilder,
    ComponentFixture,
    inject
} from '@angular/core/testing';
import SharedStateService from './SharedStateService';

describe('app/services/SharedStateService.js', () => {

    beforeEach(() => {
        addProviders([SharedStateService]);
    });

    it('should return SharedStateService instance', inject([SharedStateService], (sharedStateService:SharedStateService) => {
        expect(sharedStateService).toBeDefined();
    }));

    it('should return name', inject([SharedStateService], (sharedStateService:SharedStateService) => {
        expect(sharedStateService.getName()).toBe('SharedStateService');
    }));

});
