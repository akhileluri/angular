export const APP_PROVIDERS = [];

export UserService from './UserService';
APP_PROVIDERS.push(exports.UserService);

export Auth from './Auth';
APP_PROVIDERS.push(exports.Auth);

export FilterService from './FilterService';
APP_PROVIDERS.push(exports.FilterService);

export KpiCategoryService from './KpiCategoryService';
APP_PROVIDERS.push(exports.KpiCategoryService);

export ErrorService from './ErrorService';
import {ErrorHandler} from '@angular/core';
APP_PROVIDERS.push({provide: ErrorHandler, useClass: exports.ErrorService}); // (exports.ErrorService);

export KpiService from './KpiService';
APP_PROVIDERS.push(exports.KpiService);

export BusinessService from './BusinessService';
APP_PROVIDERS.push(exports.BusinessService);

export KpiDetailService from './KpiDetailService';
APP_PROVIDERS.push(exports.KpiDetailService);

export CategoryService from './CategoryService';
APP_PROVIDERS.push(exports.CategoryService);

export CompareService from './CompareService';
APP_PROVIDERS.push(exports.CompareService);

export CommentService from './CommentService';
APP_PROVIDERS.push(exports.CommentService);

export SharedStateService from './SharedStateService';
APP_PROVIDERS.push(exports.SharedStateService);


export KpiDefinitionService from './KpiDefinitionService';
APP_PROVIDERS.push(exports.KpiDefinitionService);

export InsightService from './InsightService';
APP_PROVIDERS.push(exports.InsightService);

export TileEditorOptionsService from './TileEditorOptionsService';
APP_PROVIDERS.push(exports.TileEditorOptionsService);

export MenuService from './MenuService';
APP_PROVIDERS.push(exports.MenuService);


export AppConfiguration from './AppConfiguration';
APP_PROVIDERS.push(exports.AppConfiguration);

export DataConfigurationService from './DataConfigurationService';
APP_PROVIDERS.push(exports.DataConfigurationService);
