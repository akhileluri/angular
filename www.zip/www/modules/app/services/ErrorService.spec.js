// This file was generated from the service scaffold
// Copyright 2016

import {Injector} from '@angular/core';
import {
    addProviders,
    TestComponentBuilder,
    ComponentFixture,
    inject
} from '@angular/core/testing';
import ErrorService from './ErrorService';

describe('app/services/ErrorService.js', () => {

    beforeEach(() => {
        addProviders([ErrorService]);
    });

    it('should return ErrorService instance', inject([ErrorService], (errorService:ErrorService) => {
        expect(errorService).toBeDefined();
    }));

    it('should return name', inject([ErrorService], (errorService:ErrorService) => {
        expect(errorService.getName()).toBe('ErrorService');
    }));

});
