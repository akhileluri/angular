// This file was generated from the service scaffold
// Copyright 2017

import {Injectable} from '@angular/core';
import Client from '../../api/api.v1';

/**
 * @example
 * let injector = Injector.resolveAndCreate([MenuService]);
 * let menuService = new injector.get(MenuService);
 * @example
 * class Component {
 *         constructor(menuService:MenuService, menuService2:MenuService) {
 *            //injected via angular, a singleton by default in same injector context
 *            console.log(menuService === menuService2);
 *        }
 * }
 */
@Injectable()
export default class MenuService {
    constructor(client:Client) {
        this._client = client;
    }

    getName():string {
        return 'MenuService';
    }

    async getMenus(queryParams) {
        // where resource URI is defined as /geographies
        const menu = await this._client.resources.menus.get(queryParams);
        return menu; // TODO -- Make sure menu data is returned --generics refactor
    }
}
