// This file was generated from the service scaffold
// Copyright 2016

import {Injectable} from '@angular/core';
import Client from '../../api/api.v1';

/**
 * @example
 * let injector = Injector.resolveAndCreate([CommentService]);
 * let commentService = new injector.get(CommentService);
 * @example
 * class Component {
 *         constructor(commentService:CommentService, commentService2:CommentService) {
 *            //injected via angular, a singleton by default in same injector context
 *            console.log(commentService === commentService2);
 *        }
 * }
 */
@Injectable()
export default class CommentService {
    constructor(client:Client) {
        this._client = client;
    }

    getName():string {
        return 'CommentService';
    }

    async getComments(kpi) {
        const res = this._client.resources.comments.tileId(kpi.tileConfiguration.tileId);
        return await res.get();
    }

    async newComment(commentItem) {
        const res = this._client.resources.comments.tileId(commentItem.kpi.tileConfiguration.tileId);
        return await res.post(commentItem);
    }

    async updateComment(commentItem) {
        const kpiRes = this._client.resources.comments.tileId(commentItem.kpi.tileConfiguration.tileId);
        const res = kpiRes.id(commentItem.id);
        return await res.put(commentItem);
    }

    async deleteComment(commentItem) {
        const kpiRes = this._client.resources.comments.tileId(commentItem.kpi.tileConfiguration.tileId);
        const res = kpiRes.id(commentItem.id);
        return await res.delete();
    }
}
