// This file was generated from the service scaffold
// Copyright 2016

import {Injectable} from '@angular/core';
import Client from '../../api/api.v1';

/**
 * @example
 * let injector = Injector.resolveAndCreate([CategoryService]);
 * let categoryService = new injector.get(CategoryService);
 * @example
 * class Component {
 *         constructor(categoryService:CategoryService, categoryService2:CategoryService) {
 *            //injected via angular, a singleton by default in same injector context
 *            console.log(categoryService === categoryService2);
 *        }
 * }
 */
@Injectable()
export default class CategoryService {
    constructor(client:Client) {
        this._client = client;
    }

    async getCategories(kpi) {
        // where resource URI is defined as /geographies
        return await this._client.resources.categories.get({ kpi: kpi, business: 'foo' });
    }

    getName():string {
        return 'CategoryService';
    }
}
