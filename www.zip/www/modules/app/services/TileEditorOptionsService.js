// This file was generated from the service scaffold
// Copyright 2017

import {Injectable} from '@angular/core';
import Client from '../../api/api.v1';

/**
 * @example
 * let injector = Injector.resolveAndCreate([TileEditorOptionsService]);
 * let tileEditorOptionsService = new injector.get(TileEditorOptionsService);
 * @example
 * class Component {
 *         constructor(tileEditorOptionsService:TileEditorOptionsService, tileEditorOptionsService2:TileEditorOptionsService) {
 *            //injected via angular, a singleton by default in same injector context
 *            console.log(tileEditorOptionsService === tileEditorOptionsService2);
 *        }
 * }
 */
@Injectable()
export default class TileEditorOptionsService {
    constructor(client:Client) {
        this._client = client;
    }

    getName():string {
        return 'TileEditorOptionsService';
    }

    async getTileOptions(optionName) {
        // where resource URI is defined as /geographies
        return await this._client.resources.tileEditorOptions.get({optionName: optionName});
    }
}
