// This file was generated from the service scaffold
// Copyright 2016

import {Injector} from '@angular/core';
import {
    addProviders,
    TestComponentBuilder,
    ComponentFixture,
    inject
} from '@angular/core/testing';
import KpiCategoryService from './KpiCategoryService';

describe('app/services/KpiCategoryService.js', () => {

    beforeEach(() => {
        addProviders([KpiCategoryService]);
    });

    it('should return KpiCategoryService instance', inject([KpiCategoryService], (kpiCategoryService:KpiCategoryService) => {
        expect(kpiCategoryService).toBeDefined();
    }));

    it('should return name', inject([KpiCategoryService], (kpiCategoryService:KpiCategoryService) => {
        expect(kpiCategoryService.getName()).toBe('KpiCategoryService');
    }));

});
