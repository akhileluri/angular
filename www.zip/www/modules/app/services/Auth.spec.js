// This file was generated from the service scaffold
// Copyright 2016

import {Injector} from '@angular/core';
import {
    it,
    describe,
    xdescribe,
    expect,
    injectAsync
} from '@angular/core/testing';
import {TestComponentBuilder, ComponentFixture} from '@angular/compiler/testing'
import Auth from './Auth';

describe('app/services/Auth.js', () => {

    beforeEachProviders(() => [Auth]);

    it('should return Auth instance', inject([Auth], (auth:Auth) => {
        expect(auth).toBeDefined();
    }));

    it('should return name', inject([Auth], (auth:Auth) => {
        expect(auth.getName()).toBe('Auth');
    }));

});

