// This file was generated from the service scaffold
// Copyright 2016

import {Injectable} from '@angular/core';
import {Http} from '@angular/http';

const PRIVATES = Symbol();
const INTERVAL_MS = 6000;

/**
 * @example
 * let injector = Injector.resolveAndCreate([Auth]);
 * let auth = new injector.get(Auth);
 * @example
 * class Component {
 *         constructor(auth:Auth, auth2:Auth) {
 *            //injected via angular, a singleton by default in same injector context
 *            console.log(auth === auth2);
 *        }
 * }
 */
@Injectable()
export default class Auth {
    intervalId = '';

    constructor(http: Http) {
        this[PRIVATES] = {};
        this._http = http;

        // THE APP NEEDS THE StoredToken to get the user an privs
        const storedToken = window.localStorage.getItem('queryString') || window.location.href.substring(window.location.href.indexOf('?') + 1);

        // const storedToken = window.localStorage.getItem('queryString');
        window.console.log('@ @ @ Stored token is @ @ @ ' + storedToken);

        if (storedToken === null || storedToken === '') {
            window.console.log('* * * *  Stored token is null or empty so -- app will navigate to the SSO Login');
            if (window.location.href.includes('environmentalscan.ama-assn.org')) {
                window.console.log('- App is in Production');
                window.location
                    .replace('https://fsso.ama-assn.org/mga/sps/oauth/oauth20/authorize' +
                        '?client_id=Digital_Environmental_Scan&client_secret=PdsvVEjvN69SepDtgVxS' +
                        '&response_type=code&grant_type=authorization_code');
            }
            else if (window.location.href.includes('localhost')) {
                window.console.log('- App is in localhost');
                window.localStorage.setItem('queryString', 'localhostUser');
                window.location.reload();
                return;
            }
            else {
                window.console.log('- App is in Test');
                window.location
                    .replace('https://fsso-test.ama-assn.org/mga/sps/oauth/oauth20/authorize' +
                        '?client_id=Digital_Environmental_Scan&client_secret=eZfFMx76sDyaxgSN2mRX' +
                        '&response_type=code&grant_type=authorization_code');
            }
        }
        else {
            window.console.log('we have a stored token -- so resolve with the stored token');
            this[PRIVATES].authToken = new Promise((resolve) => resolve(storedToken));
        }
    }

    getName(): string {
        return 'Auth';
    }

    handleError(error) {
        // In a real world app, we might use a remote logging infrastructure
        // We'd also dig deeper into the error to get a better message
        const errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(errMsg); // log to console instead
    }

    get authToken(): Promise<string> {
        return this[PRIVATES].authToken;
    }

    refreshAuthToken() {
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
        }

        const result = this._http
            .get('/auth-token-info')
            .map((r) => {
                const json = r.json();
                const timeoutValue = (json.expires_in + 1) * 1000;
                console.log('timeout = ' + timeoutValue);
                this.intervalId = setTimeout(() => this.refreshAuthToken(), timeoutValue || INTERVAL_MS);
                return json.access_token || '';
            });
        this[PRIVATES].authToken = result.toPromise();
        console.log('authToken = ' + this[PRIVATES].authToken);
        return result;
    }
}
