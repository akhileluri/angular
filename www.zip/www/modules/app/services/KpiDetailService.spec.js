// This file was generated from the service scaffold
// Copyright 2016

import {Injector} from '@angular/core';
import {
    addProviders,
    TestComponentBuilder,
    ComponentFixture,
    inject
} from '@angular/core/testing';
import KpiDetailService from './KpiDetailService';

describe('app/services/KpiDetailService.js', () => {

    beforeEach(() => {
        addProviders([KpiDetailService]);
    });

    it('should return KpiDetailService instance', inject([KpiDetailService], (kpiDetailService:KpiDetailService) => {
        expect(kpiDetailService).toBeDefined();
    }));

    it('should return name', inject([KpiDetailService], (kpiDetailService:KpiDetailService) => {
        expect(kpiDetailService.getName()).toBe('KpiDetailService');
    }));

});
