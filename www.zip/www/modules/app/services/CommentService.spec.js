// This file was generated from the service scaffold
// Copyright 2016

import {Injector} from '@angular/core';
import {
    addProviders,
    TestComponentBuilder,
    ComponentFixture,
    inject
} from '@angular/core/testing';
import CommentService from './CommentService';

describe('app/services/CommentService.js', () => {

    beforeEach(() => {
        addProviders([CommentService]);
    });

    it('should return CommentService instance', inject([CommentService], (commentService:CommentService) => {
        expect(commentService).toBeDefined();
    }));

    it('should return name', inject([CommentService], (commentService:CommentService) => {
        expect(commentService.getName()).toBe('CommentService');
    }));

});
