// This file was generated from the service scaffold
// Copyright 2016

import {Injector} from '@angular/core';
import {
    addProviders,
    TestComponentBuilder,
    ComponentFixture,
    inject
} from '@angular/core/testing';
import CompareService from './CompareService';

describe('app/services/CompareService.js', () => {

    beforeEach(() => {
        addProviders([CompareService]);
    });

    it('should return CompareService instance', inject([CompareService], (compareService:CompareService) => {
        expect(compareService).toBeDefined();
    }));

    it('should return name', inject([CompareService], (compareService:CompareService) => {
        expect(compareService.getName()).toBe('CompareService');
    }));

});
