// This file was generated from the service scaffold
// Copyright 2017

import {Injectable} from '@angular/core';
import Client from '../../api/api.v1';

/**
 * @example
 * let injector = Injector.resolveAndCreate([AppConfiguration]);
 * let appConfiguration = new injector.get(AppConfiguration);
 * @example
 * class Component {
 *         constructor(appConfiguration:AppConfiguration, appConfiguration2:AppConfiguration) {
 *            //injected via angular, a singleton by default in same injector context
 *            console.log(appConfiguration === appConfiguration2);
 *        }
 * }
 */
@Injectable()
export default class AppConfiguration {
    constructor(client:Client) {
        this._client = client;
    }

    getName():string {
        return 'AppConfiguration';
    }

    async getConfig() {
        return await this._client.resources.appConfiguration.get();
    }

    async updateConfig(config) {
        return await this._client.resources.appConfiguration.put(config);
    }
}
