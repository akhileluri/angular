// This file was generated from the service scaffold
// Copyright 2016

import {Injector} from '@angular/core';
import {
    it,
    describe,
    xdescribe,
    expect,
    injectAsync
} from '@angular/core/testing';
import {TestComponentBuilder, ComponentFixture} from '@angular/compiler/testing'
import UserService from './UserService';

describe('app/services/UserService.js', () => {

    beforeEachProviders(() => [UserService]);

    it('should return UserService instance', inject([UserService], (userService:UserService) => {
        expect(userService).toBeDefined();
    }));

    it('should return name', inject([UserService], (userService:UserService) => {
        expect(userService.getName()).toBe('UserService');
    }));

});

