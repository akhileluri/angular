// This file was generated from the service scaffold
// Copyright 2016

import {Injector} from '@angular/core';
import {
    addProviders,
    TestComponentBuilder,
    ComponentFixture,
    inject
} from '@angular/core/testing';
import KpiService from './KpiService';

describe('app/services/KpiService.js', () => {

    beforeEach(() => {
        addProviders([KpiService]);
    });

    it('should return KpiService instance', inject([KpiService], (kpiService:KpiService) => {
        expect(kpiService).toBeDefined();
    }));

    it('should return name', inject([KpiService], (kpiService:KpiService) => {
        expect(kpiService.getName()).toBe('KpiService');
    }));

});
