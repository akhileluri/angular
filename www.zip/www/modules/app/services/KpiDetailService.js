// This file was generated from the service scaffold
// Copyright 2016

import {Injectable} from '@angular/core';
import Client from '../../api/api.v1';

/**
 * @example
 * let injector = Injector.resolveAndCreate([KpiDetailService]);
 * let kpiDetailService = new injector.get(KpiDetailService);
 * @example
 * class Component {
 *         constructor(kpiDetailService:KpiDetailService, kpiDetailService2:KpiDetailService) {
 *            //injected via angular, a singleton by default in same injector context
 *            console.log(kpiDetailService === kpiDetailService2);
 *        }
 * }
 */
@Injectable()
export default class KpiDetailService {
    constructor(client:Client) {
        this._client = client;
    }

    getName():string {
        return 'KpiDetailService';
    }

    async getKpiDetail(kpi) {
        // where resource URI is defined as /geographies
        return await this._client.resources.kpiDetail.get(kpi);// getKpiDetail
    }

    async getKpiDetailByName(name) {
        // where resource URI is defined as /geographies
        return await this._client.resources.kpiDetail.get({ kpi: name });// getKpiDetail
    }
}
