// This file was generated from the service scaffold
// Copyright 2016

import {Injector} from '@angular/core';
import {
    addProviders,
    TestComponentBuilder,
    ComponentFixture,
    inject
} from '@angular/core/testing';
import CategoryService from './CategoryService';

describe('app/services/CategoryService.js', () => {

    beforeEach(() => {
        addProviders([CategoryService]);
    });

    it('should return CategoryService instance', inject([CategoryService], (categoryService:CategoryService) => {
        expect(categoryService).toBeDefined();
    }));

    it('should return name', inject([CategoryService], (categoryService:CategoryService) => {
        expect(categoryService.getName()).toBe('CategoryService');
    }));

});
