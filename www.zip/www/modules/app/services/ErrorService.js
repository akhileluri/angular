// This file was generated from the service scaffold
// Copyright 2016

import {Injectable, ErrorHandler} from '@angular/core';
import Client from '../../api/api.v1';
// import AWS from 'aws-sdk';


/**
 * @example
 * let injector = Injector.resolveAndCreate([ErrorService]);
 * let errorService = new injector.get(ErrorService);
 * @example
 * class Component {
 *         constructor(errorService:ErrorService, errorService2:ErrorService) {
 *            //injected via angular, a singleton by default in same injector context
 *            console.log(errorService === errorService2);
 *        }
 * }
 */
@Injectable()
export default class ErrorService extends ErrorHandler { // extends ExceptionHandler {

    constructor(client:Client) {
        super();
        this._client = client;
    }

    handleError(error) {
        if (error) {
            // do something with the exception
            console.log('<--------------------------------------->');
            console.log('[ErrorService] error.message = ' + error.message);
            console.log('[ErrorService] error.stack = ' + error.stack);
            console.log('<--------------------------------------->');
        }

        const errorObject = {};
        errorObject.errorId = (Date.now().toString(16).substring(4) + '-' +
            Math.random().toString(16).substring(2, 10)).toUpperCase();
        errorObject.errorCode = 1000;
        errorObject.message = error.toString();
        errorObject.url = window.location.toString();
        errorObject.logHistory = [error.stack];

        // this._client.resources.errors.post(errorObject);

//        // post error to AWS
//        AWS.config = new AWS.Config({region: 'us-east-1', accessKeyId: 'AKIAJBZLWWGZJJMQ7BGA',
//            secretAccessKey: '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'});
//        const sqs = new AWS.SQS({apiVersion: '2012-11-05'});
//        sqs.sendMessage({QueueUrl: 'https://sqs.us-east-1.amazonaws.com/285453578300/datainsights-entdashboard-telemetry',
//            MessageBody: errorObject.message}, function(err, data) {
//            if (err) {
//                console.log('Error', err);
//            }
//            else {
//                console.log('Success', data.MessageId);
//            }
//        });
    }

    getName():string {
        return 'ErrorService';
    }
}
