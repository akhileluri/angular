// This file was generated from the component scaffold
// Copyright 2018

import {Component, Injector} from '@angular/core';
import Glossary from './Glossary';
import {
    addProviders,
    async,
    inject,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [Glossary],
    template: ''
})
class TestComponent {}

describe('app/Glossary.js', () => {

    beforeEach(() => {
        addProviders([Glossary]);
    });

    it('should return component name', inject([Glossary], (glossary:Glossary) => {
        expect(glossary.name).toBe('Glossary');
    }));

    it('should initialize default name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<glossary></glossary>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('glossary h1').innerText).toBe('Glossary');
            });
    })));

    it('should initialize custom name to heading', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<glossary name="TEST"></glossary>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('glossary h1').innerText).toBe('TEST');
            });
    })));

});
