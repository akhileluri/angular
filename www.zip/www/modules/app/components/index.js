export const APP_COMPONENTS = [];

export App from './App';
APP_COMPONENTS.push(exports.App);


export Glossary from './Glossary';
APP_COMPONENTS.push(exports.Glossary);