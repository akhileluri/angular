// This file was generated from the component scaffold
// Copyright 2016
/* global _ */
import {Component, ElementRef, Renderer, ViewChild, ViewEncapsulation} from '@angular/core';
import {Router, NavigationEnd, ActivatedRoute} from '@angular/router';
import template from './App.html';
import styles from './App.scss';
import info from '../../../../package.json';
import UserService from '../../app/services/UserService';
import SharedStateService from '../../app/services/SharedStateService';
import AppConfigurationService from '../../app/services/AppConfiguration';
import Powerpoint from '../../general/services/powerpoint';
import {PageScrollConfig} from 'ng2-page-scroll';
import {ScrollSpyService} from 'ng2-scrollspy';
import config from 'config';
import Glossary from '../components/Glossary';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/mergeMap';

import theme from '../../themes/ama/theme.scss';
const THEME = {
    cssClass: 'theme-ama',
    styleFile: theme,
};

// Use the following lines to for the Test Theme in order to check that styles have been implemented
// to support multiple themes.
//
// import theme from '../../themes/test/theme.scss';
// const THEME = {
//     cssClass: 'theme-test',
//     styleFile: theme,
// };

const DEFAULT_VIEW = 'Overview'; // Analysis
@Component({
    selector: 'app',
    template: template,
    styles: [styles, THEME.styleFile],
    encapsulation: ViewEncapsulation.None,  // Make app styles apply globally throughout the app.
})
/**
 * @example
 * <app></app>
 */
export default class App {
    name: string = info.name;
    activeTheme = THEME;

    @ViewChild('filterButton')
    filterButton: ElementRef = this.filterButton;

    @ViewChild('nav')
    nav: ElementRef = this.nav;

    // Glossary Modal
    @ViewChild('glossaryModal')
    glossaryModal: Glossary = this.glossaryModal;

    navElement = null;
    buildVersion = '';
    buildDate = null;
    inProduction = false;

    notifications = [];
    newNotificationsCount = 0;
    scrollbarNearTop = true;
    isDataView = true;

    // KPIs Rendered for Powerpoint Generation
    @ViewChild('powerpointKPIContainer')
    powerpointKPIContainer: ElementRef = this.powerpointKPIContainer;
    powerpointIsLoading = false;
    powerpointKPIs = [];

    constructor(element: ElementRef,
                router: Router,
                activatedRoute: ActivatedRoute,
                renderer: Renderer,
                userService: UserService,
                sharedStateService: SharedStateService,
                appConfigurationService: AppConfigurationService,
                scrollSpyService: ScrollSpyService,
                powerpointService: Powerpoint) {
        this.body = element.nativeElement.parentElement;
        this._router = router;
        this._activatedRoute = activatedRoute;
        this._renderer = renderer;
        this._userService = userService;
        this._sharedStateService = sharedStateService;
        this._scrollSpyService = scrollSpyService;
        this._powerpointService = powerpointService;
        this._appConfigurationService = appConfigurationService;
        PageScrollConfig.defaultDuration = 250;
        PageScrollConfig.defaultScrollOffset = 50;
        this.buildVersion = config.version;
        this.buildDate = config.date;

        // Based on https://toddmotto.com/dynamic-page-titles-angular-2-router-events
        this._router.events
            .filter((event) => event instanceof NavigationEnd)
            .map(() => this._activatedRoute)
            .map((route) => {
                while (route.firstChild) {
                    route = route.firstChild;
                }

                return route;
            })
            .filter((route) => route.outlet === 'primary')
            .mergeMap((route) => route.data)
            .subscribe((data) => {
                this.setTitle(data['title']);
            });

        this._sharedStateService.setBodyElement(this.body);

        this.sectionTitleSubject = sharedStateService.sectionTitle;
        this.sectionTitle = '';

        this.sectionTitleSubject.subscribe((value) => {
            this.sectionTitle = value;
        });

        this._renderer.setElementClass(document.body, this.activeTheme.cssClass, true);
        this.inProduction = window.location.href.includes('environmentalscan.ama-assn.org');
    }


    async ngOnInit() {
        this.sectionTitle = document.getElementById('sectionTitle');
        this.user = await this._userService.getCurrentUser();
        this._sharedStateService.setUser(this.user);
        this._sharedStateService.setNotifications(this.user.notifications);

        // Get App Configuration
        this.appConfig = await this._appConfigurationService.getConfig();
        this._sharedStateService.setConfig(this.appConfig);

        // Log initial path
        this._sharedStateService.pushRecentPath(this._router.url);

        // Log path changes
        this._router.events.subscribe((val) => {
            if (val instanceof NavigationEnd) {
                this._sharedStateService.pushRecentPath(val.urlAfterRedirects);
            }
        });

        this._sharedStateService.getFilterState().subscribe((v) => {
            this.filterActive = v;
        });



        this._sharedStateService.getPowerpointState().subscribe((v) => {
            this.powerpointLoadingText = v;
        });

        if (matchMedia) {
            this.mediaQuery = window.matchMedia('(max-width: 480px)');
            this.mediaQuery.addListener(this.widthChange.bind(this));
            this.widthChange(this.mediaQuery);
        }
    }

    widthChange(mq) {
        if (mq.matches) {
            this._sharedStateService.setMinWidth('small');
        }
        else {
            this._sharedStateService.setMinWidth('large');
        }
    }

    ngOnDestroy() {
        this.sectionTitleSubject.unsubscribe();
    }

    setTitle(name) {
        this.sectionTitle = name;
        this.isDataView = (name === DEFAULT_VIEW);
        if (!this.isDataView) {
            this.filterActive = false;
            this._sharedStateService.setFilterState(false);
        }
        else {
            if (this.filterButton.nativeElement.classList.contains('active') && !this.filterActive) {
                this.filterButton.nativeElement.classList.remove('active');
            }
        }
    }

    selectView(pathName) {
        const routeParams = [pathName];
        this._router.navigate(routeParams);
    }

    feedbackLink() {
        const subject = 'Environmental Scan Feedback';
        const encodedSubject = encodeURI(subject);
        const email = ' intelligence@ama-assn.org'; // TODO: Update the correct email when we have it. [[ THIS SHOULD BE READ IN FROM THE APP CONFIGURATION]]
        const link = `mailto:${email}?Subject=${encodedSubject}`;

        return link;
    }

    launchFeedback() {
        location.href = this.feedbackLink();
    }

    onFilterButtonClick($event) {
        const buttonTgt = $event.currentTarget;
        this._sharedStateService.setFilterState(!buttonTgt.classList.contains('active'));
    }

    /**
     * FunctionDescription
     *
     * @returns {null} Nothing is returned
     */
    showGlossary() {
        this.glossaryModal.open();
    }

    closeGlossaryModal() {

    }

    async createPowerpoint() {
        const self = this;
        // self.powerpointKPIs = [];

        self.powerpointIsLoading = true;
        this.powerpointLoadingText = 'Gathering Tile Data'; // this._sharedStateService.setPowerpointState

        self.powerpointKPIs = await self._powerpointService.generateKPIs();
        self.powerpointLoadingText = 'Initiating Slide Creation';
        if (self.powerpointKPIs.length > 0) {
            //  TODO: Check if there is a reliable way to determine if the SVGs have actually finished rendering
            const startTime = self.powerpointKPIs.length * 3500;
            let remainingTime = self.powerpointKPIs.length * 3500;
            let pct = 1;
            const timer = setInterval(function() {
                remainingTime -= 1000;
                pct = Math.round(((startTime - remainingTime) / startTime) * 100);
                self.powerpointLoadingText = 'Compiling PPTX Content: ' + pct + '% complete';
                if (pct > 99) {
                    clearInterval(timer);
                }
            }, 1000);
            _.delay(function(self) {
                // clearInterval(timer);
                self._powerpointService.generatePowerpoint(self.powerpointKPIContainer, self.powerpointKPIs);
                self.powerpointLoadingText = 'Compiling PPTX Content';


                _.delay(function(self) {
                    self.powerpointLoadingText = 'Completing Slide Creation';
                    self.powerpointIsLoading = false;
                    self.powerpointKPIs = [];
                }, (self.powerpointKPIs.length * 300), self);
            }, (self.powerpointKPIs.length * 3500), self);
        // }, (self.powerpointKPIs.length * 500), self);
        }
        else {
            //  TODO: No KPIs, should the user be informed?
        }
    }


}
