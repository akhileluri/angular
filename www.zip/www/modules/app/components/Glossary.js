// This file was generated from the component scaffold
// Copyright 2018
/* global MonteGlobal*/

import {Component, Input, Output, EventEmitter, ViewChild, ViewEncapsulation} from '@angular/core';
import {ModalComponent} from 'ng2-bs3-modal/ng2-bs3-modal';
import {COMMON_DIRECTIVES} from '@angular/common';
import template from './Glossary.html';
import styles from './Glossary.scss';

@Component({
    selector: 'glossary',
    template: template,
    styles: [styles],
    encapsulation: ViewEncapsulation.None,
    directives: [
        COMMON_DIRECTIVES,
    ],
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Component-decorator.html
 * @example
 * <glossary name="Glossary" (change)="onChange($event)"></glossary>
 */
export default class Glossary {
    /**
     * An example input for this component
     * @see https://angular.io/docs/ts/latest/api/core/Input-var.html
     */
    @Input() name:string = 'Glossary';

    /**
     * An example output for this component
     * @see https://angular.io/docs/ts/latest/api/core/Output-var.html
     */
    @Output() change:EventEmitter = new EventEmitter();

    @Output() onClose:EventEmitter = new EventEmitter();

    // NOTE: Must assign to ViewChild explictly due to bug in Babel/Angular2 decorator plugins.
    // See last comment on https://github.com/angular/angular/issues/7906
    @ViewChild('modal')
    modal:ModalComponent = this.modal;

    constructor() {

    }

    async openModal(modal) {
        const openPromise = modal.open();
        openPromise.then(() => {
            setTimeout(() => {
                if (MonteGlobal.getResizeWatcher()) {
                    MonteGlobal.getResizeWatcher().runCallbacks();
                }
            }, 0);
        });
    }

    open() {
        this.openModal(this.modal);
    }

    announceClose() {
        this.onClose.emit();
    }
}
