import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {HttpModule} from '@angular/http';
import {FormsModule} from '@angular/forms';
import {Ng2PageScrollModule} from 'ng2-page-scroll';
import {ScrollSpyModule} from 'ng2-scrollspy';
import {Ng2Bs3ModalModule} from 'ng2-bs3-modal/ng2-bs3-modal';

import AppComponent from './components/App';
import {APP_COMPONENTS} from './components/';

import {Error} from '../general/views';
import {GENERAL_COMPONENTS} from '../general/components';
import {GENERAL_DIRECTIVES} from '../general/directives';
import {GENERAL_PIPES} from '../general/pipes';
import {CHART_COMPONENTS} from '../chart/components';
import {DASHBOARD_COMPONENTS} from '../dashboard/components';
import {DASHBOARD_VIEWS} from '../dashboard/views';
import {NOTIFICATION_COMPONENTS} from '../notification/components';
import {NOTIFICATION_VIEWS} from '../notification/views';
//
import {routing} from './routes';
import providers from './providers';


@NgModule({
    // module dependencies
    imports: [
        BrowserModule,
        routing,
        HttpModule,
        FormsModule,
        Ng2Bs3ModalModule,
        Ng2PageScrollModule.forRoot(),
        ScrollSpyModule.forRoot(),
    ],

    // components and directives
    declarations: [
        APP_COMPONENTS,
        Error,
        GENERAL_COMPONENTS,
        GENERAL_DIRECTIVES,
        GENERAL_PIPES,
        CHART_COMPONENTS,
        DASHBOARD_COMPONENTS,
        DASHBOARD_VIEWS,
        NOTIFICATION_COMPONENTS,
        NOTIFICATION_VIEWS,
    ],

    // root component
    // bootstrap: [AppComponent],

    // We will add the root component to the entry componenets list -- this way we do not load it by default, but prep it for load by the system.
    entryComponents: [AppComponent],

    // services
    providers: [providers],

})
export class AppModule {
    ngDoBootstrap(appRef) {
        bootstrapRoot(appRef);
    }
 }

// app - reference to the running application (ApplicationRef)
// name - name (selector) of the component to bootstrap

function bootstrapRoot(app) {
    // debugger;
    window.console.log('Adding Angular App to DOM.....');
    // AppComponent


    // create DOM element for the component being bootstrapped
    // and add it to the DOM
    const componentElement = document.createElement('app');
    document.body.appendChild(componentElement);

    // bootstrap the application with the selected component
    app.bootstrap(AppComponent);
}








