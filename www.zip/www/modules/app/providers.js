/**
 * Default list of providers that can be used for bootstrap. The contents
 * of this file are automatically modified during scaffolding of services
 * for convenience to auto register them.
 */
const DEFAULT_PROVIDERS = [
    // provide(ExceptionHandler, {useClass: ErrorService}), // TODO: Rework error handling
];

export default DEFAULT_PROVIDERS;

import {APP_PROVIDERS} from '../app/services';
DEFAULT_PROVIDERS.push(APP_PROVIDERS);

import ApiV1 from '../api/api.v1';
DEFAULT_PROVIDERS.push(ApiV1);

import {API_PROVIDERS} from '../api/services';
DEFAULT_PROVIDERS.push(API_PROVIDERS);

import {DashboardTitleResolver} from '../dashboard/providers/DashboardTitleResolver';
DEFAULT_PROVIDERS.push(DashboardTitleResolver);

import {GENERAL_PROVIDERS} from '../general/services';
DEFAULT_PROVIDERS.push(GENERAL_PROVIDERS);
