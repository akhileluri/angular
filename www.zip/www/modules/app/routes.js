import { Routes, RouterModule } from '@angular/router';

const ROUTES: Routes = [];

export default ROUTES;

// need to specify default route base URL
import config from 'config';
const base = document.createElement('base');
base.href = config.appBaseUrl;
document.head.appendChild(base);


ROUTES.push(...require('../notification/views/routes'));

// Home (from dashboard) and Error (from general) have default and catch all routes so they need to
// be placed after more specific routes.
ROUTES.push(...require('../dashboard/views/routes'));
ROUTES.push(...require('../general/views/routes'));

export const routing = RouterModule.forRoot(ROUTES, { useHash: true });
