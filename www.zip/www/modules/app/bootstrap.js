// any file with the name 'bootstrap' will not be bundled during spec tests, see settings.json

import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app';

let search;
let code;
let processingAuth = false;

function getAuth(authRef) {
    return new Promise((resolve) => {

        window.console.log(' %%%   window.location.href is ' + window.location.href);
        window.console.log(' ^^^ --------------------------------------- -------------- processingAuth' + processingAuth);
        processingAuth = true;
        // Create constant for URL fragments that we wiil be referencing and using to reroute user to auth servers

        const loc = window.location;
        search = new URLSearchParams(loc.href.substring(loc.href.indexOf('?') + 1));
        code = search.get('code') || window.sessionStorage.getItem('code');
        // const state = search.get('state') || window.sessionStorage.getItem('state');
        // const pathName = loc.pathName + loc.search;
        const tokenPath = '/v1/token?code=';
        let baseAddress = loc.protocol + '//' + loc.hostname;

        let redirect = 'https://fsso-test.ama-assn.org/mga/sps/oauth/oauth20/authorize?client_id=Digital_Environmental_Scan&response_type=code&grant_type=authorization_code&state=xyz1234';
        if(window.location.href.includes('environmentalscan.ama-assn.org')){
                redirect = 'https://fsso.ama-assn.org/mga/sps/oauth/oauth20/authorize?client_id=Digital_Environmental_Scan&response_type=code&grant_type=authorization_code&state=xyz1234';
            window.console.log("~ ~ ~ ~ ~ ~ WE ARE ON PROD!");
        }
        let authURI = baseAddress + tokenPath;
        // let authenticated = false; // a local flag that tell the browser that authentication has happened

        if (window.location.href.includes('localhost')) { // RUNNING LOCALLY
            baseAddress = baseAddress + ':8050';
            authURI = baseAddress + tokenPath;
            // resolve(true);
        }
        else if (loc.protocol === 'http:') { // make sure we are using https
            const esAddr = authURI.replace('http:', 'https:');
            window.location.replace(esAddr);
        }

        // debugger;
        resolve({authValue: 'authenticated'});
        // We are not running locally - ON WEB SERVER USING HTTPS
      /*if (!code) { // NO CODE === NOT AUTHENTICATED
            // If we dont have an Auth code -- we redirect the browser to the Auth server for the user to authenticate
            window.console.log('* * * *  We dont have an auth code -- set original location and reroute to SSO[' + loc.href + ' ]');
            window.sessionStorage.setItem('originalLocation', loc.href);
            window.location.replace(redirect);
        }
        else { // CODE ===  AUTHENTICATED or REJECTED
            window.console.log('* * * *  We have the code= ' + code);
            const authFlag = window.sessionStorage.getItem('authFlagIsSet');
            if (authFlag) {
                window.console.log('* ---* * *  We have the code + aUTH FLAG WAS SET TO= ' + authFlag);
                resolve({authValue: 'authenticated'});
            }
            else{
                // Pass the authCode to the Server API
                window.console.log('* ---* * *  We have the code + aUTH FLAG WAS NOT SET -- GOTO CONTROLAPI');

                const authenticated = fetch(baseAddress + '/control/v1/token?code=' + code).then((response) => response.json());
                resolve(authenticated);
            }
        }*/
    });
}


if (false === processingAuth) {
    getAuth().then(function(authRef) {
        processingAuth = false;
        window.console.log(' === SUCCESS aunthenticated = ' + authRef.authValue);
        if (authRef.authValue === 'authenticated') {
            const cookieInfor = window.sessionStorage.getItem('originalLocation');
            window.console.log('* GETTING cookieInfor  ' + cookieInfor);
            if (cookieInfor) {
                window.console.log('* cookieInfor exists so we are removing the original location  ');
                window.console.log(' We are setting queryString to  ' + search);
                window.console.log(' We are setting code to  ' + code);
                window.localStorage.setItem('queryString', search);
                window.sessionStorage.setItem('code', code);
                window.sessionStorage.removeItem('originalLocation');
                window.location.replace(cookieInfor);
            }
            else {
                window.console.log('* cookieInfor did NOT exist so we are removing the code item'); //why?
                // window.sessionStorage.removeItem('code');
            }
            window.console.log('--NOW SET THE authFlag to true... and load up Angular');
            window.sessionStorage.setItem('authFlagIsSet', true);
            let indi = document.getElementById("root_loading_indicator");
            if (indi !== null) {
                indi.remove();
            }

            platformBrowserDynamic().bootstrapModule(AppModule);
        }
        else {
            window.console.log('* NOT AUTHENTICATED -- SHOW ERROR');
            document.getElementById('errorDialog').showModal();
        }
    }, function(authRef) {
        processingAuth = false;
        // debugger;
        window.console.log(' === FAILED aunthenticated = ' + authRef);
        window.console.log(' === FAILED aunthenticated = ' + authRef.authValue);
        window.console.log(' ~~~ ~~~ ~~~ Bootstrap Method ERROR! NOTE - We should never see this error -- all fetch response are retuned as Resolved' + authRef);
        document.getElementById('errorDialog').showModal();
    });
}
