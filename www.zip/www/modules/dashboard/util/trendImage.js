export function getTrendImage(number) {
    if (number === null || number === undefined) {
        return 'modules/img/transparent.png'; // TODO -- This is the same as the default. Do we need a different image here?
    }

    const trend = number.trend ? number.trend : number;

    if (trend === 'positive') {
        return 'modules/img/icon_upIndicator.png';
    }

    if (trend === 'negative') {
        return 'modules/img/icon_downIndicator.png';
    }
    return 'modules/img/transparent.png';
}
