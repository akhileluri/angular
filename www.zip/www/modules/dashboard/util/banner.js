/**
 * Created by markmartin on 2/6/17.
 */

import * as SIZING from '../../app/const/sizing';

/**
 * This file provides methods used by preference views that display a success and/or error banner
 * (Currently these are 'HeadlinesEditor', 'Support', 'TileProperties', and 'UserPreferences')
 * The checkScrollSizing method references 2 DOM elements with the variable names "success" and "error"
 */

/**
 * Sets a flag the the pref view uses to display the success banner
 * Then triggers a timeout for the layout to update the banner position, and finally
 * sets a timer to have the banner display for 10 secs
 * @returns {null} Nothing is returned
 **/
export function displaySuccessBanner() {
    this.displaySuccess = true;
    setTimeout(() => this.checkScrollSizing()); // NOTE: 'setTimeout' ensures the check happens after the next render cycle - when the success banner has been added to the DOM
    setTimeout(() => {
        this.displaySuccess = false;
    }, 5000, this);
}

/**
 * Sets a flag the the pref view uses to display the error banner,
 * then triggers a timeout for the layout to update the banner position.
 * @returns {null} Nothing is returned
 **/
export function displayErrorBanner() {
    this.displayError = true;
    setTimeout(() => this.checkScrollSizing()); // NOTE: 'setTimeout' ensures the check happens after the next render cycle - when the success banner has been added to the DOM
}


/**
 * Checks for the existence of a DOM element ( named either 'success' of 'error')
 * and dynamically sets the style 'top' to make the top of the element
 * stick to to top of the view if the page is scrolled past the header bar.
 * @returns {null} Nothing is returned
 */
export function checkScrollSizing() {
    if (this.success) {
        this.successElement = this.success.nativeElement;
        if (this.successElement) {
            const pos = this._sharedStateService.getBodyScrollTop(); // NOTE : Make sure component that includes this file imports the SharedStateService
            if (pos <= (SIZING.HEADER_HEIGHT + 2)) {
                this.successElement.style.top = SIZING.HEADER_HEIGHT + 'px';
            }
            else {
                this.successElement.style.top = (pos - 2) + 'px';
            }
        }
    }
    else if (this.error) {
        this.errorElement = this.error.nativeElement;
        if (this.errorElement) {
            const pos = this._sharedStateService.getBodyScrollTop();
            if (pos <= (SIZING.HEADER_HEIGHT + 2)) {
                this.errorElement.style.top = SIZING.HEADER_HEIGHT + 'px';
            }
            else {
                this.errorElement.style.top = (pos - 2) + 'px';
            }
        }
    }
}
