
/* eslint-disable */
export const kpiQuadCatalog = {
    "kpiCategories": [
        {
            "kpis": [
                {
                    "budgetNumber": {
                        "currencyCode": "USD",
                        "format": "currency",
                        "number": 13994829800
                    },
                    "context": {
                        "category": {
                            "health": 2,
                            "id": "ALL",
                            "name": "Business: All"
                        },
                        "endDate": "FY17",
                        "geography": {
                            "health": 0,
                            "id": "ALL",
                            "name": "World Wide"
                        },
                        "product": {
                            "health": 0,
                            "id": "ALL",
                            "name": "All Products"
                        },
                        "startDate": "FY12"
                    },
                    "forecastNumber": {
                        "currencyCode": "USD",
                        "format": "currency",
                        "number": 14059459120.5
                    },
                    "insightText": "Quadruple Line Graph!",
                    "chartData": {
                        "lineGraphData": {
                            "lines": [
                                [
                                    {
                                        "currencyCode": "USD",
                                        "format": "currency",
                                        "label": "Actual",
                                        "number": 776833225.34
                                    },
                                    {
                                        "currencyCode": "USD",
                                        "format": "currency",
                                        "label": "Actual",
                                        "number": 13062553977.54
                                    },
                                    {
                                        "currencyCode": "USD",
                                        "format": "currency",
                                        "label": "Actual",
                                        "number": 776833225.34
                                    },
                                    {
                                        "currencyCode": "USD",
                                        "format": "currency",
                                        "label": "Actual",
                                        "number": 13062553977.54
                                    },
                                    {
                                        "currencyCode": "USD",
                                        "format": "currency",
                                        "label": "Actual",
                                        "number": 776833225.34
                                    },
                                    {
                                        "currencyCode": "USD",
                                        "format": "currency",
                                        "label": "Actual",
                                        "number": 13062553977.54
                                    }
                                ],
                                [
                                    {
                                        "currencyCode": "USD",
                                        "format": "currency",
                                        "label": "Budget",
                                        "number": 13994829800
                                    },
                                    {
                                        "currencyCode": "USD",
                                        "format": "currency",
                                        "label": "Budget",
                                        "number": 0
                                    },
                                    {
                                        "currencyCode": "USD",
                                        "format": "currency",
                                        "label": "Budget",
                                        "number": 13994829800
                                    },
                                    {
                                        "currencyCode": "USD",
                                        "format": "currency",
                                        "label": "Budget",
                                        "number": 0
                                    },
                                    {
                                        "currencyCode": "USD",
                                        "format": "currency",
                                        "label": "Budget",
                                        "number": 13994829800
                                    },
                                    {
                                        "currencyCode": "USD",
                                        "format": "currency",
                                        "label": "Budget",
                                        "number": 0
                                    }
                                ],
                                [
                                    {
                                        "currencyCode": "USD",
                                        "format": "currency",
                                        "label": "Forecast",
                                        "number": 14059459120.5
                                    },
                                    {
                                        "currencyCode": "USD",
                                        "format": "currency",
                                        "label": "Forecast",
                                        "number": 14059459120.5
                                    },
                                    {
                                        "currencyCode": "USD",
                                        "format": "currency",
                                        "label": "Forecast",
                                        "number": 14059459120.5
                                    },
                                    {
                                        "currencyCode": "USD",
                                        "format": "currency",
                                        "label": "Forecast",
                                        "number": 14059459120.5
                                    },
                                    {
                                        "currencyCode": "USD",
                                        "format": "currency",
                                        "label": "Forecast",
                                        "number": 14059459120.5
                                    },
                                    {
                                        "currencyCode": "USD",
                                        "format": "currency",
                                        "label": "Forecast",
                                        "number": 14059459120.5
                                    }
                                ]
                            ],
                            "maxNumber": 14059459120.5,
                            "minNumber": 0,
                            "xaxisLabels": [
                                "FY17",
                                "FY16",
                                "FY15",
                                "FY14",
                                "FY13",
                                "FY12"
                            ]
                        }
                    },
                    "kpiMetadata": {
                        "allowDrillDown": true,
                        "category": "Details",
                        "chartType": "lineGraph",
                        "chartTypeDetail": "lineGraph",
                        "definition": "Amount of sales generated after deduction of returns, allowances for damaged or missing goods and discounts.",
                        "equation": "Gross Sales – Return and Replants – Market Funding",
                        "hasBusinessesHubsDetail": true,
                        "hasCategoriesDetail": true,
                        "kpiId": "net-sales",
                        "tileSize": "quadruple",
                        "name": "Quadruple Line Graph",
                        "pointOfContactEmail": "taggardandrews@kpmg.com",
                        "pointOfContactPingId": "TANDR2",
                        "shortName": "Net Sales",
                        "showComments": true,
                        "showNumberBar": false
                    },
                    "lastRefreshDate": "2015-10-23T18:23:00.00Z",
                    "newCommentCount": 0,
                    "trending": false,
                    "previousForecastNumber": {
                        "currencyCode": "USD",
                        "format": "currency",
                        "number": 13048451120.5
                    },
                    "priority": 1,
                    "priorYearActualNumber": {
                        "currencyCode": "USD",
                        "format": "currency",
                        "number": 776833225.34
                    },
                    "source": "HFM_Mgt",
                    "totalCommentCount": 1,
                    "yearToDateNumber": {
                        "currencyCode": "USD",
                        "format": "currency",
                        "number": 1705459120.5
                    }
                },
                {
                    "chartData": {
                        "segmentedLinesData": {
                            "lines": [
                                {
                                    "label": "Touchpoints",
                                    "segmentNumbers": [
                                        {
                                            "numData": {
                                                "label": "Other",
                                                "number": 4,
                                                "percentOfTotal": 0.02
                                            }
                                        },
                                        {
                                            "numData": {
                                                "label": "Retain",
                                                "number": 8,
                                                "percentOfTotal": 0.03
                                            }
                                        },
                                        {
                                            "numData": {
                                                "label": "Acquire",
                                                "number": 32,
                                                "percentOfTotal": 0.12
                                            }
                                        },
                                        {
                                            "numData": {
                                                "label": "Develop",
                                                "number": 185,
                                                "percentOfTotal": 0.71
                                            }
                                        },
                                        {
                                            "numData": {
                                                "label": "Light Touch",
                                                "number": 33,
                                                "percentOfTotal": 0.13
                                            }
                                        }
                                    ]
                                },
                                {
                                    "label": "Number of Dealers",
                                    "segmentNumbers": [
                                        {
                                            "numData": {
                                                "label": "Other",
                                                "number": 4,
                                                "percentOfTotal": 0.02
                                            }
                                        },
                                        {
                                            "numData": {
                                                "label": "Retain",
                                                "number": 8,
                                                "percentOfTotal": 0.03
                                            }
                                        },
                                        {
                                            "numData": {
                                                "label": "Acquire",
                                                "number": 32,
                                                "percentOfTotal": 0.12
                                            }
                                        },
                                        {
                                            "numData": {
                                                "label": "Develop",
                                                "number": 185,
                                                "percentOfTotal": 0.71
                                            }
                                        },
                                        {
                                            "numData": {
                                                "label": "Light Touch",
                                                "number": 33,
                                                "percentOfTotal": 0.13
                                            }
                                        }
                                    ]
                                },
                                {
                                    "label": "Potential Growth Area",
                                    "segmentNumbers": [
                                        {
                                            "numData": {
                                                "label": "Other",
                                                "number": 4,
                                                "percentOfTotal": 0.02
                                            }
                                        },
                                        {
                                            "numData": {
                                                "label": "Retain",
                                                "number": 8,
                                                "percentOfTotal": 0.03
                                            }
                                        },
                                        {
                                            "numData": {
                                                "label": "Acquire",
                                                "number": 32,
                                                "percentOfTotal": 0.12
                                            }
                                        },
                                        {
                                            "numData": {
                                                "label": "Develop",
                                                "number": 185,
                                                "percentOfTotal": 0.71
                                            }
                                        },
                                        {
                                            "numData": {
                                                "label": "Light Touch",
                                                "number": 33,
                                                "percentOfTotal": 0.13
                                            }
                                        }
                                    ]
                                }
                            ]
                        }
                    },
                    "context": {
                        "category": {
                            "health": 2,
                            "id": "ALL",
                            "name": "Business: All"
                        },
                        "endDate": "FY17",
                        "geography": {
                            "health": 0,
                            "id": "ALL",
                            "name": "World Wide"
                        },
                        "product": {
                            "health": 0,
                            "id": "ALL",
                            "name": "All Products"
                        },
                        "startDate": "FY12"
                    },
                    "kpiMetadata": {
                        "allowDrillDown": true,
                        "category": "Details",
                        "chartType": "segmentedLines",
                        "definition": "",
                        "detailMeasures": [],
                        "equation": "((Current Volume - Previous Volume) ÷ Previous Volume)× 100",
                        "hasBusinessesHubsDetail": true,
                        "hasCategoriesDetail": true,
                        "kpiId": "test-segment-bars",
                        "tileSize": "quadruple",
                        "name": "Quadruple Segmented Lines",
                        "pointOfContactEmail": "taggardandrews@kpmg.com",
                        "pointOfContactPingId": "TANDR2",
                        "shortName": "segmentBars",
                        "showComments": false,
                        "showNumberBar": false
                    },
                    "trending": false
                }
            ],
            "name": "Detail Charts"
        }
    ],
    "name": "Visualization Catalog",
    "activateBusinessAndGeoDropDowns": true,
    "activateCategoryDropDown": true
};
