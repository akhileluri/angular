
const NUM_TYPE_SRC_MAP = {
    'actual': 'modules/img/icon_actual.svg',
    'budget': 'modules/img/icon_budget.svg',
    'forecast': 'modules/img/icon_forecast.svg',
    'priorYearActual': 'modules/img/icon_prev_year.svg',
    'previousQuarter': 'modules/img/icon_prev_qtr.svg',
    'previousForecast': 'modules/img/icon_prior_forecast.svg',
    'prevYear': 'modules/img/icon_prev_year.svg',
    'target': 'modules/img/icon_target.svg',
    'yearToDate': 'modules/img/icon_ytd.svg',
};
const NUM_TYPE_TITLE_MAP = {
    'actual': 'Actual',
    'budget': 'Budget',
    'forecast': 'Forecast',
    'priorYearActual': 'Prior Year',
    'previousForecast': 'Prior Forecast',
    'prevYear': 'Previous Year',
    'target': 'Target',
    'yearToDate': 'Year to Date',
};
const NUM_TYPE_CAPTION_MAP = {
    'actual': 'Actual',
    'budget': 'Budget',
    'forecast': 'Forecast',
    'priorYearActual': 'Prior Year',
    'previousForecast': 'Prior Forecast',
    'prevYear': 'Prev Year',
    'target': 'Target',
    'yearToDate': 'YTD',
};

export function getArrowDirection(indicator) {
    if (indicator === 'down') {
        return 'arrow_downward';
    }
    else if (indicator === 'up') {
        return 'arrow_upward';
    }

    // Better no arrow than the wrong arrow.
    return '';
}

export function getNumberTypeSrc(numberType) {
    return NUM_TYPE_SRC_MAP[numberType];
}

export function getNumberTypeTitle(numberType) {
    return NUM_TYPE_TITLE_MAP[numberType];
}

export function getNumberTypeCaption(numberType) {
    return NUM_TYPE_CAPTION_MAP[numberType];
}

export function getNumberHealthClass(health) {
    if (health !== null && health !== undefined) {
        // If the field is provided, but without a specific value
        if (!health) {
            return 'health-none';
        }

        // Else use the literal value
        return `health-${health}`;
    }

    return '';
}
