export function kpiMailToLink(kpiName, email) {
    const subject = `Environmental Scan - "${kpiName}" request for information`;
    const encodedSubject = encodeURI(subject);
    const link = `mailto:${email}?Subject=${encodedSubject}`;

    return link;
}
