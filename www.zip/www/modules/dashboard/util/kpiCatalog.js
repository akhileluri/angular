
/* eslint-disable */
export const kpiCatalog = {
"kpiCategories": [
{
"kpis":
[

{
"bottomBarNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
},

{
"format": "average/int",
"icon": "max",
"label": "MaxTemp",
"number": 18
},

{
"format": "average/int",
"icon": "min",
"label": "MinTemp",
"number": 11
}
],

"chartData":
{
"lineGraphData":
{
"lines":
[
{
    "lines":
        [
            {
                "currencyCode": "",
                "for": "1/01/17",
                "format": "",
                "label": "Temperature",
                "number": 27.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/02/17",
                "format": "",
                "label": "Temperature",
                "number": 25.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/03/17",
                "format": "",
                "label": "Temperature",
                "number": 27.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/04/17",
                "format": "",
                "label": "Temperature",
                "number": 28.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/05/17",
                "format": "",
                "label": "Temperature",
                "number": 22.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/06/17",
                "format": "",
                "label": "Temperature",
                "number": 20.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/07/17",
                "format": "",
                "label": "Temperature",
                "number": 19.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/08/17",
                "format": "",
                "label": "Temperature",
                "number": 19.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/09/17",
                "format": "",
                "label": "Temperature",
                "number": 19.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/10/17",
                "format": "",
                "label": "Temperature",
                "number": 21.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/11/17",
                "format": "",
                "label": "Temperature",
                "number": 28.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/12/17",
                "format": "",
                "label": "Temperature",
                "number": 32.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/13/17",
                "format": "",
                "label": "Temperature",
                "number": 29.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/14/17",
                "format": "",
                "label": "Temperature",
                "number": 23.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/15/17",
                "format": "",
                "label": "Temperature",
                "number": 24.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/16/17",
                "format": "",
                "label": "Temperature",
                "number": 24.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/17/17",
                "format": "",
                "label": "Temperature",
                "number": 26.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/18/17",
                "format": "",
                "label": "Temperature",
                "number": 28.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/19/17",
                "format": "",
                "label": "Temperature",
                "number": 28.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/20/17",
                "format": "",
                "label": "Temperature",
                "number": 26.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/21/17",
                "format": "",
                "label": "Temperature",
                "number": 29.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/22/17",
                "format": "",
                "label": "Temperature",
                "number": 29.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/23/17",
                "format": "",
                "label": "Temperature",
                "number": 28.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/24/17",
                "format": "",
                "label": "Temperature",
                "number": 25.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/25/17",
                "format": "",
                "label": "Temperature",
                "number": 26.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/26/17",
                "format": "",
                "label": "Temperature",
                "number": 27.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/27/17",
                "format": "",
                "label": "Temperature",
                "number": 26.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/28/17",
                "format": "",
                "label": "Temperature",
                "number": 24.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/29/17",
                "format": "",
                "label": "Temperature",
                "number": 24.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/30/17",
                "format": "",
                "label": "Temperature",
                "number": 23.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "1/31/17",
                "format": "",
                "label": "Temperature",
                "number": 23.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/01/17",
                "format": "",
                "label": "Temperature",
                "number": 25.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/02/17",
                "format": "",
                "label": "Temperature",
                "number": 25.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/03/17",
                "format": "",
                "label": "Temperature",
                "number": 22.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/04/17",
                "format": "",
                "label": "Temperature",
                "number": 22.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/05/17",
                "format": "",
                "label": "Temperature",
                "number": 24.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/06/17",
                "format": "",
                "label": "Temperature",
                "number": 26.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/07/17",
                "format": "",
                "label": "Temperature",
                "number": 29.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/08/17",
                "format": "",
                "label": "Temperature",
                "number": 33.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/09/17",
                "format": "",
                "label": "Temperature",
                "number": 24.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/10/17",
                "format": "",
                "label": "Temperature",
                "number": 21.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/11/17",
                "format": "",
                "label": "Temperature",
                "number": 27.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/12/17",
                "format": "",
                "label": "Temperature",
                "number": 27.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/13/17",
                "format": "",
                "label": "Temperature",
                "number": 26.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/14/17",
                "format": "",
                "label": "Temperature",
                "number": 25.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/15/17",
                "format": "",
                "label": "Temperature",
                "number": 26.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/16/17",
                "format": "",
                "label": "Temperature",
                "number": 23.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/17/17",
                "format": "",
                "label": "Temperature",
                "number": 24.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/18/17",
                "format": "",
                "label": "Temperature",
                "number": 29.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/19/17",
                "format": "",
                "label": "Temperature",
                "number": 33.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/20/17",
                "format": "",
                "label": "Temperature",
                "number": 30.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/21/17",
                "format": "",
                "label": "Temperature",
                "number": 29.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/22/17",
                "format": "",
                "label": "Temperature",
                "number": 32.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/23/17",
                "format": "",
                "label": "Temperature",
                "number": 34.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/24/17",
                "format": "",
                "label": "Temperature",
                "number": 32.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/25/17",
                "format": "",
                "label": "Temperature",
                "number": 32.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/26/17",
                "format": "",
                "label": "Temperature",
                "number": 26.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/27/17",
                "format": "",
                "label": "Temperature",
                "number": 27.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "2/28/17",
                "format": "",
                "label": "Temperature",
                "number": 30.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/01/17",
                "format": "",
                "label": "Temperature",
                "number": 35.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/02/17",
                "format": "",
                "label": "Temperature",
                "number": 29.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/03/17",
                "format": "",
                "label": "Temperature",
                "number": 24.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/04/17",
                "format": "",
                "label": "Temperature",
                "number": 21.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/05/17",
                "format": "",
                "label": "Temperature",
                "number": 20.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/06/17",
                "format": "",
                "label": "Temperature",
                "number": 25.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/07/17",
                "format": "",
                "label": "Temperature",
                "number": 32.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/08/17",
                "format": "",
                "label": "Temperature",
                "number": 33.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/09/17",
                "format": "",
                "label": "Temperature",
                "number": 32.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/10/17",
                "format": "",
                "label": "Temperature",
                "number": 28.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/11/17",
                "format": "",
                "label": "Temperature",
                "number": 21.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/12/17",
                "format": "",
                "label": "Temperature",
                "number": 21.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/13/17",
                "format": "",
                "label": "Temperature",
                "number": 21.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/14/17",
                "format": "",
                "label": "Temperature",
                "number": 22.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/15/17",
                "format": "",
                "label": "Temperature",
                "number": 21.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/16/17",
                "format": "",
                "label": "Temperature",
                "number": 23.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/17/17",
                "format": "",
                "label": "Temperature",
                "number": 25.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/18/17",
                "format": "",
                "label": "Temperature",
                "number": 27.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/19/17",
                "format": "",
                "label": "Temperature",
                "number": 27.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/20/17",
                "format": "",
                "label": "Temperature",
                "number": 27.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/21/17",
                "format": "",
                "label": "Temperature",
                "number": 31.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/22/17",
                "format": "",
                "label": "Temperature",
                "number": 27.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/23/17",
                "format": "",
                "label": "Temperature",
                "number": 24.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/24/17",
                "format": "",
                "label": "Temperature",
                "number": 29.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/25/17",
                "format": "",
                "label": "Temperature",
                "number": 33.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/26/17",
                "format": "",
                "label": "Temperature",
                "number": 30.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/27/17",
                "format": "",
                "label": "Temperature",
                "number": 32.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/28/17",
                "format": "",
                "label": "Temperature",
                "number": 34.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/29/17",
                "format": "",
                "label": "Temperature",
                "number": 33.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/30/17",
                "format": "",
                "label": "Temperature",
                "number": 29.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "3/31/17",
                "format": "",
                "label": "Temperature",
                "number": 29.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/01/17",
                "format": "",
                "label": "Temperature",
                "number": 29.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/02/17",
                "format": "",
                "label": "Temperature",
                "number": 31.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/03/17",
                "format": "",
                "label": "Temperature",
                "number": 33.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/04/17",
                "format": "",
                "label": "Temperature",
                "number": 36.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/05/17",
                "format": "",
                "label": "Temperature",
                "number": 34.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/06/17",
                "format": "",
                "label": "Temperature",
                "number": 33.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/07/17",
                "format": "",
                "label": "Temperature",
                "number": 29.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/08/17",
                "format": "",
                "label": "Temperature",
                "number": 29.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/09/17",
                "format": "",
                "label": "Temperature",
                "number": 33.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/10/17",
                "format": "",
                "label": "Temperature",
                "number": 37.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/11/17",
                "format": "",
                "label": "Temperature",
                "number": 39.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/12/17",
                "format": "",
                "label": "Temperature",
                "number": 36.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/13/17",
                "format": "",
                "label": "Temperature",
                "number": 34.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/14/17",
                "format": "",
                "label": "Temperature",
                "number": 33.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/15/17",
                "format": "",
                "label": "Temperature",
                "number": 35.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/16/17",
                "format": "",
                "label": "Temperature",
                "number": 41.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/17/17",
                "format": "",
                "label": "Temperature",
                "number": 37.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/18/17",
                "format": "",
                "label": "Temperature",
                "number": 33.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/19/17",
                "format": "",
                "label": "Temperature",
                "number": 34.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/20/17",
                "format": "",
                "label": "Temperature",
                "number": 35.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/21/17",
                "format": "",
                "label": "Temperature",
                "number": 36.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/22/17",
                "format": "",
                "label": "Temperature",
                "number": 34.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/23/17",
                "format": "",
                "label": "Temperature",
                "number": 34.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/24/17",
                "format": "",
                "label": "Temperature",
                "number": 33.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/25/17",
                "format": "",
                "label": "Temperature",
                "number": 34.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/26/17",
                "format": "",
                "label": "Temperature",
                "number": 37.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/27/17",
                "format": "",
                "label": "Temperature",
                "number": 40.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/28/17",
                "format": "",
                "label": "Temperature",
                "number": 39.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/29/17",
                "format": "",
                "label": "Temperature",
                "number": 40.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "4/30/17",
                "format": "",
                "label": "Temperature",
                "number": 38.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/01/17",
                "format": "",
                "label": "Temperature",
                "number": 38.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/02/17",
                "format": "",
                "label": "Temperature",
                "number": 38.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/03/17",
                "format": "",
                "label": "Temperature",
                "number": 35.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/04/17",
                "format": "",
                "label": "Temperature",
                "number": 34.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/05/17",
                "format": "",
                "label": "Temperature",
                "number": 35.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/06/17",
                "format": "",
                "label": "Temperature",
                "number": 34.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/07/17",
                "format": "",
                "label": "Temperature",
                "number": 30.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/08/17",
                "format": "",
                "label": "Temperature",
                "number": 30.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/09/17",
                "format": "",
                "label": "Temperature",
                "number": 31.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/10/17",
                "format": "",
                "label": "Temperature",
                "number": 33.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/11/17",
                "format": "",
                "label": "Temperature",
                "number": 34.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/12/17",
                "format": "",
                "label": "Temperature",
                "number": 34.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/13/17",
                "format": "",
                "label": "Temperature",
                "number": 34.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/14/17",
                "format": "",
                "label": "Temperature",
                "number": 35.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/15/17",
                "format": "",
                "label": "Temperature",
                "number": 35.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/16/17",
                "format": "",
                "label": "Temperature",
                "number": 36.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/17/17",
                "format": "",
                "label": "Temperature",
                "number": 41.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/18/17",
                "format": "",
                "label": "Temperature",
                "number": 44.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/19/17",
                "format": "",
                "label": "Temperature",
                "number": 42.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/20/17",
                "format": "",
                "label": "Temperature",
                "number": 38.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/21/17",
                "format": "",
                "label": "Temperature",
                "number": 38.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/22/17",
                "format": "",
                "label": "Temperature",
                "number": 37.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/23/17",
                "format": "",
                "label": "Temperature",
                "number": 37.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/24/17",
                "format": "",
                "label": "Temperature",
                "number": 38.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/25/17",
                "format": "",
                "label": "Temperature",
                "number": 37.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/26/17",
                "format": "",
                "label": "Temperature",
                "number": 37.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/27/17",
                "format": "",
                "label": "Temperature",
                "number": 37.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/28/17",
                "format": "",
                "label": "Temperature",
                "number": 38.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/29/17",
                "format": "",
                "label": "Temperature",
                "number": 39.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/30/17",
                "format": "",
                "label": "Temperature",
                "number": 38.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "5/31/17",
                "format": "",
                "label": "Temperature",
                "number": 39.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/01/17",
                "format": "",
                "label": "Temperature",
                "number": 39.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/02/17",
                "format": "",
                "label": "Temperature",
                "number": 38.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/03/17",
                "format": "",
                "label": "Temperature",
                "number": 38.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/04/17",
                "format": "",
                "label": "Temperature",
                "number": 38.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/05/17",
                "format": "",
                "label": "Temperature",
                "number": 39.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/06/17",
                "format": "",
                "label": "Temperature",
                "number": 38.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/07/17",
                "format": "",
                "label": "Temperature",
                "number": 36.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/08/17",
                "format": "",
                "label": "Temperature",
                "number": 37.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/09/17",
                "format": "",
                "label": "Temperature",
                "number": 39.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/10/17",
                "format": "",
                "label": "Temperature",
                "number": 42.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/11/17",
                "format": "",
                "label": "Temperature",
                "number": 44.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/12/17",
                "format": "",
                "label": "Temperature",
                "number": 45.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/13/17",
                "format": "",
                "label": "Temperature",
                "number": 45.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/14/17",
                "format": "",
                "label": "Temperature",
                "number": 43.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/15/17",
                "format": "",
                "label": "Temperature",
                "number": 42.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/16/17",
                "format": "",
                "label": "Temperature",
                "number": 44.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/17/17",
                "format": "",
                "label": "Temperature",
                "number": 45.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/18/17",
                "format": "",
                "label": "Temperature",
                "number": 45.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/19/17",
                "format": "",
                "label": "Temperature",
                "number": 45.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/20/17",
                "format": "",
                "label": "Temperature",
                "number": 43.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/21/17",
                "format": "",
                "label": "Temperature",
                "number": 42.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/22/17",
                "format": "",
                "label": "Temperature",
                "number": 42.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/23/17",
                "format": "",
                "label": "Temperature",
                "number": 44.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/24/17",
                "format": "",
                "label": "Temperature",
                "number": 43.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/25/17",
                "format": "",
                "label": "Temperature",
                "number": 41.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/26/17",
                "format": "",
                "label": "Temperature",
                "number": 41.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/27/17",
                "format": "",
                "label": "Temperature",
                "number": 41.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/28/17",
                "format": "",
                "label": "Temperature",
                "number": 40.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/29/17",
                "format": "",
                "label": "Temperature",
                "number": 41.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "6/30/17",
                "format": "",
                "label": "Temperature",
                "number": 44.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/01/17",
                "format": "",
                "label": "Temperature",
                "number": 44.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/02/17",
                "format": "",
                "label": "Temperature",
                "number": 43.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/03/17",
                "format": "",
                "label": "Temperature",
                "number": 44.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/04/17",
                "format": "",
                "label": "Temperature",
                "number": 44.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/05/17",
                "format": "",
                "label": "Temperature",
                "number": 43.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/06/17",
                "format": "",
                "label": "Temperature",
                "number": 44.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/07/17",
                "format": "",
                "label": "Temperature",
                "number": 45.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/08/17",
                "format": "",
                "label": "Temperature",
                "number": 44.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/09/17",
                "format": "",
                "label": "Temperature",
                "number": 42.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/10/17",
                "format": "",
                "label": "Temperature",
                "number": 44.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/11/17",
                "format": "",
                "label": "Temperature",
                "number": 45.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/12/17",
                "format": "",
                "label": "Temperature",
                "number": 45.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/13/17",
                "format": "",
                "label": "Temperature",
                "number": 45.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/14/17",
                "format": "",
                "label": "Temperature",
                "number": 45.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/15/17",
                "format": "",
                "label": "Temperature",
                "number": 44.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/16/17",
                "format": "",
                "label": "Temperature",
                "number": 43.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/17/17",
                "format": "",
                "label": "Temperature",
                "number": 44.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/18/17",
                "format": "",
                "label": "Temperature",
                "number": 45.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/19/17",
                "format": "",
                "label": "Temperature",
                "number": 46.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/20/17",
                "format": "",
                "label": "Temperature",
                "number": 46.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/21/17",
                "format": "",
                "label": "Temperature",
                "number": 46.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/22/17",
                "format": "",
                "label": "Temperature",
                "number": 45.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/23/17",
                "format": "",
                "label": "Temperature",
                "number": 44.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/24/17",
                "format": "",
                "label": "Temperature",
                "number": 44.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/25/17",
                "format": "",
                "label": "Temperature",
                "number": 42.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/26/17",
                "format": "",
                "label": "Temperature",
                "number": 42.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/27/17",
                "format": "",
                "label": "Temperature",
                "number": 44.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/28/17",
                "format": "",
                "label": "Temperature",
                "number": 43.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/29/17",
                "format": "",
                "label": "Temperature",
                "number": 41.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/30/17",
                "format": "",
                "label": "Temperature",
                "number": 42.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "7/31/17",
                "format": "",
                "label": "Temperature",
                "number": 43.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/01/17",
                "format": "",
                "label": "Temperature",
                "number": 44.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/02/17",
                "format": "",
                "label": "Temperature",
                "number": 45.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/03/17",
                "format": "",
                "label": "Temperature",
                "number": 44.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/04/17",
                "format": "",
                "label": "Temperature",
                "number": 44.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/05/17",
                "format": "",
                "label": "Temperature",
                "number": 43.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/06/17",
                "format": "",
                "label": "Temperature",
                "number": 41.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/07/17",
                "format": "",
                "label": "Temperature",
                "number": 42.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/08/17",
                "format": "",
                "label": "Temperature",
                "number": 42.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/09/17",
                "format": "",
                "label": "Temperature",
                "number": 42.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/10/17",
                "format": "",
                "label": "Temperature",
                "number": 42.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/11/17",
                "format": "",
                "label": "Temperature",
                "number": 43.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/12/17",
                "format": "",
                "label": "Temperature",
                "number": 43.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/13/17",
                "format": "",
                "label": "Temperature",
                "number": 42.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/14/17",
                "format": "",
                "label": "Temperature",
                "number": 42.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/15/17",
                "format": "",
                "label": "Temperature",
                "number": 43.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/16/17",
                "format": "",
                "label": "Temperature",
                "number": 43.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/17/17",
                "format": "",
                "label": "Temperature",
                "number": 43.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/18/17",
                "format": "",
                "label": "Temperature",
                "number": 45.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/19/17",
                "format": "",
                "label": "Temperature",
                "number": 44.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/20/17",
                "format": "",
                "label": "Temperature",
                "number": 43.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/21/17",
                "format": "",
                "label": "Temperature",
                "number": 44.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/22/17",
                "format": "",
                "label": "Temperature",
                "number": 45.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/23/17",
                "format": "",
                "label": "Temperature",
                "number": 16.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/24/17",
                "format": "",
                "label": "Temperature",
                "number": 40.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/25/17",
                "format": "",
                "label": "Temperature",
                "number": 40.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/26/17",
                "format": "",
                "label": "Temperature",
                "number": 39.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/27/17",
                "format": "",
                "label": "Temperature",
                "number": 39.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/28/17",
                "format": "",
                "label": "Temperature",
                "number": 41.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/29/17",
                "format": "",
                "label": "Temperature",
                "number": 40.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/30/17",
                "format": "",
                "label": "Temperature",
                "number": 41.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "8/31/17",
                "format": "",
                "label": "Temperature",
                "number": 41.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "9/01/17",
                "format": "",
                "label": "Temperature",
                "number": 39.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "9/02/17",
                "format": "",
                "label": "Temperature",
                "number": 48.00,
                "units": ""
            },

            {
                "currencyCode": "",
                "for": "9/03/17",
                "format": "",
                "label": "Temperature",
                "number": 51.00,
                "units": ""
            }
        ]
}
],

"maxNumber": 51,
"minNumber": 16,
"xaxisLabels":
[
"1/01/17",
"1/02/17",
"1/03/17",
"1/04/17",
"1/05/17",
"1/06/17",
"1/07/17",
"1/08/17",
"1/09/17",
"1/10/17",
"1/11/17",
"1/12/17",
"1/13/17",
"1/14/17",
"1/15/17",
"1/16/17",
"1/17/17",
"1/18/17",
"1/19/17",
"1/20/17",
"1/21/17",
"1/22/17",
"1/23/17",
"1/24/17",
"1/25/17",
"1/26/17",
"1/27/17",
"1/28/17",
"1/29/17",
"1/30/17",
"1/31/17",
"2/01/17",
"2/02/17",
"2/03/17",
"2/04/17",
"2/05/17",
"2/06/17",
"2/07/17",
"2/08/17",
"2/09/17",
"2/10/17",
"2/11/17",
"2/12/17",
"2/13/17",
"2/14/17",
"2/15/17",
"2/16/17",
"2/17/17",
"2/18/17",
"2/19/17",
"2/20/17",
"2/21/17",
"2/22/17",
"2/23/17",
"2/24/17",
"2/25/17",
"2/26/17",
"2/27/17",
"2/28/17",
"3/01/17",
"3/02/17",
"3/03/17",
"3/04/17",
"3/05/17",
"3/06/17",
"3/07/17",
"3/08/17",
"3/09/17",
"3/10/17",
"3/11/17",
"3/12/17",
"3/13/17",
"3/14/17",
"3/15/17",
"3/16/17",
"3/17/17",
"3/18/17",
"3/19/17",
"3/20/17",
"3/21/17",
"3/22/17",
"3/23/17",
"3/24/17",
"3/25/17",
"3/26/17",
"3/27/17",
"3/28/17",
"3/29/17",
"3/30/17",
"3/31/17",
"4/01/17",
"4/02/17",
"4/03/17",
"4/04/17",
"4/05/17",
"4/06/17",
"4/07/17",
"4/08/17",
"4/09/17",
"4/10/17",
"4/11/17",
"4/12/17",
"4/13/17",
"4/14/17",
"4/15/17",
"4/16/17",
"4/17/17",
"4/18/17",
"4/19/17",
"4/20/17",
"4/21/17",
"4/22/17",
"4/23/17",
"4/24/17",
"4/25/17",
"4/26/17",
"4/27/17",
"4/28/17",
"4/29/17",
"4/30/17",
"5/01/17",
"5/02/17",
"5/03/17",
"5/04/17",
"5/05/17",
"5/06/17",
"5/07/17",
"5/08/17",
"5/09/17",
"5/10/17",
"5/11/17",
"5/12/17",
"5/13/17",
"5/14/17",
"5/15/17",
"5/16/17",
"5/17/17",
"5/18/17",
"5/19/17",
"5/20/17",
"5/21/17",
"5/22/17",
"5/23/17",
"5/24/17",
"5/25/17",
"5/26/17",
"5/27/17",
"5/28/17",
"5/29/17",
"5/30/17",
"5/31/17",
"6/01/17",
"6/02/17",
"6/03/17",
"6/04/17",
"6/05/17",
"6/06/17",
"6/07/17",
"6/08/17",
"6/09/17",
"6/10/17",
"6/11/17",
"6/12/17",
"6/13/17",
"6/14/17",
"6/15/17",
"6/16/17",
"6/17/17",
"6/18/17",
"6/19/17",
"6/20/17",
"6/21/17",
"6/22/17",
"6/23/17",
"6/24/17",
"6/25/17",
"6/26/17",
"6/27/17",
"6/28/17",
"6/29/17",
"6/30/17",
"7/01/17",
"7/02/17",
"7/03/17",
"7/04/17",
"7/05/17",
"7/06/17",
"7/07/17",
"7/08/17",
"7/09/17",
"7/10/17",
"7/11/17",
"7/12/17",
"7/13/17",
"7/14/17",
"7/15/17",
"7/16/17",
"7/17/17",
"7/18/17",
"7/19/17",
"7/20/17",
"7/21/17",
"7/22/17",
"7/23/17",
"7/24/17",
"7/25/17",
"7/26/17",
"7/27/17",
"7/28/17",
"7/29/17",
"7/30/17",
"7/31/17",
"8/01/17",
"8/02/17",
"8/03/17",
"8/04/17",
"8/05/17",
"8/06/17",
"8/07/17",
"8/08/17",
"8/09/17",
"8/10/17",
"8/11/17",
"8/12/17",
"8/13/17",
"8/14/17",
"8/15/17",
"8/16/17",
"8/17/17",
"8/18/17",
"8/19/17",
"8/20/17",
"8/21/17",
"8/22/17",
"8/23/17",
"8/24/17",
"8/25/17",
"8/26/17",
"8/27/17",
"8/28/17",
"8/29/17",
"8/30/17",
"8/31/17",
"9/01/17",
"9/02/17",
"9/03/17"
]
}
},

"insightText": "Temp ALL",
"tileConfiguration":
{
"allowDrillDown": true,
"category": "Weather",
"chartType": "lineGraph",
"chartTypeDetail": "lineGraph",
"definition": "Temperature",
"detailMeasures":
[

],

"equation": "Temperature",
"healthVariancePercent": 0.03,
"isDetailHeader": false,
"kpiId": "temperature",
"tileSize": "single",
"largerNumberIsHealthier": true,
"majorLines":
[
"Actual"
],

"menuFamilyIds":
[

],

"name": "Temperature",
"numberBarCenter": "High Temperature",
"numberBarLeft": "Average Temperature",
"numberBarRight": "Low Temperature",
"pointOfContactEmail": "taggardandrewsr@kpmg.com",
"pointOfContactName": "Taggard Andrews",
"pointOfContactPingId": "",
"referenceLineKpiIds":
[

],
"shortName": "Temperature",
"showComments": true,
"showNumberBar": true,
"supportLineKpiIds":
[

],

"usePercentChangeOverTimeInKpiData": false,
"watch": false
},
"kpiSummary":
[
{
"values":
[

]
}
],

"lastRefreshDate": "2016-09-15T16:08:33.000Z",
"primaryDisplayNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
}
],

"priority": 1,
"source": "National Weather Service",
"totalCommentCount": 0,
"trending": false
},
{
"bottomBarNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
},

{
"format": "average/int",
"icon": "max",
"label": "MaxTemp",
"number": 18
},

{
"format": "average/int",
"icon": "min",
"label": "MinTemp",
"number": 11
}
],
"insightText": "Bar Chart",
"chartData": {
"barChartData": {
"maxNumber": 23000000000,
"minNumber": 16000000000,
"numbers": [
{
"number": 19000000000,
"format": "currency",
"currencyCode": "USD",
"health": "positive",
"label": "2011"
},
{
"number": 21000000000,
"format": "currency",
"currencyCode": "USD",
"label": "2012"
},
{
"number": 18000000000,
"format": "currency",
"currencyCode": "USD",
"health": "negative",
"label": "2013"
},
{
"number": 23000000000,
"format": "currency",
"currencyCode": "USD",
"label": "2014"
},
{
"number": 16000000000,
"format": "currency",
"currencyCode": "USD",
"health": "neutral",
"label": "2015"
},
{
"number": 17000000000,
"budget": 22000000000,
"format": "currency",
"health": "negative",
"currencyCode": "USD",
"label": "2016"
}
]
}
},
"tileConfiguration":
{
"allowDrillDown": true,
"category": "Weather",
"chartType": "horizontalBarChart",
"chartTypeDetail": "horizontalBarChart",
"definition": "Temperature",
"detailMeasures":
[

],

"equation": "Temperature",
"healthVariancePercent": 0.03,
"isDetailHeader": false,
"kpiId": "temperature",
"kpiType": "single",
"largerNumberIsHealthier": true,
"majorLines":
[
"Actual"
],

"menuFamilyIds":
[

],

"name": "Temperature",
"numberBarCenter": "High Temperature",
"numberBarLeft": "Average Temperature",
"numberBarRight": "Low Temperature",
"pointOfContactEmail": "taggardandrewsr@kpmg.com",
"pointOfContactName": "Taggard Andrews",
"pointOfContactPingId": "",
"referenceLineKpiIds":
[

],
"shortName": "Temperature",
"showComments": true,
"showNumberBar": true,
"supportLineKpiIds":
[

],

"usePercentChangeOverTimeInKpiData": false,
"watch": false
},
"kpiSummary":
[
{
"values":
[

]
}
],
"lastRefreshDate": "2016-09-15T16:08:33.000Z",
"primaryDisplayNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
}
],
"newCommentCount": 0,
"trending": false,
"priority": 21,
"source": "National Weather Service",
"totalCommentCount": 3
},
{
"bottomBarNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
},

{
"format": "average/int",
"icon": "max",
"label": "MaxTemp",
"number": 18
},

{
"format": "average/int",
"icon": "min",
"label": "MinTemp",
"number": 11
}
],
"insightText": "Bar Chart",
"chartData": {
"barChartData": {
"maxNumber": 23000000000,
"minNumber": 16000000000,
"numbers": [
{
"number": 19000000000,
"format": "currency",
"currencyCode": "USD",
"health": "positive",
"label": "2011"
},
{
"number": 21000000000,
"format": "currency",
"currencyCode": "USD",
"label": "2012"
},
{
"number": 18000000000,
"format": "currency",
"currencyCode": "USD",
"health": "negative",
"label": "2013"
},
{
"number": 23000000000,
"format": "currency",
"currencyCode": "USD",
"label": "2014"
},
{
"number": 16000000000,
"format": "currency",
"currencyCode": "USD",
"health": "neutral",
"label": "2015"
},
{
"number": 17000000000,
"budget": 22000000000,
"format": "currency",
"health": "negative",
"currencyCode": "USD",
"label": "2016"
}
]
}
},
"tileConfiguration":
{
"allowDrillDown": true,
"category": "Weather",
"chartType": "verticalBarChart",
"chartTypeDetail": "verticalBarChart",
"definition": "Temperature",
"detailMeasures":
[

],

"equation": "Temperature",
"healthVariancePercent": 0.03,
"isDetailHeader": false,
"kpiId": "temperature",
"kpiType": "single",
"largerNumberIsHealthier": true,
"majorLines":
[
"Actual"
],

"menuFamilyIds":
[

],

"name": "Temperature",
"numberBarCenter": "High Temperature",
"numberBarLeft": "Average Temperature",
"numberBarRight": "Low Temperature",
"pointOfContactEmail": "taggardandrewsr@kpmg.com",
"pointOfContactName": "Taggard Andrews",
"pointOfContactPingId": "",
"referenceLineKpiIds":
[

],
"shortName": "Temperature",
"showComments": true,
"showNumberBar": true,
"supportLineKpiIds":
[

],

"usePercentChangeOverTimeInKpiData": false,
"watch": false
},
"kpiSummary":
[
{
"values":
[

]
}
],
"lastRefreshDate": "2016-09-15T16:08:33.000Z",
"primaryDisplayNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
}
],
"newCommentCount": 0,
"trending": false,
"priority": 21,
"source": "National Weather Service",
"totalCommentCount": 3
}
],
"name": "Line Graphs"
},
{
"kpis":
[
{
"chartData": {
"donutChartData": {
"donutCharts": [
{
"numbers": [
{
"number": 0.69,
"format": "percentage",
"health": "positive",
"label": "2015"
}
]
}
]
}
},
"bottomBarNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
},

{
"format": "average/int",
"icon": "max",
"label": "MaxTemp",
"number": 18
},

{
"format": "average/int",
"icon": "min",
"label": "MinTemp",
"number": 11
}
],
"insightText": "Temp ALL",
"tileConfiguration":
{
"allowDrillDown": true,
"category": "Weather",
"chartType": "donut",
"chartTypeDetail": "donut",
"definition": "Temperature",
"detailMeasures":
[

],

"equation": "Temperature",
"healthVariancePercent": 0.03,
"isDetailHeader": false,
"kpiId": "temperature",
"kpiType": "single",
"largerNumberIsHealthier": true,
"majorLines":
[
"Actual"
],

"menuFamilyIds":
[

],

"name": "Temperature",
"numberBarCenter": "High Temperature",
"numberBarLeft": "Average Temperature",
"numberBarRight": "Low Temperature",
"pointOfContactEmail": "taggardandrewsr@kpmg.com",
"pointOfContactName": "Taggard Andrews",
"pointOfContactPingId": "",
"referenceLineKpiIds":
[

],
"shortName": "Temperature",
"showComments": true,
"showNumberBar": true,
"supportLineKpiIds":
[

],

"usePercentChangeOverTimeInKpiData": false,
"watch": false
},
"kpiSummary":
[
{
"values":
[

]
}
],

"lastRefreshDate": "2016-09-15T16:08:33.000Z",
"primaryDisplayNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
}
],

"priority": 1,
"source": "National Weather Service",
"totalCommentCount": 0,
"trending": false
},
{
"chartData": {
"donutChartData": {
"donutCharts": [
{
"numbers": [
{
"number": 0.88,
"budget": 0.78,
"format": "percentage",
"health": "negative",
"label": "2016"
}
]
},
{
"numbers": [
{
"number": 0.69,
"format": "percentage",
"health": "neutral",
"label": "2015"
}
]
}
]
}
},
"bottomBarNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
},

{
"format": "average/int",
"icon": "max",
"label": "MaxTemp",
"number": 18
},

{
"format": "average/int",
"icon": "min",
"label": "MinTemp",
"number": 11
}
],
"insightText": "Temp ALL",
"tileConfiguration":
{
"allowDrillDown": true,
"category": "Weather",
"chartType": "donut",
"chartTypeDetail": "donut",
"definition": "Temperature",
"detailMeasures":
[

],

"equation": "Temperature",
"healthVariancePercent": 0.03,
"isDetailHeader": false,
"kpiId": "temperature",
"kpiType": "single",
"largerNumberIsHealthier": true,
"majorLines":
[
"Actual"
],

"menuFamilyIds":
[

],

"name": "Temperature",
"numberBarCenter": "High Temperature",
"numberBarLeft": "Average Temperature",
"numberBarRight": "Low Temperature",
"pointOfContactEmail": "taggardandrewsr@kpmg.com",
"pointOfContactName": "Taggard Andrews",
"pointOfContactPingId": "",
"referenceLineKpiIds":
[

],
"shortName": "Temperature",
"showComments": true,
"showNumberBar": true,
"supportLineKpiIds":
[

],

"usePercentChangeOverTimeInKpiData": false,
"watch": false
},
"kpiSummary":
[
{
"values":
[

]
}
],

"lastRefreshDate": "2016-09-15T16:08:33.000Z",
"primaryDisplayNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
}
],

"priority": 1,
"source": "National Weather Service",
"totalCommentCount": 0,
"trending": false
},
{
"chartData": {
"donutChartData": {
"donutCharts": [
{
"numbers": [
{
"number": 0.54,
"budget": 0.52,
"format": "percentage",
"health": "neutral",
"label": "2016"
},
{
"number": 160000
},
{
"number": 200000
}
]
},
{
"numbers": [
{
"number": 0.61,
"budget": 0.67,
"format": "percentage",
"health": "positive",
"label": "2015"
}
]
},
{
"numbers": [
{
"number": 0.91,
"budget": 0.83,
"format": "percentage",
"health": "negative",
"label": "2015"
}
]
}
]
}
},
"bottomBarNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
},

{
"format": "average/int",
"icon": "max",
"label": "MaxTemp",
"number": 18
},

{
"format": "average/int",
"icon": "min",
"label": "MinTemp",
"number": 11
}
],
"insightText": "Temp ALL",
"tileConfiguration":
{
"allowDrillDown": true,
"category": "Weather",
"chartType": "donut",
"chartTypeDetail": "donut",
"definition": "Temperature",
"detailMeasures":
[

],

"equation": "Temperature",
"healthVariancePercent": 0.03,
"isDetailHeader": false,
"kpiId": "temperature",
"kpiType": "single",
"largerNumberIsHealthier": true,
"majorLines":
[
"Actual"
],

"menuFamilyIds":
[

],

"name": "Temperature",
"numberBarCenter": "High Temperature",
"numberBarLeft": "Average Temperature",
"numberBarRight": "Low Temperature",
"pointOfContactEmail": "taggardandrewsr@kpmg.com",
"pointOfContactName": "Taggard Andrews",
"pointOfContactPingId": "",
"referenceLineKpiIds":
[

],
"shortName": "Temperature",
"showComments": true,
"showNumberBar": true,
"supportLineKpiIds":
[

],

"usePercentChangeOverTimeInKpiData": false,
"watch": false
},
"kpiSummary":
[
{
"values":
[

]
}
],

"lastRefreshDate": "2016-09-15T16:08:33.000Z",
"primaryDisplayNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
}
],

"priority": 1,
"source": "National Weather Service",
"totalCommentCount": 0,
"trending": false
},
{
"chartData": {
"donutMetricData": {
"donutCharts": [
{
"numbers": [
{
"number": 0.37,
"budget": 0.42,
"format": "percentage",
"health": "positive",
"label": "2015"
}
]
}
],
"metricNumbers": [
{
"number": 6400000000,
"format": "currency",
"label": "R&D Expense"
},
{
"number": 16000000000,
"format": "currency",
"label": "Net Sales"
}
]
}
},
"bottomBarNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
},

{
"format": "average/int",
"icon": "max",
"label": "MaxTemp",
"number": 18
},

{
"format": "average/int",
"icon": "min",
"label": "MinTemp",
"number": 11
}
],
"insightText": "Temp ALL",
"tileConfiguration":
{
"allowDrillDown": true,
"category": "Weather",
"chartType": "donutMetric",
"chartTypeDetail": "donutMetric",
"definition": "Temperature",
"detailMeasures":
[

],

"equation": "Temperature",
"healthVariancePercent": 0.03,
"isDetailHeader": false,
"kpiId": "temperature",
"kpiType": "single",
"largerNumberIsHealthier": true,
"majorLines":
[
"Actual"
],

"menuFamilyIds":
[

],

"name": "Temperature",
"numberBarCenter": "High Temperature",
"numberBarLeft": "Average Temperature",
"numberBarRight": "Low Temperature",
"pointOfContactEmail": "taggardandrewsr@kpmg.com",
"pointOfContactName": "Taggard Andrews",
"pointOfContactPingId": "",
"referenceLineKpiIds":
[

],
"shortName": "Temperature",
"showComments": true,
"showNumberBar": true,
"supportLineKpiIds":
[

],

"usePercentChangeOverTimeInKpiData": false,
"watch": false
},
"kpiSummary":
[
{
"values":
[

]
}
],

"lastRefreshDate": "2016-09-15T16:08:33.000Z",
"primaryDisplayNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
}
],

"priority": 1,
"source": "National Weather Service",
"totalCommentCount": 0,
"trending": false
},
{
"chartData": {
"donutVerticalData": {
"barChartData": {
"maxNumber": 100,
"minNumber": 0,
"numbers": [
{
"format": "Percentage",
"label": "7",
"health": "negative",
"number": 0.077
},
{
"format": "Percentage",
"label": "8",
"health": "neutral",
"number": 0.142
},
{
"format": "Percentage",
"health": "positive",
"label": "9",
"number": 0.043
}
]
},
"donutChartData": {
"numbers": [
{
"format": "Percentage",
"label": "Total",
"health": "negative",
"number": 0.26
}
]
}
}
},
"bottomBarNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
},

{
"format": "average/int",
"icon": "max",
"label": "MaxTemp",
"number": 18
},

{
"format": "average/int",
"icon": "min",
"label": "MinTemp",
"number": 11
}
],
"insightText": "Temp ALL",
"tileConfiguration":
{
"allowDrillDown": true,
"category": "Weather",
"chartType": "donutVertical",
"chartTypeDetail": "donutVertical",
"definition": "Temperature",
"detailMeasures":
[

],

"equation": "Temperature",
"healthVariancePercent": 0.03,
"isDetailHeader": false,
"kpiId": "temperature",
"kpiType": "single",
"largerNumberIsHealthier": true,
"majorLines":
[
"Actual"
],

"menuFamilyIds":
[

],

"name": "Temperature",
"numberBarCenter": "High Temperature",
"numberBarLeft": "Average Temperature",
"numberBarRight": "Low Temperature",
"pointOfContactEmail": "taggardandrewsr@kpmg.com",
"pointOfContactName": "Taggard Andrews",
"pointOfContactPingId": "",
"referenceLineKpiIds":
[

],
"shortName": "Temperature",
"showComments": true,
"showNumberBar": true,
"supportLineKpiIds":
[

],

"usePercentChangeOverTimeInKpiData": false,
"watch": false
},
"kpiSummary":
[
{
"values":
[

]
}
],

"lastRefreshDate": "2016-09-15T16:08:33.000Z",
"primaryDisplayNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
}
],

"priority": 1,
"source": "National Weather Service",
"totalCommentCount": 0,
"trending": false
},
{
"chartData": {
"segmentedDonutData": {
"segmentNumbers": [
{
"label": "Other",
"numData": {
"format": "percentage",
"number": 0.02,
"percentOfTotal": 0.02,
"units": "visits"
}
},
{
"label": "Retain",
"numData": {
"format": "percentage",
"number": 0.03,
"percentOfTotal": 0.03,
"units": "visits"
}
},
{
"label": "Acquire",
"numData": {
"format": "percentage",
"number": 0.12,
"percentOfTotal": 0.12,
"units": "visits"
}
},
{
"label": "Develop",
"numData": {
"format": "percentage",
"number": 0.71,
"percentOfTotal": 0.71,
"units": "visits"
}
},
{
"label": "Light Touch",
"numData": {
"format": "percentage",
"number": 0.13,
"percentOfTotal": 0.13,
"units": "visits"
}
}
],
"summaryNumber": {
"label": "Total",
"number": 262,
"units": "visits"
}
}
},
"bottomBarNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
},

{
"format": "average/int",
"icon": "max",
"label": "MaxTemp",
"number": 18
},

{
"format": "average/int",
"icon": "min",
"label": "MinTemp",
"number": 11
}
],
"insightText": "Temp ALL",
"tileConfiguration":
{
"allowDrillDown": true,
"category": "Weather",
"chartType": "segmentedDonut",
"chartTypeDetail": "segmentedDonut",
"definition": "Temperature",
"detailMeasures":
[

],

"equation": "Temperature",
"healthVariancePercent": 0.03,
"isDetailHeader": false,
"kpiId": "temperature",
"kpiType": "single",
"largerNumberIsHealthier": true,
"majorLines":
[
"Actual"
],

"menuFamilyIds":
[

],

"name": "Temperature",
"numberBarCenter": "High Temperature",
"numberBarLeft": "Average Temperature",
"numberBarRight": "Low Temperature",
"pointOfContactEmail": "taggardandrewsr@kpmg.com",
"pointOfContactName": "Taggard Andrews",
"pointOfContactPingId": "",
"referenceLineKpiIds":
[

],
"shortName": "Temperature",
"showComments": true,
"showNumberBar": true,
"supportLineKpiIds":
[

],

"usePercentChangeOverTimeInKpiData": false,
"watch": false
},
"kpiSummary":
[
{
"values":
[

]
}
],

"lastRefreshDate": "2016-09-15T16:08:33.000Z",
"primaryDisplayNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
}
],

"priority": 1,
"source": "National Weather Service",
"totalCommentCount": 0,
"trending": false
},
{
"chartData": {
"segmentedDonutData": {
"segmentNumbers": [
{
"label": "Dist Comp",
"numData": {
"format": "percentage",
"number": 0.08
}
},
{
"label": "Grower Incnt",
"numData": {
"format": "percentage",
"number": 0.1
}
},
{
"label": "Pmnt Incnt",
"numData": {
"format": "percentage",
"number": 0.22
}
},
{
"label": "KASA",
"numData": {
"format": "percentage",
"number": 0.16
}
},
{
"label": "LM Progs",
"numData": {
"format": "percentage",
"number": 0.18
}
},
{
"label": "Disc Progs",
"numData": {
"format": "percentage",
"number": 0.12
}
},
{
"label": "GP Claims",
"numData": {
"format": "percentage",
"number": 0.14
}
}
],
"summaryNumber": {
"format": "currency",
"label": "Total",
"number": 1000000000
}
}
},
"bottomBarNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
},

{
"format": "average/int",
"icon": "max",
"label": "MaxTemp",
"number": 18
},

{
"format": "average/int",
"icon": "min",
"label": "MinTemp",
"number": 11
}
],
"insightText": "Temp ALL",
"tileConfiguration":
{
"allowDrillDown": true,
"category": "Weather",
"chartType": "segmentedDonut",
"chartTypeDetail": "segmentedDonut",
"definition": "Temperature",
"detailMeasures":
[

],

"equation": "Temperature",
"healthVariancePercent": 0.03,
"isDetailHeader": false,
"kpiId": "temperature",
"kpiType": "single",
"largerNumberIsHealthier": true,
"majorLines":
[
"Actual"
],

"menuFamilyIds":
[

],

"name": "Temperature",
"numberBarCenter": "High Temperature",
"numberBarLeft": "Average Temperature",
"numberBarRight": "Low Temperature",
"pointOfContactEmail": "taggardandrewsr@kpmg.com",
"pointOfContactName": "Taggard Andrews",
"pointOfContactPingId": "",
"referenceLineKpiIds":
[

],
"shortName": "Temperature",
"showComments": true,
"showNumberBar": true,
"supportLineKpiIds":
[

],

"usePercentChangeOverTimeInKpiData": false,
"watch": false
},
"kpiSummary":
[
{
"values":
[

]
}
],

"lastRefreshDate": "2016-09-15T16:08:33.000Z",
"primaryDisplayNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
}
],

"priority": 1,
"source": "National Weather Service",
"totalCommentCount": 0,
"trending": false
},
{
"chartData": {
"donutSegmentVerticalData": {
"donutChartData": {
"numbers": [
{
"number": 0.12,
"label": "Total",
"forecast": 0.15,
"health": "neutral"
}
]
},
"segmentChartData": [
{
"label": "Other",
"numData": {
"format": "percentage",
"number": 0.02,
"percentOfTotal": 0.02,
"units": "visits"
}
},
{
"label": "Retain",
"numData": {
"format": "percentage",
"number": 0.03,
"percentOfTotal": 0.03,
"units": "visits"
}
},
{
"label": "Acquire",
"numData": {
"format": "percentage",
"number": 0.12,
"percentOfTotal": 0.12,
"units": "visits"
}
},
{
"label": "Develop",
"numData": {
"format": "percentage",
"number": 0.71,
"percentOfTotal": 0.71,
"units": "visits"
}
},
{
"label": "Light Touch",
"numData": {
"format": "percentage",
"number": 0.13,
"percentOfTotal": 0.13,
"units": "visits"
}
}
]
}
},
"bottomBarNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
},

{
"format": "average/int",
"icon": "max",
"label": "MaxTemp",
"number": 18
},

{
"format": "average/int",
"icon": "min",
"label": "MinTemp",
"number": 11
}
],
"insightText": "Temp ALL",
"tileConfiguration":
{
"allowDrillDown": true,
"category": "Weather",
"chartType": "donutSegmentVertical",
"chartTypeDetail": "donutSegmentVertical",
"definition": "Temperature",
"detailMeasures":
[

],

"equation": "Temperature",
"healthVariancePercent": 0.03,
"isDetailHeader": false,
"kpiId": "temperature",
"kpiType": "single",
"largerNumberIsHealthier": true,
"majorLines":
[
"Actual"
],

"menuFamilyIds":
[

],

"name": "Temperature",
"numberBarCenter": "High Temperature",
"numberBarLeft": "Average Temperature",
"numberBarRight": "Low Temperature",
"pointOfContactEmail": "taggardandrewsr@kpmg.com",
"pointOfContactName": "Taggard Andrews",
"pointOfContactPingId": "",
"referenceLineKpiIds":
[

],
"shortName": "Temperature",
"showComments": true,
"showNumberBar": true,
"supportLineKpiIds":
[

],

"usePercentChangeOverTimeInKpiData": false,
"watch": false
},
"kpiSummary":
[
{
"values":
[

]
}
],

"lastRefreshDate": "2016-09-15T16:08:33.000Z",
"primaryDisplayNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
}
],

"priority": 1,
"source": "National Weather Service",
"totalCommentCount": 0,
"trending": false
},
{
"chartData": {
"gaugeChartData": {
"numbers": [
{
"format": "percentage",
"health": "positive",
"label": "PR FCST",
"number": 0.24
},
{
"format": "percentage",
"health": "negative",
"label": "BUD",
"number": -0.07
},
{
"format": "percentage",
"health": "neutral",
"label": "PR YR",
"number": 0.03
}
]
}
},
"bottomBarNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
},

{
"format": "average/int",
"icon": "max",
"label": "MaxTemp",
"number": 18
},

{
"format": "average/int",
"icon": "min",
"label": "MinTemp",
"number": 11
}
],
"insightText": "Temp ALL",
"tileConfiguration":
{
"allowDrillDown": true,
"category": "Weather",
"chartType": "gauges",
"chartTypeDetail": "gauges",
"definition": "Temperature",
"detailMeasures":
[

],

"equation": "Temperature",
"healthVariancePercent": 0.03,
"isDetailHeader": false,
"kpiId": "temperature",
"kpiType": "single",
"largerNumberIsHealthier": true,
"majorLines":
[
"Actual"
],

"menuFamilyIds":
[

],

"name": "Temperature",
"numberBarCenter": "High Temperature",
"numberBarLeft": "Average Temperature",
"numberBarRight": "Low Temperature",
"pointOfContactEmail": "taggardandrewsr@kpmg.com",
"pointOfContactName": "Taggard Andrews",
"pointOfContactPingId": "",
"referenceLineKpiIds":
[

],
"shortName": "Temperature",
"showComments": true,
"showNumberBar": true,
"supportLineKpiIds":
[

],

"usePercentChangeOverTimeInKpiData": false,
"watch": false
},
"kpiSummary":
[
{
"values":
[

]
}
],

"lastRefreshDate": "2016-09-15T16:08:33.000Z",
"primaryDisplayNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
}
],

"priority": 1,
"source": "National Weather Service",
"totalCommentCount": 0,
"trending": false
}
],
"name": "Donut Charts"
},
{
"kpis": [
{
"chartData": {
"gaugeChartData": {
"numbers": [
{
"format": "percentage",
"health": "positive",
"label": "PR FCST",
"number": 0.24
},
{
"format": "percentage",
"health": "negative",
"label": "BUD",
"number": -0.07
},
{
"format": "percentage",
"health": "neutral",
"label": "PR YR",
"number": 0.03
}
]
}
},
"bottomBarNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
},

{
"format": "average/int",
"icon": "max",
"label": "MaxTemp",
"number": 18
},

{
"format": "average/int",
"icon": "min",
"label": "MinTemp",
"number": 11
}
],
"insightText": "Temp ALL",
"tileConfiguration":
{
"allowDrillDown": true,
"category": "Weather",
"chartType": "tornadoChart",
"chartTypeDetail": "tornadoChart",
"definition": "Temperature",
"detailMeasures":
[

],

"equation": "Temperature",
"healthVariancePercent": 0.03,
"isDetailHeader": false,
"kpiId": "temperature",
"kpiType": "single",
"largerNumberIsHealthier": true,
"majorLines":
[
"Actual"
],

"menuFamilyIds":
[

],

"name": "Temperature",
"numberBarCenter": "High Temperature",
"numberBarLeft": "Average Temperature",
"numberBarRight": "Low Temperature",
"pointOfContactEmail": "taggardandrewsr@kpmg.com",
"pointOfContactName": "Taggard Andrews",
"pointOfContactPingId": "",
"referenceLineKpiIds":
[

],
"shortName": "Temperature",
"showComments": true,
"showNumberBar": true,
"supportLineKpiIds":
[

],

"usePercentChangeOverTimeInKpiData": false,
"watch": false
},
"kpiSummary":
[
{
"values":
[

]
}
],

"lastRefreshDate": "2016-09-15T16:08:33.000Z",
"primaryDisplayNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
}
],

"priority": 1,
"source": "National Weather Service",
"totalCommentCount": 0,
"trending": false
},
{
"chartData": {
"gaugeChartData": {
"numbers": [
{
"format": "percentage",
"health": "neutral",
"label": "FCST",
"number": -0.02
},
{
"format": "percentage",
"health": "positive",
"label": "PY",
"number": 0.06
},
{
"format": "percentage",
"health": "positive",
"label": "PR FCST",
"number": 0.05
}
],
"callouts": [
{
"number": 5000000,
"format": "currency",
"currencyCode": "USD",
"for": "FCST"
}
]
},
"differenceData": {
"numbers": [
{
"format": "percentage",
"label": "BUD",
"number": 0.25
}
]
}
},
"bottomBarNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
},

{
"format": "average/int",
"icon": "max",
"label": "MaxTemp",
"number": 18
},

{
"format": "average/int",
"icon": "min",
"label": "MinTemp",
"number": 11
}
],
"insightText": "Temp ALL",
"tileConfiguration":
{
"allowDrillDown": true,
"category": "Weather",
"chartType": "tornadoDifferenceChart",
"chartTypeDetail": "tornadoDifferenceChart",
"definition": "Temperature",
"detailMeasures":
[

],

"equation": "Temperature",
"healthVariancePercent": 0.03,
"isDetailHeader": false,
"kpiId": "temperature",
"kpiType": "single",
"largerNumberIsHealthier": true,
"majorLines":
[
"Actual"
],

"menuFamilyIds":
[

],

"name": "Temperature",
"numberBarCenter": "High Temperature",
"numberBarLeft": "Average Temperature",
"numberBarRight": "Low Temperature",
"pointOfContactEmail": "taggardandrewsr@kpmg.com",
"pointOfContactName": "Taggard Andrews",
"pointOfContactPingId": "",
"referenceLineKpiIds":
[

],
"shortName": "Temperature",
"showComments": true,
"showNumberBar": true,
"supportLineKpiIds":
[

],

"usePercentChangeOverTimeInKpiData": false,
"watch": false
},
"kpiSummary":
[
{
"values":
[

]
}
],

"lastRefreshDate": "2016-09-15T16:08:33.000Z",
"primaryDisplayNumbers":
[
{
"format": "average/int",
"icon": "avg",
"label": "AvgTemp",
"number": 51
}
],

"priority": 1,
"source": "National Weather Service",
"totalCommentCount": 0,
"trending": false
}
],
"name": "Other Charts"
}
],
"name": "Visualization Catalog",
"activateBusinessAndGeoDropDowns": true,
"activateCategoryDropDown": true
};
