/**
 * @module preloader/reporter
 */
module.exports = {

    /**
     * Sends the error to teh server
     * @param {object} error The error object to send
     * @returns {void}
     */
    send: function(error) {
        const config = require('config');
        window.console.log(config);

        const serviceUrl = config.server + '/v1/errors';



        const $ = require('jquery');
        console.log('Reporting error to server: ' + JSON.stringify(error, null, '\t'));
        $.ajax(serviceUrl, {
            data: JSON.stringify(error),
            contentType: 'application/json',
            type: 'PUT',
        });
    },

};
