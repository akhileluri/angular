var errorCodes = require('./errorcodes');

describe('preloader/errorcodes.js', function () {

    it('should return errorCodes instance', function () {
        expect(errorCodes).toBeDefined();
    });
});

