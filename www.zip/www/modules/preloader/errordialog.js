/**
 * This default implementation leverages the modal API from Twitter Bootstrap
 * but can be replaced with an alternate implementation without modifying other
 * parts of the error handling mechansim
 *
 * @module preloader/errordialog
 */

module.exports = {
    reload: function() {
        window.location.reload();
    },
    /**
     * Displays a message to the user in a way that blocks further user actions.
     * Once the user has acknowledged the message, the page reloads to return the app to a known-good state.
     * @param {object} error The error object to show
     * @param {string} error.id a unique id value to display to users which corresponds to a value logged to the server
     * @param {string} error.message a localized string to display to users
     * @returns {void}
     */
    show: function(error) {
        const html = require('./errordialog.html');
        const $ = require('jquery');
        const i18n = require('i18next');

        try {
            // Add the dialog template to the end of <body>

            $(document.body).append(typeof html === 'function' ? html() : html);// could be template function

            const $dialog = $('#errorDialogModal');
            const $errorId = $dialog.find('.error-id');
            const $errorMessage = $dialog.find('.error-message');
            const $errorTitle = $dialog.find('.modal-title');

            let $title = 'Error';
            let $message = 'Your page can not be displayed as requested.  Please reload the page.';

            const $errorCode = error.id.split(':')[0];
            if ($errorCode === '401') {
                // TODO: Handle cases where the user in unauthorized. This is fairly general, so we have to consider a framework level approach.
                $title = 'Error: User Authenication Error';
                $message = 'You are not properly verified to access this area.';

                // TODO: This is a temporary fix (2018-MAR-14), this should prompt the user for a new token.
                window.localStorage.removeItem('queryString');
            }
            else if ($errorCode === '403') {
                $title = 'Error: User Permission Error';
                $message = 'You do not have the necessary authorization to access this area.';
            }
            else if ($errorCode === '404') {
                $title = 'Error: Resource Not Found';
                $message = 'The requested page could not be found.';
            }

            $errorTitle.data('i18n-options', {title: $title}); // set the 'id' variable which the localized string will reference
            $errorId.data('i18n-options', {id: error.id}); // set the 'id' variable which the localized string will reference
            $errorMessage.data('i18n-options', {message: $message}); // set the 'message' variable which the localized string will reference
            $dialog.i18n(); // invoke localization

            if (!$errorId.text()) {
                $errorId.text(error.id);
            }

            // handle the dialog being dismissed by reloading the page so we return to a known-good state
            $dialog.on('hide.bs.modal', function() {
                // TODO: consider also cleaning localstorage, etc if cached data could prevent being in a known-good state
                module.exports.reload();
            });

            $dialog.modal(); // show the modal
        }
        catch (ex) {
            // We'll end up here if an error occurs before Bootstrap has loaded. Fall back to a confirmation
            // which devs can click 'cancel' on and open up a debugger

            // eslint-disable-next-line no-alert
            if (window.confirm(error.message + '\n\n' + i18n.t('preloader.errorDialog-id', {id: error.id}))) {
                module.exports.reload();
            }
        }
    },
};
