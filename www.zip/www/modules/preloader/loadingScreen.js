// Shows and removes the loading screen

require('./loadingScreen.less');
const html = require('./loading.html');
const loadingScreen = document.createElement('div');

loadingScreen.innerHTML = typeof html === 'function' ? html() : html;// could be template function

/**
 * @module preloader/loadingscreen
 * @example
 * let loadingScreen = require('modules/preloader/loadingscreen');
 */
module.exports = {
    /**
     * Show the loading screen
     * @returns {void}
     * @example
     * loadingScreen.show();
     */
    show: function() {
        if (!loadingScreen.parentNode) {
            document.body.appendChild(loadingScreen);
        }
    },

    /**
     * Hide the loading screen
     * @returns {void}
     * @example
     * loadingScreen.show();
     */
    remove: function() {
        if (loadingScreen.parentNode) {
            loadingScreen.parentNode.removeChild(loadingScreen);
        }
    },
};
