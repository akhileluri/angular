// This file was generated from the service scaffold
// Copyright 2016

const head:Element = document.getElementsByTagName('head')[0];

function addStyle(url:string, id:string, toElement:Element) {
    const link:Element = document.createElement('link');

    link.rel = 'stylesheet';
    link.href = url;
    link.id = id;
    toElement.appendChild(link);
}

addStyle('//fonts.googleapis.com/icon?family=Material+Icons', 'mdlIcons', head);
// addStyle('//fonts.googleapis.com/css?family=Assistant:200,300,400,600', 'uiFonts', head);
addStyle('fonts/MyFontsWebfontsKit.css?family=MuseoSans:200,300,400,600', 'museoFont', head);

// addStyle('//fonts.googleapis.com/css?family=Roboto|Roboto+Condensed', 'robotoFonts', head);
// addStyle('//fonts.googleapis.com/css?family=Nosifer', 'nosiferFonts', head);
// addStyle('//fonts.googleapis.com/css?family=Slabo+27px', 'slaboFonts', head);
// addStyle('//fonts.googleapis.com/css?family=Saira+Extra+Condensed', 'sairaFonts', head);
