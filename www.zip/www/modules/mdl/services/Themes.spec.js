// This file was generated from the service scaffold
// Copyright 2016

import {Injector} from '@angular/core';
import {
    addProviders,
    inject,
    async,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

import Themes from './Themes';

describe('mdl/services/Themes.js', () => {

    let themes:Themes = null;

    beforeEach(() => {
        addProviders([Themes]);
    });

    beforeEach(inject([Themes], (_themes:Themes) => {
        themes = _themes;
    }));

    it('should return Themes instance', () => {
        expect(themes).toBeDefined();
    });

    it('should return name', () => {
        expect(themes.getName()).toBe('Themes');
    });

    afterEach(() => themes = null);

});

