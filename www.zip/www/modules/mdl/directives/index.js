export const MDL_DIRECTIVES = [];

export MdlJs from './MdlJs';
MDL_DIRECTIVES.push(exports.MdlJs);

export MdlLayout from './MdlLayout';
MDL_DIRECTIVES.push(exports.MdlLayout);


export MdlTextfield from './MdlTextfield';
MDL_DIRECTIVES.push(exports.MdlTextfield);


export MdlTabs from './MdlTabs';
MDL_DIRECTIVES.push(exports.MdlTabs);

export MdlProgress from './MdlProgress';
MDL_DIRECTIVES.push(exports.MdlProgress);
