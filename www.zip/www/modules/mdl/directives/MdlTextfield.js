// This file was generated from the directive scaffold
// Copyright 2016

import {Directive, ElementRef} from '@angular/core';
import cssify from 'cssify';
cssify(require('./MdlTextfield.scss'));

@Directive({
    selector: '.mdl-textfield',
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Directive-decorator.html
 * @see http://getmdl.io/components/index.html#textfields-section
 * @example
 * <div class="mdl-textfield mdl-js-textfield">
    <input class="mdl-textfield__input" type="text" id="sample1">
    <label class="mdl-textfield__label" for="sample1">Text...</label>
  </div>
 */
export default class MdlTextfield {
    constructor(elementRef:ElementRef) {
        this._element = elementRef.nativeElement;
        this._element.addEventListener('mdl-componentupgraded', () => {
            const select = this._element.querySelector('select');
            if (select) {
                this._element.classList.add('is-dirty');
            }
        });
    }
}
