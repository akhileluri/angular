// This file was generated from the directive scaffold
// Copyright 2016

import {Component} from '@angular/core';
import MdlJs from './MdlJs';
import {
    inject,
    async,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [MdlJs],
    template: ''
})
class TestComponent {}

describe('mdl/MdlJs.js', () => {

    let materialWidgets:array = Object.keys(window).filter((key:string) => {
        return key.indexOf('Material') === 0;
    });

    materialWidgets.forEach((widget:string) => {
        if (widget === 'MaterialLayoutTab')
        {
            //TODO: follow up on this, but its not mdl-js-tabs
            return;
        }

        it(`should initialize ${widget}`, async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
            let name:string = widget.replace('Material','').toLowerCase();

            //some names are all lowercase (ie MaterialCheckBox -> mdl-js-checkbox) and others are not (ie MaterialDataTable -> mdl-js-data-table)
            switch(widget) {
                case 'MaterialIconToggle':
                    name = 'icon-toggle';
                    break;
                case 'MaterialDataTable':
                    name = 'data-table';
                    break;
                case 'MaterialRipple':
                    name = 'ripple-effect';
                    break;
            }

            let selector:string = `mdl-${name}`,
                template:string = `
                <label class="${selector} mdl-js-${name}">
                    <input class="mdl-checkbox__input mdl-radio__button mdl-switch__input mdl-icon-toggle__input"/>
                    <span class="mdl-snackbar__text"></span>
                    <span class="mdl-snackbar__action"></span>
                </label>`;
            //console.log(template);
            return tcb
                .overrideTemplate(TestComponent, template)
                .createAsync(TestComponent)
                .then((fixture:ComponentFixture) => {
                    fixture.detectChanges();
                    let mdl = fixture.nativeElement.querySelector(`.${selector}`);
                    //expect(mdl.outerHTML).toBe('not this');
                    expect(mdl.dataset.upgraded.includes(widget)).toBe(true);
                });
        })));

    });

});
