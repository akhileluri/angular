// This file was generated from the directive scaffold
// Copyright 2016

import {Component} from '@angular/core';
import MdlLayout from './MdlLayout';
import {
    inject,
    async,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [MdlLayout],
    template: ''
})
class TestComponent {}

xdescribe('mdl/MdlLayout.js', () => {

    it('should initialize default value', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<div mdlLayout></div>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('[mdlLayout]').classList.contains('mdlLayout')).toBe(false);
            });
    })));

    it('should initialize custom value', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<div mdlLayout="true"></div>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('[mdlLayout]').classList.contains('mdlLayout')).toBe(true);
            });
    })));

});
