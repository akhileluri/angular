// This file was generated from the directive scaffold
// Copyright 2016

import {Directive, ElementRef, Input} from '@angular/core';

@Directive({
    selector: '.mdl-progress',
})
/**
 * @see https://angular.io/docs/ts/latest/api/core/Directive-decorator.html
 * @example
 * <div [progress]="50" [buffer]="75" class="mdl-progress mdl-js-progress"></div>
 */
export default class MdlProgress {
    /**
     * The current progress value to show
     */
    @Input() progress:number = 0;

    /**
     * The current buffer value to show
     */
    @Input() buffer:number = 100;

    constructor(elementRef:ElementRef) {
        this.$element = elementRef.nativeElement;
        this.$element.addEventListener('mdl-componentupgraded', () => this.ngOnChanges());
    }

    ngOnChanges() {
        if (this.$element.MaterialProgress) {
            this.$element.MaterialProgress.setProgress(this.progress);
            this.$element.MaterialProgress.setBuffer(this.buffer);
        }
    }
}
