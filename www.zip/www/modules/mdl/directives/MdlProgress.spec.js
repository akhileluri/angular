// This file was generated from the directive scaffold
// Copyright 2016

import {Component} from '@angular/core';
import MdlProgress from './MdlProgress';
import MdlJs from './MdlJs';

import {
    inject,
    async,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [MdlProgress, MdlJs],
    template: ''
})
class TestComponent {
    progress:number = 50;
    buffer:number = 75;
}

describe('mdl/MdlProgress.js', () => {

    it('should initialize with static progress and buffer', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<div [progress]="50" [buffer]="75" class="mdl-progress mdl-js-progress"></div>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                let mdlprogress = fixture.nativeElement.querySelector('.mdl-progress');
                expect(mdlprogress.classList.contains('is-upgraded')).toBe(true);
                expect(mdlprogress.MaterialProgress).toBeDefined();
                expect(mdlprogress.querySelector('.progressbar').style.width).toBe('50%');
                expect(mdlprogress.querySelector('.bufferbar').style.width).toBe('75%');
            });
    })));

    it('should respond to changes to progress and buffer', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<div [progress]="progress" [buffer]="buffer" class="mdl-progress mdl-js-progress"></div>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.componentInstance.progress = 25;
                fixture.componentInstance.buffer = 90;
                fixture.detectChanges();
                let mdlprogress = fixture.nativeElement.querySelector('.mdl-progress');
                expect(mdlprogress.classList.contains('is-upgraded')).toBe(true);
                expect(mdlprogress.MaterialProgress).toBeDefined();
                expect(mdlprogress.querySelector('.progressbar').style.width).toBe('25%');
                expect(mdlprogress.querySelector('.bufferbar').style.width).toBe('90%');
            });
    })));

});
