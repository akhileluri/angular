// This file was generated from the directive scaffold
// Copyright 2016

import {Directive, ElementRef} from '@angular/core';
import {Router, Event, NavigationStart} from '@angular/router';

@Directive({
    selector: '.mdl-layout',
})
/**
 * @see http://getmdl.io/components/index.html#layout-section
 */
export default class MdlLayout {
    constructor(elementRef:ElementRef, router:Router) {
        this.$element = elementRef.nativeElement;
        this.$routeSubscription = router.events.subscribe(this.onRouteChange.bind(this));
    }

    ngOnDestroy() {
        this.$routeSubscription.unsubscribe();
    }

    get layout():any {
        return this.$element.MaterialLayout;
    }

    onRouteChange(event:Event) {
        if (event instanceof NavigationStart) {
            this.closeDrawer();
        }
    }

    toggleDrawer() {
        this.layout.toggleDrawer ? this.layout.toggleDrawer() : this.layout.drawerToggleHandler_();
    }

    closeDrawer() {
        if (this.isDrawerOpen) {
            this.toggleDrawer();
        }
    }

    openDrawer() {
        if (!this.isDrawerOpen) {
            this.toggleDrawer();
        }
    }

    get drawer():Element {
        return this.$element.querySelector('.mdl-layout__drawer');
    }

    get isDrawerOpen():boolean {
        const drawer = this.drawer;
        return drawer && drawer.classList.contains('is-visible');
    }
}
