// This file was generated from the directive scaffold
// Copyright 2016

import {Directive, ElementRef} from '@angular/core';
import 'material-design-lite/material';

@Directive({
    // selector: '[class*=mdl-js-]'//TODO: https://github.com/angular/angular/issues/6042
    selector: [
        '.mdl-js-button',
        '.mdl-js-ripple-effect',
        '.mdl-js-menu',
        '.mdl-js-slider',
        '.mdl-js-checkbox',
        '.mdl-js-data-table',
        '.mdl-js-progress',
        '.mdl-js-tabs',
        '.mdl-js-textfield',
        '.mdl-js-icon-toggle',
        '.mdl-js-radio',
        '.mdl-js-snackbar',
        '.mdl-js-spinner',
        '.mdl-js-switch',
        '.mdl-js-tooltip',
        '.mdl-js-layout',
        '.mdl-js-data-table',
    ].join(','),
})
/**
 * Automatically initializes all MDL components dyamically compiled and added to the application,
 */
export default class MdlJs {

    constructor(elementRef:ElementRef) {
        this.$element = elementRef.nativeElement;
    }

    ngAfterViewInit() {
        window.componentHandler.upgradeElement(this.$element);
    }

}
