// This file was generated from the directive scaffold
// Copyright 2016

import {Directive, ElementRef, EventEmitter} from '@angular/core';
import {Router, Event, NavigationStart} from '@angular/router';
import cssify from 'cssify';

cssify(require('./MdlTabs.scss'));

const change:EventEmitter = new EventEmitter();

@Directive({
    host: {
        '(click)': 'onClick($event)',
    },
    selector: '[routerLink].mdl-tabs__tab',
})
/**
 * A hook for mdl-tabs so that it will function correctly when a tabs
 * href is bound with a routeLink.
 *
 * @class MdlTabs
 * @see https://angular.io/docs/ts/latest/api/core/Directive-decorator.html
 * @example
 *
 <div class="mdl-tabs__tab-bar">
     <a [routerLink]="['Charts']" class="mdl-tabs__tab">
     <i class="material-icons">insert_chart</i>Charts
     </a>
     <a [routerLink]="['Comparison']" class="mdl-tabs__tab">
     <i class="material-icons">compare_arrows</i>Comparison
     </a>
     <a [routerLink]="['Spreadsheet']" class="mdl-tabs__tab">
     <i class="material-icons">view_list</i>Spreadsheet
     </a>
 </div>
 */
export default class MdlTabs {

    constructor(elementRef:ElementRef, router:Router) {
        this._location = router.location;
        this._element = elementRef.nativeElement;
        this._subscriptions = [
            router.events.subscribe(this.onRouterEvent),
            change.subscribe(this.onLocationChange),
        ];
    }

    ngOnInit() {
        this.onLocationChange();
    }

    ngOnDestroy() {
        this._subscriptions.forEach((s) => s.unsubscribe());
    }

    onClick(e:Event) {
        // prevent click from getting to parent mdl-tabs and causing error since this is a route link
        e.stopImmediatePropagation();
        e.stopPropagation();
        change.emit();
    }

    onRouterEvent(event:Event) {
        if (event instanceof NavigationStart) {
            this.onLocationChange();
        }
    }

    onLocationChange = () => {
        const path = this._location.path();
        let href = this._element.attributes.getNamedItem('href').value;
        if (href.charAt(0) === '#') {
            href = href.substr(1);
        }
        if (path.indexOf(href) === 0) {
            this._element.classList.add('is-active');
        }
        else {
            this._element.classList.remove('is-active');
        }
    }

}
