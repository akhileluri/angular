// This file was generated from the directive scaffold
// Copyright 2016

import {Component} from '@angular/core';
import MdlTextfield from './MdlTextfield';
import MdlJs from './MdlJs';
import {
    inject,
    async,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [MdlTextfield, MdlJs],
    template: ''
})
class TestComponent {}

describe('mdl/MdlTextfield.js', () => {

    it('should initialize textfield', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<div class="mdl-textfield mdl-js-textfield">
    <input class="mdl-textfield__input" type="text" id="sample1">
    <label class="mdl-textfield__label" for="sample1">Text...</label>
  </div>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                let mdltextfield = fixture.nativeElement.querySelector('.mdl-textfield');
                expect(mdltextfield.classList.contains('is-upgraded')).toBe(true);
            });
    })));

});
