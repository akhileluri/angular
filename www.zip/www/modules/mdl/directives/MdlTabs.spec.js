// This file was generated from the directive scaffold
// Copyright 2016

import {Component} from '@angular/core';
import MdlTabs from './MdlTabs';
import MdlJs from './MdlJs';

import {
    inject,
    async,
    TestComponentBuilder,
    ComponentFixture
} from '@angular/core/testing';

@Component({
    selector: 'test-component',
    directives: [MdlTabs,MdlJs],
    template: ''
})
class TestComponent {}

describe('mdl/MdlTabs.js', () => {

    xit('should initialize prevent default clicks on route links', async(inject([TestComponentBuilder], (tcb:TestComponentBuilder) => {
        return tcb
            .overrideTemplate(TestComponent, `<div class="mdl-tabs__tab-bar">
     <a [routerLink]="['Charts']" class="mdl-tabs__tab">
     <i class="material-icons">insert_chart</i>Charts
     </a>
     <a [routerLink]="['Comparison']" class="mdl-tabs__tab">
     <i class="material-icons">compare_arrows</i>Comparison
     </a>
     <a [routerLink]="['Spreadsheet']" class="mdl-tabs__tab">
     <i class="material-icons">view_list</i>Spreadsheet
     </a>
 </div>`)
            .createAsync(TestComponent)
            .then((fixture:ComponentFixture) => {
                fixture.detectChanges();
                expect(fixture.nativeElement.querySelector('[mdlTabs]').classList.contains('mdlTabs')).toBe(false);
            });
    })));

});
